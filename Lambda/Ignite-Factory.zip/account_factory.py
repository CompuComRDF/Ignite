import boto3
import time
import uuid
import util
import config
import datetime
from time import sleep
from botocore.exceptions import ClientError


# ============================================================
#               MAIN ENTRYPOINT: CREATE ACCOUNT
# ============================================================

def provision_product(account_name, account_email, organization_unit_name, principal_arn, central_account_id):

    sc = boto3.client('servicecatalog')

    # 1. Get portfolio
    portfolio_id = get_portfolio_id(sc)
    if portfolio_id is None:
        util.logger("ERROR: Portfolio ID not found.")
        return None

    # 2. Get product
    product_id = get_product_id(sc, portfolio_id)
    if product_id is None:
        util.logger("ERROR: Product ID not found.")
        return None

    # 3. Get provisioning artifact
    artifact_id = get_provisioning_artifact_id(sc, product_id)
    if artifact_id is None:
        util.logger("ERROR: Provisioning artifact not found.")
        return None

    # 4. Ensure portfolio principal association
    associate_principal_portfolio(sc, principal_arn, portfolio_id)

    # 5. Build SC parameters
    params = [
        {'Key': 'SSOUserEmail', 'Value': config.sso_user_email},
        {'Key': 'SSOUserFirstName', 'Value': config.sso_user_first_name},
        {'Key': 'SSOUserLastName', 'Value': config.sso_user_last_name},
        {'Key': 'ManagedOrganizationalUnit', 'Value': organization_unit_name},
        {'Key': 'AccountName', 'Value': account_name},
        {'Key': 'AccountEmail', 'Value': account_email},
    ]

    util.logger(f"PROVISIONING PRODUCT FOR: {account_name}")

    # 6. Provision Product
    try:
        response = sc.provision_product(
            ProductId=product_id,
            ProvisioningArtifactId=artifact_id,
            ProvisionedProductName=account_name,
            ProvisioningParameters=params,
            ProvisionToken=str(uuid.uuid4())
        )
    except Exception as e:
        util.logger(f"Provision product exception: {str(e)}")
        return None

    # Extract provisioning record ID
    record_id = response["RecordDetail"]["RecordId"]

    # 7. Wait for provisioning to complete
    status = wait_for_provisioning(sc, record_id)

    if status != "SUCCEEDED":
        util.logger(f"Provisioning failed with status: {status}")
        return None

    util.logger("SERVICE CATALOG CREATE ACCOUNT SUCCEEDED!")

    # 8. Wait for AWS Organizations to register the account
    account_id = get_account_id_by_email(account_email)

    if not account_id:
        util.logger("ERROR: Account ID not found in AWS Organizations.")
        return None

    util.logger(f"ACCOUNT CREATED: {account_id}")

    # 9. IAM Setup — wait for IAM services inside the new account to become ready
    role_credentials = wait_for_iam_ready(account_id)

    iam = boto3.client(
        'iam',
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN']
    )

    assume_policy = config.assume_role_policy_document.replace('<ACCOUNT_ID>', central_account_id)

    # Create role + attach AdminAccess
    util.create_role(iam, "Ignite-Client", "Cross Account Role used by Ignite Central Account", assume_policy)
    policy_arn = util.get_policy_arn(iam, "AdministratorAccess")
    util.attach_permission_policy(iam, "Ignite-Client", policy_arn)

    return account_id


# ============================================================
#                  WAIT FOR SERVICE CATALOG
# ============================================================

def wait_for_provisioning(sc_client, record_id, timeout_minutes=45):
    """
    Wait for Service Catalog provisioning through DescribeRecord.
    """
    util.logger(f"Waiting for Service Catalog provisioning of record {record_id}...")

    timeout = time.time() + timeout_minutes * 60

    while time.time() < timeout:
        try:
            resp = sc_client.describe_record(Id=record_id)
        except Exception as e:
            util.logger(f"DescribeRecord error: {str(e)}")
            sleep(10)
            continue

        status = resp["RecordDetail"]["Status"]
        util.logger(f"Provisioning status: {status}")

        if status in ("SUCCEEDED", "FAILED"):
            return status

        sleep(30)

    return "TIMED_OUT"


# ============================================================
#            GET ACCOUNT ID FROM AWS ORGANIZATIONS
# ============================================================

def get_account_id_by_email(account_email, timeout_minutes=45):
    """
    Poll AWS Organizations until the new account email appears.
    """
    org = boto3.client('organizations')
    timeout = time.time() + timeout_minutes * 60

    util.logger(f"Waiting for account email to appear in AWS Organizations: {account_email}")

    while time.time() < timeout:

        try:
            paginator = org.get_paginator("list_accounts")
            for page in paginator.paginate():
                for acct in page["Accounts"]:
                    if acct['Email'].lower() == account_email.lower():
                        util.logger(f"Found account ID: {acct['Id']}")
                        return acct['Id']

        except ClientError as e:
            util.logger(f"Organizations error: {str(e)}")

        util.logger("Account not visible yet. Waiting 20s...")
        sleep(20)

    return None


# ============================================================
#                 WAIT FOR IAM READY IN NEW ACCOUNT
# ============================================================

def wait_for_iam_ready(account_id, max_attempts=20):
    """
    Some new accounts take minutes before IAM/STSes are ready.
    """
    util.logger(f"Waiting for IAM to initialize in account {account_id}...")

    for attempt in range(1, max_attempts + 1):
        try:
            creds = util.assume_role(account_id)
            util.logger("IAM is ready.")
            return creds
        except Exception as e:
            util.logger(f"IAM not ready (attempt {attempt}/{max_attempts}): {str(e)}")
            sleep(30)

    raise Exception("IAM never became ready in the new account")


# ============================================================
#                      PORTFOLIO LOOKUP
# ============================================================

def get_portfolio_id(sc_client):
    try:
        portfolios = sc_client.list_portfolios(AcceptLanguage='en', PageSize=20)

        for p in portfolios["PortfolioDetails"]:
            if p["DisplayName"] == "AWS Control Tower Account Factory Portfolio":
                util.logger(f"portfolio_id: {p['Id']}")
                return p["Id"]

    except Exception as e:
        util.logger(f"get_portfolio_id EXCEPTION: {str(e)}")

    return None


# ============================================================
#                   PRODUCT LOOKUP
# ============================================================

def get_product_id(sc_client, portfolio_id):
    try:
        response = sc_client.search_products_as_admin(
            PortfolioId=portfolio_id,
            ProductSource='ACCOUNT'
        )

        for p in response["ProductViewDetails"]:
            if p["ProductViewSummary"]["Name"] == "AWS Control Tower Account Factory":
                util.logger(f"product_id: {p['ProductViewSummary']['ProductId']}")
                return p["ProductViewSummary"]["ProductId"]

    except Exception as e:
        util.logger(f"get_product_id EXCEPTION: {str(e)}")

    return None


# ============================================================
#           PROVISIONING ARTIFACT (VERSION) LOOKUP
# ============================================================

def get_provisioning_artifact_id(sc_client, product_id):
    try:
        resp = sc_client.describe_product_as_admin(Id=product_id)
        summary = resp["ProvisioningArtifactSummaries"]
        latest = summary[-1]["Id"]

        util.logger(f"prov_artifact_id: {latest}")
        return latest

    except Exception as e:
        util.logger(f"get_provisioning_artifact_id EXCEPTION: {str(e)}")

    return None


# ============================================================
#        PORTFOLIO PRINCIPAL ASSOCIATION CHECK/CREATE
# ============================================================

def associate_principal_portfolio(sc_client, principal_arn, portfolio_id):

    # list existing principals
    principals = []
    paginator = sc_client.get_paginator('list_principals_for_portfolio')

    for page in paginator.paginate(PortfolioId=portfolio_id):
        principals.extend(page["Principals"])

    existing_arns = [p['PrincipalARN'] for p in principals]

    if principal_arn in existing_arns:
        util.logger("Principal already associated.")
        return True

    try:
        sc_client.associate_principal_with_portfolio(
            PortfolioId=portfolio_id,
            PrincipalARN=principal_arn,
            PrincipalType='IAM'
        )
        util.logger("Associated principal → sleeping 10 seconds.")
        sleep(10)
        return True

    except Exception as e:
        util.logger(f"Unable to associate principal: {str(e)}")
        return False

