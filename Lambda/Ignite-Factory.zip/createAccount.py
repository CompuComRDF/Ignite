import json
import boto3
import botocore
import time
import sys
import os

def lambda_handler(event, context):
    print(event)
    client = get_client('organizations')
    tenantName = os.environ['tenantName'] #change this to read fromm SNS Event
    emailDomain = os.environ['emailDomain']
    oganizationUnitList = ["Development","UAT","Production"]
    if(not tenantName or not tenantEmail):
        print('#####   PARAMETER VALUES ARE MISSING    #####')

    try:
        listRoots= client.list_roots()
        rootId = listRoots['Roots'][0]['Id']
    except:
        rootId = "Error"

    if rootId is not "Error":
        for organizationUnitName in oganizationUnitList:
            accountName = tenantName + "-" + organizationUnitName
            accountEmail = tenantName + "-" + organizationUnitName + "@" + emailDomain
            print("Creating new account: " + accountName + " with Email: " + accountEmail)

            organizationUnitId = get_ou_id(rootId,organizationUnitName)
            accountId = create_account(accountName,accountEmail,rootId,organizationUnitId)
            print("Created " + organizationUnitName + " account:{}\n".format(accountId))
        
    else:
        print("#####   Cannot access the AWS Organization ROOT. Contact the master account Administrator for more details.    #####")

    return {
        'statusCode': 200,
    }

def get_client(service):
    client = boto3.client(service)
    return client

def create_account(accountName,accountEmail,rootId,organizationUnitId):
    accountId = 'None'
    client = get_client('organizations')
    
    try:
        print("Trying to create the account with {}".format(accountEmail))
        create_account_response = client.create_account(Email=accountEmail, AccountName=accountName,
                                                        #RoleName=,
                                                        IamUserAccessToBilling="DENY")
        time.sleep(40)
        accountStatus = client.describe_create_account_status(CreateAccountRequestId=create_account_response['CreateAccountStatus']['Id'])

        while(accountStatus['CreateAccountStatus']['State'] is 'IN_PROGRESS'):
            print(accountStatus['CreateAccountStatus']['State'])
            time.sleep(40)
        else:    
            print("Account Creation status: {}".format(accountStatus['CreateAccountStatus']['State']))
            
        if(accountStatus['CreateAccountStatus']['State'] == 'FAILED'):
            print("Account Creation Failed. Reason : {}".format(accountStatus['CreateAccountStatus']['FailureReason']))
            sys.exit(1)

    except botocore.exceptions.ClientError as e:
        print("#####   In the except module. Error : {}".format(e) + "    #####")
        
    time.sleep(10)
    create_account_status_response = client.describe_create_account_status(CreateAccountRequestId=create_account_response.get('CreateAccountStatus').get('Id'))
    accountId = create_account_status_response.get('CreateAccountStatus').get('AccountId')
    while(accountId is "None" ):
        create_account_status_response = client.describe_create_account_status(CreateAccountRequestId=create_account_response.get('CreateAccountStatus').get('Id'))
        accountId = create_account_status_response.get('CreateAccountStatus').get('AccountId')
        time.sleep(10)
        
    client.move_account(AccountId=accountId,SourceParentId=rootId,DestinationParentId=organizationUnitId)

    return accountId

def get_ou_id(root_id,organization_unit_name):

    ou_client = get_client('organizations')
    list_of_OU_ids = []
    list_of_OU_names = []
    ou_name_to_id = {}

    list_of_OUs_response = ou_client.list_organizational_units_for_parent(ParentId=root_id)
    
    for i in list_of_OUs_response['OrganizationalUnits']:
        list_of_OU_ids.append(i['Id'])
        list_of_OU_names.append(i['Name'])
        
    if(organization_unit_name not in list_of_OU_names):
        print("The provided Organization Unit Name doesnt exist. Creating an OU named: {}".format(organization_unit_name))
        try:
            ou_creation_response = ou_client.create_organizational_unit(ParentId=root_id,Name=organization_unit_name)
            for k,v in ou_creation_response.items():
                for k1,v1 in v.items():
                    if(k1 == 'Name'):
                        organization_unit_name = v1
                    if(k1 == 'Id'):
                        organization_unit_id = v1
        except botocore.exceptions.ClientError as e:
            print("Error in creating the OU: {}".format(e))
    else:
        for i in range(len(list_of_OU_names)):
            ou_name_to_id[list_of_OU_names[i]] = list_of_OU_ids[i]
        organization_unit_id = ou_name_to_id[organization_unit_name]
    
    return organization_unit_id
