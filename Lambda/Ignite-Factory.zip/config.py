#import boto3
#AWS_ACCOUNT_ID = boto3.client('sts').get_caller_identity()["Account"]
#principal_arn = 'arn:aws:iam::' + AWS_ACCOUNT_ID + ':role/service-role/Ignite-Server-role-q9wctqx7'

sso_user_email='julius.malixi@compucom.com'
sso_user_first_name='Julius'
sso_user_last_name='Malixi'

assume_role_policy_document = '{\
    "Version": "2012-10-17",\
    "Statement": [\
        {\
            "Effect": "Allow",\
            "Principal": {\
                "AWS": "arn:aws:iam::<ACCOUNT_ID>:root"\
            },\
            "Action": "sts:AssumeRole",\
            "Condition": {}\
        }\
    ]\
}'
