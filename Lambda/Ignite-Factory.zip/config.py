import json

principal_arn = 'arn:aws:iam::762125257137:role/service-role/Ignite-Server-role-q9wctqx7'
sso_user_email='julius.malixi@compucom.com'
sso_user_first_name='Julius'
sso_user_last_name='Malixi'
    
KEY_ID = ''
ACCESS_KEY = ''
TOKEN = ''
    
setup_files = {'Lambda/Ignite-Client.zip':False,
            'Lambda/Ignite-RDF.zip':False,
            'Lambda/ConnectKVS2Audio.zip':False,
            'Lambda/kvs_Converter.zip':False,
            'ContactFlows/Connect-RDF-Agent':False,
            'ContactFlows/Connect-RDF-Main':False,
            'ContactFlows/Connect-RDF-Outbound':False,
            'ContactFlows/Connect-RDF-Queue':False,
            'ContactFlows/Connect-RDF-Whisper':False,
            'ContactFlows/Default customer whisper':False,
            'IVR/config/config.csv':False,
            'IVR/config/ivr-callflow.csv':False,
            'IVR/config/ivr-holidays.csv':False,
            'IVR/config/ivr-sysadmin.csv':False,
            'IVR/config/ivr-tts.csv':False,
            'IVR/config/sysadmin-callflow.csv':False,
            'IVR/config/voicemail.csv':False,
            'IVR/prompts/ivr/en-US/vmaillatency.wav':False,
            'IVR/prompts/ivr/en-US/TechDificulties.wav':False,
            'IVR/prompts/ivr/en-US/silence30s.wav':False,
            'IVR/prompts/ivr/en-US/Music_Jazz_MyTimetoFly_Inst_60s.wav':False,
            'IVR/prompts/ivr/en-US/Music_Jazz_MyTimetoFly_Inst_150s.wav':False,
            'IVR/prompts/ivr/en-US/goodbye.wav':False,
            'IVR/prompts/ivr/en-US/InvalidInput1.wav':False,
            'IVR/prompts/ivr/en-US/InvalidInput2.wav':False,
            'IVR/prompts/ivr/en-US/NoInput1.wav':False,
            'IVR/prompts/ivr/en-US/NoInput2.wav':False,
            'IVR/prompts/ivr/en-US/MaxInput.wav':False,
            'IVR/prompts/ivr/en-US/MaxInputXfer.wav':False,
            'IVR/prompts/ivr/en-US/repeat.wav':False,
            'IVR/prompts/ivr/fr-CA/vmaillatency.wav':False,
            'IVR/prompts/ivr/fr-CA/TechDificulties.wav':False,
            'IVR/prompts/ivr/fr-CA/silence30s.wav':False,
            'IVR/prompts/ivr/fr-CA/Music_Jazz_MyTimetoFly_Inst_60s.wav':False,
            'IVR/prompts/ivr/fr-CA/Music_Jazz_MyTimetoFly_Inst_150s.wav':False,
            'IVR/prompts/ivr/fr-CA/goodbye.wav':False,
            'IVR/prompts/ivr/fr-CA/InvalidInput1.wav':False,
            'IVR/prompts/ivr/fr-CA/InvalidInput2.wav':False,
            'IVR/prompts/ivr/fr-CA/NoInput1.wav':False,
            'IVR/prompts/ivr/fr-CA/NoInput2.wav':False,
            'IVR/prompts/ivr/fr-CA/MaxInput.wav':False,
            'IVR/prompts/ivr/fr-CA/MaxInputXfer.wav':False,
            'IVR/prompts/ivr/fr-CA/repeat.wav':False,
            'IVR/prompts/ivr/es-MX/vmaillatency.wav':False,
            'IVR/prompts/ivr/es-MX/TechDificulties.wav':False,
            'IVR/prompts/ivr/es-MX/silence30s.wav':False,
            'IVR/prompts/ivr/es-MX/Music_Jazz_MyTimetoFly_Inst_60s.wav':False,
            'IVR/prompts/ivr/es-MX/Music_Jazz_MyTimetoFly_Inst_150s.wav':False,
            'IVR/prompts/ivr/pt-BR/vmaillatency.wav':False,
            'IVR/prompts/ivr/pt-BR/TechDificulties.wav':False,
            'IVR/prompts/ivr/pt-BR/silence30s.wav':False,
            'IVR/prompts/ivr/pt-BR/Music_Jazz_MyTimetoFly_Inst_60s.wav':False,
            'IVR/prompts/ivr/pt-BR/Music_Jazz_MyTimetoFly_Inst_150s.wav':False
    }

assume_role_policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Principal": {
                    "Service": "lambda.amazonaws.com"
                },
                "Action": "sts:AssumeRole"
            }
        ]
    }

s3_central_bucket_policy = '{\
   "Version":"2012-10-17",\
   "Statement":[\
      {\
         "Effect":"Allow",\
         "Principal":{\
            "AWS":"arn:aws:iam::762125257137:role/service-role/Ignite-Server-role-q9wctqx7"\
         },\
         "Action":[\
            "s3:GetObject",\
            "s3:PutObject",\
            "s3:DeleteObject",\
            "s3:PutObjectAcl"\
         ],\
         "Resource":"arn:aws:s3:::<S3BUCKETNAME>/*"\
      }\
   ]\
}'