import json
import boto3
import util

def create_role(role_name, description):
    iam_client = boto3.client('iam',
        aws_access_key_id=config.KEY_ID,
        aws_secret_access_key=config.ACCESS_KEY,
        aws_session_token=config.TOKEN)
        
    response = iam_client.create_role(
        Path='/',
        RoleName=role_name,
        AssumeRolePolicyDocument=config.assume_role_policy,
        Description=description,
        #MaxSessionDuration=123,
        #PermissionsBoundary='string',
        #Tags=[
        #    {
        #        'Key': 'string',
        #        'Value': 'string'
        #    },
        #]
    ) 

def get_policy_arn(iam_policy_name):
    iam_client = boto3.client('iam',
        aws_access_key_id=config.KEY_ID,
        aws_secret_access_key=config.ACCESS_KEY,
        aws_session_token=config.TOKEN)

    iam_policy_arn = 'None'
    list_permission_policies = []
    list_permission_arns = []
    list_permission_names = []
    permissions_name_to_arn = {}

    try:
        list_of_permissions_response = iam_client.list_policies(
            Scope='All',
            OnlyAttached=False,
            PathPrefix='/',
            PolicyUsageFilter='PermissionsPolicy',
            MaxItems=100
        )

        list_permission_policies = list_of_permissions_response['Policies']
        
        while "Marker" in list_of_permissions_response:
                list_of_permissions_response = iam_client.list_policies(
                Scope='All',
                OnlyAttached=False,
                PathPrefix='/',
                PolicyUsageFilter='PermissionsPolicy',
                Marker=list_of_permissions_response['Marker'],
                MaxItems=100
            )
            
            list_permission_policies.extend(list_of_permissions_response['Policies'])

        for permission_policy in list_permission_policies:
            list_permission_arns.append(permission_policy['Arn'])
            list_permission_names.append(permission_policy['PolicyName'])

        for i in range(len(list_permission_names)):
            permissions_name_to_arn[list_permission_names[i]] = list_permission_arns[i]

        iam_policy_arn = permissions_name_to_arn[iam_policy_name]

    return(iam_policy_arn)
    
def attach_permission_policy(role_name, policy_arn):
    iam_client = boto3.client('iam',
        aws_access_key_id=config.KEY_ID,
        aws_secret_access_key=config.ACCESS_KEY,
        aws_session_token=config.TOKEN)

    response = iam_client.attach_role_policy(
        RoleName=role_name,
        PolicyArn=policy_arn
    )