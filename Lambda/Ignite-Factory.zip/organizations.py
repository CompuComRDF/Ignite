import json
import boto3
import time
import sys
import config

def get_ou_id(org_client, root_id, organization_unit_name):

    list_of_OU_ids = []
    list_of_OU_names = []
    ou_name_to_id = {}

    try:
        list_of_OUs_response = org_client.list_organizational_units_for_parent(ParentId=root_id)
        
        for ou in list_of_OUs_response['OrganizationalUnits']:
            list_of_OU_ids.append(ou['Id'])
            list_of_OU_names.append(ou['Name'])
            
        if(organization_unit_name not in list_of_OU_names):
            logger("CREATING OU: {}".format(organization_unit_name))
            try:
                ou_creation_response = org_client.create_organizational_unit(ParentId=root_id,Name=organization_unit_name)
                for k,v in ou_creation_response.items():
                    for k1,v1 in v.items():
                        if(k1 == 'Name'):
                            organization_unit_name = v1
                        if(k1 == 'Id'):
                            organization_unit_id = v1
            #except botocore.exceptions.ClientError as e:
            except Exception as Ex1:
                logger("ERROR CREATING OU: {}".format(Ex1))
        else:
            logger("EXISTING OU: {}".format(organization_unit_name))
            for i in range(len(list_of_OU_names)):
                ou_name_to_id[list_of_OU_names[i]] = list_of_OU_ids[i]
            organization_unit_id = ou_name_to_id[organization_unit_name]
    except Exception as Ex1:
        logger("get_ou_id EXCEPTION: " + str(Ex1))
        
    return organization_unit_id

def get_account_id(org_client, account_name, account_email, root_id, organization_unit_id, organization_unit_name):

    account_id = "None"
    list_accounts = []
    list_account_ids = []
    list_account_names = []
    account_name_to_id = {}

    try:
        list_of_accounts_response = org_client.list_accounts(
            #MaxResults=50
        )
    
        list_accounts = list_of_accounts_response['Accounts']
        
        while "NextToken" in list_of_accounts_response:
            list_of_accounts_response = org_client.client.list_accounts(
                MaxResults=100,
                NextToken=list_of_accounts_response['NextToken']
            )
            list_accounts.extend(list_of_accounts_response['Accounts'])
                
        for account in list_accounts:
            list_account_ids.append(account['Id'])
            list_account_names.append(account['Name'])
            
        if(account_name not in list_account_names):
            logger("CREATING ACCOUNT: {}".format(account_name))
            try:
                account_id = create_account(org_client,account_name,account_email,root_id,organization_unit_id, organization_unit_name)
            #except botocore.exceptions.ClientError as e:
            except Exception as Ex1:
                logger("ERROR CREATING ACCOUNT: {}".format(Ex1))
        else:
            logger("EXISTING ACCOUNT: {}".format(account_name) + "  OU: {}".format(organization_unit_name))
            for i in range(len(list_account_names)):
                account_name_to_id[list_account_names[i]] = list_account_ids[i]
            account_id = account_name_to_id[account_name]

    except Exception as Ex1:
        logger("get_account_id EXCEPTION: " + str(Ex1))
    
    return account_id

def create_account(org_client, account_name, account_email, root_id, organization_unit_id, organization_unit_name):
    account_id = 'None'

    try:
        create_account_response = org_client.create_account(Email=account_email, AccountName=account_name,
                                                        #RoleName=,
                                                        IamUserAccessToBilling="DENY")
        logger("ACCOUNT CREATION STARTED")
        time.sleep(10)
        account_status = org_client.describe_create_account_status(CreateAccountRequestId=create_account_response['CreateAccountStatus']['Id'])

        while(account_status['CreateAccountStatus']['State'] == 'IN_PROGRESS'):
            logger(account_status['CreateAccountStatus']['State'])
            time.sleep(10)
        else:    
            logger("ACCOUNT CREATION STATUS: {}".format(account_status['CreateAccountStatus']['State']))
            
        if(account_status['CreateAccountStatus']['State'] == 'FAILED'):
            logger("ACCOUNT CREATION FAILED: {}".format(account_status['CreateAccountStatus']['FailureReason']))
            sys.exit(1)

    except Exception as Ex1:
        logger("create_account EXCEPTION: {}".format(Ex1))
        
    time.sleep(10)
    create_account_status_response = org_client.describe_create_account_status(CreateAccountRequestId=create_account_response.get('CreateAccountStatus').get('Id'))
    account_id = create_account_status_response.get('CreateAccountStatus').get('AccountId')
    while(account_id == "None" ):
        logger("WAITING FOR ACCOUNT ID")
        create_account_status_response = org_client.describe_create_account_status(CreateAccountRequestId=create_account_response.get('CreateAccountStatus').get('Id'))
        account_id = create_account_status_response.get('CreateAccountStatus').get('AccountId')
        time.sleep(10)
        
    logger("ACCOUNT CREATION COMPLETED: {}".format(account_id))        

    org_client.move_account(AccountId=account_id, SourceParentId=root_id, DestinationParentId=organization_unit_id)
    logger("MOVING ACCOUNT TO OU: {}".format(organization_unit_name))

    return account_id
