import json
import boto3
import time
import sys
import config

def logger(message):
    print("#####   " + message + "    #####")

def assume_role(account_id):
    logger("ASSUMING AWSControlTowerAdmin ROLE OF ACCOUNT: " + account_id)
    sts_client = boto3.client('sts')
    sts_session = sts_client.assume_role(RoleArn='arn:aws:iam::' + account_id + ':role/AWSControlTowerExecution',
                                      RoleSessionName='initialization-session')
    
    config.KEY_ID = sts_session['Credentials']['AccessKeyId']
    config.ACCESS_KEY = sts_session['Credentials']['SecretAccessKey']
    config.TOKEN = sts_session['Credentials']['SessionToken']
    logger("ASSUMED ROLE AWSControlTowerAdmin SUCCESSFULLY: {}" + format(config.KEY_ID))


def check_function_exists(function_name):
    function_found = False
    
    list_of_lambdas_response = lambda_client.list_functions(
        MaxItems=100
    )

    list_lambdas = list_of_lambdas_response['Functions']
    
    while "Marker" in list_of_lambdas_response:
        list_of_lambdas_response = lambda_client.list_functions(
            Marker=list_of_lambdas_response['Marker'],
            MaxItems=100
        )
        
        list_lambdas.extend(list_of_lambdas_response['Functions'])
    
    if function_name in list_lambdas:
        function_found = True
    
    return(function_found)

