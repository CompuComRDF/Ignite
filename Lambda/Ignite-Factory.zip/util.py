import boto3
import sys
from time import sleep

def logger(message):
    print("#####   " + message + "    #####")

def assume_role(account_id):
    logger("ASSUMING AWSControlTowerExecution ROLE OF ACCOUNT: " + account_id)

    role_credentials = {}

    wait_counter = 0
    sts_client = boto3.client('sts')
    while(wait_counter <= 3):
        try:
            sts_session = sts_client.assume_role(RoleArn='arn:aws:iam::' + account_id + ':role/AWSControlTowerExecution',
                                            RoleSessionName='initialization-session')
            
            role_credentials['KEY_ID'] = sts_session['Credentials']['AccessKeyId']
            role_credentials['ACCESS_KEY'] = sts_session['Credentials']['SecretAccessKey']
            role_credentials['TOKEN'] = sts_session['Credentials']['SessionToken']
            logger("ASSUMED ROLE AWSControlTowerExecution SUCCESSFULLY: {}" + format(role_credentials['KEY_ID']))
            break
        except Exception as Ex1:
            logger('WAITING FOR ACCOUNT SERVICES TO BE READY: ' + str(Ex1))
            wait_counter += 1
            sleep(30)
            pass
    else:
        logger("UNABLE TO ASSUME ROLE AWSControlTowerExecution.  PLEASE TRY AGAIN.")
        sys.exit(1)
    
    return(role_credentials)

def create_role(iam_client, role_name, description, assume_role_policy):
    logger('CREATING IAM ROLE: ' + role_name)
    try:
        found_role = False
        list_roles_response = iam_client.list_roles()

        list_roles = list_roles_response['Roles']
        
        while "Marker" in list_roles_response:
            list_roles_response = iam_client.list_roles(
                Marker=list_roles_response['Marker'],
            )
            
            list_roles.extend(list_roles_response['Roles'])

        for role in list_roles:
            if role_name in role['RoleName']:
                found_role = True
                result = role['Arn']

        if not found_role:
            create_iam_role_response = iam_client.create_role(
                Path='/',
                RoleName=role_name,
                AssumeRolePolicyDocument=assume_role_policy,
                Description=description,
            )
            result = create_iam_role_response['Role']['Arn'] 
        else:
            logger("IAM ROLE ALREADY EXISTS " + result)

    except Exception as Ex1:
        result = 'None'
        logger("create_role EXCEPTION: " + str(Ex1))

    return(result)

def get_policy_arn(iam_client, iam_policy_name):
    logger('GETTING IAM POLICY ARN: ' + iam_policy_name)
    iam_policy_arn = 'None'
    list_permission_policies = []
    list_permission_arns = []
    list_permission_names = []
    permissions_name_to_arn = {}

    try:
        list_of_permissions_response = iam_client.list_policies(
            Scope='All',
            OnlyAttached=False,
            PathPrefix='/',
            PolicyUsageFilter='PermissionsPolicy',
            MaxItems=100
        )

        list_permission_policies = list_of_permissions_response['Policies']
        
        while "Marker" in list_of_permissions_response:
            list_of_permissions_response = iam_client.list_policies(
                Scope='All',
                OnlyAttached=False,
                PathPrefix='/',
                PolicyUsageFilter='PermissionsPolicy',
                Marker=list_of_permissions_response['Marker'],
                MaxItems=100
            )
            
            list_permission_policies.extend(list_of_permissions_response['Policies'])

        for permission_policy in list_permission_policies:
            list_permission_arns.append(permission_policy['Arn'])
            list_permission_names.append(permission_policy['PolicyName'])

        for i in range(len(list_permission_names)):
            permissions_name_to_arn[list_permission_names[i]] = list_permission_arns[i]

        iam_policy_arn = permissions_name_to_arn[iam_policy_name]
    except Exception as Ex1:
        logger("get_policy_arn EXCEPTION: " + str(Ex1))
        
    return(iam_policy_arn)
    
def attach_permission_policy(iam_client, role_name, policy_arn):
    logger('ATTACHING IAM POLICY ARN: ' + policy_arn + ' TO ROLE: ' + role_name)
    try:
        iam_client.attach_role_policy(
            RoleName=role_name,
            PolicyArn=policy_arn
        )
    except Exception as Ex1:
        logger("attach_permission_policy EXCEPTION: " + str(Ex1))