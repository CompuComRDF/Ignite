def logger(message):
    print("#####   " + message + "    #####")
