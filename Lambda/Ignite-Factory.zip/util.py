import boto3
import sys
from time import sleep

def logger(message):
    print("#####   " + message + "    #####")

def assume_role(account_id):
    logger("ASSUMING AWSControlTowerExecution ROLE OF ACCOUNT: " + account_id)

    role_credentials = {}

    wait_counter = 0
    sts_client = boto3.client('sts')
    while(wait_counter <= 3):
        try:
            sts_session = sts_client.assume_role(RoleArn='arn:aws:iam::' + account_id + ':role/AWSControlTowerExecution',
                                            RoleSessionName='initialization-session')
            
            role_credentials['KEY_ID'] = sts_session['Credentials']['AccessKeyId']
            role_credentials['ACCESS_KEY'] = sts_session['Credentials']['SecretAccessKey']
            role_credentials['TOKEN'] = sts_session['Credentials']['SessionToken']
            logger("ASSUMED ROLE AWSControlTowerExecution SUCCESSFULLY: {}" + format(role_credentials['KEY_ID']))
            break
        except Exception as Ex1:
            logger('WAITING FOR ACCOUNT SERVICES TO BE READY: ' + str(Ex1))
            wait_counter += 1
            sleep(30)
            pass
    else:
        logger("UNABLE TO ASSUME ROLE AWSControlTowerExecution.  PLEASE TRY AGAIN.")
        sys.exit(1)
    
    return(role_credentials)

def create_role(role_credentials, role_name, description, assume_role_policy):
    logger('CREATING IAM ROLE: ' + role_name)
    iam_client = boto3.client('iam',
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])   
    
    try:
        found_role = False
        list_roles_response = iam_client.list_roles()

        list_roles = list_roles_response['Roles']
        
        while "Marker" in list_roles_response:
            list_roles_response = iam_client.list_roles(
                Marker=list_roles_response['Marker'],
            )
            
            list_roles.extend(list_roles_response['Roles'])

        for role in list_roles:
            if role_name in role['RoleName']:
                found_role = True
                result = role['Arn']

        if not found_role:
            create_iam_role_response = iam_client.create_role(
                Path='/',
                RoleName=role_name,
                AssumeRolePolicyDocument=assume_role_policy,
                Description=description,
            )
            result = create_iam_role_response['Role']['Arn'] 
        else:
            logger("IAM ROLE ALREADY EXISTS " + result)

    except Exception as Ex1:
        result = 'None'
        logger("create_role EXCEPTION: " + str(Ex1))

    return(result)