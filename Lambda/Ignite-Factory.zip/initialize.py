import json
import boto3
import util
import config
import account_factory
import organizations
from github import Github
import base64

def get_central_account(organization_type, organization_name, email_domain):
    #AWS ORGANIZATION TYPE need to figure out how to assume the correct role.
    if organization_type == 'AWS':
        org_client = boto3.client('organizations')
        
        try:
            roots_list = org_client.list_roots()
            root_id = roots_list['Roots'][0]['Id']
        except Exception as Ex1:
            root_id = "Error"
            util.logger("get_central_account EXCEPTION: " + str(Ex1))
    
        if root_id != "Error":
        
           organization_unit_id = organizations.get_ou_id(org_client, root_id, organization_unit_name)
           account_id = organizations.get_account_id(org_client, account_name, account_email, root_id, organization_unit_id, organization_unit_name)
        else:
            util.logger("CAN NOT ACCESS THE AWS ORGANIZATION ROOT. CONTACT THE MASTER ACCOUNT ADMINISTRATOR.")        

    elif organization_type == 'LZ':
        try:
            account_name = organization_name + '-Central'
            organization_unit_name = 'Shared Services'            
    
            if '@' not in email_domain:
                account_email = account_name + "-" + organization_unit_name.lower().replace(" ", "") + "@" + email_domain
            else:
                account_email = email_domain
                
            util.logger('USING ACCOUNT EMAIL ADDRESS: ' + account_email)
            
            account_id = account_factory.get_account_id(account_name)
            
            if account_id == 'None':
                account_id = account_factory.provision_product(account_name, account_email, organization_unit_name)
            else:
                util.logger('IGNITE CENTRAL ACCOUNT: ' + account_name + ' ALREADY EXISTS.')
            
            if account_id != 'None': 
                util.assume_role(account_id)
                # Create Instances DB table in Central Account for DEV, UAT, and PROD
                get_instances_table()
            
                # Create Central Account S3 Bucket to download Setup Files from GitHub
                bucket_name = get_s3_bucket(account_id, account_name)
                list_s3_obects = get_s3_bucket_objects(bucket_name)
            #
            #    # Create Ignite-Client lambda function on Central Account
            #    get_ignite_client(bucket_name, list_s3_obects)
            #
            #    # Add permissions to Ignite-Client lambda function to invoke Ignite-Server
            #    add_lambda_invoke_permissions(account_name, account_id)
            #
            #    # Create Ignite-RDF lambda function on Central Account
            #    get_ignite_rdf(bucket_name, list_s3_obects)
            
        except Exception as Ex1:
            util.logger("get_central_account EXCEPTION: " + str(Ex1))
    else:
        util.logger("INVALID ORGANIZATION TYPE")
        
def get_instances_table():
    db_client = boto3.client('dynamodb',
        aws_access_key_id=config.KEY_ID,
        aws_secret_access_key=config.ACCESS_KEY,
        aws_session_token=config.TOKEN)
    
    organizational_units = ['DEV','UAT','PROD']

    for ou in organizational_units:
        table_name = 'Instances-' + ou
        list_table_names = []

        try: 
            list_of_tables_response = db_client.list_tables(
                Limit=100
            )
        
            list_table_names = list_of_tables_response['TableNames']
            
            while "LastEvaluatedTableName" in list_of_tables_response:
                list_of_tables_response = db_client.client.list_tables(
                    ExclusiveStartTableName=list_of_tables_response['LastEvaluatedTableName'],
                    Limit=100
                )
                list_table_names.extend(list_of_tables_response['TableNames'])

            if(table_name not in list_table_names):
                util.logger("CREATING DYNAMODB TABLE: {}".format(table_name))
            
                response = db_client.create_table(
                    AttributeDefinitions=[
                        {
                            'AttributeName': 'Tenant',
                            'AttributeType': 'S'
                        }                
                    ],
                    TableName=table_name,
                    KeySchema=[
                        {
                            'AttributeName': 'Tenant',
                            'KeyType': 'HASH'
                        },
                    ],
                    ProvisionedThroughput={
                        'ReadCapacityUnits': 5,
                        'WriteCapacityUnits': 5
                    },
                    SSESpecification={
                        'Enabled': True,
                        'SSEType': 'KMS'
                        #'KMSMasterKeyId': 'string'
                    },
                    TableClass='STANDARD',
                    DeletionProtectionEnabled=True
                )        
            else:
                util.logger("EXISTING DYNAMODB TABLE: " + table_name)
        except Exception as Ex1:
            util.logger("get_instances_table EXCEPTION: " + str(Ex1))
            
def get_s3_bucket(account_id, account_name):
    s3_client = boto3.client('s3',
        aws_access_key_id=config.KEY_ID,
        aws_secret_access_key=config.ACCESS_KEY,
        aws_session_token=config.TOKEN)

    bucket_name = account_name.lower() + '-ignite'
    bucket_exists = False
    list_of_s3_buckets_response = s3_client.list_buckets()

    for bucket in list_of_s3_buckets_response['Buckets']:
        if bucket_name == bucket['Name']:
            util.logger("EXISTING S3 BUCKET: " + bucket_name)
            bucket_exists = True
            location = "/" + bucket['Name']
            
    if not bucket_exists:
        util.logger("CREATING S3 BUCKET: " + bucket_name)

        try:
            create_s3_bucket_response = s3_client.create_bucket(
                Bucket=bucket_name,
                CreateBucketConfiguration={
                    'LocationConstraint': 'ca-central-1'
                }
            )        

            s3_bucket_policy = config.s3_central_bucket_policy.replace('<S3BUCKETNAME>',bucket_name)
            util.logger("Updating S3 Bucket Resource Policy: " + s3_bucket_policy)
            
            s3_bucket_policy_response = s3_client.put_bucket_policy(
                Bucket=bucket_name,
                Policy=s3_bucket_policy
            )
            
        except Exception as Ex1:
            util.logger("get_s3_bucket EXCEPTION: " + str(Ex1))
        
    return(bucket_name)

def get_s3_bucket_objects(bucket_name):
    s3_client = boto3.client('s3',
        aws_access_key_id=config.KEY_ID,
        aws_secret_access_key=config.ACCESS_KEY,
        aws_session_token=config.TOKEN)

    file_list = config.setup_files

    try:
        s3_bucket_objects_response = s3_client.list_objects(
            Bucket=bucket_name,
            MaxKeys=100
        )

        list_s3_objects = []
        
        if "Contents" in s3_bucket_objects_response:
            list_s3_objects = s3_bucket_objects_response['Contents']

            #while "NextMarker" in s3_bucket_objects_response:
            while s3_bucket_objects_response['IsTruncated']:
                s3_bucket_objects_response = s3_client.list_objects(
                    Marker=s3_bucket_objects_response['NextMarker'],
                    MaxItems=100,
                )
                
                list_s3_objects.extend(s3_bucket_objects_response['Contents'])
            
        for file in file_list:
        	for s3_object in list_s3_objects:
        		if s3_object["Key"] == file:
        			file_list[file] = True

        g = Github('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')
        repo = g.get_repo('CompuComRDF/Ignite')
        #branches = repo.get_branches()
        #for branch in branches:
        #    print(branch.name)        
    
        for file in file_list:
            if not file_list[file]:
                util.logger("UPLOADING FILE TO S3: " + file)
                copy_files_from_github_to_s3(repo, bucket_name, file)
            else:
                util.logger("FILE ALREADY EXISTS IN S3: " + file)

        g.close()
        
    except Exception as Ex1:
        util.logger("get_s3_bucket_objects EXCEPTION: " + str(Ex1))

    return(list_s3_objects)
    
def copy_files_from_github_to_s3(repo, bucket_name, filename):
    try:
        contents = repo.get_contents(filename)
        decoded = contents.decoded_content
        #contents = repo.get_contents(urllib.parse.quote(filename)).content
        #decoded = base64.b64decode(content_encoded)

    except Exception as Ex1:
        util.logger("FILE LARGER THAN 1 MB: " + filename)
        decoded = get_blob_content(repo, filename)        
        pass
    
    s3_resource = boto3.resource('s3')
    s3_resource.Object(bucket_name, filename).put(Body=decoded)

def get_blob_content(repo, filename):
    # first get the branch reference
    branch = "main"
    ref = repo.get_git_ref(f'heads/{branch}')
    # then get the tree
    tree = repo.get_git_tree(ref.object.sha, recursive='/' in filename).tree
    # look for path in tree
    sha = [x.sha for x in tree if x.path == filename]
    if not sha:
        # well, not found..
        return None
    # we have sha
    blob = repo.get_git_blob(sha[0])
    b64 = base64.b64decode(blob.content)
    
    return b64
    
def get_ignite_client(bucket_name, list_s3_obects):
    lambda_client = boto3.client('lambda',
        aws_access_key_id=config.KEY_ID,
        aws_secret_access_key=config.ACCESS_KEY,
        aws_session_token=config.TOKEN)

    function_name = 'Ignite-Client'
    if not util.check_function_exists(function_name):
        try:
            for s3_object in list_s3_obects:
                if s3_object["Key"] == function_name + '.zip':
                    s3_file_name = s3_object["Key"]
                    s3_file_size = s3_object["Size"]

            ignite_client_role = 'Ignite-Client-role'
            permissions_to_attach = ['AmazonDynamoDBFullAccess','AmazonConnect_FullAccess','AmazonS3FullAccess','AWSLambda_FullAccess']
            iam.create_role(ignite_client_role, 'IAM Role for Ignite-Client lambda function')
            for permission in permissions_to_attach:
                iam.attach_permission_policy(ignite_client_role, get_policy_arn(permission))

            response = lambda_client.create_function(
                FunctionName='Ignite-Client',
                Runtime='python3.12',
                Role=ignite_client_role,
                Handler='lambda_function.lambda_handler',
                Code={
                    'ZipFile': b(s3_file_size),
                    'S3Bucket': bucket_name,
                    'S3Key': s3_file_name,
                    #'S3ObjectVersion': 'string',
                    #'ImageUri': 'string'
                },
                #Description='string',
                Timeout=600,
                MemorySize=1024,
                Publish=True,
                PackageType='Zip',
                #DeadLetterConfig={
                #    'TargetArn': 'string'
                #},
                #Environment={
                #    'Variables': {
                #        'string': 'string'
                #    }
                #},
                #KMSKeyArn='string',
                #TracingConfig={
                #    'Mode': 'Active'|'PassThrough'
                #},
                #Tags={
                #    'string': 'string'
                #},
                #Layers=[
                #    'string',
                #],
                #FileSystemConfigs=[
                #    {
                #        'Arn': 'string',
                #        'LocalMountPath': 'string'
                #    },
                #],
                #CodeSigningConfigArn='string',
                Architectures=[
                    'x86_64',
                ]
                #EphemeralStorage={
                #    'Size': 123
                #},
                #SnapStart={
                #    'ApplyOn': 'PublishedVersions'|'None'
                #},
                #LoggingConfig={
                #    'LogFormat': 'JSON',
                #    'ApplicationLogLevel': 'TRACE'|'DEBUG'|'INFO'|'WARN'|'ERROR'|'FATAL',
                #    'SystemLogLevel': 'DEBUG'|'INFO'|'WARN',
                #    'LogGroup': 'string'
                #}
            )

        except Exception as Ex1:
            util.logger("get_ignite_client EXCEPTION: " + str(Ex1))
    else:
        util.logger("FUNCTION ALREADY EXISTS: " + function_name)        

def get_ignite_rdf(bucket_name, list_s3_obects):
    lambda_client = boto3.client('lambda',
        aws_access_key_id=config.KEY_ID,
        aws_secret_access_key=config.ACCESS_KEY,
        aws_session_token=config.TOKEN)

    function_name = 'Ignite-RDF'
    if not util.check_function_exists(function_name):
        try:
            for s3_object in list_s3_obects:
                if s3_object["Key"] == function_name + '.zip':
                    s3_file_name = s3_object["Key"]
                    s3_file_size = s3_object["Size"]

            rdf_client_role = 'Ignite-RDF-role'
            permissions_to_attach = ['AmazonDynamoDBFullAccess','AmazonConnect_FullAccess','AmazonS3FullAccess']
            iam.create_role(rdf_client_role, 'IAM Role for Ignite-RDF lambda function')
            for permission in permissions_to_attach:
                iam.attach_permission_policy(ignite_client_role, get_policy_arn(permission))

            response = lambda_client.create_function(
                FunctionName='Ignite-RDF',
                Runtime='python3.9',
                Role=rdf_client_role,
                Handler='lambda_function.lambda_handler',
                Code={
                    'ZipFile': b(s3_file_size),
                    'S3Bucket': bucket_name,
                    'S3Key': s3_file_name,
                    #'S3ObjectVersion': 'string',
                    #'ImageUri': 'string'
                },
                #Description='string',
                Timeout=8,
                MemorySize=1024,
                Publish=True,
                PackageType='Zip',
                #DeadLetterConfig={
                #    'TargetArn': 'string'
                #},
                Environment={
                    'Variables': {
                        'TRACE_MODE': 'PROD'
                    }
                },
                #KMSKeyArn='string',
                #TracingConfig={
                #    'Mode': 'Active'|'PassThrough'
                #},
                #Tags={
                #    'string': 'string'
                #},
                #Layers=[
                #    'string',
                #],
                #FileSystemConfigs=[
                #    {
                #        'Arn': 'string',
                #        'LocalMountPath': 'string'
                #    },
                #],
                #CodeSigningConfigArn='string',
                Architectures=[
                    'x86_64',
                ]
                #EphemeralStorage={
                #    'Size': 123
                #},
                #SnapStart={
                #    'ApplyOn': 'PublishedVersions'|'None'
                #},
                #LoggingConfig={
                #    'LogFormat': 'JSON',
                #    'ApplicationLogLevel': 'TRACE'|'DEBUG'|'INFO'|'WARN'|'ERROR'|'FATAL',
                #    'SystemLogLevel': 'DEBUG'|'INFO'|'WARN',
                #    'LogGroup': 'string'
                #}
            )

        except Exception as Ex1:
            util.logger("get_ignite_rdf EXCEPTION: " + str(Ex1))
    else:
        util.logger("FUNCTION ALREADY EXISTS: " + function_name) 
        
def add_lambda_invoke_permissions(account_name, account_id):
    lambda_client = boto3.client('lambda')
    response = lambda_client.add_permission(
        FunctionName='Ignite-Server',
        StatementId=account_name,
        Action='lambda:InvokeFunction',
        Principal='arn:aws:iam::' + account_id + ':role/service-role/AWSControlTowerAdmin',
        SourceArn='string',
        SourceAccount='string',
        EventSourceToken='string',
        Qualifier='string',
        RevisionId='string',
        PrincipalOrgID='string',
        FunctionUrlAuthType='NONE'|'AWS_IAM'
    )
