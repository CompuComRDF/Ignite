import json
import initialize
import client
import util

def lambda_handler(event, context):
    print(event)

    if (event['request']=='Initialize'):
        if(not event['OrganizationName'] or not event['EmailDomain']):
            util.logger('IGNITE INITIALIZATION - Parameter values are missing.')
        else:
            organization_type = event['OrganizationType'] # LZ or 
            organization_name = event['OrganizationName']
            email_domain = event['EmailDomain']
            util.logger('IGNITE INITIALIZATION STARTING for: ' + organization_name)
            initialize.get_central_account(organization_type, organization_name, email_domain)

    elif (event['request']=='CreateInstance'):
        if(not event['TenantName'] or not event['EmailDomain']):
            util.logger('IGNITE CREATE INSTANCE - Parameter values are missing.')
        else:
            tenant_name = event['TenantName']
            email_domain = event['EmailDomain']
            util.logger('IGNITE CREATING INSTANCE for: ' + tenant_name)
            client.create_instance(organization_name, tenant_name, email_domain)
    else:
        util.logger('IGNITE INITIALIZATION - Missing Request.')
        
    return {
        'statusCode': 200,
    }
