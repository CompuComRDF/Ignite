import json
import account_factory
import util
import os

def lambda_handler(event, context):
    print(event)

    if('AccountName' not in event or 'AccountEmail' not in event or 'OrganizationUnitName' not in event or 'PrincipalARN' not in event):
        util.logger('IGNITE FACTORY - Parameter values are missing.')
    else:
        account_name = event['AccountName'] 
        account_email = event['AccountEmail']
        ou = event['OrganizationUnitName']
        organization_unit_name = os.environ.get(ou, ou)

        principal_arn = event['PrincipalARN']
        if 'CentralAccountID' in event:
            central_account_id = event['CentralAccountID']
        else:
            central_account_id = ''
        util.logger('CREATING ACCOUNT: ' + account_name)
        account_id = account_factory.provision_product(account_name, account_email, organization_unit_name, principal_arn, central_account_id)
      
    return {
        'accountID': account_id,
        'statusCode': 200,
    }
