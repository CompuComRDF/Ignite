#import boto3
#AWS_ACCOUNT_ID = boto3.client('sts').get_caller_identity()["Account"]
#principal_arn = 'arn:aws:iam::' + AWS_ACCOUNT_ID + ':role/service-role/Ignite-Server-role-q9wctqx7'

sso_user_email='julius.malixi@compucom.com'
sso_user_first_name='Julius'
sso_user_last_name='Malixi'
