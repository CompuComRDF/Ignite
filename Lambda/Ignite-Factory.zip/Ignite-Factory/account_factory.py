import json
import boto3
import util
import config
from random import randint
from time import sleep
import datetime

def provision_product(account_name, account_email, organization_unit_name, principal_arn):      
    account_id = 'None'    
    sc_client=boto3.client('servicecatalog')

    portfolio_id = get_portfolio_id(sc_client)

    if not portfolio_id == 'None':
        #(product_id, prov_artifact_id) = get_product_info(sc_client, portfolio_id)
        product_id = get_product_info(sc_client, portfolio_id)
        
        if not product_id == 'None':
            prov_artifact_id = get_provisioning_artifact_id(sc_client, product_id)
            
            if not prov_artifact_id == 'None':
                associate_principal_portfolio(sc_client, principal_arn, portfolio_id)
                params = [
                    {'Value': config.sso_user_email, 'Key': 'SSOUserEmail'},
                    {'Value': config.sso_user_first_name, 'Key': 'SSOUserFirstName'},
                    {'Value': config.sso_user_last_name, 'Key': 'SSOUserLastName'},
                    {'Value': organization_unit_name, 'Key': 'ManagedOrganizationalUnit'},
                    {'Value': account_name, 'Key': 'AccountName'},
                    {'Value': account_email, 'Key': 'AccountEmail'}
                    ]                

                util.logger('PROVISIONING PRODUCT FOR: ' + account_name)
                try:
                    output = sc_client.provision_product(
                        ProductId=product_id,
                        ProvisioningArtifactId=prov_artifact_id,
                        ProvisionedProductName=account_name,
                        ProvisioningParameters=params,
                        ProvisionToken=str(randint(1000000000000, 9999999999999))
                        )
                    result = output['RecordDetail']['ProvisionedProductId']
                except Exception as Ex1:
                    util.logger("provision_product EXCEPTION: " + str(Ex1))
                    result = str(Ex1)

                if result.startswith('pp-'):
                    pp_id = result
                    status = get_pp_status(sc_client, pp_id)
                    iteration = 1
                    #if status == 'UNDER_CHANGE':
                    #    put_metric_data(iteration, 'CENTRAL')
                        
                    while iteration <= 3:
                        if status != 'UNDER_CHANGE':
                            iteration = 4
                        else:
                            util.logger('Iteration-' + str(iteration) + ': ' + status)
                            sleep(30)
                            status = get_pp_status(sc_client, pp_id)
                        iteration += 1
                        
                    account_id = get_account_id(account_name)
                    
                    if account_id != 'None':
                        util.logger('ACCOUNT ID CREATED: ' + account_id)
                    else:
                        util.logger('ACCOUNT ID NOT FOUND')
                        
                else:
                    util.logger('SC Product Launch Failed: ' + str(params))
            
    return account_id

def get_portfolio_id(sc_client):
    portfolio_id = 'None'
    list_portfolios = []
    list_portfolio_ids = []
    list_portfolio_names = []
    portfolio_name_to_id = {}

    try:    
        portfolios_response = sc_client.list_portfolios(
            AcceptLanguage='en',
            PageSize=10
        )
        
        util.logger('List of portfolios: ' + str(portfolios_response))
        list_portfolios = portfolios_response['PortfolioDetails']

        while "PageToken" in portfolios_response:
            portfolios_response = sc_client.list_portfolios(
                AcceptLanguage='en',
                PageToken=portfolios_response['PageToken'],
                PageSize=10
            )
            list_portfolios.extend(portfolios_response['PortfolioDetails'])
 
        for portfolio in list_portfolios:
            list_portfolio_ids.append(portfolio['Id'])
            list_portfolio_names.append(portfolio['DisplayName'])
            
        for i in range(len(list_portfolios)):
            portfolio_name_to_id[list_portfolio_names[i]] = list_portfolio_ids[i]
        portfolio_id = portfolio_name_to_id['AWS Control Tower Account Factory Portfolio']    
    except Exception as Ex1:
        util.logger("get_portfolio_id EXCEPTION: " + str(Ex1))

    util.logger("portfolio_id: " + str(portfolio_id))        
    return portfolio_id

def get_product_info(sc_client, portfolio_id):
    product_id = 'None'
    prov_artifact_id = 'None'
    list_products = []
    list_product_ids = []
    list_product_names = []
    product_name_to_id = {}

    try:    
        products_response = sc_client.search_products_as_admin(
            AcceptLanguage='en',
            PortfolioId=portfolio_id,
            PageSize=10,
            ProductSource='ACCOUNT'
        )

        list_products = products_response['ProductViewDetails']
        #util.logger("List Products: " + str(list_products))
        
        while "NextPageToken" in products_response:
            products_response = sc_client.search_products_as_admin(
                AcceptLanguage='en',
                PortfolioId=portfolio_id,
                PageSize=10,
                PageToken=products_response['NextPageToken'],
                ProductSource='ACCOUNT'
            )
            list_products.extend(products_response['ProductViewDetails'])

        for product in list_products:
            list_product_ids.append(product['ProductViewSummary']['ProductId'])
            list_product_names.append(product['ProductViewSummary']['Name'])
            
        for i in range(len(list_products)):
            #product_name_to_id[list_product_names[i['Name']]] = list_product_ids[i]['Id']
            product_name_to_id[list_product_names[i]] = list_product_ids[i]
        product_id = product_name_to_id['AWS Control Tower Account Factory']    

    except Exception as Ex1:
        util.logger("get_product_info EXCEPTION: " + str(Ex1))

    util.logger("product_id: " + str(product_id)) 

    return (product_id)

def get_provisioning_artifact_id(sc_client, prod_id):
    ''' Query for Provisioned Artifact Id '''

    pa_list = list()
    prov_artifact_id = 'None'

    try:
        pa_list = sc_client.describe_product_as_admin(
            Id=prod_id)['ProvisioningArtifactSummaries']
    except Exception as exe:
        util.logger("Unable to find the Provisioned Artifact Id: " + str(exe))

    if len(pa_list) > 0:
        prov_artifact_id = pa_list[-1]['Id']
    else:
        util.logger("Unable to find the Provisioned Artifact Id: " + str(pa_list))

    util.logger("prov_artifact_id: " + str(prov_artifact_id))
    
    return prov_artifact_id
    
def get_account_id(account_name):
    #util.assume_role('762125257137')
    org_client = boto3.client('organizations')
    
    account_id = "None"
    list_accounts = []
    list_account_ids = []
    list_account_names = []
    account_name_to_id = {}

    try:
        list_of_accounts_response = org_client.list_accounts(
            #MaxResults=50
        )
    
        list_accounts = list_of_accounts_response['Accounts']
        
        while "NextToken" in list_of_accounts_response:
            list_of_accounts_response = org_client.list_accounts(
                #MaxResults=100,
                NextToken=list_of_accounts_response['NextToken']
            )
            list_accounts.extend(list_of_accounts_response['Accounts'])
                
        for account in list_accounts:
            list_account_ids.append(account['Id'])
            list_account_names.append(account['Name'])
            
        for i in range(len(list_account_names)):
            account_name_to_id[list_account_names[i]] = list_account_ids[i]
        
        if account_name in list_account_names:
            account_id = account_name_to_id[account_name]

    except Exception as Ex1:
        util.logger("get_account_id EXCEPTION: " + str(Ex1))
    
    return account_id

def list_principals_in_portfolio(sc_client, port_id):
    '''List all prinicpals associated with a portfolio'''

    pri_info = list()
    pri_list = list()

    try:
        sc_paginator = sc_client.get_paginator('list_principals_for_portfolio')
        sc_page_iterator = sc_paginator.paginate(PortfolioId=port_id)
    except Exception as exe:
        util.logger('Unable to get prinicpals list: ' + str(exe))

    for page in sc_page_iterator:
        pri_list += page['Principals']

    for item in pri_list:
        pri_info.append(item['PrincipalARN'])
    util.logger('list_principals: ' + str(pri_info))
    
    return pri_info


def associate_principal_portfolio(sc_client, principal, port_id):
    '''Associate a pricipal to portfolio if doesn't exist'''

    result = True
    pri_list = list_principals_in_portfolio(sc_client, port_id)

    if principal not in pri_list:
        try:
            result = sc_client.associate_principal_with_portfolio(
                PortfolioId=port_id, PrincipalARN=principal,
                PrincipalType='IAM')
            util.logger('Associated ' + principal + 'to ' + port_id + '. Sleeping ' + str(SLEEP) + ' secs.')
            sleep(SLEEP)
        except Exception as Ex1:
            util.logger('Unable to associate a principal: ' + str(Ex1))
            result = False

    return result

def get_pp_status(sc_client, pp_id):
    '''Return the provisioned product state and error message (if any)'''

    status = None
    message = None

    try:
        result = sc_client.describe_provisioned_product(
            Id=pp_id)['ProvisionedProductDetail']
        status = result['Status']
        if 'StatusMessage' in result:
            message = result['StatusMessage']
    except Exception as Ex1:
        util.logger("Unable to get provisioned product status: " + str(Ex1))

    return status

def put_metric_data(iteration, account_type):
    wait_time  = datetime.datetime.now() + datetime.timedelta(0,60)
    
    cw_client = boto3.client('cloudwatch')
    cw_client.put_metric_data(
    Namespace='IGNITE',
    MetricData=[
        {
            'MetricName': 'IGNITE',
            'Dimensions': [
                {
                    'Name': 'PROVISION_ACCOUNT',
                    'Value': account_type
                },
            ],
            'Timestamp': wait_time,
            'Value': iteration,
            'Unit': 'Count'
        },
    ]
)    
