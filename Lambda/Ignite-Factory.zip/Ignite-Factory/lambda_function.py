import json
import account_factory
import util

def lambda_handler(event, context):
    print(event)

    if(not event['AccountName'] or not event['AccountEmail'] or not event['OrganizationUnitName'] or not event['PrincipalARN']):
        util.logger('IGNITE FACTORY - Parameter values are missing.')
    else:
        account_name = event['AccountName'] 
        account_email = event['AccountEmail']
        organization_unit_name = event['OrganizationUnitName']
        principal_arn = event['PrincipalARN']
        util.logger('CREATING ACCOUNT: ' + account_name)
        account_factory.provision_product(account_name, account_email, organization_unit_name, principal_arn)
      
    return {
        'statusCode': 200,
    }
