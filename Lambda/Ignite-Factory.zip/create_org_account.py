import boto3
import time

org_client = boto3.client("organizations")

def create_account_and_move(account_name, account_email, ou_id):
    """
    Create a new AWS account and move it into a target OU.
    """

    print(f"Creating account: {account_name} ({account_email})...")
    create_response = org_client.create_account(
        Email=account_email,
        AccountName=account_name,
        IamUserAccessToBilling="DENY"  # or 'ALLOW' if you want IAM users to access billing
    )
    request_id = create_response["CreateAccountStatus"]["Id"]

    # Wait for account creation to complete
    print("Waiting for account creation to complete...")
    while True:
        status_response = org_client.describe_create_account_status(
            CreateAccountRequestId=request_id
        )
        status = status_response["CreateAccountStatus"]["State"]

        if status in ["IN_PROGRESS", "PENDING"]:
            time.sleep(10)
            continue
        elif status == "SUCCEEDED":
            account_id = status_response["CreateAccountStatus"]["AccountId"]
            print(f"Account created successfully: {account_id}")
            break
        else:
            reason = status_response["CreateAccountStatus"].get("FailureReason", "Unknown")
            raise Exception(f"Account creation failed: {reason}")

    # Move the account to the target OU
    # First, find its current parent (usually the root)
    parents = org_client.list_parents(ChildId=account_id)
    current_parent_id = parents["Parents"][0]["Id"]

    if current_parent_id != ou_id:
        print(f"Moving account {account_id} from {current_parent_id} → {ou_id}...")
        org_client.move_account(
            AccountId=account_id,
            SourceParentId=current_parent_id,
            DestinationParentId=ou_id
        )
        print("Account moved successfully.")
    else:
        print("Account already in the target OU.")

    return account_id

# Example usage:
if __name__ == "__main__":
    new_account_id = create_account_and_move(
        account_name="ExampleDevAccount",
        account_email="example-dev-account+aws@example.com",
        ou_id="ou-abcd-12345678"  # Replace with your target OU ID
    )
    print(f"✅ Finished: New account ID is {new_account_id}")
