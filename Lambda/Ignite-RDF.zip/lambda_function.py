import json
import boto3

def lambda_handler(event, context):
    print(event)
    import util
    import config
    import queues

    statusCode = 200
    channel = event['Details']['ContactData']['Channel']
    config.instanceARN = event['Details']['ContactData']['InstanceARN']
    instanceDetails = config.instanceARN.split(":")
    config.region = instanceDetails[3]
    instanceARNindex = (instanceDetails[5].find('/')+1)
    config.instanceID = instanceDetails[5][instanceARNindex:]
    config.s3BucketName = "amazon-connect-" + instanceDetails[5][instanceARNindex:]
    config.account = instanceDetails[4]
    config.contactID = event['Details']['ContactData']['InitialContactId']
    config.ou = event['Details']['ContactData']['Attributes']['RDF'].split(':')[7].upper()

    if 'TASK' not in channel: 
        config.dnis = event['Details']['ContactData']['SystemEndpoint']['Address'][1:]
        config.ani = event['Details']['ContactData']['CustomerEndpoint']['Address'][1:]
    
    function = event['Details']['Parameters']['function']

    try:
        session = json.loads(event['Details']['Parameters']['session'])
        config.tenant = session['tenant']
        config.queueID = session['queueID']
        config.holidayFile = session['holidayFile']
        config.tenantHoliday = session['tenantHoliday']
        config.sysAdminFile = session['sysAdminFile']
        config.globalMenuRepeat = session['globalMenuRepeat']
        config.globalMenuPrevious = session['globalMenuPrevious']
        config.globalZeroPrompt = session['globalZeroPrompt']
        config.globalInputTerm = session['globalInputTerm']
        config.speechAnalytics = session['speechAnalytics']
        config.chatAnalytics = session['chatAnalytics']
    except Exception as ex1:
        session = {}
        if function=='initialize' and channel =='VOICE':
            print('#####   START CALL FOR DNIS: ' + config.dnis + ' ANI: ' + config.ani  + ' CONTACTID: ' + config.contactID + ' ENV: ' + config.ou + '   #####')
        elif function=='initialize' and channel =='TASK':
            function = channel.lower()
            print('#####   START TASK FOR  ANI: ' + config.ani + ' CONTACTID: ' + config.contactID + ' ENV: ' + config.ou + '   #####')
        elif function=='queue':
            print('#####   START QUEUE FOR ANI: ' + config.ani + ' CONTACTID: ' + config.contactID + ' ENV: ' + config.ou + '   #####')
            s3Client = boto3.client('s3', config.region)
            try:
                tmpFile = 'tmp/' + config.contactID + '.tmp'
                response = s3Client.get_object(Bucket=config.s3BucketName, Key=tmpFile)
                session = json.loads(response['Body'].read().decode('utf-8'))
                response = s3Client.delete_object(
                    Bucket=config.s3BucketName,
                    Key=tmpFile
                )
            except:
                print('#####   ERROR READING SESSION   #####')
                pass
        elif function=='agent':
            print('#####   START AGENT TO QUEUE TRANSFER: ' + config.ani + ' CONTACTID: ' + config.contactID + ' ENV: ' + config.ou + '   #####')
        else:
            print('#####   ERROR IN APPLICATION FOR DNIS: ' + config.dnis + ' CONTACTID: ' + config.contactID + ' ENV: ' + config.ou + '   #####')
            print(ex1)
            return exception_handler(config.techDifficulties['appFailure'] + str(ex1))

    try:
        config.businessHours = session['businessHours']
    except:
        config.businessHours = False

    session['dnis'] = config.dnis
    session['function'] = function
    session['contactID'] = config.contactID

    if function in ['initialize', 'queue', 'agent', 'task']:
        if function == "queue":
            session['blockType']="INITQ"
            session['loopCounter']=0
        elif function == "initialize":
            session['blockType']="INIT"
    
        session['initialize']=True    
        session['subIndex'] = 0
        session['contactDisposition'] = ""
        session['agentTip'] = ""
        session['userData'] = ""
        session['menuTracker']=[]
        session['menuIndex'] = 0
        session['menuRepeat']=False
        session['queueTracker']=[]
        session['queueIndex'] = 0

        if 'TASK' not in channel:
            session['DNIS'] = event['Details']['ContactData']['SystemEndpoint']['Address'][1:]

        try:
            jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, 'config.csv', 'KEY')
        
            for x in jsonContent:
                session[jsonContent[x]['KEY']]=jsonContent[x]['VALUE'] #Use session to persist data
        
            jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, 'queues.csv', 'KEY')
        
            config.tenant = session['tenant']
            config.queueID = jsonContent[session['defaultQueue']]['VALUE']
            config.holidayFile = session['holidayFile']
            session['tenantHoliday'] = session['holidayFile']
            config.tenantHoliday = session['tenantHoliday']
            session['queueID']=jsonContent[session['defaultQueue']]['VALUE']
            session['queue']=session['defaultQueue']
            session['language']=event['Details']['ContactData']['LanguageCode']
            config.language = session['language']

            if function=='initialize':
                print('#####   TENANT APPLICATION: ' + config.tenant.upper() + ' CONTACTID: ' + config.contactID + '   #####') 

            if function=='queue':
                if channel == 'TASK':
                    session['queue']=event['Details']['ContactData']['Attributes']['QUEUE']
                else:
                    session['queue']=event['Details']['ContactData']['Queue']['Name']
                import queues
                session = queues.setQueue(session)

            if function=='agent':
                session['initialize'] = False    
                session['fileName'] = session['callFlow']
                session['queue']=event['Details']['ContactData']['Queue']['Name']
                print('#####   AGENT TO QUEUE APPLICATION. TRANSFERING TO QUEUE: ' + session['queue'] + ' CONTACTID: ' + config.contactID + '   #####') 
                import queues
                session = queues.setQueue(session)
                client = queues.connectClient(config.region, config.account)
                response = client.update_contact_attributes(
                    InitialContactId=config.contactID,
                    InstanceId=config.instanceID,
                    Attributes={
                        'callFlowID': session['globalMaxtriesAction'] 
                    }
                )
            
            if function=='task':
                import queues
                session['initialize'] = False    
                session['fileName'] = session['callFlow']
                client = queues.connectClient(config.region, config.account)
                response = client.get_contact_attributes(
                    InstanceId=config.instanceID,
                    InitialContactId=config.contactID
                )
                #session['queue']=event['Details']['ContactData']['Queue']['Name']
                session['queue']=response['Attributes']['QUEUE']
                session['vmQueueName'] = response['Attributes']['VMQUEUE']
                print('#####   TASK TO QUEUE: ' + session['queue'] + ' CONTACTID: ' + config.contactID + '   #####') 
                session = queues.setQueue(session)

            try:
                config.sysAdminFile = session['sysAdminFile']
            except:
                session['sysAdminFile'] = ''
            
            try:
                config.globalMenuRepeat = session['globalMenuRepeat']
            except:
                session['globalMenuRepeat'] = ''
            
            try:
                config.globalMenuPrevious = session['globalMenuPrevious']
            except:
                session['globalMenuPrevious'] = ''
            
            try:
                config.globalZeroPrompt = session['globalZeroPrompt']
                if config.globalZeroPrompt:
                    session['businessHours'] = queues.checkBusinessHours()
                    config.businessHours = session['businessHours']
            except:
                session['globalZeroPrompt'] = ''
            
            try:
                config.globalInputTerm = session['globalInputTerm']
            except:
                session['globalInputTerm'] = ''
            
            try:
                config.speechAnalytics = session['speechAnalytics']
            except:
                session['speechAnalytics'] = 'off'
            
            try:
                config.chatAnalytics = session['chatAnalytics']
            except:
                session['chatAnalytics'] = 'off'

        except Exception as ex1:
            print('#####   INITIALIZATION FAILURE: ' + str(ex1) + ' DNIS: ' + config.dnis + ' CONTACTID: ' + config.contactID + ' ENV: ' + config.ou + '   #####')
            return exception_handler(config.techDifficulties['initFailure'] + str(ex1))

        return {
                'statusCode': statusCode,
                'connectFlowType': session['connectFlowType'],
                'language': session['language'],
                'speechAnalytics': session['speechAnalytics'],
                'chatAnalytics': session['chatAnalytics'],
                'session': json.dumps(session),
                'body': json.dumps('Success!')
            }

    elif function=='prompts':
        import prompts
        return(prompts.playPrompt(session, event))

    elif function=='menu':
        import menu
        return(menu.getInput(session, event))

    else:
        import controller
        return(controller.getRecord(session, event))

def exception_handler(e):
    statusCode = 400
    import config
    if config.ou == 'PROD':
        e = config.techDifficulties['prodFailure']
    return {
        'statusCode': statusCode,
        'body': json.dumps(str(e))
    }
