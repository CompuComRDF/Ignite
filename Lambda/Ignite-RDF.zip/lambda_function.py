import json
import boto3
from boto3.dynamodb.conditions import Key, Attr
import traceback
from context import ctx
from context import Session
import util
import logging
import logger
import prompts
import menu
import lex
import rdfwebservice
import controller

logging.getLogger('boto3').setLevel(logging.WARNING)
logging.getLogger('botocore').setLevel(logging.WARNING)
logging.getLogger('botocore.credentials').setLevel(logging.WARNING)

def lambda_handler(event, context):
    status_code = 200
    details = event.get("Details", {})
    contact_data = details.get("ContactData", {})
    parameters = details.get("Parameters", {})
    attributes = contact_data.get("Attributes", {})
    channel = contact_data.get("Channel", "")
    function = parameters.get("function", "")
    initiation_method = contact_data.get("InitiationMethod")
    arn = contact_data.get("InstanceARN", "")
    arn_parts = arn.split(":")
    path = arn_parts[5]
    session = Session()

    initialize_context(context, contact_data, arn, arn_parts, path, channel, initiation_method)
    logger.info(f'▶️ EVENT: {json.dumps({**event, "Details": {**event["Details"], "ContactData": {**event["Details"]["ContactData"], "Attributes": {**event["Details"]["ContactData"].get("Attributes", {}), "session": "omitted for brevity"}}, "Parameters": {**event["Details"].get("Parameters", {}), "session": "omitted for brevity"}}}, separators=(",", ":"))}')

    if 'session' not in parameters:
        if initiation_method == 'DISCONNECT': function = 'survey'
        if log_start_event(function, channel):
            if function in ['initialize', 'queue', 'agent', 'task', 'survey']:
                session = initialize_session(session, parameters, attributes, function)
                try:
                    if channel != 'TASK':
                        session = ignite_start(session)
                    load_configurations(session, event, function, channel)
                except Exception as ex1:
                    logger.error(f"❌ INITIALIZATION FAILURE: {ex1} DNIS: {ctx.dnis.get()} ENV: {ctx.ou.get()} ")
                    logger.error(f'❌ TRACEBACK MESSAGE: {traceback.format_exc()}')
                    return exception_handler(f"Initialization Failure.  The error I found is {ex1}")

                return build_initial_response(status_code, session, load_contact_flows())
        else:
            return exception_handler(f"Application Failure.  The error I found is {ex1}")
    else:
        session = Session(json.loads(parameters.get('session')))
        load_context_from_session(session)
        rdf_icons = {'controller' : '🧠', 'prompts' : '🔊', 'menu' : '☎️', 'webservice' : '🌐', 'lex' : '🗣️'}
        logger.info(f'{rdf_icons.get(function, "🧾")} SESSION: {json.dumps(session, separators=(",", ":"))}')

    return route_function(function, session, parameters, status_code)

def initialize_context(context_obj, contact_data, arn, arn_parts, path, channel, initiation_method):
    ctx.reset()
    ctx.instance_arn.set(arn)
    ctx.instance_id.set(path[path.find("/") + 1:])
    ctx.s3_bucket_name.set(f"amazon-connect-{ctx.instance_id.get()}")
    ctx.account.set(arn_parts[4])
    ctx.region.set(contact_data.get("AwsRegion", ""))
    ctx.contact_id.set(contact_data.get('InitialContactId',''))
    ctx.ou.set(context_obj.invoked_function_arn.split(":")[7].upper())
    ctx.channel.set(channel)

    if initiation_method != 'DISCONNECT':
        if channel == "TASK":
            ctx.dnis.set('')
            ctx.ani.set(contact_data.get("Attributes", {}).get("PHONE", "")[1:])
        else:
            ctx.dnis.set(contact_data.get("SystemEndpoint", {}).get("Address", "")[1:])
            ctx.ani.set(contact_data.get("CustomerEndpoint", {}).get("Address", "").lstrip("+"))

        util.connect_jitter('update_contact_attributes', {'OriginalDNIS':ctx.dnis.get()})
    else:
        ctx.dnis.set(contact_data.get("Attributes", {}).get("OriginalDNIS", ""))
        ctx.ani.set(contact_data.get("CustomerEndpoint", {}).get("Address", "").lstrip("+"))

def log_start_event(function, channel):
    result = True
    if function == 'initialize' and channel == 'VOICE':
        logger.info(f"📞 START VOICE CALL — DNIS: {ctx.dnis.get()} ANI: {ctx.ani.get()} ENV: {ctx.ou.get()}")
    elif function == 'survey':
        logger.info(f"📊 START SURVEY — DNIS: {ctx.dnis.get()} ANI: {ctx.ani.get()} ENV: {ctx.ou.get()}")
    elif function == 'initialize' and channel == 'TASK':
        logger.info(f"📜 START TASK — ANI: {ctx.ani.get()} ENV: {ctx.ou.get()}")
    elif function == 'queue':
        logger.info(f"🎯 START QUEUE FLOW — ANI: {ctx.ani.get()} ENV: {ctx.ou.get()}")
    elif function == 'agent':
        logger.info(f"🔄 START AGENT TO QUEUE TRANSFER — ANI: {ctx.ani.get()} ENV: {ctx.ou.get()}")
    elif function == 'webservice' and channel == 'TASK':
        logger.info(f"🌐 START WEB SERVICE REQUEST — ANI: {ctx.ani.get()} ENV: {ctx.ou.get()}")
    else:
        logger.error(f"❌ APPLICATION FAILURE — DNIS: {ctx.dnis.get()} ENV: {ctx.ou.get()}")
        result = False
    
    return result

def initialize_session(session, parameters, attributes, function):
    if function in ['queue', 'survey', 'agent'] and attributes.get('session'):
        session = Session(json.loads(attributes.get('session')))
        session.update({
            'initialize': True if function in ['queue', 'survey'] else False,
            'function': function,
            'contactFlowStart': attributes.get("ContactFlowStart", ""),
            'subIndex': 0
        })
        logger.info(f'🎯 {function.upper()}: {json.dumps(session, separators=(",", ":"))}')
    else:
        session.update({
            'initialize': True,
            'dnis': ctx.dnis.get(),
            'ani': ctx.ani.get(),
            'app_link': parameters.get("APPLINK", ""),
            'function': function,
            'contactFlowStart': attributes.get("ContactFlowStart", ""),
            'ENV': ctx.ou.get(),
            'contact_id': ctx.contact_id.get(),
            'subIndex': 0,
            'contactDisposition': "",
            'ivrDisposition': "",
            'agentTip': "",
            'userData': "{}",
            'authenticated': False,
            'shared_modules': ctx.shared_modules.get()
        })

    return session

def load_context_from_session(session):
    ctx.ani.set(session.get('ani'))
    ctx.dnis.set(session.get('dnis'))
    ctx.queue_id.set(session.get('queue_id'))
    ctx.business_hours.set(session.get('business_hours', True))
    ctx.app_folder.set(f"{session['tenant_id']}-{session['app_id']}")
    ctx.shared_modules.set(session.get('shared_modules', ctx.shared_modules.get()))

def build_initial_response(status_code, session, contact_flows):
    return {
        'statusCode': status_code,
        'connectFlowType': session['connectFlowType'],
        'language': session['language'],
        'speechAnalytics': session['speechAnalytics'],
        'chatAnalytics': session['chatAnalytics'],
        'QueueFlowID': contact_flows.get('Connect-RDF-Queue'),
        'AgentWhisperFlowID': contact_flows.get('Connect-RDF-Whisper'),
        'ConnectRDFInitID': contact_flows.get('Connect-RDF-Init'),
        'ConnectRDFPlayID': contact_flows.get('Connect-RDF-Play'),
        'ConnectRDFRecordID': contact_flows.get('Connect-RDF-Record'),
        'ConnectRDFMainID': contact_flows.get('Connect-RDF-Main'),
        'ConnectRDFLanguagesID': contact_flows.get('Connect-RDF-Languages'),
        'ConnectRDFPaymentsID': contact_flows.get('Connect-RDF-Payments'),
        'session': json.dumps(session),
        'body': json.dumps('Success!')
    }

def route_function(function, session, parameters, status_code):
    if function == 'prompts':
        return prompts.play_prompt(session)
    elif function == 'menu':
        return menu.get_input(session, parameters)
    elif function == 'lex':
        return lex.get_intent(session, parameters)
    elif function == 'webservice':
        return _handle_webservice(session, parameters, status_code)
    else:
        return controller.process_next_block(session, parameters)

def load_configurations(session, event, function, channel):
    config_content = util.read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), 'config.csv', 'KEY')
    for x in config_content:
        val = config_content[x]['VALUE'].lower()
        session[config_content[x]['KEY']] = True if val == 'true' else False if val == 'false' else config_content[x]['VALUE']

    queue_id_content = util.read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), 'queues.json', 'KEY')

    #if len(session['available_languages']) > 1:
    #    session['defaultQueue'] = session['defaultQueue'].strip() + ' ' + session['language_names'][0].strip()

    if function == 'survey':
        session['queue'] = event['Details']['ContactData']['Queue']['Name']
    else:
        session['queue'] = session['defaultQueue']
    
    session['queue_id'] = queue_id_content[session['queue']]['ID']
    ctx.queue_id.set(session['queue_id'])    
    
    #if session.get('globalZeroPrompt'):
    #    session['business_hours'] = queues.checkAppBusHours()
    #    ctx.business_hours.set(session['business_hours'])

    if function == 'initialize' or function == 'survey':
        if function != 'survey':
            session['contactDisposition'] = util.add_disposition(session['contactDisposition'], f"APPLICATION: {session['app_id']}")

        session['flow_index'] = -1
        session['language'] = session['available_languages'][0]
        session['language_name'] = session['language_names'][0] if len(session['available_languages']) > 1 else ''
        session['call_back'] = "off"
        session['voice_mail'] = "off"
        session['queue_survey'] = "on"
        session['flow_action'] = {}

    if function == 'queue':
        if channel == 'TASK':
            session['queue'] = event['Details']['ContactData']['Attributes']['QUEUE']
        else:
            session['queue'] = event['Details']['ContactData']['Queue']['Name']

    if function == 'agent':
        session['initialize'] = False
        session['fileName'] = 'ivr-callflow.csv'
        session['queue'] = event['Details']['ContactData']['Queue']['Name']
        if 'language' not in session:
            session['language'] = session['available_languages'][0]
        logger.info(f"✅ AGENT TO QUEUE: {session['queue']}")
        session['contactDisposition'] = util.connect_jitter('get_contact_attributes', '').get('contactDisposition', '')
        update_attributes = {
            'callFlowID': 'AGENT-Start'
        }
        util.connect_jitter('update_contact_attributes', update_attributes)

    if function == 'task':
        session['initialize'] = False
        session['fileName'] = session['call_flow']
        get_contact_attributes_response = util.connect_jitter('get_contact_attributes', '')
        session['queue'] = get_contact_attributes_response['QUEUE']
        session['vmQueueName'] = get_contact_attributes_response['VMQUEUE']
        logger.info(f"✅ TASK TO QUEUE: {session['queue']}")

def load_contact_flows():
    contact_flow_content = util.read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), 'contact_flows.json', 'KEY')

    return contact_flow_content

def ignite_start(session):
    try:
        applications_list = util.read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), 'applications.json', ctx.dnis.get())
        matched_app = None

        for app in applications_list:
            if session.get('app_link'):
                if session['app_link'] == app['Tenant']:
                    matched_app = app
                    break
            else:
                if ctx.dnis.get() in app['DNIS']:
                    matched_app = app
                    break

        # Set session vars once
        if matched_app:
            session['tenant_id'], _, session['app_id'] = matched_app['Tenant'].partition("-")
            session['available_languages'] = json.loads(matched_app['Language'])
            session['flow_control'] = json.loads(matched_app['FlowControl'])
            
            ctx.app_folder.set(f"{session['tenant_id']}-{session['app_id']}")

            if any("MenuTree" in flow for flow in session['flow_control'].values()):
                session['menutree_file'] = session['app_id'] + '-menutree'
                session['closed_tree'] = False
                session['emergency_tree'] = False
                menutree_contents = util.read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), session['menutree_file'] + '.csv', 'BLOCK')
                if 'C1' in menutree_contents:
                    session['closed_tree'] = True
                if 'E1' in menutree_contents:
                    session['emergency_tree'] = True

            session['language_names'] = []
            voices = util.get_voices()

            if len(session['available_languages']) == 1:
                session['language_names'].append('')
            else:
                for lang in session['available_languages']:
                    for voice in voices: 
                        language_parts = voice['LanguageName'].split(" ")
                        #language_name = ' ' + language_parts[len(language_parts) - 1]
                        language_name = language_parts[len(language_parts) - 1]
                        if lang == voice['LanguageCode'] and language_name not in session['language_names']:
                            session['language_names'].append(language_name)

        # Always do ANI forwarding scan
        for app in applications_list:
            try:
                dnis_list = json.loads(app.get('DNIS', '[]'))
                for mapping in dnis_list:
                    if '+' + ctx.ani.get() in mapping:
                        session['ani'] = 'Forwarded'
                        ctx.ani.set(session['ani'])
                        break
            except json.JSONDecodeError:
                pass

    except Exception as ex1:
        logger.error(f"❌  IGNITE START EXCEPTION: {str(ex1)}")
        ctx.app_folder.set('shared')
        session.update({
            'tenant_id': '',
            'app_id': 'default',
            'language_names': [''],
            'available_languages': ['en-US'],
            'flow_control': {"0": "Greeting", "1": "Queue"}, #<---- This needs to be fixed
        })

    return session

def _handle_webservice(session, parameters, status_code):
    session['soapResponse'] = '{}'
    try:
        session['blockAction'] = util.convert(session.get('blockAction',''))
        session['blockKey'] = str(session['blockAction'].get('false', ''))
        session['actionFalse'] = str(session['blockAction'].get('false', ''))
    except:
        session['blockAction'] = ''
        session['blockKey'] = ''
        session['actionFalse'] = ''

    if ctx.channel.get() == 'VOICE':
        blockParam = util.convert(session.get('blockParam', '').replace("'", '"'))
    else:
        blockParam = {
            'secret': parameters.get('secret'),
            'version': parameters.get('version'),
            'operation': parameters.get('operation'),
            'param': {
                'accountId': parameters.get('accountId')
            }
        }

    try:
        if session.get('blockType', 'SOAP') == 'SOAP':
            session = rdfwebservice.soap(blockParam, session)
            if ctx.channel.get() == 'VOICE':
                session['blockKey'] = str(session['blockAction']['true'] if session['soapResponse'] != 'error' else session['blockAction']['false'])
        else:
            session = rdfwebservice.rest(blockParam, session)
            session['blockKey'] = str(session['blockAction']['true'] if session['restResponse'] != 'error' else session['blockAction']['false'])
    except Exception as ex1:
        logger.error(f'WEB SERVICE EXCEPTION: {ex1}')

    if ctx.channel.get() == 'VOICE':
        return {
            'blockAction': session['blockKey'],
            'actionFalse': session['actionFalse'],
            'session': json.dumps(session),
            'body': json.dumps('Success!')
        }
    else:
        return {
            'statusCode': status_code,
            'body': session['soapResponse']
        }
            
def exception_handler(e):
    status_code = 400
    if ctx.ou.get() == 'PROD':
        e = 'We are currently experiencing technical difficulties.  Please try again later.  Thank you for calling.  Goodbye'
    return {
        'statusCode': status_code,
        'body': json.dumps(str(e))
    }