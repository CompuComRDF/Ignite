import json
import boto3
import botocore
from boto3.dynamodb.conditions import Attr
from context import ctx
import csv
import datetime
import os
import random
import time
from pathlib import Path
import difflib
import logger

# Global in-memory cache
_cached_data = {}

def read_cache(region, s3_bucket_name, instance_id, file_name, key, start=True):
    refreshed = False
    app_folder = instance_id if file_name in ctx.shared_modules.get() else f"{instance_id}/{ctx.app_folder.get()}"
    file_path = Path('/tmp') / app_folder / file_name

    if not file_path.exists():
        file_path.parent.mkdir(parents=True, exist_ok=True)

        if file_name in {'queues.json', 'contact_flows.json'}:
            _get_connect_config(file_path, file_name)
        elif file_name == 'applications.json':
            _get_applications(file_path)
        elif file_name == 'ivr-callflow.csv':
            _get_local_resource(file_path, file_name)
        else:
            s3_folder = _get_s3_folder(file_name)
            _download_from_s3(region, s3_bucket_name, s3_folder, file_name, file_path)
    else:
        if start and file_name != 'ivr-callflow.csv':
            refreshed = _refresh_cache_if_needed(file_path, file_name, region, s3_bucket_name, key)

    # Re-parse only if not cached or the file was refreshed
    if file_path not in _cached_data or refreshed:
        if refreshed:
            logger.info(f"💾 UPDATING CACHE: {file_path}")
        else:
            logger.info(f"💾 CREATING CACHE: {file_path}")

        if file_name in {'applications.json', 'queues.json', 'contact_flows.json'}:
            with open(file_path, encoding="utf-8-sig") as jsonfile:
                data = json.load(jsonfile)
        else:
            with open(file_path, encoding="utf-8-sig") as csvfile:
                csv_reader = csv.DictReader(csvfile)
                data = {row[key]: row for row in csv_reader}

        _cached_data[file_path] = data

    return _cached_data[file_path]

def get_sysadmin(sys_admin_key):
    try:
        sysadmin_content = read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), 'ivr-sysadmin.csv', 'KEY')
        entry = next((item for item in sysadmin_content.values() if item.get('KEY') == sys_admin_key), None)

        if not entry:
            return False

        value = entry.get('VALUE', '')

        if ":" in value:
            prefix, *rest = value.split(":", 1)
            if prefix == 'ON':
                value = f'tts:{rest[0]}' if rest else ''
            elif prefix == 'OFF':
                value = ''

        return {'TRUE': True, 'FALSE': False}.get(value, value)

    except Exception:
        return False

def get_broadcast():
    broadcast_keys = ['BM01','BM02','BM03']
    broadcast_value=''
    sysadmin_content = read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), 'ivr-sysadmin.csv', 'KEY')
    for j in sysadmin_content:
        for broadcast_key in broadcast_keys:
            if sysadmin_content[j]['KEY'] == broadcast_key:
                try:
                    broadcast_value_parts = sysadmin_content[j]['VALUE'].split(":")
                    if broadcast_value_parts[0] == 'ON':
                        broadcast_value +=  'tts:' + broadcast_value_parts[1] + '|' 
                except Exception as ex1:
                    broadcast_value =  ''
                    pass

    if broadcast_value:
        broadcast_value = broadcast_value[:-1]

    return(broadcast_value)

def get_survey_question(survey_key):
    return(get_sysadmin(f"SQ{survey_key:02d}"))

def get_survey_options(survey_key):
    survey_options=''
    num_options = 0
    sysadmin_content = read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), 'ivr-sysadmin.csv', 'KEY')
    for j in sysadmin_content:
        if sysadmin_content[j]['KEY'] == f"SQ{survey_key:02d}":
            num_options = int(sysadmin_content[j]['OPTIONS'])

    for i in range(1, num_options + 1):
        survey_options += str(i) + ':SURVEY-SaveResponse|' 

    survey_options += 'maxaction:SURVEY-InvalidResponse'

    return(survey_options)

def convert(raw_data):
    converted_data = {}
    for item in raw_data.split("|"):
        key, _, value = item.partition(":")
        converted_data[key] = value
    return converted_data
    
def validate_json(json_data):
    try:
        json.loads(json_data)
        return True
    except json.JSONDecodeError:
        return False

def check_multiple_actions(raw_data):
    raw_data = raw_data.split("|")
    if len(raw_data)>1:
        return True
    return False

def add_disposition(current, new, log=False):
    if log and new not in {'init', 'IVR-Loop', 'IVR-Flow', 'IVR-Action', 'IVR-FlowGetKey'}:
        logger.info(f"✅ {new} ANI: {ctx.ani.get()}")

    if not current:
        return new

    return f"{current},{new}"

def append(str1, str2):
    return (str1+str2)

def get_voices():
    list_voices = []
    polly_client = boto3.client('polly')
    describe_voices_response = polly_client.describe_voices(
        IncludeAdditionalLanguageCodes=False
    )

    list_voices = describe_voices_response['Voices']

    while 'NextToken' in describe_voices_response:
        describe_voices_response = polly_client.describe_voices(
            IncludeAdditionalLanguageCodes=False,
            NextToken=describe_voices_response['NextToken']
        )
        list_voices.extend(describe_voices_response['Voices'])

    return(list_voices)

#Search through a list and check to see if a key in the list contains a key value 
def check_item_exists(key_name, key_value, data):
    return(any(item[key_name] == key_value for item in data))

def get_item_object(key_name, key_value, data):
    return(next((item for item in data if item[key_name] == key_value), None))

#Search through a list and return the value of a key_name if the key_search is equal to key_value
def get_item(key_name, key_search, key_value, data):
    return(next(item[key_name] for item in data if item[key_search] == key_value))

def create_customer_profile(profiles_client, domain_name, data):
    result = ''  # Default result to empty string in case of failure
    account_type_mapping = {
        'B': 'BUSINESS',
        'P': 'INDIVIDUAL'
    }

    try:
        for key in data:
            if not data[key]:  # If the value is empty or None
                data[key] = ' '  # Replace with a space character

        # Use .get() to safely retrieve values from the dictionary
        person_name = data.get('personName', ' ')
        address1 = data.get('address1', ' ')
        city = data.get('city', ' ')
        postal = data.get('postal', ' ')
        account_balance = data.get('accountBalance', ' ')
        last_bill_date = data.get('lastBillDate', ' ')
        payment_due_date = data.get('paymentDueDate', ' ')
        customer_type = data.get('customerType', ' ')
        premise_type = data.get('premiseType', ' ')
        gas_status = data.get('gasStatus', ' ')
        control_central_url = data.get('controlCentralURL', ' ')
        account_id = data.get('accountId', ' ')
        account_type = account_type_mapping.get(data.get('accountType', ' '), 'OTHER')
        phone_number = data.get('phonenumber', ' ')

        # Safely extract the name into first, middle, and last names
        if person_name:
            first_name, middle_name, last_name = separate_name(person_name)
        else:
            first_name, middle_name, last_name = ' ', ' ', ' '

        # Prepare address and attributes
        address = {
            'Address1': address1,
            'City': city,
            'PostalCode': postal
        }

        attributes = {
            'AccountBalance': str(account_balance),
            'LastBillDate': last_bill_date,
            'PaymentDueDate': payment_due_date,
            'CustomerType': customer_type,
            'PremiseType': premise_type,
            'GasStatus': gas_status,
            'ControlCentralURL': control_central_url
        }

        # Call create_profile
        create_profile_response = profiles_client.create_profile(
            DomainName=domain_name,
            AccountNumber=account_id,
            PartyType=account_type,
            FirstName=first_name,
            MiddleName=middle_name,
            LastName=last_name,
            PhoneNumber=phone_number,
            Address=address,
            Attributes=attributes
        )

        # If profile creation is successful, return the ProfileId
        result = create_profile_response.get('ProfileId', '')

    except Exception as Ex1:
        # Log the exception and ignore, continuing the process
        logger.error(f"❌ CREATE CUSTOMER PROFILE EXCEPTION: {str(Ex1)}")

    return result

def update_customer_profile(profiles_client, domain_name, profile_id, data):
    result = ''  # Default result to empty string in case of failure
    account_type_mapping = {
        'B': 'BUSINESS',
        'P': 'INDIVIDUAL'
    }

    try:
        for key in data:
            if not data[key]:  # If the value is empty or None
                data[key] = ' '  # Replace with a space character

        # Use .get() to safely retrieve values from the dictionary
        person_name = data.get('personName', '')
        address1 = data.get('address1', '')
        city = data.get('city', '')
        postal = data.get('postal', '')
        account_balance = data.get('accountBalance', '')
        last_bill_date = data.get('lastBillDate', '')
        payment_due_date = data.get('paymentDueDate', '')
        customer_type = data.get('customerType', '')
        premise_type = data.get('premiseType', '')
        gas_status = data.get('gasStatus', '')
        control_central_url = data.get('controlCentralURL', '')
        account_id = data.get('accountId', '')
        account_type = account_type_mapping.get(data.get('accountType', ' '), 'OTHER')
        phone_number = data.get('phonenumber', '')

        # Safely extract the name into first, middle, and last names
        if person_name:
            first_name, middle_name, last_name = separate_name(person_name)
        else:
            first_name, middle_name, last_name = '', '', ''

        # Prepare address and attributes
        address = {
            'Address1': address1,
            'City': city,
            'PostalCode': postal
        }

        attributes = {
            'AccountBalance': str(account_balance),
            'LastBillDate': last_bill_date,
            'PaymentDueDate': payment_due_date,
            'CustomerType': customer_type,
            'PremiseType': premise_type,
            'GasStatus': gas_status,
            'ControlCentralURL': control_central_url
        }

        # Call create_profile
        update_profile_response = profiles_client.update_profile(
            DomainName=domain_name,
            ProfileId=profile_id,
            AccountNumber=account_id,
            PartyType=account_type,
            FirstName=first_name,
            MiddleName=middle_name,
            LastName=last_name,
            PhoneNumber=phone_number,
            Address=address,
            Attributes=attributes
        )

        # If profile creation is successful, return the ProfileId
        result = update_profile_response.get('ProfileId', '')

    except Exception as Ex1:
        # Log the exception and ignore, continuing the process
        logger.error(f"❌ UPDATE CUSTOMER PROFILE EXCEPTION: {str(Ex1)}")

    return result

def separate_name(full_name):
    # Define common name suffixes (in lowercase and without periods)
    suffixes = {"jr", "sr", "ii", "iii", "iv"}

    # Split the name into parts
    name_parts = full_name.strip().split()

    # Default values
    first_name = ' '
    middle_name = ' '
    last_name = ' '
    suffix = ' '

    # Check if the last part is a suffix (case insensitive and handle period)
    last_part = name_parts[-1].lower().rstrip('.')  # Remove any trailing period and convert to lowercase
    if last_part in suffixes:
        suffix = name_parts.pop()  # Remove suffix from name_parts and store it
        suffix = suffix.capitalize()  # Capitalize the first letter of the suffix

    # Handle different name structures
    if len(name_parts) == 1:
        # Only one part (e.g., "Madonna")
        first_name = name_parts[0]
    elif len(name_parts) == 2:
        # First and last name only (e.g., "John Doe")
        first_name = name_parts[0]
        last_name = name_parts[1]
    elif len(name_parts) >= 3:
        # First, middle, and last name (e.g., "John Michael Doe" or "John D. Doe")
        first_name = name_parts[0]
        last_name = name_parts[-1]
        middle_name = " ".join(name_parts[1:-1])

    return (first_name, middle_name, last_name)

def get_secret(secret_prefix, secret_key):
    secret_name = secret_prefix + '_' + ctx.ou.get().upper()
    secret_value = ''

    # Create a Secrets Manager client
    session = boto3.session.Session()
    secret_client = session.client(
        service_name='secretsmanager',
        region_name=ctx.region.get()
    )

    try:
        get_secret_value_response = secret_client.get_secret_value(
            SecretId=secret_name
        )

    except Exception as ex1:
        logger.error(f"❌ SOAP SECRET FAILED: {str(ex1)}")

    secret_value = json.loads(get_secret_value_response['SecretString'])[secret_key]

    return(secret_value)

def clean_certificate(cert_str):
    # Strip out any extra whitespace at the start and end
    cleaned_cert = cert_str.strip()

    # Normalize newlines to ensure the certificate string format is uniform
    cleaned_cert = cleaned_cert.replace("\n", "")

    # Remove duplicate BEGIN/END certificate tags (if they exist)
    # Ensure only one BEGIN CERTIFICATE and one END CERTIFICATE is present
    if cleaned_cert.startswith("-----BEGIN CERTIFICATE-----") and cleaned_cert.endswith("-----END CERTIFICATE-----"):
        cleaned_cert = cleaned_cert[27:-25]  # Remove the BEGIN/END parts

    # Reintroduce the necessary line breaks to properly format the PEM certificate
    # For readability and proper handling, we will split the base64 content into 64-character lines.
    cleaned_cert = "-----BEGIN CERTIFICATE-----\n" + \
                   "\n".join([cleaned_cert[i:i+64] for i in range(0, len(cleaned_cert), 64)]) + \
                   "\n-----END CERTIFICATE-----"

    return cleaned_cert

def get_client(type, region, account):
    sts_client = boto3.client('sts')
    sts_session = sts_client.assume_role(RoleArn='arn:aws:iam::'+account+':role/xaccount-rdf-role',
                                      RoleSessionName='cross_acct_lambda')

    KEY_ID = sts_session['Credentials']['AccessKeyId']
    ACCESS_KEY = sts_session['Credentials']['SecretAccessKey']
    TOKEN = sts_session['Credentials']['SessionToken']

    client = boto3.client(type,
        region_name=region,
        aws_access_key_id=KEY_ID,
        aws_secret_access_key=ACCESS_KEY,
        aws_session_token=TOKEN)
    
    return(client)

def connect_jitter(function, params):
    connect_client = get_client('connect', ctx.region.get(), ctx.account.get())
    max_tries = 5
    prev_delay = 1.0
    result = None

    for attempt in range(max_tries):
        try:
            if attempt > 0:
                logger.warning(f"⚠️ Reattempt {attempt} {function} ANI: {ctx.ani.get()}")

            if function == 'update_contact_attributes':
                connect_client.update_contact_attributes(
                    InitialContactId=ctx.contact_id.get(),
                    InstanceId=ctx.instance_id.get(),
                    Attributes=params
                )

                result = True

            elif function == 'get_contact_attributes':
                get_contact_attributes_response = connect_client.get_contact_attributes(
                    InitialContactId=ctx.contact_id.get(),
                    InstanceId=ctx.instance_id.get(),
                )

                result = get_contact_attributes_response['Attributes']

            elif function == 'get_contactflowid':
                paginator = connect_client.get_paginator("list_contact_flows")
                
                # Iterate through all pages to find the contact flow by name
                for page in paginator.paginate(InstanceId=ctx.instance_id.get()):
                    for flow in page.get("ContactFlowSummaryList", []):
                        if flow.get("Name") == params:
                            result = flow.get("Id")

            elif function == 'get_current_user_data':
                get_current_user_data_response = connect_client.get_current_user_data(
                    InstanceId=ctx.instance_id.get(),
                    Filters={
                        "Queues": [params]
                    }
                )

                result = get_current_user_data_response.get("UserDataList", [])

            elif function == 'list_user_proficiencies':
                list_user_proficiencies_response = connect_client.list_user_proficiencies(
                    InstanceId=ctx.instance_id.get(),
                    UserId=params
                )

                result = list_user_proficiencies_response.get("UserProficiencyList", [])                

            if attempt > 0:
                logger.warning(f"⚠️ Reattempt {attempt} {function} success ANI: {ctx.ani.get()}")

            break
        except Exception as Ex1:
            logger.error(f"❌ Exception {function}: {str(Ex1)} ANI: {ctx.ani.get()}")
            if attempt == max_tries -1:
                break
            #Exponential backoff with full jitter
            prev_delay=decorrelated_jitter(prev_delay)
            logger.warning(f"⚠️ Retrying in {prev_delay:.2f} seconds ANI: {ctx.ani.get()}")
            time.sleep(prev_delay)

    if result is None:
        if function == 'update_contact_attributes':
            return False
        else:
            return []

    return result

def decorrelated_jitter(prev_delay, base=1.0, cap=4.0):
    return min(cap, random.uniform(base, prev_delay * 3))

def check_ani_in_dnis(ani_to_find, table):

    # Start scanning the table
    response = table.scan()
    items = response.get('Items', [])

    while True:
        for item in items:
            dnis_data = item.get('DNIS')
            if not dnis_data:
                continue

            try:
                # Parse the JSON string to a list of dicts
                dnis_list = json.loads(dnis_data)
                for mapping in dnis_list:
                    if '+' + ani_to_find in mapping:
                        return True
            except json.JSONDecodeError:
                # If the string is not valid JSON, skip the item
                continue

        # Check if there's more data to scan
        if 'LastEvaluatedKey' in response:
            response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            items = response.get('Items', [])
        else:
            break

    return False

def convert_seconds_to_text(seconds, language):
    # Round up seconds to the nearest minute
    minutes = (seconds + 59) // 60  # Adding 59 ensures rounding up

    # Calculate hours and remaining minutes
    hours = minutes // 60
    remaining_minutes = minutes % 60

    # Prepare the text output
    time_text = ""

    if hours > 0:
        # Use singular for 1 hour, plural otherwise
        time_text += f"{hours} hour" if hours == 1 else f"{hours} hours"

    if remaining_minutes > 0:
        if time_text:
            time_text += " and "
        # Use singular for 1 minute, plural otherwise
        time_text += f"{remaining_minutes} minute" if remaining_minutes == 1 else f"{remaining_minutes} minutes"

    if seconds <= 60:
        time_text = "less than a minute"

    if language != 'en-US':
        try:
            translate_client = boto3.client('translate')
            translation_response = translate_client.translate_text(
                Text=time_text,
                SourceLanguageCode='en-US',
                TargetLanguageCode=language
            )
            time_text = translation_response['TranslatedText']
            logger.debug(f"Translation to language '{language}': {time_text}")
        except (botocore.exceptions.BotoCoreError, botocore.exceptions.ClientError) as e:
            logger.error(f"Translation failed for language '{language}': {e}")

    # Return the formatted time text
    return time_text

def _get_s3_folder(file_name):
    if file_name in ctx.shared_modules.get():
        return 'shared/'
    else:
        return f"{ctx.app_folder.get()}/config/"

def _download_from_s3(region, s3_bucket_name, s3_folder, file_name, file_path):
    s3_resource = boto3.resource('s3', region)
    s3_resource.meta.client.download_file(s3_bucket_name, s3_folder + file_name, str(file_path))

def _refresh_cache_if_needed(file_path, file_name, region, s3_bucket_name, key):
    was_updated = False

    s3_cache_dt = datetime.datetime.fromtimestamp(file_path.stat().st_ctime, tz=datetime.timezone.utc)
    s3_folder = _get_s3_folder(file_name)
    client = boto3.client('s3', region)

    if file_name == 'queues.json' or file_name == 'contact_flows.json':
        try:
            was_updated = _update_from_dynamodb(file_path, file_name)
        except Exception as e:
            logger.error(f"Failed to update cache from DynamoDB: {e}")
    elif file_name == 'applications.json':
        try:
            was_updated = _update_from_applications(file_path, key)
        except Exception as e:
            logger.error(f"Failed to update applications from DynamoDB: {e}")
    else:   
        try:
            # Attempt to get the object from S3 only if it has been modified
            client.get_object(
                Bucket=s3_bucket_name,
                Key=s3_folder + file_name,
                IfModifiedSince=s3_cache_dt
            )
            _download_from_s3(region, s3_bucket_name, s3_folder, file_name, file_path)
            was_updated = True
        except client.exceptions.ClientError as e:
            logger.debug(f"Cache not updated, reason: {e}")
    
    return was_updated

def _update_from_dynamodb(file_path, file_name):
    """Update cache based on DynamoDB data if necessary."""
    was_updated = False
    table = boto3.resource('dynamodb').Table(f"Instances-{ctx.ou.get()}")
    tenant_instance_name = f"{ctx.ou.get().lower()}{os.environ['ORGANIZATION_NAME']}-{ctx.app_folder.get().split('-')[0]}"
    
    try:
        get_item_response = table.get_item(Key={'Tenant': tenant_instance_name})
        last_updated = datetime.datetime.fromisoformat(get_item_response['Item'].get('LastUpdated'))
        cache_dt = datetime.datetime.fromtimestamp(file_path.stat().st_ctime, tz=datetime.timezone.utc)
        
        if last_updated > cache_dt:
            _get_connect_config(file_path, file_name)
            was_updated = True

    except Exception as e:
        logger.error(f"Error reading from DynamoDB: {e}")
    
    return was_updated

def _get_connect_config(filePath, file_name):
    if file_name == 'queues.json':
        config_type = 'QueueData'
    else:
        config_type = 'CallFlows'

    try:
        table = boto3.resource('dynamodb').Table('Instances-' + ctx.ou.get())
        tenant_instance_name = f"{ctx.ou.get().lower()}{os.environ['ORGANIZATION_NAME']}-{ctx.app_folder.get()[:ctx.app_folder.get().find('-')]}"
        get_item_response = table.get_item(Key={'Tenant': tenant_instance_name})
        return_list = get_item_response['Item'].get(config_type, '{}')

    except Exception as Ex1:
        logger.error(f"❌ GET CONNECT CONFIG EXCEPTION: {str(Ex1)}")

    with open(filePath, 'w') as configFile:
        configFile.write(return_list)

def _get_applications(file_path):
    try:
        table = boto3.resource('dynamodb').Table(f"Tenants-{ctx.ou.get()}")
        dynamodb_response = table.scan()
        return_list = dynamodb_response['Items']

    except Exception as Ex1:
        logger.error(f"❌ GET APPLICATIONS EXCEPTION: {str(Ex1)}")

    with open(file_path, 'w') as configFile:
        configFile.write(json.dumps(return_list))

def _update_from_applications(file_path, key):
    """Update cache based on DynamoDB data if necessary."""
    was_updated = False
    table = boto3.resource('dynamodb').Table(f"Tenants-{ctx.ou.get()}")
    
    try:
        dynamodb_response = table.scan(
            FilterExpression=Attr('DNIS').contains('+' + key)
        )
        last_updated = (
            datetime.datetime.fromisoformat(dynamodb_response['Items'][0].get('LastUpdated'))
            if dynamodb_response['Items'][0].get('LastUpdated')
            else None
        )

        cache_dt = datetime.datetime.fromtimestamp(file_path.stat().st_ctime, tz=datetime.timezone.utc)
        
        if last_updated is not None and last_updated > cache_dt:
            _get_applications(file_path)
            was_updated = True

    except Exception as e:
        logger.error(f"Error reading from DynamoDB: {e}")
    
    return was_updated

def _get_local_resource(file_path, file_name):
    local_resource = Path(__file__).resolve().parent
    local_path = local_resource / 'config' / file_name

    with local_path.open("rb") as local_object:
        local_content = local_object.read()

    with file_path.open("wb") as file:
        file.write(local_content)

def search_user_extension(tenant_id, extension):
    user_queue_arn = None
    user_configs= _get_user_configs(tenant_id)

    for user in user_configs:
        if extension == user['Extension']:
            user_queue_arn = user['QueueId']
    
    return user_queue_arn

def search_user_directory(tenant_id, first_name, last_name):
    #usert_list = ['john smith', 'jane doe']
    user_queue_arn = None
    user_list = []
    user_configs= _get_user_configs(tenant_id)
    for user in user_configs:
        user_list.append(user['Name'])

    spoken = f"{first_name} {last_name}"
    match = difflib.get_close_matches(spoken, user_list, n=1, cutoff=0.4)

    if match:
        for user in user_configs:
            if match[0] == user['Name']:
                user_queue_arn = user.get('QueueId')

    return user_queue_arn

def get_user_status(user_queue_arn):
    status = False
    connect_client = get_client('connect', ctx.region.get(), ctx.account.get())
    user_data_response = connect_client.get_current_user_data(
        InstanceId=ctx.instance_id.get(),
        Filters={
            'Agents': [user_queue_arn]
        },
        MaxResults=1
    )

    user_data_list = user_data_response.get('UserDataList', [])
    if user_data_list:
        user_data = user_data_list[0]
        status_name = user_data.get('Status', {}).get('StatusName')
        status = True if status_name.lower() == 'available' else False

    logger.info(f"STATUS: {status}")

    return status

def _get_user_configs(tenant_id):
    user_list = []
    dynamodb_client = boto3.client('dynamodb', region_name=ctx.region.get())

    try:
        list_users_response = dynamodb_client.scan(
            TableName=f"Users-{ctx.ou.get()}"
        )

        for user in list_users_response['Items']:
            if user['Tenant']['S'] == tenant_id:
                user_config = {}
                user_config['Name'] = f"{user['Name']['S'].split(',')[1].strip().lower()} {user['Name']['S'].split(',')[0].strip().lower()}"
                user_config['QueueId'] = user.get('QueueId', {}).get('S')
                user_config['Extension'] = user.get('Extension', {}).get('S')
                user_list.append(user_config)

    except Exception as Ex1:
        logger.error("_get_user_list EXCEPTION: " + str(Ex1))
    
    return user_list

def _handle_lex(bot_name, slot_type_name, ou, tenant_id):
    lex_client = get_client('lexv2-models', ctx.region.get(), ctx.account.get())
    user_list = _get_user_list(ou, tenant_id)

    try:
        list_bots_response = lex_client.list_bots(
            filters=[
                {
                    'name': 'BotName',
                    'values': [bot_name],
                    'operator': 'EQ'
                },
            ]
        )    

        for bot in list_bots_response['botSummaries']:
            if bot_name == bot['botName']:
                bot_id = bot['botId']
                bot_version = bot['latestBotVersion']

        list_locales_response = lex_client.list_bot_locales(
            botId=bot_id,
            botVersion=bot_version
        )

        for locale in list_locales_response['botLocaleSummaries']:
            if locale['localeName'] == 'en_US':
                bot_locale_id = locale['localeId']

        list_slot_types_response = lex_client.list_slot_types(
            botId=bot_id,
            botVersion=bot_version,
            localeId=bot_locale_id,
            filters=[
                {
                    'name': 'SlotTypeName',
                    'values': [slot_type_name],
                    'operator': 'EQ'
                }
            ]
        )

        for slot_type in list_slot_types_response['slotTypeSummaries']:
            if slot_type_name == slot_type['slotTypeName']:
                slot_type_id = slot_type['slotTypeId']

        # Define your names
        # names = ['John Smith', 'Jane Doe', 'Alice Johnson']
        # Format them as slot values
        slot_values = [{'sampleValue': {'value': name}} for name in user_list]

        lex_client.update_slot_type(
            botId=bot_id,
            botVersion=bot_version,
            localeId=bot_locale_id,
            slotTypeId=slot_type_id,
            slotTypeName=slot_type_name,
            slotTypeValues=slot_values,
            valueSelectionSetting={
                'resolutionStrategy': 'OriginalValue'
            }
        )

    except Exception as Ex1:
        logger.error("_handle_lex EXCEPTION: " + str(Ex1))
    
def find_builtin_prompt(filename: str, language_name: str, available_languages):
    """
    Find a prompt in Amazon Connect by filename.
 
    :param instance_id: Amazon Connect instance ID
    :param filename: 'welcome.wav' or 'welcome'
    :return: PromptSummary dict if found, else None
    """
    connect_client = get_client('connect', ctx.region.get(), ctx.account.get())
 
    if len(available_languages) > 1:
        raw_name = f'{filename} {language_name}'
    else:
        raw_name = filename

    no_ext = filename[:-4] if filename.lower().endswith(".wav") else filename

    #logger.info(f"Raw Name: {raw_name}")
    valid_names = {raw_name, no_ext}
 
    paginator = connect_client.get_paginator("list_prompts")
    
    for page in paginator.paginate(InstanceId=ctx.instance_id.get()):
        for prompt in page.get("PromptSummaryList", []):
            #logger.info(f"Prompt Name: {prompt['Name']}")
            if prompt["Name"] in valid_names:
                #logger.info(f"Name: {prompt['Name']}")
                #logger.info(f"Id: {prompt['Id']}")
                #logger.info(f"ARN: {prompt['Arn']}")
                return prompt['Arn']
 
    return None
