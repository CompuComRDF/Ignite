import json
import util

def playPrompt(session, event):
    import config
    session = json.loads(event['Details']['Parameters']['session'])
    session['prompts'] = session['blockParam']
    session['promptType'] = ""
    session['prompt'] = ""
    session['promptLoop'] = "false"

    localBuiltIns = {
        'session': session,
        'util': util,
    }

    promptsList = session['prompts'].split("|")
    for i in range(len(promptsList)):
            if i==session['promptIndex']:
                promptItem=util.convert(promptsList[i])
                for j in promptItem:
                    if promptItem[j] == config.globalZeroPrompt and not config.businessHours:
                        session['promptSize']-=1
                    else:    
                        if j in ['tts','ssml']:
                            session['promptType'] = "tts"
                            jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, session['ttsFile'], 'LABEL')
                            session['prompt'] = '<speak>' + str(jsonContent[promptItem[j]][session['language']]) + '</speak>'
                        elif j in ['error']:
                                session['prompt'] = '<speak>' + str(promptItem[j]) + '</speak>'
                        elif j in ['wav']:    
                            session['prompt'] = "s3://" + config.s3BucketName + "/prompts/" + config.tenant + "/" + session['language'] + "/" + promptItem[j] +".wav"
                            session['promptType'] = "wav"
                        elif j in ['var']:    
                            session['prompt'] = str(eval(promptItem[j], config.rdfBuiltIns, localBuiltIns))
                            if '.wav' in session['prompt']:
                                session['promptType'] = "wav"
                                if 'latency' in session['prompt']:
                                    session['promptIndex']-=1
                            else:
                                session['prompt'] = '<speak>' + session['prompt'] + '</speak>'
                                session['promptType'] = "tts"
                        elif j in ['text', 'en-US', 'fr-CA', 'es-MX', 'pt-BR']:
                            #session['promptType'] = "tts"
                            session['promptType'] = j
                            session['prompt'] = '<speak>' + str(promptItem[j]) + '</speak>'
                        elif j in ['currency']:
                            session['promptType'] = "tts"
                            if 'session' in promptItem[j]:
                                session['prompt'] = str(eval(promptItem[j], config.rdfBuiltIns, localBuiltIns))
                            else: 
                                session['prompt'] = str(promptItem[j])
                            centIndex = (session['prompt'].find('.')+1)
                            cents = session['prompt'][centIndex:]
                            dollars = session['prompt'][0:centIndex-1]
                            if session['language'] == 'en-US':
                                session['prompt'] = '<speak><say-as interpret-as="cardinal">' + dollars + '</say-as>' + 'dollars and' + '<say-as interpret-as="cardinal">' + cents + '</say-as>' + 'cents</speak>'
                            else:
                                session['prompt'] = '<speak><say-as interpret-as="cardinal">' + dollars + '</say-as>' + 'dollars et' + '<say-as interpret-as="cardinal">' + cents + '</say-as>' + 'cents</speak>'
                        elif j in ['slowcharacters']:
                            session['promptType'] = "tts"
                            if 'session' in promptItem[j]:
                                session['prompt'] = str(eval(promptItem[j], config.rdfBuiltIns, localBuiltIns))
                            else:
                                session['prompt'] = str(promptItem[j])
                            session['prompt'] = ', '.join(session['prompt'])
                            session['prompt'] = '<speak>' + session['prompt'] + '</speak>'
                        else:
                            session['promptType'] = "tts"
                            if 'session' in promptItem[j]:
                                session['prompt'] = str(eval(promptItem[j], config.rdfBuiltIns, localBuiltIns))
                            else:
                                session['prompt'] = str(promptItem[j])
                            session['prompt'] = '<speak><say-as interpret-as="'+ j + '">' + session['prompt'] + '</say-as></speak>'

    if session['promptIndex'] < session['promptSize']:
        session['promptLoop'] = "true";

    session['promptIndex']+=1
    
    return {
        'statusCode': 200,
        'promptIndex': session['promptIndex'],
        'promptSize': session['promptSize'],
        'promptType': session['promptType'],
        'prompt': session['prompt'],
        'promptLoop': session['promptLoop'],
        'inputTimeout': session['inputTimeout'],
        'globalInputTerm': config.globalInputTerm,
        'blockParam': session['prompts'],
        'blockType': session['blockType'],
        'blockAction': session['blockAction'],
        'language': str(session['language']),
        'session': json.dumps(session),
        'barge': session['barge'],
        'body': json.dumps('Success!')
    }

