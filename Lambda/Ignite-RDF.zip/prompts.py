import json
import boto3
import botocore
from context import ctx
import util
import datetime
from safe_runner import SafeRunner
import logger
import re

def play_prompt(session):
    runner = SafeRunner.from_defaults(local_built_ins= {
        'session': session,
        'util': util
    })

    """Builds the next prompt (SSML or WAV) and advances session['prompt_index']."""
    def ssml(text: str) -> str:
        return f"<speak>{text}</speak>"

    # Concatenate TTS prompts into a single prompt for continuity
    try:
        single_prompt = check_single_prompt(session['blockParam'])
        session['prompts'] = (
            f"{session['language']}:{process_tts(session, session['blockParam'], session['language'], runner)}"
            if single_prompt else session['blockParam']
        )

        # Remove broadcast message tokens for this TREE (so REPEAT won’t replay them)
        session['blockParam'] = '|'.join(
            item for item in session['blockParam'].split('|')
            if f"{session['blockKey']}.B" not in item
        )

        # Defaults
        session['prompt_type'] = session['language']
        session['prompt'] = ""
        session['prompt_loop'] = "false"

        prompts_list = session['prompts'].split("|")
        target_idx = session['prompt_index']

        if 0 <= target_idx < len(prompts_list):
            prompt_item = util.convert(prompts_list[target_idx])

            # Decrement prompt_size if this is the globalZeroPrompt outside business hours
            for k, v in prompt_item.items():
                if v == session['globalZeroPrompt'] and not ctx.business_hours.get():
                    session['prompt_size'] -= 1

            # Build prompt based on type
            for key, val in prompt_item.items():
                if key in ('tts', 'ssml'):
                    # TTS from label file
                    tts_labels = util.read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), 'ivr-tts.csv', 'LABEL')
                    session['prompt_type'] = session['language']
                    session['prompt'] = ssml(str(tts_labels[val][session['language']]))

                elif key == 'tree':
                    # Menu tree with optional broadcast on first attempt
                    tree_labels = util.read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), session['menuTreeFile'], 'LABEL')
                    broadcast = tree_labels.get(val, {}).get('BROADCAST', '')
                    session['prompt_type'] = session['language']
                    if broadcast and session['menuAttempt'] == 0:
                        tts_labels = util.read_cache(
                            ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), 'ivr-tts.csv', 'LABEL')
                        session['prompt'] = ssml(
                            f"{tts_labels[val][session['language']]}. {tree_labels[val][session['language']]}"
                        )
                    else:
                        session['prompt'] = ssml(str(tree_labels[val][session['language']]))

                elif key == 'error':
                    session['prompt'] = ssml(str(val))

                elif key == 'wav':
                    bucket = ctx.s3_bucket_name.get()
                    app_folder = ctx.app_folder.get()
                    lang = session['language']
                    session['prompt'] = f"s3://{bucket}/{app_folder}/prompts/{lang}/{val}.wav"
                    session['prompt_type'] = "wav"

                elif key == 'holdmusic':
                    bucket = ctx.s3_bucket_name.get()
                    session['prompt'] = f"s3://{bucket}/shared/{val}.wav"
                    session['prompt_type'] = "wav"

                elif key == 'var':
                    evaluated = str(runner.eval_expr(val))
                    session['prompt'] = evaluated
                    if evaluated.endswith('.wav'):
                        session['prompt_type'] = "wav"
                        if 'latency' in evaluated:
                            session['prompt_index'] -= 1
                    else:
                        session['prompt'] = ssml(evaluated)
                        session['prompt_type'] = session['language']

                elif key == 'text' or key in session['available_languages']:
                    session['prompt_type'] = key
                    session['prompt'] = ssml(str(val))

                elif key == 'currency':
                    session['prompt_type'] = session['language']
                    evaluated = str(runner.eval_exprl(val))
                    cent_idx = evaluated.find('.') + 1
                    cents = evaluated[cent_idx:]
                    dollars = evaluated[:cent_idx - 1]
                    if session['language'] == 'en-US':
                        session['prompt'] = ssml(
                            f'<say-as interpret-as="cardinal">{dollars}</say-as>'
                            f'dollars and'
                            f'<say-as interpret-as="cardinal">{cents}</say-as>'
                            f'cents'
                        )
                    else:
                        session['prompt'] = ssml(
                            f'<say-as interpret-as="cardinal">{dollars}</say-as>'
                            f'dollars et'
                            f'<say-as interpret-as="cardinal">{cents}</say-as>'
                            f'cents'
                        )

                elif key == 'slowcharacters':
                    session['prompt_type'] = session['language']
                    evaluated = str(runner.eval_expr(val))
                    slow = ', '.join(evaluated)
                    session['prompt'] = ssml(slow)

                elif key == 'characters':
                    session['prompt_type'] = session['language']
                    evaluated = str(runner.eval_expr(val))
                    session['prompt'] = evaluated

                elif key == 'builtin':
                    session['prompt_type'] = key
                    evaluated = str(runner.eval_expr(val))
                    session['prompt'] = evaluated

                else:
                    # Generic say-as wrapper
                    session['prompt_type'] = session['language']
                    evaluated = str(runner.eval_expr(val))
                    session['prompt'] = ssml(f'<say-as interpret-as="{key}">{evaluated}</say-as>')

        # Loop if more prompts remain
        if session['prompt_index'] < session['prompt_size']:
            session['prompt_loop'] = "true"

        session['prompt_index'] += 1

    except Exception as Ex1:
        logger.info("❌ PLAY PROMPTS ERROR: " + str(Ex1))

    return {
        'statusCode': 200,
        'promptIndex': session['prompt_index'],
        'promptSize': session['prompt_size'],
        'promptType': session['prompt_type'],
        'prompt': session['prompt'],
        'promptLoop': session['prompt_loop'],
        'inputTimeout': session['input_timeout'],
        'inputLength': session['input_length'],
        'globalInputTerm': session.get('InputTerm', session['globalInputTerm']),
        'blockParam': session['prompts'],
        'blockType': session['blockType'],
        'blockAction': session['blockAction'],
        'language': str(session['language']),
        'botAliasArn': session.get('bot_alias_arn'),
        'session': json.dumps(session),
        'barge': session['barge'],
        'body': json.dumps('Success!')
    }

def convert_to_cardinal(num, language):
    """Returns the number as a cardinal representation (i.e., just the number)."""
    if language != 'en-US':
        return(translate_text(num, language))
    return str(num)

def english_ordinal_word(n):
    if not 1 <= n <= 100:
        raise ValueError("Number must be between 1 and 100")

    ones = {
        1: "first", 2: "second", 3: "third", 4: "fourth",
        5: "fifth", 6: "sixth", 7: "seventh", 8: "eighth", 9: "ninth"
    }

    teens = {
        10: "tenth", 11: "eleventh", 12: "twelfth", 13: "thirteenth",
        14: "fourteenth", 15: "fifteenth", 16: "sixteenth",
        17: "seventeenth", 18: "eighteenth", 19: "nineteenth"
    }

    tens = {
        20: "twentieth", 30: "thirtieth", 40: "fortieth",
        50: "fiftieth", 60: "sixtieth", 70: "seventieth",
        80: "eightieth", 90: "ninetieth"
    }

    if n < 10:
        return ones[n]
    if n < 20:
        return teens[n]
    if n in tens:
        return tens[n]
    if n == 100:
        return "one hundredth"

    tens_part = (n // 10) * 10
    ones_part = n % 10
    tens_word = tens[tens_part].replace("ieth", "y")

    return f"{tens_word}-{ones[ones_part]}"

#def convert_to_ordinal(n, language):
#    """Converts a number to its ordinal equivalent in words (e.g., 1 -> '1st', 2 -> '2nd')."""
#    suffixes = ['th', 'st', 'nd', 'rd'] + ['th'] * 16
#    if 10 <= n % 100 <= 20:
#        suffix = 'th'
#    else:
#        suffix = suffixes[n % 10]
#
#   if language != 'en-US':
#        return(translate_text(str(n) + suffix, language))
#    
#    return str(n) + suffix

def convert_to_ordinal(n, language, gender="feminine"):
    """
    Converts a number (1–100) into a spoken ordinal optimized
    for Spanish, French, and Portuguese.
    Default gender: feminine
    """

    # Natural speech fallback
    if language.startswith(("es", "pt")) and n > 10:
        return translate_text(str(n), language)

    english_word = english_ordinal_word(n)

    if language == "en-US":
        return english_word

    translated = translate_text(english_word, language)

    # ── Spanish gender handling
    if language.startswith("es") and gender == "feminine":
        translated = (
            translated.replace("primero", "primera")
                       .replace("segundo", "segunda")
                       .replace("tercero", "tercera")
        )

    # ── French gender handling (only affects 1st)
    if language.startswith("fr") and gender == "feminine":
        translated = translated.replace("premier", "première")

    # ── Portuguese gender handling
    if language.startswith("pt") and gender == "feminine":
        translated = (
            translated.replace("primeiro", "primeira")
                       .replace("segundo", "segunda")
                       .replace("terceiro", "terceira")
                       .replace("vigésimo", "vigésima")
                       .replace("trigésimo", "trigésima")
        )

    return translated

def convert_date(date_str, language):
    """Converts a date in YYYYMMDD format to MM/DD/YYYY."""
    date_obj = datetime.datetime.strptime(date_str, "%Y%m%d")

    if language != 'en-US':
        return(translate_text(date_obj.strftime("%m/%d/%Y"), language))
    
    return date_obj.strftime("%m/%d/%Y")

def convert_time(time_str, language):
    """Converts a time in military format (HH:MM) to HH:MM AM/PM format."""
    time_obj = datetime.datetime.strptime(time_str, "%H:%M")

    if language != 'en-US':
        return(translate_text(time_obj.strftime("%I:%M %p"), language))
    
    return time_obj.strftime("%I:%M %p")

def convert_currency(currency_str, language):
    """Converts a currency value in <dollarvalue>.<centsvalue> format to a $ formatted string."""
    try:
        # Ensure the string is a valid float and format it to a string with two decimal places
        dollar_value = float(currency_str)
        if language != 'en-US':
            return(translate_text(f"${dollar_value:,.2f}", language))
            
        return f"${dollar_value:,.2f}"
    except ValueError:
        return currency_str  # If it's not a valid currency format, just return the raw value

def convert_phone(phone_str, language):
    """Converts a 10 or 11 digit phone number to a formatted phone number."""
    # Remove any non-numeric characters from the phone string
    result = ''
    digits = re.sub(r'\D', '', phone_str)

    if len(digits) == 10:
        # Format 10-digit phone number (commas after 3rd and 6th digits)
        result = f"{digits[:3]},{digits[3:6]},{digits[6:]}"
    elif len(digits) == 11:
        # Format 11-digit phone number (commas after 4th and 7th digits)
        result = f"{digits[:4]},{digits[4:7]},{digits[7:]}"
    else:
        result = phone_str  # Return as-is if it's not 10 or 11 digits

    if language != 'en-US':
        return(translate_text(result, language))
    
    return result

def convert_address(address_str, language):
    """Attempt to format a basic address with street, city, state, country, postal/zip code."""

    # Split address into sections by comma
    address_sections = [section.strip() for section in address_str.split(',')]
    
    # Create placeholders for components
    address_parts = {
        'Street': None,
        'Apartment': None,
        'City': None,
        'State': None,
        'Postal': None,
        'Country': None
    }

    # Try to capture street address (first part)
    address_parts['Street'] = address_sections[0] if address_sections else None

    # Try to capture apartment (if any)
    apartment_pattern = r'(apt|suite|unit)\s?[\w\d]+'
    for section in address_sections:
        if re.search(apartment_pattern, section, re.IGNORECASE):
            address_parts['Apartment'] = section
            break

    # Try to capture city (find the first non-state component after street)
    state_abbreviation_pattern = r'\b[A-Z]{2}\b'  # For state abbreviation
    for i, section in enumerate(address_sections[1:], 1):
        if re.search(state_abbreviation_pattern, section):
            address_parts['State'] = section
            address_parts['City'] = ', '.join(address_sections[1:i])  # City is before the state
            break

    # If no state abbreviation found, try to capture city from remaining sections
    if not address_parts['City'] and len(address_sections) > 1:
        address_parts['City'] = ', '.join(address_sections[1:])

    # Try to capture postal/zip code (5 or 9 digits)
    postal_pattern = r'\d{5}(-\d{4})?'  # Standard 5-digit or 9-digit zip code
    for section in address_sections:
        if re.search(postal_pattern, section):
            address_parts['Postal'] = section

    # Try to capture country (last section)
    if len(address_sections) > 1 and not re.search(state_abbreviation_pattern, address_sections[-1]):
        address_parts['Country'] = address_sections[-1]

    # Format the final address
    formatted_address = [
        address_parts[key] for key in ['Street', 'Apartment', 'City', 'State', 'Postal'] if address_parts[key]
    ]
    if address_parts['Country']:
        formatted_address.append(address_parts['Country'])

    # Return formatted address as a string
    if language != 'en-US':
        return(translate_text(', '.join(formatted_address), language))
        
    return ', '.join(formatted_address)

def check_single_prompt(prompt_list):
    single_prompt = False
    pairs = prompt_list.split('|')

    for pair in pairs:
        type_value = pair.split(':')
        data_type = type_value[0]
        if data_type in ['tts','text','eval','char','cardinal','number', 'characters', 'slowcharacters','ordinal','date','time','currency','phone','address']:
            single_prompt = True

    return single_prompt

def process_tts(session, input_str, language, runner):
    """Processes the input string and converts based on the type of each value, ignoring unknown types."""
    result = []

    # Split the input by '|'
    pairs = input_str.split('|')

    # Loop through each type:value pair
    for pair in pairs:
        type_value = pair.split(':')
        if len(type_value) != 2:
            continue  # Skip if the pair is invalid

        data_type, value = type_value[0], type_value[1]
        if 'session' in value:
            value = runner.eval_expr(value) 

        # Process based on type
        if data_type == "tts":
            tts_content = util.read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), 'ivr-tts.csv', 'LABEL')
            if '.B' in value or 'BM0' in value:
                result.append(str(tts_content[value][session['language']] + '<break time="1000ms"/>'))  
            else:
                result.append(str(tts_content[value][session['language']]))  
        elif data_type == session['language']:
            result.append(value)
        elif data_type == "text":
            result.append(value)
        elif data_type == "eval":
            result.append(runner.eval_expr(value))
        elif data_type == "char":
            result.append(' '.join(value))  # Separate by space
        elif data_type == "cardinal" or data_type == "number":
            try:
                result.append(str(convert_to_cardinal(int(value), language)))  # Keep as numeric value
            except ValueError:
                result.append(value)  # If it's not a number, keep the value as-is
        elif data_type == "slowcharacters":
            result.append(', '.join(value))  # Separate by commas
        elif data_type == "characters":
            result.append(value)
        elif data_type == "ordinal":
            try:
                result.append(convert_to_ordinal(int(value), language))  # Convert to ordinal
            except ValueError:
                result.append(value)  # If it's not a number, keep the value as-is
        elif data_type == "date":
            result.append(convert_date(value, language))  # Convert to MM/DD/YYYY
        elif data_type == "time":
            result.append(convert_time(value, language))  # Convert to HH:MM AM/PM
        elif data_type == "currency":
            result.append(convert_currency(value, language))  # Convert to formatted currency
        elif data_type == "phone":
            result.append(convert_phone(value, language))  # Convert to formatted phone number
        elif data_type == "address":
            result.append(convert_address(value, language))  # Convert to structured address format
        else:
            # If the type is unknown, we simply ignore it
            continue

    #Check if all items in result are empty
    if all(item.strip() == '' for item in result):
        # Return empty string
        return ''
    else:
        # Return the concatenated result
        return ', '.join(result) + '.'

def translate_text(input, language):
    try:
        translate_client = boto3.client('translate')
        translation_response = translate_client.translate_text(
            Text=input,
            SourceLanguageCode='en-US',
            TargetLanguageCode=language
        )
        translation = translation_response['TranslatedText']
        logger.debug(f"Translation to language '{language}': {translation}")
    except (botocore.exceptions.BotoCoreError, botocore.exceptions.ClientError) as e:
        logger.error(f"Translation failed for language '{language}': {e}")

    return translation    
