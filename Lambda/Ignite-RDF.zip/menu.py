import json
import util
import config
    
def getInput(session, event):
    errorResponse = dict.fromkeys(['errorPrompt','errorPromptType','maxAction'])
    session['menuLoop'] = "true"
    resetQueue = "false"

    try:
        session['menuAttempts'] = session['menuOptions']['attempts']
    except:
        session['menuAttempts'] = session['globalMenuAttempts']
        
    #Check if this is the initial input captured by caller.  If so, initialize menuOptions
    if len(session['capturedInput'])==0:
        try:
            session['menuOptions'] = util.convert(event['Details']['Parameters']['blockAction'])
        except:
            session['menuOptions'] = session['menuOptions']
            
    menuSelection = event['Details']['Parameters']['selectedOption'].lower()

    #GLOBAL TIMEOUT
    if menuSelection == "timeout":
        #MENU TIMEOUT
        if len(session['capturedInput'])==0:
            errorType = menuSelection
        else:
            errorType = 'invalid'
            
        try:
            session['blockAction'] = session['menuOptions'][errorType]
        except:
            errorResponse = errorHandle(session, errorType)
            session['promptIndex']=0
            session['blockAction'] = "error"
        session['capturedInput'] = ""

    #GLOBAL ZERO
    #elif menuSelection == '0' and not config.businessHours and not config.globalZeroPrompt == '' and session['blockType']=="MENU":
    #    errorResponse = errorHandle(session, 'invalid')
    #    session['promptIndex']=0
    #    session['blockAction'] = "error"  
                
    #GLOBAL REPEAT
    elif menuSelection == config.globalMenuRepeat and (session['blockType']=="MENU" or session['blockType']=="INPUT" or session['blockType']=="TREE"):
        try:
            session['blockAction'] = session['menuOptions'][menuSelection]
        except:    
            session['blockAction'] = "error"
            errorResponse['errorPromptType'] = "skip"
            repeatAttempt = int(session['repeatAttempt'])
            if int(session['repeatAttempt']) < int(session['menuAttempts']):
                session['menuLoop'] = "true"
                session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey']+"-Repeat")   
                repeatAttempt +=1
                session['repeatAttempt'] = str(repeatAttempt)
                session['promptIndex']=0
            else:
                errorResponse = errorHandle(session, 'max')
                session['promptIndex']=0    
                #try:
                #    errorResponse['maxAction'] = session['menuOptions']['maxaction']
                #except:
                #    errorResponse['maxAction'] = session['globalMaxtriesAction']            
                #session['menuLoop'] = "false"
                #session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey']+"-MaxTries")           

    #GLOBAL PREVIOUS
    elif menuSelection == config.globalMenuPrevious and session['blockType']=="MENU":
        try:
            session['blockAction'] = session['menuOptions'][menuSelection]
        except:
            if session['menuIndex'] == 1:
                errorResponse = errorHandle(session, 'invalid')
                session['promptIndex']=0
                session['blockAction'] = "error"                
            else:
                #Delete the current Menu
                session['menuIndex'] -=1
                del session['menuTracker'][session['menuIndex']]
                session['queueIndex'] -=1
                del session['queueTracker'][session['queueIndex']]
                #Go to previous Menu
                session['menuIndex'] -=1
                session['queueIndex'] -=1
                if session['menuTracker'][session['menuIndex']]=='SUB':
                    session['subIndex'] -=1
                    i=0
                    for n in session['subModule']:
                        if session['subIndex'] == i:
                            session['fileName'] = n
                    i+=1
                    del session['subModule'][session['fileName']]
                    del session['menuTracker'][session['menuIndex']]
                    del session['queueTracker'][session['queueIndex']]
                    session['menuIndex'] -=1
                    session['queueIndex'] -=1

                session['blockAction'] = session['menuTracker'][session['menuIndex']]
                del session['menuTracker'][session['menuIndex']]

                session['queue'] = session['queueTracker'][session['queueIndex']]
                del session['queueTracker'][session['queueIndex']] 
                
                import queues
                session = queues.setQueue(session)
                session['blockParam'] = config.instanceARN + '/queue/' + session['queueID']
                
                resetQueue = 'true'

    elif menuSelection == config.globalMenuPrevious and session['blockType']=="TREE":
        if len(session['blockParam']) > 7:
            session['blockType'] = 'TREEBRANCH'
            session['blockParam'] = session['blockParam'][0:len(session['blockParam'])-1]
            session['blockAction'] = session['blockKey']
        else:
            errorResponse = errorHandle(session, 'invalid')
            session['promptIndex']=0
            session['blockAction'] = "error"                

    #MENU/INPUT
    else:
        session['menuSelection'] = menuSelection
        try:
            if session['blockType']=="MENU":
                session['blockAction'] = session['menuOptions'][menuSelection]
                session['menuOptions']={}

            elif session['blockType']=="TREE":
                jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, session['menuTreeFile'], 'LABEL')
                session['menuTree'] = session['blockParam'] + session['menuSelection']
                menuTreeKey = util.convert(session['menuTree'])['tree']
                if menuTreeKey in jsonContent:
                    session['blockType'] = 'TREEBRANCH'
                    session['blockParam'] =  session['menuTree']
                    if jsonContent[menuTreeKey][session['language']] and jsonContent[menuTreeKey][session['language']].strip():
                        session['blockAction'] = session['blockKey']
                    else:
                        session['blockType'] = 'TREE'
                        session['blockAction'] = 'LOOP' 
                else:
                    raise Exception("Invalid MenuTree Key")
            elif session['blockType']=="INPUT2": #This method captures single digits at a time
                if not menuSelection == config.globalInputTerm:
                    session['capturedInput'] = util.append(session['capturedInput'], menuSelection)
                    if len(session['capturedInput']) <= int(session['menuOptions']['length']):
                        session['blockAction'] = "continue"
                else:
                    if len(session['capturedInput']) < int(session['menuOptions']['length']):
                        raise Exception("Not enough digits")
                    else:
                        saveInput = "session[\'" + session['menuOptions']['var'] + "\'] = session[\'capturedInput\']"
                        exec(saveInput)
                        session['capturedInput'] = ""
                        session['blockAction'] = session['menuOptions']['action']
                        session['menuOptions']={}
            else: #This is the INPUT method
                if len(menuSelection) == 1:
                    try:
                        session['blockAction'] = session['menuOptions'][menuSelection]
                        session['menuOptions']={}
                    except:
                        session['capturedInput'] = menuSelection
                        session['blockAction'] = "continue"
                else:
                    session['capturedInput'] = util.append(session['capturedInput'], menuSelection)
                    if not len(session['capturedInput']) == int(session['menuOptions']['length']):
                        raise Exception("Invalid number of digits entered")
                    else:
                        saveInput = "session[\'" + session['menuOptions']['var'] + "\'] = session[\'capturedInput\']"
                        exec(saveInput)
                        session['capturedInput'] = ""
                        session['inputTimeout'] = 0
                        session['blockAction'] = session['menuOptions']['action']
                        session['menuOptions']={}                
        except Exception as ex1:
            print(ex1)
            session['capturedInput'] = ""
            try:
                session['blockAction'] = session['menuOptions']['invalid']
            except:
                #errorResponse = errorHandle(session, 'invalid', region, s3BucketName)
                errorResponse = errorHandle(session, 'invalid')
                session['promptIndex']=0
                session['blockAction'] = "error"

    return {
            'statusCode': 200,
            'blockParam': session['blockParam'],
            'blockAction': session['blockAction'],
            'menuAttempts': session['menuAttempts'],
            'menuLoop': session['menuLoop'],
            'language': str(session['language']),
            'inputTimeout': session['inputTimeout'],
            'globalInputTerm': config.globalInputTerm,
            'errorPrompt': errorResponse['errorPrompt'],
            'errorPromptType': errorResponse['errorPromptType'],
            'maxAction': errorResponse['maxAction'],
            'globalMenuAttempts': str(session['globalMenuAttempts']),
            'barge': session['barge'],
            'resetQueue': resetQueue,
            'session': json.dumps(session),
            'body': json.dumps('Success!')
        }

def errorHandle(session, errorAttempt):
    maxAction=''
    if errorAttempt in ['timeout']:
        promptListType = 'globalTimeoutPrompt'
    else:
        promptListType = 'globalInvalidPrompt'
    
    menuAttempt = int(session['menuAttempt'])
    
    if int(session['menuAttempt']) < int(session['menuAttempts']) and errorAttempt not in ['max']:
        session['menuLoop'] = "true"
        attempt = int(session[errorAttempt])
        promptList = session[promptListType].split("|")
        promptItem = util.convert(promptList[attempt])
        for j in promptItem:
            if j in ['wav']:
                errorPrompt = "s3://" + config.s3BucketName + "/prompts/" + config.tenant + "/" + session['language'] + "/" + promptItem[j] +".wav"
                errorPromptType = "wav"
            else:
                #jsonContent = util.readCSV(config.region, config.s3BucketName, session['ttsFile'], 'LABEL')
                jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, session['ttsFile'], 'LABEL')
                #errorPromptType = "tts"
                errorPromptType = session['language'] 
                errorPrompt = '<speak>' + jsonContent[promptItem[j]][session['language']] + '</speak>'
        menuAttempt +=1
        session['menuAttempt'] = str(menuAttempt)
        attempt +=1
        session[errorAttempt] = str(attempt)
        session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey']+ '-' + errorAttempt)            
    #MAX TIMEOUT LOGIC
    else:
        session['menuLoop'] = "false"
        session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey']+"-MaxTries")
        try:
            maxAction = session['menuOptions']['maxaction']
            errorPromptType = 'skip'
            errorPrompt = ''
        except:
            maxAction = session['globalMaxtriesAction']            

        promptListType = 'globalMaxtriesPrompt'
        promptItem = util.convert(session[promptListType])
        for m in promptItem:
            if m in ['wav']:
                errorPrompt = "s3://" + config.s3BucketName + "/prompts/" + config.tenant + "/" + session['language'] + "/" + promptItem[m] +".wav"
                errorPromptType = "wav" 
            else:
                #jsonContent = util.readCSV(config.region, config.s3BucketName, session['ttsFile'], 'LABEL')
                jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, session['ttsFile'], 'LABEL')
                #errorPromptType = "tts"
                errorPromptType = session['language'] 
                errorPrompt = '<speak>' + jsonContent[promptItem[m]][session['language']] + '</speak>'
    return{
        'errorPrompt': errorPrompt,
        'errorPromptType': errorPromptType,
        'maxAction': maxAction
    }

