import json
import util
from context import ctx

def get_input(session, parameters):
    error_response = {'error_prompt': None, 'error_prompt_type': None, 'max_action': None}
    session = _init_menu(session, parameters)

    menu_selection = parameters.get('selectedOption', '').lower()

    if menu_selection == "timeout":
        session, error_response = _handle_timeout(session)

    elif menu_selection == session.get('globalMenuRepeat') and session.get('blockType') in {"MENU", "INPUT", "TREE"}:
        session, error_response =_handle_repeat(session)

    elif menu_selection == session.get('globalMenuPrevious') and session.get('blockType') == "TREE":
        session, error_response = _handle_previous(session)

    else:
        session['menu_selection'] = menu_selection
        try:
            block_type = session['blockType']

            if block_type == "MENU":
                session = _handle_menu_block(session, menu_selection)

            elif block_type == "TREE":
                session = _handle_tree_block(session, menu_selection)

            else:  # INPUT
                session = _handle_input_block(session, menu_selection)

        except Exception:
            # Generic invalid handling
            session['captured_input'] = ""
            try:
                session['blockAction'] = session['menu_options']['invalid']
                session.pop('menu_options', None)
            except Exception:
                session, error_response = _error_handle(session, 'invalid')
                session['prompt_index'] = 0
                session['blockAction'] = "error"

    return {
        'statusCode': 200,
        'blockParam': session['blockParam'],
        'blockAction': session['blockAction'],
        'menuAttempts': session['menu_attempts'],
        'menuLoop': session['menu_loop'],
        'language': str(session['language']),
        'inputTimeout': session['input_timeout'],
        'globalInputTerm': session.get('InputTerm', session['globalInputTerm']),
        'errorPrompt': error_response['error_prompt'],
        'errorPromptType': error_response['error_prompt_type'],
        'maxAction': error_response['max_action'],
        'globalMenuAttempts': str(session['globalMenuAttempts']),
        'barge': session['barge'],
        'resetQueue': 'false',
        'session': json.dumps(session),
        'body': json.dumps('Success!')
    }

def _get_menu_attempts(session):
    return int(
        session.get('menu_options', {}).get(
            'attempts',
            session.get('local_menu_attempts', session['globalMenuAttempts'])
        )
    )

def _init_menu(session, parameters):
    session['menu_loop'] = "true"
    session['menu_attempts'] = _get_menu_attempts(session)
    if (
        not session.get("captured_input")
        and not isinstance(session.get("menu_options"), dict)
        and session.get("blockType") != "TREE"
    ):
        session["menu_options"] = util.convert(parameters.get("blockAction"))
    
    return session


def _handle_timeout(session):
    error_type = 'timeout' if not session.get('captured_input') else 'invalid'
    error_response = {'error_prompt': None, 'error_prompt_type': None, 'max_action': None}

    try:
        session['blockAction'] = session['menu_options'][error_type]
        session.pop('menu_options', None)
    except Exception:
        session, error_response = _error_handle(session, error_type)
        session['prompt_index'] = 0
        session['blockAction'] = "error"

    session['captured_input'] = ""
    return session, error_response


def _handle_repeat(session):
    error_response = {'error_prompt': None, 'error_prompt_type': None, 'max_action': None}
    try:
        session['blockAction'] = session['menu_options'][session['globalMenuRepeat']]
    except Exception:
        session['blockAction'] = "error"
        error_response['error_prompt_type'] = "skip"
        session['menu_loop'] = "true"
        session['ivrDisposition'] = util.add_disposition(
            session['ivrDisposition'],
            f"{session['blockKey']}-Repeat",
            log=True
        )
        session['prompt_index'] = 0
    
    return session, error_response

def _handle_previous(session):
    error_response = {'error_prompt': None, 'error_prompt_type': None, 'max_action': None}

    if len(session['blockKey']) > 2:
        session['blockAction'] = session['blockKey'][:-1]
    else:
        session, error_response = _error_handle(session, 'invalid')
        session['prompt_index'] = 0
        session['blockAction'] = "error"

    return session, error_response

def _save_captured_input_to_session(session):
    var_name = session['menu_options']['var']
    session[var_name] = session['captured_input']

    return session

def _handle_menu_block(session, menu_selection):
    session['blockAction'] = session['menu_options'][menu_selection]
    # Remove options after a successful selection to prepare for next menu
    session.pop('menu_options', None)

    return session

def _handle_tree_block(session, menu_selection):
    menutree_contents = util.read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), session['fileName'], 'BLOCK')
    key = session['blockKey'] + menu_selection

    if key not in menutree_contents:
        raise Exception("Invalid MenuTree Key")

    '''
    action_dict = util.convert(menutree_contents[key]['ACTION'])

    session['auth'] = action_dict.get('auth')
    action_type = next(
        (k for k in {
            'menu', 'play', 'queue', 'transfer', 'app', 'component', 'callflow', 'contactflow', 'aiagent', 'lex'
        } if k in action_dict),
        None
    )

    session['flow_action'] = {action_type: action_dict[action_type]}

    if action_type == 'aiagent':
        session['flow_action'] = {'transfer': '12012281622'}

    if action_type == 'queue' or (action_type in ['menu', 'play'] and action_dict[action_type] != 'Dynamic'):
        session['queue'] = session['flow_action'][action_type]

    #if _contains_next_option(key, session['menutree_keys']):
    if action_type in {'menu', 'play', 'component'}:
        session['blockType'] = 'TREE'
        session['blockAction'] = key
    else:
        session['contactDisposition'] = util.add_disposition(
            session['contactDisposition'],
            f"{key}:{action_type.capitalize()}"
        )
        session['blockAction'] = 'RETURN'

    '''
    session['blockAction'] = key

    return session

def _handle_input_block(session, menu_selection):
    if len(menu_selection) == 1:
        try:
            session['blockAction'] = session['menu_options'][menu_selection]
            session['menu_options'] = {}
        except Exception:
            session['captured_input'] = menu_selection
            session['blockAction'] = "continue"
        return session

    session['captured_input'] = util.append(session['captured_input'], menu_selection)
    input_term = session.get('InputTerm', session['globalInputTerm'])

    if input_term == '#':
        min_len = int(session['menu_options']['minlength'])
        max_len = int(session['menu_options']['maxlength'])
        if min_len <= len(session['captured_input']) <= max_len:
            session = _save_captured_input_to_session(session)
            session['captured_input'] = ""
            session['input_timeout'] = 0
            session['blockAction'] = session['menu_options']['action']
            session['menu_options'] = {}
        else:
            raise Exception("Invalid number of digits entered")
    else:
        length = int(session['menu_options']['length'])
        if len(session['captured_input']) != length:
            raise Exception("Invalid number of digits entered")
        session = _save_captured_input_to_session(session)
        session['captured_input'] = ""
        session['input_timeout'] = 0
        session['blockAction'] = session['menu_options']['action']
        session['menu_options'] = {}
    
    return session

def _error_handle(session, error_attempt):
    error_prompt = ''
    error_prompt_type = ''
    max_action = ''

    is_timeout = error_attempt == 'timeout'
    prompt_list_type = 'globalTimeoutPrompt' if is_timeout else 'globalInvalidPrompt'

    menu_attempt = int(session['menu_attempt'])

    if menu_attempt < int(session['menu_attempts']) and error_attempt != 'max':
        session['menu_loop'] = "true"
        attempt = int(session[error_attempt])

        prompt_list = session[prompt_list_type].split("|")
        prompt_item = util.convert(prompt_list[attempt])

        for key, value in prompt_item.items():
            if key == 'wav':
                error_prompt = f"s3://{ctx.s3_bucket_name.get()}/prompts/{session['language']}/{value}.wav"
                error_prompt_type = 'wav'
            else:
                tts_content = util.read_cache(
                    ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(),
                    'ivr-tts.csv', 'LABEL'
                )
                error_prompt_type = session['language']
                error_prompt = f"<speak>{tts_content[value][session['language']]}</speak>"

        session['menu_attempt'] = str(menu_attempt + 1)
        session[error_attempt] = str(attempt + 1)
        session['ivrDisposition'] = util.add_disposition(
            session['ivrDisposition'], f"{session['blockKey']}-{error_attempt}", log=True
        )

    else:
        session['menu_loop'] = "false"
        session['ivrDisposition'] = util.add_disposition(
            session['ivrDisposition'], f"{session['blockKey']}-MaxTries", log=True
        )

        try:
            max_action = session['menu_options']['maxaction']
            session.pop('menu_options', None)
            error_prompt_type = 'skip'
        except Exception:
            if session['blockType'] == "TREE":
                session['contactDisposition'] = util.add_disposition(
                    session['contactDisposition'], f"{session['blockKey']}:MaxTries"
                )
                # If we were navigating into app-like targets, fallback to queue on max-tries
                if any(k in {'flow', 'module', 'component', 'app'} for k in session.get('flow_action', {})):
                    session['flow_action'] = {'queue': session['queue']}
                max_action = "RETURN"
            else:
                max_action = session['globalMaxtriesAction']

        prompt_item = util.convert(session['globalMaxtriesPrompt'])
        for key, value in prompt_item.items():
            if key == 'wav':
                error_prompt = f"s3://{ctx.s3_bucket_name.get()}/prompts/{session['language']}/{value}.wav"
                error_prompt_type = 'wav'
            else:
                tts_content = util.read_cache(
                    ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(),
                    'ivr-tts.csv', 'LABEL'
                )
                error_prompt_type = session['language']
                error_prompt = f"<speak>{tts_content[value][session['language']]}</speak>"

    return session, {
        'error_prompt': error_prompt,
        'error_prompt_type': error_prompt_type,
        'max_action': max_action
    }

def _contains_next_option(search_key, menu_keys):
    normalized_key = search_key.strip().lower()
    return any(
        len(item.strip()) > len(normalized_key) and normalized_key in item.strip().lower()
        for item in menu_keys
    )

