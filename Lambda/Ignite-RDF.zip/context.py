from contextvars import ContextVar
from typing import Any, Dict

SHARED_MODULES_DEFAULT = ("applications.json", "queues.json", "contact_flows.json", "ivr-callflow.csv")

DEFAULTS: Dict[str, Any] = {
    "instance_arn": "",
    "instance_id": "",
    "s3_bucket_name": "",
    "account": "",
    "region": "",
    "contact_id": "",
    "ou": "",
    "channel": "",
    "ani": "",
    "dnis": "",
    "queue_id": "",
    "business_hours": True,
    "app_folder": "",
    "shared_modules": None
}

class Context:
    def __init__(self) -> None:
        for name, default in DEFAULTS.items():
            setattr(self, name, ContextVar(name, default=default))

    def reset(self) -> None:
        for name, default in DEFAULTS.items():
            cv = getattr(self, name)
            if name == "shared_modules":
                cv.set(list(SHARED_MODULES_DEFAULT))   # fresh list each invoke
            else:
                cv.set(default)

    def set_many(self, **kwargs: Any) -> None:
        for name, value in kwargs.items():
            cv = getattr(self, name, None)
            if not isinstance(cv, ContextVar):
                raise AttributeError(f"Unknown context field: {name}")
            cv.set(value)

    def snapshot(self) -> Dict[str, Any]:
        return {name: getattr(self, name).get() for name in DEFAULTS.keys()}

ctx = Context()

# session could now be referenced as either session.var or session['var']
class Session(dict):
    def __getattr__(self, k): return self.get(k)
    def __setattr__(self, k, v): self[k] = v