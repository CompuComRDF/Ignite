import json
import boto3
import config
import util

def chkAppCode(appCode):
    appCodeValue=''
    jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, config.sysAdminFile, 'KEY')
    for j in jsonContent:
        if jsonContent[j]['KEY'] == 'APPCODE':
            appCodeValue = jsonContent[j]['VALUE']
    return(appCode==appCodeValue)
    
def getBroadcast(broadcastID):
    broadcastKey='BM0' + str(broadcastID)
    jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, config.sysAdminFile, 'KEY')
    for j in jsonContent:
        if jsonContent[j]['KEY'] == broadcastKey:
            broadcastMessage = jsonContent[j]['VALUE']
    if broadcastMessage == 'na':
        broadcastStatus = 'disabled'
    else:
        broadcastStatus = 'enabled'
    return(broadcastStatus)
    
def setBroadcastOn(broadcastID):
    body='KEY,VALUE\n'
    broadcastKey='BM0' + str(broadcastID)
    jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, config.sysAdminFile, 'KEY')
    for j in jsonContent:
        if jsonContent[j]['KEY'] == broadcastKey:
            body = body + broadcastKey + ',' + 'tts:' + broadcastKey + '\n'
        else:
            body = body + jsonContent[j]['KEY'] + ',' +  jsonContent[j]['VALUE'] + '\n'           
    return(updateS3(body))

def setBroadcastOff(broadcastID):
    body='KEY,VALUE\n'
    broadcastKey='BM0' + str(broadcastID)
    jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, config.sysAdminFile, 'KEY')
    for j in jsonContent:
        if jsonContent[j]['KEY'] == broadcastKey:
            body = body + broadcastKey + ',' + 'na\n'
        else:
            body = body + jsonContent[j]['KEY'] + ',' +  jsonContent[j]['VALUE'] + '\n'           
    return(updateS3(body))
    
def chkVoiceMail():
    return(util.getSysAdmin('VM'))

def setVoiceMailOn():
    result='success'
    body='KEY,VALUE\n'
    jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, config.sysAdminFile, 'KEY')
    for j in jsonContent:
        if jsonContent[j]['KEY'] == 'VM':
            body = body + 'VM,TRUE\n'
        else:
            body = body + jsonContent[j]['KEY'] + ',' +  jsonContent[j]['VALUE'] + '\n'           
    return(updateS3(body))

def setVoiceMailOff():
    result='success'
    body='KEY,VALUE\n'
    jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, config.sysAdminFile, 'KEY')
    for j in jsonContent:
        if jsonContent[j]['KEY'] == 'VM':
            body = body + 'VM,FALSE\n'
        else:
            body = body + jsonContent[j]['KEY'] + ',' +  jsonContent[j]['VALUE'] + '\n'           
    return(updateS3(body))

def getDynamicMenu(dynamicMenuID, dynamicMenuOption):
    dynamicMenuStatus = 'invalid'
    dynamicMenuKey='DM' + str(dynamicMenuID)
    dynamicMenu = ''
    jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, config.sysAdminFile, 'KEY')
    for j in jsonContent:
        if jsonContent[j]['KEY'] == dynamicMenuKey:
            dynamicMenu = util.convert(jsonContent[j]['VALUE'])

    if dynamicMenu:
        for n in dynamicMenu:
            if dynamicMenuOption in n:
                if 'x' in n:
                    dynamicMenuStatus = 'disabled'
                else:
                    dynamicMenuStatus = 'enabled'
    return(dynamicMenuStatus)

def setDynamicMenuOn(dynamicMenuID, dynamicMenuOption):
    updatedMenu={}
    result = "error"
    body='KEY,VALUE\n'
    dynamicMenuKey='DM' + str(dynamicMenuID)
    jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, config.sysAdminFile, 'KEY')
    for j in jsonContent:
        if jsonContent[j]['KEY'] == dynamicMenuKey:
            dynamicMenu = util.convert(jsonContent[j]['VALUE'])
            for n in list(dynamicMenu):
                if dynamicMenuOption + 'x' in n:
                    result = 'found'
                    updatedMenu[dynamicMenuOption] = dynamicMenu[n]
                else:
                    updatedMenu[n]=dynamicMenu[n]
            
            dynamicMenuRecord = '|'.join(i + ':' + updatedMenu[i] for i in updatedMenu)        
            body = body + dynamicMenuKey + ',' + dynamicMenuRecord + '\n'                    
        else:
            body = body + jsonContent[j]['KEY'] + ',' +  jsonContent[j]['VALUE'] + '\n'

    if result == 'found':
        result = updateS3(body)
        
    return(result)

def setDynamicMenuOff(dynamicMenuID, dynamicMenuOption):
    updatedMenu={}
    result = "error"
    body='KEY,VALUE\n'
    dynamicMenuKey='DM' + str(dynamicMenuID)
    jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, config.sysAdminFile, 'KEY')
    for j in jsonContent:
        if jsonContent[j]['KEY'] == dynamicMenuKey:
            dynamicMenu = util.convert(jsonContent[j]['VALUE'])
            for n in list(dynamicMenu):
                if dynamicMenuOption in n:
                    result = 'found'
                    updatedMenu[dynamicMenuOption + 'x'] = dynamicMenu[n]
                else:
                    updatedMenu[n]=dynamicMenu[n]
                    
            dynamicMenuRecord = '|'.join(i + ':' + updatedMenu[i] for i in updatedMenu)
            body = body + dynamicMenuKey + ',' + dynamicMenuRecord + '\n'   
        else:
            body = body + jsonContent[j]['KEY'] + ',' +  jsonContent[j]['VALUE'] + '\n'
    
    if result == 'found':
        result = updateS3(body)
        
    return(result)

def updateS3(body):
    result='success'
    try:
        s3Resource = boto3.resource('s3', config.region)
        s3Resource.Object(config.s3BucketName, 'config/' + config.sysAdminFile).put(Body=body)
    except Exception as ex1:
        result='error'
        print(str(ex1)) 
    return(result)
