import os, time
os.environ['TZ'] = 'US/Eastern'
time.tzset()
time.tzname

#traceMode = True
tenant = ''
instanceARN = ''
instanceID=''
contactID=''
dnis = ''
ani = ''
region = ''
account = ''
s3BucketName = ''
language = 'en-US'
queueID = ''
holidayFile = ''
tenantHoliday = ''
sysAdminFile = ''
businessHours = False
globalMenuRepeat = ''
globalMenuPrevious = ''
globalZeroPrompt = ''
globalInputTerm = ''
speechAnalytics = 'off'
chatAnalytics = 'off'
techDifficulties = {
    'prodFailure':'We are currently experiencing technical difficulties.  Please try again later.  Thank you for calling.  Goodbye',
    'appFailure': 'Application Failure.  The error I found is',
    'initFailure':'Initialization Failure.  The error I found is'
    }
rdfBuiltIns = {
    '__builtins__':{ 
        'min': min, 
        'Exception': Exception,
        'FloatingPointError': FloatingPointError,
        'IndentationError': IndentationError,
        'IndexError': IndexError,
        'KeyError': KeyError,
        'NameError': NameError,
        'None': None,
        'OverflowError': OverflowError,
        'PermissionError': PermissionError,
        'RecursionError': RecursionError,
        'ReferenceError': ReferenceError,
        'RuntimeError': RuntimeError,
        'RuntimeWarning': RuntimeWarning,
        'SyntaxError': SyntaxError, 
        'SyntaxWarning': SyntaxWarning, 
        'SystemError': SystemError, 
        'SystemExit': SystemExit, 
        'TabError': TabError,
        'TimeoutError': TimeoutError, 
        'True': True, 
        'TypeError': TypeError, 
        'UnboundLocalError': UnboundLocalError,
        'UserWarning': UserWarning, 
        'ValueError': ValueError,
        'Warning': Warning, 
        'ZeroDivisionError': ZeroDivisionError,
        'abs': abs,
        'all': all,
        'any': any,
        'ascii': ascii,
        'bin': bin,
        'bool': bool,
        'bytearray': bytearray,
        'bytes': bytes,
        'chr': chr,
        'complex': complex,
        'dict': dict,
        'divmod': divmod,
        'enumerate': enumerate,
        'float': float,
        'format': format,
        'frozenset': frozenset,
        'int': int,
        'iter': iter,
        'len': len,
        'list': list,
        'map': map,
        'max': max,
        'min': min,
        'object': object,
        'oct': oct,
        'range': range,
        'reversed': reversed,
        'round': round,
        'set': set,
        'setattr': setattr,
        'slice': slice,
        'sorted': sorted,
        'str': str,
        'sum': sum,
        'tuple': tuple,
        'type': type,
        'vars': vars
        }
    }
