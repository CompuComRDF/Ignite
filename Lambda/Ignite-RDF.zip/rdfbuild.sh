rm ../Ignite-RDF.zip
zip -r -X ../Ignite-RDF.zip . 
