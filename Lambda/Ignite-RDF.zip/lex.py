import json
import util
from context import ctx

def get_intent(session, parameters):
    error_response = {'error_prompt': None, 'error_prompt_type': None, 'max_action': None}
    session = _init_lex(session, parameters)

    lex_full_intent = parameters.get('intent', '')

    if lex_full_intent['IntentName'] == 'FallbackIntent':
        if not lex_full_intent['AlternativeIntents']:
            lex_intent = 'timeout'
        else:
            lex_intent = 'invalid'
    else:
        lex_intent = lex_full_intent['IntentName']

    if lex_intent == "timeout":
        session, error_response = _handle_timeout(session)
    
    elif lex_intent == 'invalid':
        session, error_response = _handle_invalid(session)

    else:
        session['lex_intent'] = lex_intent

        try:
            session = _handle_lex_intent(session, lex_intent)
            session['slots'] = lex_full_intent.get('Slots', {})

        except Exception:
            # Generic invalid handling
            session, error_response = _handle_invalid(session)

    return {
        'statusCode': 200,
        'blockParam': session['blockParam'],
        'blockAction': session['blockAction'],
        'menuAttempts': session['lex_attempts'],
        'menuLoop': session['lex_loop'],
        'language': str(session['language']),
        'inputTimeout': session['input_timeout'],
        'errorPrompt': error_response['error_prompt'],
        'errorPromptType': error_response['error_prompt_type'],
        'maxAction': error_response['max_action'],
        'globalMenuAttempts': str(session['globalMenuAttempts']),
        'barge': session['barge'],
        'resetQueue': 'false',
        'session': json.dumps(session),
        'body': json.dumps('Success!')
    }

def _init_lex(session, parameters):
    session['lex_loop'] = "true"
    if not isinstance(session.get("lex_options"), dict):    
        session["lex_options"] = util.convert(parameters.get("blockAction"))
    session['lex_attempts'] = _get_lex_attempts(session)

    return session

def _get_lex_attempts(session):
    return int(
        session.get('lex_options', {}).get(
            'attempts',
            session.get('local_lex_attempts', session['globalMenuAttempts'])
        )
    )

def _handle_timeout(session):
    error_type = 'timeout'
    error_response = {'error_prompt': None, 'error_prompt_type': None, 'max_action': None}

    try:
        session['blockAction'] = session['lex_options'][error_type]
        session.pop('lex_options', None)
    except Exception:
        session, error_response = _error_handle(session, error_type)
        session['prompt_index'] = 0
        session['blockAction'] = "error"

    session['slots'] = ""
    return session, error_response

def _handle_invalid(session):
    error_type = 'invalid'
    error_response = {'error_prompt': None, 'error_prompt_type': None, 'max_action': None}    
    try:
        session['blockAction'] = session['lex_options'][error_type]
        session.pop('lex_options', None)
    except Exception:
        session, error_response = _error_handle(session, error_type)
        session['prompt_index'] = 0
        session['blockAction'] = "error"

    session['slots'] = ""
    return session, error_response

def _handle_lex_intent(session, lex_intent):
    session['blockAction'] = session['lex_options'][lex_intent]
    session.pop('lex_options', None)

    return session

def _error_handle(session, error_attempt):
    error_prompt = ''
    error_prompt_type = ''
    max_action = ''

    prompt_list_type = 'globalTimeoutPrompt' if error_attempt == 'timeout' else 'globalInvalidPrompt'

    lex_attempt = int(session['lex_attempt'])

    if lex_attempt < int(session['lex_attempts']) and error_attempt != 'max':
        session['lex_loop'] = "true"
        attempt = int(session[error_attempt])

        prompt_list = session[prompt_list_type].split("|")
        prompt_item = util.convert(prompt_list[attempt])

        for key, value in prompt_item.items():
            if key == 'wav':
                error_prompt = f"s3://{ctx.s3_bucket_name.get()}/prompts/{session['language']}/{value}.wav"
                error_prompt_type = 'wav'
            else:
                tts_content = util.read_cache(
                    ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(),
                    'ivr-tts.csv', 'LABEL'
                )
                error_prompt_type = session['language']
                error_prompt = f"<speak>{tts_content[value][session['language']]}</speak>"

        session['lex_attempt'] = str(lex_attempt + 1)
        session[error_attempt] = str(attempt + 1)
        session['ivrDisposition'] = util.add_disposition(
            session['ivrDisposition'], f"{session['blockKey']}-{error_attempt}", log=True
        )

    else:
        session['lex_loop'] = "false"
        session['ivrDisposition'] = util.add_disposition(
            session['ivrDisposition'], f"{session['blockKey']}-MaxTries", log=True
        )

        try:
            max_action = session['lex_options']['maxaction']
            session.pop('lex_options', None)
            error_prompt_type = 'skip'
        except Exception:
            max_action = session['globalMaxtriesAction']

        prompt_item = util.convert(session['globalMaxtriesPrompt'])
        for key, value in prompt_item.items():
            if key == 'wav':
                error_prompt = f"s3://{ctx.s3_bucket_name.get()}/prompts/{session['language']}/{value}.wav"
                error_prompt_type = 'wav'
            else:
                tts_content = util.read_cache(
                    ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(),
                    'ivr-tts.csv', 'LABEL'
                )
                error_prompt_type = session['language']
                error_prompt = f"<speak>{tts_content[value][session['language']]}</speak>"

    return session, {
        'error_prompt': error_prompt,
        'error_prompt_type': error_prompt_type,
        'max_action': max_action
    }
