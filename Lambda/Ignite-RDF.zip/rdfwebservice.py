import json
import config
import util
import zeep
import traceback
import operator


def rest(blockParam, session):
    import requests

    #url = 'https://api_url'
    #headers = {'Accept': 'application/json'}
    #auth = HTTPBasicAuth('apikey', '1234abcd')
    #files = {'file': open('filename', 'rb')}
    #req = requests.get(url, headers=headers, auth=auth, files=files)
    try:
        restApi = blockParam['api']
        restOperation = blockParam['operation']
        #restSecretID = blockParam['secret']
        
        if restOperation == 'get':
            response  = requests.get(restApi)
            if response.status_code == 200:
                session['restResponse'] = response.json()
                print('#####   REST API SUCCESS: ' + str(restApi) + ' OPERATION: ' + restOperation + ' WITH RESPONSE: ' + str(session['restResponse']) + '   #####')
            else:
                raise Exception(response.status_code)

        if restOperation == 'post':
            restPayload = blockParam['payload']
            response = requests.post(restApi, json=restPayload)
            if response.status_code == 201:
                session['restResponse'] = response.json()
                print('#####   REST API SUCCESS: ' + str(restApi) + ' OPERATION: ' + restOperation + ' WITH RESPONSE: ' + str(session['restResponse']) + '   #####')
            else:
                raise Exception(response.status_code)

        if restOperation == 'put':
            restPayload = blockParam['payload']
            response = requests.put(restApi, json=restPayload)
            if response.status_code == 200:
                session['restResponse'] = response.json()
                print('#####   REST API SUCCESS: ' + str(restApi) + ' OPERATION: ' + restOperation + ' WITH RESPONSE: ' + str(session['restResponse']) + '   #####')
            else:
                raise Exception(response.status_code)

        if restOperation == 'patch':
            restPayload = blockParam['payload']
            response = requests.patch(restApi, json=restPayload)
            if response.status_code == 200:
                session['restResponse'] = response.json()
                print('#####   REST API SUCCESS: ' + str(restApi) + ' OPERATION: ' + restOperation + ' WITH RESPONSE: ' + str(session['restResponse']) + '   #####')
            else:
                raise Exception(response.status_code)

        if restOperation == 'delete':
            response = requests.delete(restApi)
            if response.status_code == 200:
                session['restResponse'] = response.json()
                print('#####   REST API SUCCESS: ' + str(restApi) + ' OPERATION: ' + restOperation + ' WITH RESPONSE: ' + str(session['restResponse']) + '   #####')
            else:
                raise Exception(response.status_code)

    except Exception as Ex1:
        session['restResponse'] = 'error'
        print('#####   REST API FAILED: ' + str(restApi) + ' OPERATION: ' + restOperation + ' WITH EXCEPTION: ' + str(Ex1) + '   #####')
        print('#####   TRACEBACK MESSAGE: ' + traceback.format_exc() + '   #####')

    return(session)

def soap(blockParam, session):
    try:
        wsdl = blockParam['wsdl']
        soapOperation = blockParam['operation']
        runSoapRequest = "session['soapResponse'] = soap.service." 
        
        try:
            soapVersion = blockParam['version']
        except:
            soapVersion = '1.2'

        soap = zeep.Client(wsdl=wsdl)
        for service in soap.wsdl.services.values():
            serviceName = service.name
            for port in service.ports.values():
                if soapVersion == "1.1":
                    if (type(port.binding) == zeep.wsdl.bindings.soap.Soap11Binding):
                        portName = port.name

                        operations = sorted(
                            port.binding._operations.values(),
                            key=operator.attrgetter('name'))

                        for operation in operations:
                            if operation.name in soapOperation:
                                runSoapRequest += soapOperation 

                        if soapOperation not in runSoapRequest:
                            raise Exception ("Operation Not Found")
                else:
                    if (type(port.binding) == zeep.wsdl.bindings.soap.Soap11Binding):
                        portName = port.name

                        operations = sorted(
                            port.binding._operations.values(),
                            key=operator.attrgetter('name'))

                        for operation in operations:
                            if operation.name in soapOperation:
                                runSoapRequest += soapOperation 

                        if soapOperation not in runSoapRequest:
                            raise Exception ("Operation Not Found")

        print('#####   CALLING WEB SERVICE: ' + wsdl + ' SERVICE: ' + serviceName + ' PORT: ' + portName +  ' OPERATION: ' + runSoapRequest + '   #####')
        localBuiltIns = {
            'session': session,
            'soap': soap,
        }

        #NEED ADDITIONAL WORK HERE FOR CERTIFICATES
        try:
            #from zeep.wsse.username import UsernameToken
            certificate = soapContent['certificate']['VALUE']
            certFile = util.getCertificate(config.region, config.s3BucketName, config.instanceID, certificate)
            from zeep.transports import Transport
            import requests
            soapSession = requests.Session()
            soapSession.cert = certFile
            transport = Transport(session=soapSession)
            soap = zeep.Client(wsdl=wsdl, service_name=serviceName, port_name=portName, transport=transport)
            #soap = zeep.Client(wsdl=wsdl, service_name=service, port_name=port, transport=transport, wsse=UsernameToken('username', 'password'))
            exec(runSoapRequest, config.rdfBuiltIns, localBuiltIns)
            print('#####   WEB SERVICE SUCCESS WITH CERTIFICATE: ' + str(session['soapResponse']) + '   #####')
        except:
            #from zeep.wsse.username import UsernameToken
            #soap = zeep.Client(wsdl=wsdl, service_name=service, port_name=port, transport=transport, wsse=UsernameToken('username', 'password'))
            soap = zeep.Client(wsdl=wsdl, service_name=serviceName, port_name=portName)
            exec(runSoapRequest, config.rdfBuiltIns, localBuiltIns)
            session['soapResponse'] = str(session['soapResponse']) 
            session['soapResponse'] = ''.join(session['soapResponse'].splitlines()) 
            session['soapResponse'] = session['soapResponse'].replace("'", '"')
            print('#####   WEB SERVICE SUCCESS: ' + str(session['soapResponse']) + '   #####')
            try:
                session['soapResponse'] = json.loads(session['soapResponse'])
            except:
                pass

    except Exception as ex1:
        print('#####   WEB SERVICE FAILED: ' + str(ex1) + '   #####')
        print('#####   TRACEBACK MESSAGE: ' + traceback.format_exc() + '   #####')
        session['soapResponse']='error'
    return(session)
