import json
from context import ctx
import util
import traceback
import operator
import boto3
from botocore.exceptions import ClientError
import zeep
from zeep import Client, helpers as zeep_helpers
from zeep.wsse import UsernameToken
from zeep.transports import Transport
import requests
from zeep.helpers import serialize_object
from zeep.plugins import HistoryPlugin
from lxml import etree
from zeep.exceptions import Fault, XMLParseError, ValidationError
from requests.exceptions import RequestException
from lxml.etree import XMLSyntaxError
import logger
from safe_runner import SafeRunner
from zeep.wsse.username import UsernameToken
from zeep.wsdl.bindings.soap import Soap11Binding, Soap12Binding
import re

def rest(blockParam, session):
    #import requests

    #url = 'https://api_url'
    #headers = {'Accept': 'application/json'}
    #auth = HTTPBasicAuth('apikey', '1234abcd')
    #files = {'file': open('filename', 'rb')}
    #req = requests.get(url, headers=headers, auth=auth, files=files)
    try:
        restApi = blockParam['api']
        restOperation = blockParam['operation']
        #restSecretID = blockParam['secret']
        
        if restOperation == 'get':
            response  = requests.get(restApi)
            if response.status_code == 200:
                session['restResponse'] = response.json()
                logger.info(f"✅ REST API SUCCESS: {restApi} OPERATION: {restOperation} WITH RESPONSE: {session['restResponse']}")
            else:
                raise Exception(response.status_code)

        if restOperation == 'post':
            restPayload = blockParam['payload']
            response = requests.post(restApi, json=restPayload)
            if response.status_code == 201:
                session['restResponse'] = response.json()
                logger.info(f"✅ REST API SUCCESS: {restApi} OPERATION: {restOperation} WITH RESPONSE: {session['restResponse']}")
            else:
                raise Exception(response.status_code)

        if restOperation == 'put':
            restPayload = blockParam['payload']
            response = requests.put(restApi, json=restPayload)
            if response.status_code == 200:
                session['restResponse'] = response.json()
                logger.info(f"✅ REST API SUCCESS: {restApi} OPERATION: {restOperation} WITH RESPONSE: {session['restResponse']}")
            else:
                raise Exception(response.status_code)

        if restOperation == 'patch':
            restPayload = blockParam['payload']
            response = requests.patch(restApi, json=restPayload)
            if response.status_code == 200:
                session['restResponse'] = response.json()
                logger.info(f"✅ REST API SUCCESS: {restApi} OPERATION: {restOperation} WITH RESPONSE: {session['restResponse']}")
            else:
                raise Exception(response.status_code)

        if restOperation == 'delete':
            response = requests.delete(restApi)
            if response.status_code == 200:
                session['restResponse'] = response.json()
                logger.info(f"✅ REST API SUCCESS: {restApi} OPERATION: {restOperation} WITH RESPONSE: {session['restResponse']}")
            else:
                raise Exception(response.status_code)

    except Exception as Ex1:
        session['restResponse'] = 'error'
        logger.error(f"❌ REST API FAILED: {restApi} OPERATION: {restOperation} WITH EXCEPTION: {str(Ex1)}")
        logger.error(f"❌ TRACEBACK MESSAGE: {traceback.format_exc()}")

    return(session)

def soap(blockParam, session):
    # ------------- helpers (local to keep your function self-contained) -------------
    def _safe_eval_if_session_expr(expr):
        if isinstance(expr, str) and "session" in expr:
            try:
                runner_tmp = SafeRunner.from_defaults(local_built_ins={'session': session, 'json': json})
                return runner_tmp.eval_expr(expr)
            except Exception:
                return expr
        return expr

    def _normalize_params(raw):
        if isinstance(raw, dict):
            return raw
        if isinstance(raw, str):
            s = raw.strip()
            if not s:
                return None
            try:
                obj = json.loads(s)
                return obj if isinstance(obj, dict) else None
            except Exception:
                return None
        return None

    def _find_operation_and_validate_version(client, version, op_name):
        has_valid_port = False
        for svc in client.wsdl.services.values():
            for port in svc.ports.values():
                if version == "1.1" and isinstance(port.binding, Soap11Binding):
                    has_valid_port = True
                if version != "1.1" and isinstance(port.binding, Soap12Binding):
                    has_valid_port = True
        if not has_valid_port:
            raise Exception(f"No matching SOAP {version} binding found.")
        op = getattr(client.service, op_name, None)
        if op is None:
            raise Exception("Operation Not Found")
        return op

    def _maybe_wrap_params_for_single_body(op, params_dict):
        """If the operation body has a single wrapper element (e.g. 'input'),
        and caller provided a flat dict, wrap it as {wrapper: dict} to match WSDL."""
        if not isinstance(params_dict, dict):
            return params_dict
        try:
            parts = list(op.input.body.type.elements)  # [(name, element), ...]
            if len(parts) == 1:
                wrapper = parts[0][0]
                if wrapper not in params_dict:
                    return {wrapper: params_dict}
        except Exception:
            pass
        return params_dict

    def _log_history_one_line(history):
        try:
            for label, item in (
                ("✅ SOAP REQUEST", getattr(history, "last_sent", None)),
                ("✅ SOAP RESPONSE", getattr(history, "last_received", None)),
            ):
                env = None

                # Shape 1: direct dict with 'envelope'
                if isinstance(item, dict) and "envelope" in item:
                    env = item["envelope"]

                # Shape 2: object with .envelope
                elif hasattr(item, "envelope"):
                    env = item.envelope

                # Shape 3: list/tuple -> inspect last entry
                elif isinstance(item, (list, tuple)) and item:
                    candidate = item[-1]
                    if isinstance(candidate, dict) and "envelope" in candidate:
                        env = candidate["envelope"]
                    elif hasattr(candidate, "envelope"):
                        env = candidate.envelope
                    elif isinstance(candidate, tuple) and len(candidate) == 2:
                        raw = candidate[1]
                        if isinstance(raw, (bytes, bytearray, str)):
                            try:
                                env = etree.fromstring(raw if isinstance(raw, (bytes, bytearray)) else raw.encode("utf-8"))
                            except Exception:
                                env = None

                if env is None:
                    continue

                #one_line = etree.tostring(env, pretty_print=False, encoding="unicode").replace("\n", "").replace("\r", "")

                MAX_LEN = 20000

                one_line = etree.tostring(env, pretty_print=False, encoding="unicode").replace("\n","").replace("\r","")

                # Redact secrets in namespaced tags like <wsse:Password>…</wsse:Password>
                one_line = re.sub(
                    r'<(?P<name>(?:[\w.-]+:)?(?:Password|Pass|Token|AccessToken|ApiKey|Secret|Authorization))\b[^>]*>.*?</(?P=name)>',
                    r'<\g<name>***REDACTED***</\g<name>>',
                    one_line,
                    flags=re.I | re.DOTALL,
                )

                # Redact secrets in attributes: password="…", token='…', api-key="…"
                one_line = re.sub(
                    r'(\b(?:password|pass|token|access[_-]?token|api[_-]?key|secret|authorization)\b\s*=\s*)(["\'])(?:(?!\2).)*\2',
                    r'\1\2***REDACTED***\2',
                    one_line,
                    flags=re.I,
                )

                # Truncate if too long
                if len(one_line) > MAX_LEN:
                    one_line = one_line[:MAX_LEN] + "…(truncated)"

                msg = f"{label} --- {one_line}"

                # Use print so it shows up even if logger level filters INFO
                logger.info(msg)

        except Exception as log_err:
            try:
                logger.exception(f"History logging failed: {log_err}")
            except Exception:
                print(f"History logging failed: {log_err}")

    # -------------------------------------------------------------------------------

    soapVersion = blockParam.get('version', '1.2')
    session['soapResponse'] = 'error'  # default until success

    # Build runner WITHOUT zeep client first (prevents UnboundLocal issues)
    runner = SafeRunner.from_defaults(local_built_ins={'session': session, 'json': json})

    try:
        # --- Resolve WSDL / credentials / params the same way you did ---
        if 'secret' in blockParam:
            wsdl = get_soap_secret(blockParam['secret'], "WSDL")
            username = get_soap_secret(blockParam['secret'], "USERNAME")
            password = get_soap_secret(blockParam['secret'], "PASSWORD")
        else:
            wsdl = _safe_eval_if_session_expr(blockParam.get('wsdl', ''))
            username = _safe_eval_if_session_expr(blockParam.get('username', ''))
            password = _safe_eval_if_session_expr(blockParam.get('password', ''))

        if not wsdl:
            raise Exception("WSDL is required")

        soapOperation = blockParam['operation']  # let this raise if missing 
        # param may be literal or "session[...]"
        try:
            if 'param' in blockParam and isinstance(blockParam['param'], str) and 'session' in blockParam['param']:
                params = runner.eval_expr(blockParam['param'])
            else:
                params = blockParam.get('param', '')
        except Exception:
            params = ''

        # Normalize params to dict (if possible)
        params = _normalize_params(params)

        # --- Build zeep client + history, then inject into SafeRunner as 'soap' ---
        http_sess = requests.Session()
        transport = Transport(session=http_sess)
        history = HistoryPlugin()

        soap_client = Client(wsdl, transport=transport, plugins=[history], wsse=UsernameToken(username or "", password or ""))

        # (This is a workaround and may need to be changed for other implementations)
        try:
            soap_client.service._binding_options['address'] = str(wsdl).replace('?wsdl','')
        except Exception:
            pass

        # Validate binding for requested version; also gets us the bound operation for introspection
        operation = _find_operation_and_validate_version(soap_client, soapVersion, soapOperation)

        # If the body expects a single wrapper (e.g., 'input') and the caller gave a flat dict, wrap it.
        params = _maybe_wrap_params_for_single_body(operation, params)

        # Update/replace runner so that 'soap' exists inside the sandbox for string exec
        runner = SafeRunner.from_defaults(local_built_ins={'session': session, 'json': json, 'soap': soap_client})

        # --- Build the SAME exec string you used before ---
        runSoapRequest = f"session['soapResponse'] = soap.service.{soapOperation}"
        if isinstance(params, dict):
            runSoapRequest = f"{runSoapRequest}({repr(params)})"
        else:
            runSoapRequest = f"{runSoapRequest}()"

        logger.info(f"✅ CALLING WEB SERVICE: {wsdl} OPERATION: {runSoapRequest}")

        # Execute in the sandbox 
        try:
            runner.exec_stmt(runSoapRequest)
            clean_response = zeep_helpers.serialize_object(session['soapResponse'])
            session['soapResponse'] = clean_response
            logger.info(f"✅ WEB SERVICE SUCCESS: {json.dumps(clean_response)}")
            session['contactDisposition'] = util.add_disposition(session.get('contactDisposition',''),'Soap:Success')
        except Fault as fault:
            session['contactDisposition'] = util.add_disposition(session.get('contactDisposition',''),'Soap:Failed')
            session['soapResponse'] = 'error'
            logger.error(f"❌ WEB SERVICE FAULT: {str(fault)}")
        except (XMLParseError, ValidationError) as parse_err:
            session['contactDisposition'] = util.add_disposition(session.get('contactDisposition',''),'Soap:Failed')
            session['soapResponse'] = 'error'
            logger.error(f"❌ SOAP XML ERROR: {str(parse_err)}")
        except RequestException as req_err:
            session['contactDisposition'] = util.add_disposition(session.get('contactDisposition',''),'Soap:Failed')
            session['soapResponse'] = 'error'
            logger.error(f"❌ TRANSPORT  ERROR: {str(req_err)}")
        except Exception as ex_exec:
            session['contactDisposition'] = util.add_disposition(session.get('contactDisposition',''),'Soap:Failed')
            session['soapResponse'] = 'error'
            logger.error(f"❌ WEB SERVICE UNEXPECTED ERROR (exec): {str(ex_exec)}")

        # One-line SOAP request/response (safe)
        _log_history_one_line(history)

    except Exception as ex1:
        session['contactDisposition'] = util.add_disposition(session.get('contactDisposition',''),'Soap:Failed')
        logger.error(f"❌ WEB SERVICE FAILED: {str(ex1)}")
        logger.error(f"❌ TRACEBACK MESSAGE: {traceback.format_exc()}")
        session['soapResponse'] = 'error'

    return session

def simulate(blockParam, session):
    if 'session' in blockParam['key']:
        key = eval(blockParam['key'])
    else:
        key = blockParam['key']

    logger.info(f"✅ SIMULATE KEY: {key}")
    s3_client = boto3.client('s3', ctx.region.get())
    s3_folder = ctx.app_folder.set('/config/')

    try:
        response = s3_client.get_object(Bucket=ctx.s3_bucket_name.get(), Key=s3_folder + key + '.json')
        file_content = response['Body'].read().decode('utf-8')
        session['soapResponse']=json.loads(file_content)
        logger.info(f"✅ SIMULATE SUCCESS: {session['soapResponse']}")

    except Exception as ex1:
        try:
            response = s3_client.get_object(Bucket=ctx.s3_bucket_name.get(), Key=s3_folder + 'NotFound.json')
            file_content = response['Body'].read().decode('utf-8')
            session['soapResponse']=json.loads(file_content)

        except Exception as ex1:
            logger.error(f"❌ SIMULATION FAILED: {str(ex1)}")
            logger.error(f"❌ TRACEBACK MESSAGE: {traceback.format_exc()}")
            session['soapResponse']='error'

    return(session)


def get_soap_secret(secret_prefix, secret_key):
    secret_name = secret_prefix + '_' + ctx.ou.get().upper()
    secret_value = ''

    # Create a Secrets Manager client
    session = boto3.session.Session()
    secret_client = session.client(
        service_name='secretsmanager',
        region_name=ctx.region.get()
    )

    try:
        get_secret_value_response = secret_client.get_secret_value(
            SecretId=secret_name
        )

    except Exception as ex1:
        logger.error(f"❌ SOAP SECRET FAILED: {str(ex1)}")

    secret_value = json.loads(get_secret_value_response['SecretString'])[secret_key]

    return(secret_value)
