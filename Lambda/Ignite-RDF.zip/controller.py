import json
import boto3
from context import ctx
import datetime
import traceback
import os
import re
import util
import queues
import rdfwebservice
import logger
import prompts
from safe_runner import SafeRunner

ERROR_BLOCK_KEYS = ['ERROR', 'ADMINERR']
RETURN_BLOCK_KEYS = ['RETURN', 'SETMETRICS', 'SEQUENCERETURN']
SUB_BLOCK_TYPES = ['SUBFLOW', 'SUBMOD', 'RETURN']
LOCAL_BLOCK_TYPES = ['EXEC', 'EVAL', 'USERDATA', 'CASE', 'SUBFLOW', 'SUBMOD', 'RETURN', 'PROFILE', 'SETMETRICS', 'SIMULATE', 'SEQUENCERETURN']
IVR_BLOCK_TYPES = ['MENU', 'PLAY', 'INPUT', 'RECORD', 'TREE', 'LEX']

def process_next_block(session, parameters):
    runner = SafeRunner.from_defaults(local_built_ins= {
        'ctx': ctx,
        'session': session,
        'util': util,
        'queues': queues,
        'json':json,
        're':re,
        'datetime':datetime,
        'next':next,
        '__import__': __import__
    })
        
    statusCode = 200
    statusMessage =  json.dumps('Success!')
    data = {}

    session['blockKey'] = parameters['blockKey']
    session = _reset_ivr_session(session)

    try:
        if session['blockKey'] in ERROR_BLOCK_KEYS:
            raise Exception(parameters.get('error', 'Contact Flow Error'))

        if session['initialize']:
            session = _handle_init(session)

        callflow_content = util.read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), session['fileName'], 'BLOCK', False)
        session = _get_next_block(session, callflow_content, runner)

        while True:
            while session['blockType'] in LOCAL_BLOCK_TYPES:
                session['ivrDisposition'] = util.add_disposition(session['ivrDisposition'],f"{session['blockKey']}", log=True)
                if session['blockType'] in SUB_BLOCK_TYPES:
                    session = _handle_subroutine(session, callflow_content, runner)
                    callflow_content = util.read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), session['fileName'], 'BLOCK', True)
                    session = _get_next_block(session, callflow_content, runner)

                if session['blockType']=='EXEC': session = _handle_exec(session, callflow_content, runner)
                if session['blockType']=='EVAL': session = _handle_eval(session, callflow_content, runner)
                if session['blockType']=='USERDATA': session = _handle_userdata(session, callflow_content, runner)
                if session['blockType']=='CASE': session = _handle_case(session, callflow_content, runner)
                if session['blockType']=='SETMETRICS': session = _handle_setmetrics(session, parameters)
                if session['blockType']=='SEQUENCERETURN': session = _handle_sequencereturn(session, parameters)
                if session['blockType']=='PROFILE': session = _handle_profile(session, callflow_content, runner)
                if session['blockType']=='SIMULATE': session = _handle_simulate(session, callflow_content)

                session = _get_next_block(session, callflow_content, runner)

            # All of the Block Types that follow requires Amazon Connect Contact Flow to process
            session['ivrDisposition'] = util.add_disposition(session['ivrDisposition'],f"{session['blockKey']}", log=True)
            if session['blockType']=='AGENT': session = _handle_agent(session, callflow_content)
            if session['blockType']=='REST': session = _handle_rest(session, callflow_content)
            if session['blockType']=='SOAP': session = _handle_soap(session, callflow_content)
            if session['blockType']=='CALLBACK': session = _handle_callback(session)
            if session['blockType']=='SURVEY': session = _handle_survey(session)
            if session['blockType']=='LAMBDA': session = _handle_lambda(session, callflow_content)
            if session['blockType']=='LANGUAGE': session = _handle_language(session, callflow_content, runner)
            if session['blockType']=='SETQUEUE': session = _handle_setqueue(session, runner)
            if session['blockType']=='QUEUE': session = _handle_queue(session, callflow_content)
            if session['blockType']=='XFER': session = _handle_xfer(session, runner)
            if session['blockType']=='APPLINK': session = _handle_applink(session, runner)
            if session['blockType']=='USER': session = _handle_user(session, runner)
            if session['blockType']=='CONTACT_FLOW': session = _handle_contactflow(session, runner)
            if session['blockType'] in IVR_BLOCK_TYPES: session = _handle_ivr_blocks(session, callflow_content, runner)
            if session['blockType'] != 'RETURN':
                break

        try:
            (session, data) = _set_nextaction(session, callflow_content, runner)
        except Exception as ex1:
            logger.error('❌ CONTROLLER FAILURE UNABLE TO SET NEXT ACTION: ' + str(ex1))
            logger.error('❌ TRACEBACK MESSAGE: ' + traceback.format_exc())
            session['blockAction'] = 'DISCONNECT'
    
    except Exception as ex1:
        logger.error('❌ CONTROLLER FAILURE: ' + str(ex1))
        logger.error('❌ TRACEBACK MESSAGE: ' + traceback.format_exc())
        statusCode = 500
        statusMessage = "We are experiencing technical difficulties." 
        if os.environ['TRACE_MODE'] == 'DEV':
            statusMessage += str(ex1)

    return build_controller_response(statusCode, session, data, statusMessage)

def _handle_init(session):
    session['fileName'] = "ivr-callflow.csv"
    util.connect_jitter('update_contact_attributes', {'callFlowID': ''})

    match session['function']:
        case "queue":
            session["blockKey"] = session["blockAction"]
        case "survey":
            session["blockKey"] = "SURVEY-Start"
        case _:
            session["blockKey"] = "IVR-Start"

    session['initialize'] = False

    return session

def _reset_ivr_session(session):
    session.update({
        'prompt_size': 0,
        'prompt_index': 0,
        'menu_attempt': 0,
        'lex_attempt': 0,
        'timeout': 0,
        'invalid': 0,
        'captured_input': '',
        'action_true': "na",
        'action_false': "na",
        'input_timeout': 0,
        'input_length': 0,
        'repeat_attempt': 0,
        'barge': 'true'
    })
    session.pop('menu_options', None)

    return session

def _get_next_block(session, callflow_content, runner):
    if not session['blockKey']:
        session['blockType'] = ''
        session['blockParam'] = ''
        session['blockAction'] = 'DISCONNECT'
        raise Exception('Block Key can not be empty.')

    if session['blockKey']=='init' and ctx.channel.get()=='TASK' :
        session['blockKey'] = 'VOICEMAIL-Start' 

    if session['blockKey'] not in RETURN_BLOCK_KEYS:
        if not util.check_multiple_actions(callflow_content[session['blockKey']]['ACTION']):
            if session['blockKey'] == callflow_content[session['blockKey']]['ACTION']:
                session['ivrDisposition'] = util.add_disposition(session['ivrDisposition'],f"{session['blockKey']}", log=True)
                raise Exception('Block Key can not have the same value as Block Action.')

        #This checks to see if there's a dynamic setting for blockParam (i.e. Broadcast Messages from SysAdmin)
        while 'eval:' in callflow_content[session['blockKey']]['PARAM']:
            blockParam=util.convert(callflow_content[session['blockKey']]['PARAM'])
            session['blockParam'] = runner.eval_expr(blockParam['eval'])
            #Empty or na setting, so bypass this block (i.e. Broadcast Message is not set)
            if session['blockParam'] == 'na' or session['blockParam'] == '':
                session['ivrDisposition'] = util.add_disposition(session['ivrDisposition'],f"{session['blockKey']}", log=True)
                session['blockKey'] = callflow_content[session['blockKey']]['ACTION']
            break
        else:
            session['blockParam'] = callflow_content[session['blockKey']]['PARAM']
        
        session['blockType'] = callflow_content[session['blockKey']]['TYPE']
    else:
        session['blockType'] = session['blockKey']

    return session

def _handle_subroutine(session, callflow_content, runner):
    if session['blockType'] in ['SUBFLOW', 'SUBMOD']:
        logger.info('✅ START SUBROUTINE: ' + runner.eval_expr(session['blockParam']) + ' ANI: ' + ctx.ani.get())
        session['subModule']={}
        session['subModule'][session['fileName']]=callflow_content[session['blockKey']]['ACTION']
        session['subIndex'] +=1
        session['fileName'] = runner.eval_expr(session['blockParam']) + ".csv"

        if 'menutree' in session['fileName']:
            if 'save_block_key' in session['flow_action']:
                session['blockKey'] = session['flow_action']['save_block_key']
            else:
                if ctx.business_hours.get():
                    if session['emergency_tree']:
                        session['blockKey']='E1'
                    else:
                        session['blockKey']='M1'                                
                else:
                    session['blockKey']='C1'
        else:
            session['blockKey']="START"

        if session['blockType'] == 'SUBMOD' and session['fileName'] not in session['shared_modules']:
            ctx.shared_modules.set([*ctx.shared_modules.get(), session['fileName']])
            session['shared_modules'] = ctx.shared_modules.get()

    if session['blockType'] == "RETURN":
        session['subIndex'] -=1
        i=0
        for n in session['subModule']:
            if session['subIndex'] == i:
                session['fileName'] = n
                session['blockKey']= session['subModule'][session['fileName']]
                session['blockType'] = 'HANGUP'
        i+=1
        del session['subModule'][session['fileName']]
        session['ivrDisposition'] = util.add_disposition(session['ivrDisposition'],f"{session['blockKey']}", log=True)
    
    return session

def _handle_exec(session, callflow_content, runner):
    session['blockKey'] = callflow_content[session['blockKey']]['ACTION']
    try:
        runner.exec_stmt(session['blockParam'])
    except Exception as Ex1:
        logger.error ('❌ EXEC EXCEPTION: ' + str(Ex1))

    return session

def _handle_eval(session, callflow_content, runner):
    session['blockAction'] = util.convert(callflow_content[session['blockKey']]['ACTION'])
    val = runner.eval_expr(session['blockParam'])

    is_true = (val is True) or (isinstance(val, str) and val.lower() == 'true')
    session['blockKey'] = str(session['blockAction']['true' if is_true else 'false'])
    session['evalResponse'] = val
    
    return session

def _handle_userdata(session, callflow_content, runner):
    blockParam = util.convert(callflow_content[session['blockKey']]['PARAM'].replace("'", '"'))
    result = {}

    if 'key' in blockParam:
        userDataKey = blockParam['key']
        userDataValue = str(runner.eval_expr(blockParam['value']))

        result[userDataKey] = userDataValue

    else:
        #pairs = blockParam.split('|')

        #for item in blockParam:
        #    result[item.strip()] = str(runner.eval_expr(blockParam[item].strip()))

        for item in blockParam:
            value = runner.eval_expr(blockParam[item].strip())

            # If it's a dictionary or list, convert it to JSON
            if isinstance(value, (dict, list)):
                result[item.strip()] = json.dumps(value)
            else:
                result[item.strip()] = str(value)

    util.connect_jitter('update_contact_attributes', result)
    session['blockKey'] = callflow_content[session['blockKey']]['ACTION']

    return session

def _handle_case(session, callflow_content, runner):
    foundAction=False
    caseValue = runner.eval_expr(session['blockParam'])

    session['evalResponse'] = caseValue 

    caseActions = util.convert(callflow_content[session['blockKey']]['ACTION'])
    for n in caseActions:
        if n==str(caseValue):
            foundAction=True
            session['blockKey']=caseActions[n]
    if not foundAction:
        session['blockKey']=caseActions['else']

    return session

def _handle_lambda(session, callflow_content):
    sts_client = boto3.client('sts')
    sts_session = sts_client.assume_role(RoleArn='arn:aws:iam::'+ctx.account.get()+':role/xaccount-rdf-role',
                        RoleSessionName='customer-profile-session')

    KEY_ID = sts_session['Credentials']['AccessKeyId']
    ACCESS_KEY = sts_session['Credentials']['SecretAccessKey']
    TOKEN = sts_session['Credentials']['SessionToken']

    lambda_client = boto3.client('lambda',
        region_name=ctx.region.get(),
        aws_access_key_id=KEY_ID,
        aws_secret_access_key=ACCESS_KEY,
        aws_session_token=TOKEN)

    get_function_response = lambda_client.get_function(FunctionName=session['blockParam'])
    session['blockParam'] = get_function_response['Configuration']['FunctionArn']
    session['blockAction'] = callflow_content[session['blockKey']]['ACTION']
 
    return session

def _handle_setmetrics(session, parameters):
    session['queuemetrics']={}
    session['queuemetrics']['agentsOnline'] = int(parameters.get('AGENTS_ONLINE', '0') or '0')
    session['queuemetrics']['agentsStaffed'] = int(parameters.get('AGENTS_STAFFED', '0') or '0')
    session['queuemetrics']['agentsAvailable'] = int(parameters.get('AGENTS_AVAILABLE', '0') or '0')
    session['queuemetrics']['contactsInQueue'] = round(int(parameters.get('CONTACTS_IN_QUEUE', '0') or '0')+1)
    session['queuemetrics']['OldestContactAge'] = round(int(parameters.get('OLDEST_CONTACT_AGE', '0') or '0'))
    if session['queuemetrics']['agentsOnline'] > 0:
        session['queuemetrics']['EstimatedWaitTime'] = int((session['queuemetrics']['contactsInQueue']/session['queuemetrics']['agentsOnline']) * session['queuemetrics']['OldestContactAge'])
    else:
        session['queuemetrics']['EstimatedWaitTime'] = 0

    session['blockKey'] = session['blockParam']

    return session

def _handle_sequencereturn(session, parameters):
    session['Payshield-IVR-Response-Status'] = parameters.get('Payshield-IVR-Response-Status','')
    session['Payshield-IVR-Response-Approved'] = parameters.get('Payshield-IVR-Response-Approved','')
    session['Payshield-IVR-Response-PayshieldTransactionReference'] = parameters.get('Payshield-IVR-Response-PayshieldTransactionReference','')
    session['Payshield-IVR-Response-Metadata-Moneriscanada-Receipt-Referencenum'] = parameters.get('Payshield-IVR-Response-Metadata-Moneriscanada-Receipt-Referencenum','')

    blockParam = util.convert(session['blockParam'])
    if session['Payshield-IVR-Response-Status'] == 'success':
        session['blockKey'] = str(blockParam['true'])
    elif session['Payshield-IVR-Response-Status'] == 'in-progress':
        session['blockKey'] = str(blockParam.get('timeout', str(blockParam['false'])))
    else:
        session['blockKey'] = str(blockParam['false'])
    
    return session

def _handle_profile(session, callflow_content, runner):
    sts_client = boto3.client('sts')
    sts_session = sts_client.assume_role(RoleArn='arn:aws:iam::'+ctx.account.get()+':role/xaccount-rdf-role',
                        RoleSessionName='customer-profile-session')

    KEY_ID = sts_session['Credentials']['AccessKeyId']
    ACCESS_KEY = sts_session['Credentials']['SecretAccessKey']
    TOKEN = sts_session['Credentials']['SessionToken']

    profiles_client = boto3.client('customer-profiles',
        region_name=ctx.region.get(),
        aws_access_key_id=KEY_ID,
        aws_secret_access_key=ACCESS_KEY,
        aws_session_token=TOKEN)

    blockParam = util.convert(callflow_content[session['blockKey']]['PARAM'].replace("'", '"'))
    session['blockKey'] = callflow_content[session['blockKey']]['ACTION']

    domain_name = blockParam['domain']
    data = runner.eval_expr(blockParam['data'])
    phone_number = data.get('phoneNumber','')
    acct_id = data.get('accountId','')

    try:
        get_profile_response = profiles_client.search_profiles(
            DomainName=domain_name,
            KeyName='AccountNumber',
            Values=[acct_id]
        ) 
        # Check if any profiles were found
        profiles = get_profile_response['Items']
        if len(profiles) > 1:
            logger.debug("More than one profile found")
        elif len(profiles) == 1:
            profile_id = util.update_customer_profile(profiles_client, domain_name, profiles[0]['ProfileId'], data)
            logger.debug("Updated Customer Profile: " + profile_id)
        else: #No profiles found
            profile_id = util.create_customer_profile(profiles_client, domain_name, data)
            logger.debug("Created Customer Profile: " + profile_id)

    except Exception as Ex1:
        logger.error('❌ ERROR SEARCHING CUSTOMER PROFILES: ' + str(Ex1))
    
    return session

def _handle_simulate(session, callflow_content):
    session['blockAction'] = util.convert(callflow_content[session['blockKey']]['ACTION'])
    blockParam = util.convert(callflow_content[session['blockKey']]['PARAM'].replace("'", '"'))
    
    session = rdfwebservice.simulate(blockParam, session)
    if session['soapResponse'] != 'error':
        session['blockKey'] = str(session['blockAction']['true'])
    else:
        session['blockKey'] = str(session['blockAction']['false'])
    
    return session

def _handle_agent(session, callflow_content):
    if util.check_multiple_actions(callflow_content[session['blockKey']]['ACTION']):
        session['blockAction'] = util.convert(callflow_content[session['blockKey']]['ACTION'])
        if "true" in session['blockAction']:
            session['action_true'] = session['blockAction']['true']
        if "false" in session['blockAction']:
            session['action_false'] = session['blockAction']['false']
    
    return session

def _handle_rest(session, callflow_content):
    blockAction = util.convert(callflow_content[session['blockKey']]['ACTION'])
    session['action_false'] = str(blockAction['false'])

    return session

def _handle_soap(session, callflow_content):
    blockAction = util.convert(callflow_content[session['blockKey']]['ACTION'])
    session['action_false'] = str(blockAction['false'])

    return session

def _handle_callback(session):
    session['callback_number'] = ''.join(filter(str.isdigit, session['callback_number']))
    if len(session['callback_number']) == 11:
        # Remove the first digit
        session['callback_number'] = session['callback_number'][1:]
    
    return session

def _handle_survey(session):

    return session

def _handle_ivr_blocks(session, callflow_content, runner):
    single_prompt = prompts.check_single_prompt(callflow_content[session['blockKey']]['PARAM'])
    session['prompt_index'] = 0
    if single_prompt:
        session['prompt_size'] = 1
    else:
        session['prompt_size'] = len(callflow_content[session['blockKey']]['PARAM'].split("|"))

    try:
        #Check to see if there's a barge setting.
        session['barge'] = util.convert(callflow_content[session['blockKey']]['ACTION'])['barge']                
    except:
        pass

    if session['blockType'] == "INPUT":
        action_data = util.convert(callflow_content[session['blockKey']]['ACTION'])

        session['input_timeout'] = action_data.get('seconds', 0)
        session['input_length'] = action_data.get('length', 0)

        if 'term' in action_data:
            session['InputTerm'] = action_data['term']
        else:
            session.pop('InputTerm', None)

        if 'minlength' in action_data:
            session['minlength'] = action_data['minlength']

        if 'maxlength' in action_data:
            session['maxlength'] = action_data['maxlength']

        
    if session['blockType'] == "TREE":
        session['flow_action'] = {k: v for k, v in session['flow_action'].items() if k == "save_block_key"} if "save_block_key" in session['flow_action'] else {}
        action_types = {"menu", "queue", "play", "transfer", "app", "callflow", "component", "contactflow", 'aiagent', 'lex'}
        action_type = next((k for k in action_types if k in util.convert(callflow_content[session['blockKey']]['ACTION'])), None)
        action_type_value = util.convert(callflow_content[session['blockKey']]['ACTION']).get(action_type)
        tree_prompts = callflow_content[session['blockKey']]['PARAM']

        if action_type == 'queue':  
            session['flow_action'][action_type] = action_type_value
            session['queue'] = action_type_value 
            session['contactDisposition'] = util.add_disposition(session['contactDisposition'],session['blockKey'] + ':Menu')
        elif action_type in {'menu', 'play'} and action_type_value == 'Dynamic':
            action_type = 'component'
            session['flow_action']['component'] = action_type_value
        #This is for demo purposes only
        elif action_type == 'aiagent':
            session['flow_action']['transfer'] = '12012281622'
        else:
            session['flow_action'][action_type] = action_type_value
            if action_type != 'component':
                session['contactDisposition'] = util.add_disposition(session['contactDisposition'],session['blockKey'] + ':' + action_type[:1].upper() + action_type[1:])

        if action_type not in ['menu', 'play'] and not tree_prompts:
            session['blockType'] = 'RETURN'

        if action_type == 'component' and 'save_block_key' not in session['flow_action']:
            session['flow_action']['save_block_key'] = session['blockKey']
            session['contactDisposition'] = util.add_disposition(session['contactDisposition'],session['blockKey'] + ':' + 'SelfServe')
            session['blockType'] = 'RETURN'
        else:
            session['flow_action'].pop('save_block_key', None)

        #if action_type == 'app':
        #    session['blockType'] = 'RETURN'

        try:
            session['auth'] = util.convert(callflow_content[session['blockKey']]['ACTION'])['auth']
        except:
            session['auth'] = False

        try:
            session['local_menu_attempts'] = util.convert(callflow_content[session['blockKey']]['ACTION'])['maxtries']
        except:
            session.pop('local_menu_attempts', None)
        
    if session['blockType'] == "LEX":
        action_data = util.convert(callflow_content[session['blockKey']]['ACTION'])
        bot_id = runner.eval_expr(action_data.get('bot_id'))
        alias_id = runner.eval_expr(action_data.get('alias_id'))
        session['bot_alias_arn'] = f"arn:aws:lex:{ctx.region.get()}:{ctx.account.get()}:bot-alias/{bot_id}/{alias_id}"

    return session

def _handle_language(session, callflow_content, runner):
    session['language']= runner.eval_expr(session['blockParam'])
    
    return session

def _handle_setqueue(session, runner):
    session['queue'] = runner.eval_expr(session['blockParam'])

    try:
        queue_content = util.read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), 'queues.json', 'KEY')
        ctx.queue_id.set(queue_content[session['queue']]['ID'])
        session['call_back'] = queue_content[session['queue']]['QueueTags'].get('CallBack', 'off')
        session['voice_mail'] = queue_content[session['queue']]['QueueTags'].get('VoiceMail', 'off')
        session['queue_hours'] = queue_content[session['queue']]['QueueTags'].get('QueueHours', '')
        session['queue_survey'] = queue_content[session['queue']]['QueueTags'].get('QueueSurvey', 'on')
        action = ''
        for queue_tag in queue_content[session['queue']]['QueueTags']:
            if queue_tag not in ['CallBack', 'VoiceMail', 'QueueHours', 'QueueSurvey', 'vmx3_queue_email']:
                action = f"{queue_tag}:{(queue_content[session['queue']]['QueueTags'].get(queue_tag)).strip()}"

        if action:
            session['queue_action'] = util.convert(action)
            #THIS ONE LINE OF CODE BELOW COMPLETED THE THIRD MAIN CYCLE
            session['flow_index'] = next((int(k) for k, v in session['flow_control'].items() if "Queue" in v), None)
        if session['queue_hours'] != '' and f"{session['queue_hours']}-bushours.csv" not in session['shared_modules']:
            ctx.shared_modules.set([*ctx.shared_modules.get(), f"{session['queue_hours']}-bushours.csv"])
            ctx.shared_modules.set([*ctx.shared_modules.get(), f"{session['queue_hours']}-holidays.csv"])
            session['shared_modules'] = ctx.shared_modules.get()

    except Exception as Ex1:
        #An exception occurred likely due to a new queue being recently added and not in cache.  Reload cache.
        logger.info("❌ RELOADING QUEUE CACHE DUE TO ERROR: " + str(Ex1))
        os.chdir('/tmp')
        filePath = os.path.join(os.getcwd(), ctx.instance_id.get(), 'queues.json')
        os.remove(filePath)
        queue_content = util.read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), 'queues.json', 'KEY')
        ctx.queue_id.set(queue_content[session['queue']]['ID'])

    #session['agentTip']= session['queue']
    session['agentTip'] = re.sub(r'[^A-Za-z ]+', '', session['queue'].replace('-', ' '))
    session['queue_id'] = ctx.queue_id.get()
    session['blockParam'] = ctx.instance_arn.get() + '/queue/' + session['queue_id']

    return session

def _handle_queue(session, callflow_content):
    session['contactDisposition'] = util.add_disposition(session['contactDisposition'],'Queue:' + session['queue'])

    #if util.check_multiple_actions(callflow_content[session['blockKey']]['ACTION']):
    #    session['blockAction'] = util.convert(callflow_content[session['blockKey']]['ACTION'])
    #    if "true" in session['blockAction']:
    #        callflow_content[session['blockKey']]['ACTION'] = session['blockAction']['true']
    #    if "false" in session['blockAction']:
    #        session['action_false'] = session['blockAction']['false']

    #Set Language Proficiency
    if len(session['available_languages']) > 1:
        session['blockParam'] = queues.set_routing_proficiency('Language', session['language_name'])
        session['agentTip'] = f"{session['agentTip']} {session.get('language_name', 'English')}"           
    else:
        session['blockParam'] = 'None'

    logger.info('✅ TRANSFERRING CALLER: ' + ctx.ani.get() + ' TO QUEUE: ' + session['queue'])

    return session

def _handle_xfer(session, runner):
    session['blockParam'] = "+" + runner.eval_expr(session['blockParam'])
    
    return session

def _handle_applink(session, runner):
    session['blockParam'] = f"{session['tenant_id']}-{runner.eval_expr(session['blockParam'])}"          
    
    return session

def _handle_user(session, runner):
    session['blockParam'] = runner.eval_expr(session['blockParam'])

    return session

def _handle_contactflow(session, runner):
    session['blockParam'] = util.connect_jitter('get_contactflowid', runner.eval_expr(session['blockParam']))

    return session


def _set_nextaction(session, callflow_content, runner):
    data = {}
    if 'eval' in callflow_content[session['blockKey']]['ACTION']:
        blockAction=util.convert(callflow_content[session['blockKey']]['ACTION'])
        session['blockAction'] = runner.eval_expr(blockAction['eval'])
    else:
        if session['blockType'] in ['GETMETRICS']:
            session['blockParam'] = callflow_content[session['blockKey']]['ACTION']
            session['blockAction'] = 'SETMETRICS' 

        elif session['blockType'] in ['SEQUENCE']:
            blockParam = util.convert(callflow_content[session['blockKey']]['PARAM'].replace("'", '"'))

            if 'secret' in blockParam:
                data['sequenceARN'] = util.get_secret(blockParam['secret'], "Payshield-Lambda-ARN")
                data['sequenceKeyID'] = util.get_secret(blockParam['secret'], "Payshield-IVR-KeyID")
                data['sequenceKeyCert'] = util.clean_certificate(util.get_secret(blockParam['secret'], "Payshield-IVR-Certificate"))
                data['sequenceProjID'] = util.get_secret(blockParam['secret'], "SendSMS-ProjectId")

            data['sequenceParam'] = blockParam.get('param','')

            if data['sequenceParam'] == 'Payshield-IVR-ProcessTransaction':
                import uuid
                data['sequenceUUID'] = 'IVR-' + str(uuid.uuid4())

            if 'value' in blockParam:
                data['sequenceValue'] = runner.eval_expr(blockParam.get('value'))

            if 'prompt' in blockParam:
                data['sequencePrompt'] = runner.eval_expr(blockParam.get('prompt'))

            session['blockParam'] = callflow_content[session['blockKey']]['ACTION']
            session['blockAction'] = 'SEQUENCERETURN' 

        elif session['blockType'] in ['TREE']:
            action_types = {"menu", "queue", "play", "transfer", "app", "callflow", "component", "contactflow", 'aiagent', 'lex'}
            action_type = next((k for k in action_types if k in util.convert(callflow_content[session['blockKey']]['ACTION'])), None)
            if action_type not in ['menu', 'play']:
                session['blockType'] = 'PLAY'
                session['blockAction'] = 'RETURN'

        else:
            session['blockAction'] = callflow_content[session['blockKey']]['ACTION']
    
    return (session, data)

def build_controller_response(statusCode, session, data, statusMessage):        
    return {
        'statusCode': statusCode,
        'promptIndex': session.get('prompt_index',''),
        'promptSize': session.get('prompt_size',''),
        'blockType': session.get('blockType',''),
        'blockParam': session.get('blockParam',''),
        'sequencePrompt': data.get('sequencePrompt',''),
        'sequenceParam': data.get('sequenceParam',''),
        'sequenceValue': data.get('sequenceValue',''),
        'sequenceARN': data.get('sequenceARN',''),
        'sequenceKeyID': data.get('sequenceKeyID',''),
        'sequenceKeyCert': data.get('sequenceKeyCert',''),
        'sequenceProjID': data.get('sequenceProjID',''),
        'sequenceUUID': data.get('sequenceUUID',''),
        'blockAction': session.get('blockAction',''),
        'actionTrue': session.get('action_true',''),
        'actionFalse': session.get('action_false',''),
        'language': str(session.get('language','')),
        'agentTip': session.get('agentTip',''),
        'userData': session.get('userData',''),
        'contactDisposition': session.get('contactDisposition',''),
        'barge': session.get('barge',''),
        'resetQueue': 'false',
        'speechAnalytics': session.get('speechAnalytics',''),
        'chatAnalytics': session.get('chatAnalytics',''),
        'callback_number': '+1' + session.get('callback_number',''),
        'session': json.dumps(session),
        'body': statusMessage 
    }