import json
import boto3
import csv
import datetime
import math
import zeep
import traceback
import os

def getRecord(session, event):
    statusCode = 200
    statusMessage =  json.dumps('Success!')
    import util
    import queues
    import config
    import sysAdmin
    data = {}
    error = event['Details']['Parameters']['error']
    channel = event['Details']['ContactData']['Channel']
    session = json.loads(event['Details']['Parameters']['session'])
    session['blockKey'] = event['Details']['Parameters']['blockKey']
    session['promptSize'] = 0
    session['promptIndex'] = 0
    session['menuAttempt'] = 0
    session['timeout'] = 0
    session['invalid'] = 0
    session['capturedInput'] =""
    session['actionTrue'] = "na"
    session['actionFalse'] = "na"
    session['inputTimeout'] = 0
    session['repeatAttempt'] = 0
    session['barge'] = 'true' 
    resetQueue = 'false'

    localBuiltIns = {
        'session': session,
        'sysAdmin': sysAdmin,
        'util': util,
        'queues': queues,
        'json':json
    }

    try:
        if session['blockKey'] == "ERROR" or session['blockKey'] == "ADMINERR":
            raise Exception(error)
            
        if session['initialize']:
            session['fileName'] = session['callFlow']
            client = queues.connectClient(config.region, config.account)
            response = client.update_contact_attributes(
                InitialContactId=config.contactID,
                InstanceId=config.instanceID,
                Attributes={
                    'callFlowID': '' 
                }
            )
        else:
            jsonContent = util.readCallFlowRecord(config.region, config.s3BucketName, config.instanceID, session['fileName'], 'BLOCK', False)
          
            if session['blockKey'] == "RETURN":
                session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey'])
                session['blockType'] = "RETURN"
            else:
                if session['blockKey']=='':
                    session['blockType'] = ''
                    session['blockParam'] = ''
                    session['blockAction'] = 'DISCONNECT'
                    raise Exception('Block Key can not be empty.')

                if session['blockKey']=='init' and channel=='TASK' :
                    session['blockKey'] = session['defaultVM'] 

                if not util.chkActionSize(jsonContent[session['blockKey']]['ACTION']):
                    if session['blockKey'] == jsonContent[session['blockKey']]['ACTION']:
                        session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey'])
                        raise Exception('Block Key can not have the same value as Block Action.')

                #This checks to see if there's a dynamic setting for blockParam (i.e. Broadcast Messages from SysAdmin)
                while 'eval:' in jsonContent[session['blockKey']]['PARAM']:
                    blockParam=util.convert(jsonContent[session['blockKey']]['PARAM'])
                    jsonContent[session['blockKey']]['PARAM'] = eval(blockParam['eval'], config.rdfBuiltIns, localBuiltIns)
                    #Empty or na setting, so bypass this block (i.e. Broadcast Message is not set)
                    if jsonContent[session['blockKey']]['PARAM'] == 'na' or jsonContent[session['blockKey']]['PARAM'] == '':
                        session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey'])
                        session['blockKey'] = jsonContent[session['blockKey']]['ACTION']
                        session['blockParam'] = jsonContent[session['blockKey']]['PARAM']

                session['blockParam'] = jsonContent[session['blockKey']]['PARAM']
                session['blockType'] = jsonContent[session['blockKey']]['TYPE']
                
        while session['blockType'] in ['EXEC','EVAL','LOOP', 'CASE', 'INIT','INITQ','SUB','RETURN','SOAP','REST']: 
            if session['blockType'] == "SUB":
                session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey'])
                session['subModule']={}
                session['subModule'][session['fileName']]=jsonContent[session['blockKey']]['ACTION']
                session['subIndex'] +=1
                session['fileName'] = session['blockParam'] +".csv"
                session['blockKey']="START"

                session['menuTracker'].append('SUB')
                session['menuIndex'] +=1
                session['queueTracker'].append('SUB')
                session['queueIndex'] += 1 

                print('#####   START SUBROUTINE: ' + session['blockParam'] + ' ANI: ' + config.ani + '   #####')
            if session['blockType'] == "RETURN":
                session['subIndex'] -=1
                i=0
                for n in session['subModule']:
                    if session['subIndex'] == i:
                        session['fileName'] = n
                        session['blockKey']= session['subModule'][session['fileName']]
                        session['blockType'] = 'HANGUP'
                i+=1
                del session['subModule'][session['fileName']]
                session['menuIndex'] -= 1
                session['queueIndex'] -= 1

                while session['menuTracker'][session['menuIndex']] != 'SUB':
	                del session['menuTracker'][session['menuIndex']]
	                del session['queueTracker'][session['queueIndex']]
	                session['menuIndex'] -=1
	                session['queueIndex'] -=1
                else:
                    del session['menuTracker'][session['menuIndex']]
                    del session['queueTracker'][session['queueIndex']]
                    session['queue'] = session['queueTracker'][session['queueIndex']-1]
                    session = queues.setQueue(session)
                    session['blockParam'] = config.instanceARN + '/queue/' + session['queueID']
                    resetQueue = 'true'

            jsonContent = util.readCallFlowRecord(config.region, config.s3BucketName, config.instanceID, session['fileName'], 'BLOCK', True)

            session['initialize'] = False
                
            if session['blockType']=="INIT":
                try:
                    session['blockKey'] = jsonContent[config.dnis]['BLOCK']
                    session['contactDisposition']=session['blockKey']
                    try:
                        exec(jsonContent[session['blockKey']]['PARAM'], config.rdfBuiltIns, localBuiltIns)
                    except:
                        pass
                except:
                    session['blockKey'] = session['defaultDNIS']
                    session['contactDisposition']= ''
            
            if session['blockType'] in ['EXEC']:
                session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey'])
                try:
                    exec(session['blockParam'], config.rdfBuiltIns, localBuiltIns)
                except Exception as Ex1:
                    print ('EXEC EXCEPTION: ' + str(Ex1))
                    #pass
                session['blockKey'] = jsonContent[session['blockKey']]['ACTION']

            if session['blockType'] == 'EVAL':
                session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey'])
                if util.chkActionSize(jsonContent[session['blockKey']]['ACTION']):
                    session['blockAction'] = util.convert(jsonContent[session['blockKey']]['ACTION'])
                else:
                    session['blockAction'] = jsonContent[session['blockKey']]['ACTION']
                #session['evalResponse'] = eval(session['blockParam'])
                session['evalResponse'] = eval(session['blockParam'], config.rdfBuiltIns, localBuiltIns)
       
                if 'queues.checkBusinessHours()' in session['blockParam']:
                    session['businessHours'] = session['evalResponse']

                if type(session['evalResponse']).__name__ == "bool":
                    if session['evalResponse']:
                        session['blockKey'] = str(session['blockAction']['true'])
                    else:
                        session['blockKey'] = str(session['blockAction']['false'])
                else:
                    if session['evalResponse']=="True":
                        session['blockKey'] = str(session['blockAction']['true'])
                    elif session['evalResponse']=="False":
                        session['blockKey'] = str(session['blockAction']['false'])
                    else:
                        session['blockKey'] = session['blockAction']
                
            if session['blockType'] in ['LOOP']:
                session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey'])
                session['blockAction'] = util.convert(jsonContent[session['blockKey']]['ACTION'])
                if "true" in session['blockAction']:
                    session['actionTrue'] = session['blockAction']['true']
                if "false" in session['blockAction']:
                    session['actionFalse'] = session['blockAction']['false']
                session['loopCounter'] += 1
                if session['loopCounter'] < int(session['blockParam']):
                    session['blockKey'] = session['actionFalse']
                else:
                    session['loopCounter']=0
                    session['blockKey'] = session['actionTrue']

            if session['blockType'] in ['CASE']:
                foundAction=False
                session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey'])
                caseValue = eval(session['blockParam'], config.rdfBuiltIns, localBuiltIns)
                session['evalResponse'] = caseValue 
                caseActions = util.convert(jsonContent[session['blockKey']]['ACTION'])
                for n in caseActions:
                    if n==str(caseValue):
                        foundAction=True
                        session['blockKey']=caseActions[n]
                if not foundAction:
                    session['blockKey']=caseActions['else']

            if session['blockType'] in ['REST']:
                session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey'])
                session['blockAction'] = util.convert(jsonContent[session['blockKey']]['ACTION'])
                blockParam = util.convert(jsonContent[session['blockKey']]['PARAM'].replace("'", '"'))
                import rdfwebservice
                session = rdfwebservice.rest(blockParam, session)
                if session['restResponse'] != 'error':
                    session['blockKey'] = str(session['blockAction']['true'])
                else:
                    session['blockKey'] = str(session['blockAction']['false'])

            if session['blockType'] in ['SOAP']:
                session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey'])
                session['blockAction'] = util.convert(jsonContent[session['blockKey']]['ACTION'])
                blockParam = util.convert(jsonContent[session['blockKey']]['PARAM'].replace("'", '"'))
                #blockParam = util.convert(jsonContent[session['blockKey']]['PARAM'])
                import rdfwebservice
                session = rdfwebservice.soap(blockParam, session)
                #session['blockKey'] = jsonContent[session['blockKey']]['ACTION']
                if session['soapResponse'] != 'error':
                    session['blockKey'] = str(session['blockAction']['true'])
                else:
                    session['blockKey'] = str(session['blockAction']['false'])

            try:
                if not util.chkActionSize(jsonContent[session['blockKey']]['ACTION']):
                    if session['blockKey'] == jsonContent[session['blockKey']]['ACTION']:
                        session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey'])
                        raise Exception('Block Key can not have the same value as Block Action.')                

                #This checks to see if there's a dynamic setting for blockParam (i.e. Broadcast Messages from SysAdmin)
                while 'eval:' in jsonContent[session['blockKey']]['PARAM']:
                    blockParam=util.convert(jsonContent[session['blockKey']]['PARAM'])
                    jsonContent[session['blockKey']]['PARAM'] = eval(blockParam['eval'], config.rdfBuiltIns, localBuiltIns)
                    #Empty or na setting, so bypass this block (i.e. Broadcast Message is not set)
                    if jsonContent[session['blockKey']]['PARAM'] == 'na' or jsonContent[session['blockKey']]['PARAM'] == '':
                        session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey'])
                        session['blockKey'] = jsonContent[session['blockKey']]['ACTION']
                        session['blockType'] = jsonContent[session['blockKey']]['TYPE']
                        
                session['blockType'] = jsonContent[session['blockKey']]['TYPE']
                session['blockParam'] = jsonContent[session['blockKey']]['PARAM']
            except:
                pass


        # All of the Block Types that follow requires Connect Call Flow to process
        if session['blockType'] in ['USERDATA']:
            session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey'])
            #session['userData'] = util.addDisposition(session['userData'],session['blockParam'])
            #session['blockKey'] = session['blockAction']
            session['userData'] = eval(session['blockParam'], config.rdfBuiltIns, localBuiltIns)

        if session['blockType'] in ['MENU', 'PLAY', 'INPUT', 'RECORD']:
            session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey'])
            session['promptSize'] = len(jsonContent[session['blockKey']]['PARAM'].split("|"))
            session['promptIndex'] = 0
            try:
                #Check to see if there's a barge setting.
                session['barge'] = util.convert(jsonContent[session['blockKey']]['ACTION'])['barge']                
            except:
                pass
            if session['blockType'] == "MENU":
                try:
                    #If globalMenuPrevious options exists, don't add to menuTracker
                    previousOveride = util.convert(jsonContent[session['blockKey']]['ACTION'])[config.globalMenuPrevious]
                except:
                    if session['blockKey'] not in session['menuTracker']:
                        session['menuTracker'].append(session['blockKey'])
                        session['menuIndex'] +=1
                        session['queueTracker'].append(session['queue'])
                        session['queueIndex'] += 1

            if session['blockType'] == "INPUT":
                session['inputTimeout'] = util.convert(jsonContent[session['blockKey']]['ACTION'])['seconds']
                
        if session['blockType'] in ['LANGUAGE']:
            session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey'])
            session['language']=jsonContent[session['blockKey']]['PARAM']

        if session['blockType'] in ['SETQUEUE']:
            session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey'])
            try:
                blockParam = util.convert(jsonContent[session['blockKey']]['PARAM'])
                #try:
                #    session['queueType'] = blockParam['type']
                #except:
                #    session['queueType'] = 'voice'

                if 'session' in blockParam[session['language']]:
                    session['queue'] = eval(blockParam[session['language']], config.rdfBuiltIns, localBuiltIns)
                else:
                    session['queue'] = blockParam[session['language']]

                session = queues.setQueue(session)
                session['blockParam'] = config.instanceARN + '/queue/' + session['queueID']
                #if session['queueType'] == 'VM':
                #    session['blockParam'] = config.instanceARN + '/queue/' + session['vmQueueID']
                #else:
                #    session['blockParam'] = config.instanceARN + '/queue/' + session['queueID']

            except:
                session['queue'] = jsonContent[session['blockKey']]['PARAM']
                session = queues.setQueue(session)
                session['blockParam'] = config.instanceARN + '/queue/' + session['queueID']

        if session['blockType'] in ['QUEUE']:
            session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey'])
            session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['queue'])

            if util.chkActionSize(jsonContent[session['blockKey']]['ACTION']):
                session['blockAction'] = util.convert(jsonContent[session['blockKey']]['ACTION'])
                if "true" in session['blockAction']:
                    jsonContent[session['blockKey']]['ACTION'] = session['blockAction']['true']
                if "false" in session['blockAction']:
                    session['actionFalse'] = session['blockAction']['false']

            s3TempFile = 'tmp/' + config.contactID + '.tmp'
            body = json.dumps(session) 
            s3Resource = boto3.resource('s3', config.region)
            s3Resource.Object(config.s3BucketName, s3TempFile).put(Body=body)
            print('#####   SAVING SESSION BEFORE TRANSFERRING TO QUEUE FOR: ' + str(session) + '   #####')
            print('#####   TRANSFERRING CALL: ' + config.ani + ' FOR ' + config.tenant.upper() + ' TO QUEUE:' + session['queue'] +  ' WITH QUEUEID:' + session['queueID'] + '   #####')
            
        if session['blockType'] in ['XFER']:
            session['contactDisposition'] = util.addDisposition(session['contactDisposition'],session['blockKey'])
            session['blockParam'] = "+" + session['blockParam']

        try:
            if 'eval' in jsonContent[session['blockKey']]['ACTION']:
                blockAction=util.convert(jsonContent[session['blockKey']]['ACTION'])
                session['blockAction'] = eval(blockAction['eval'], config.rdfBuiltIns, localBuiltIns)
            else:
                session['blockAction'] = jsonContent[session['blockKey']]['ACTION']
        except:
            session['blockAction'] = 'DISCONNECT'
    
    except Exception as ex1:
        print('#####   CONTROLLER FAILURE: ' + str(ex1) + '   #####')
        print('#####   TRACEBACK MESSAGE: ' + traceback.format_exc() + '   #####')
        statusCode = 500
        statusMessage = "We are experiencing technical difficulties." 
        if os.environ['TRACE_MODE'] == 'DEV':
            statusMessage += str(ex1)
        #client = queues.connectClient(config.region, config.account)
        #response = client.update_contact_attributes(
        #    InitialContactId=config.contactID,
        #    InstanceId=config.instanceID,
        #    Attributes={
        #        'errorMessage': str(ex1)
        #    }
        #)        
        #if session['blockKey'] == "ADMINERR":
        #    if session['adminerr']=='3337':
        #        session['blockType'] = "PLAY"
        #        finalDisposition = session['contactDisposition'].split(',')[-1]
        #        #session['blockParam'] = "error:Trace error found|error:" + str(ex1) + "|error: at|error:" + "<speak><say-as interpret-as=\"characters\">" + finalDisposition + "</say-as></speak>"
        #        session['blockParam'] = "error:Trace error found|error:" + str(ex1) + "|error: at|error:" + " ".join(finalDisposition) 
        #        session['promptSize'] = 4
        #    else:
        #        session['blockType'] = "PLAY"
        #        session['blockParam'] = "wav:TechDificulties"
        #        session['promptSize'] = 1 
        #    session['blockAction'] = "DISCONNECT"    
        #else:
        #    session['blockType'] = "DISCONNECT"
        #    session['globalInputTerm'] = "#"
        #    #session['blockParam'] = "error:" + config.techDifficulties['prodFailure']
        #    session['blockParam'] = "wav:TechDificulties"
        #    #session['blockAction'] = 'timeout:DISCONNECT|invalid:DISCONNECT|*:DISCONNECT|9:DISCONNECT|#:ADMINERR'
        #    #session['blockAction'] = 'var:adminerr|timeout:DISCONNECT|invalid:DISCONNECT|length:4|action:ADMINERR|seconds:1'
        #    session['blockAction'] = 'DISCONNECT'
        #    session['promptSize'] = 1        
        ##session['blockAction'] = "DISCONNECT"        
        
    return {
        'statusCode': statusCode,
        'promptIndex': session['promptIndex'],
        'promptSize': session['promptSize'],
        'blockType': session['blockType'],
        'blockParam': session['blockParam'],
        'blockAction': session['blockAction'],
        'actionTrue': session['actionTrue'],
        'actionFalse': session['actionFalse'],
        'language': str(session['language']),
        'agentTip': session['agentTip'],
        'userData': session['userData'],
        'contactDisposition': session['contactDisposition'],
        'barge': session['barge'],
        'resetQueue': resetQueue,
        'speechAnalytics': session['speechAnalytics'],
        'chatAnalytics': session['chatAnalytics'],    
        'session': json.dumps(session),
        #'body': json.dumps('Success!')
        'body': statusMessage 
    }
