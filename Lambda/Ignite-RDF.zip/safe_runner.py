#!/usr/bin/env python3
"""
SafeRunner: a tiny helper to evaluate or execute small expressions/snippets
inside a *constrained* environment with controlled __builtins__ and user-supplied
locals (e.g., session, util, queues).

Typical usage in your Lambda:
    runner = SafeRunner.from_defaults(local_built_ins={
        "session": session,
        "util": util,
        "queues": queues,
        "json": __import__("json"),
        "re": __import__("re"),
        "datetime": __import__("datetime"),
        "next": next,
        "__import__": __import__,
    })

    # Evaluate an expression like "queues.checkAppBusHours()"
    result = runner.eval_expr('queues.checkAppBusHours()')

    # Execute statements (no return):
    runner.exec_stmt('session["menu_loop"] = "true"')
"""

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Dict, Optional
import logger


def _default_rdf_builtins() -> Dict[str, Any]:
    """
    Minimal, explicit whitelist of builtins that will be exposed to untrusted code.
    Keep this list tight. Add only what you truly need.
    Mirrors your earlier pattern (min + exception/warning types + None).
    """
    # Core
    safe = {
        'min': min,
        'None': None,
        'True': True,
        'abs': abs,
        'all': all,
        'any': any,
        'ascii': ascii,
        'bin': bin,
        'bool': bool,
        'chr': chr,
        'dict': dict,
        'divmod': divmod,
        'enumerate': enumerate,
        'float': float,
        'format': format,
        'frozenset': frozenset,
        'int': int,
        'iter': iter,
        'len': len,
        'list': list,
        'max': max,
        'min': min,
        'range': range,
        'reversed': reversed,
        'round': round,
        'set': set,
        'sorted': sorted,
        'str': str,
        'sum': sum,
        'tuple': tuple
    }

    # Exceptions / Warnings (allow raising/catching)
    exceptions = {
        "BaseException": BaseException,
        "Exception": Exception,
        "ArithmeticError": ArithmeticError,
        "AssertionError": AssertionError,
        "AttributeError": AttributeError,
        "EOFError": EOFError,
        "FloatingPointError": FloatingPointError,
        "GeneratorExit": GeneratorExit,
        "ImportError": ImportError,
        "IndentationError": IndentationError,
        "IndexError": IndexError,
        "KeyError": KeyError,
        "KeyboardInterrupt": KeyboardInterrupt,
        "LookupError": LookupError,
        "MemoryError": MemoryError,
        "NameError": NameError,
        "NotImplementedError": NotImplementedError,
        "OSError": OSError,
        "OverflowError": OverflowError,
        "PermissionError": PermissionError,
        "RecursionError": RecursionError,
        "ReferenceError": ReferenceError,
        "RuntimeError": RuntimeError,
        "StopIteration": StopIteration,
        "SyntaxError": SyntaxError,
        "SystemError": SystemError,
        "SystemExit": SystemExit,
        "TypeError": TypeError,
        "UnboundLocalError": UnboundLocalError,
        "ValueError": ValueError,
        "ZeroDivisionError": ZeroDivisionError,
        "Warning": Warning,
        "UserWarning": UserWarning,
        "DeprecationWarning": DeprecationWarning,
        "PendingDeprecationWarning": PendingDeprecationWarning,
        "SyntaxWarning": SyntaxWarning,
        "RuntimeWarning": RuntimeWarning,
        "FutureWarning": FutureWarning,
        "ImportWarning": ImportWarning,
        "UnicodeWarning": UnicodeWarning,
        "BytesWarning": BytesWarning,
        "ResourceWarning": ResourceWarning,
    }

    safe.update(exceptions)
    return {"__builtins__": safe}


@dataclass
class SafeRunner:
    """
    A constrained evaluator/runner that mimics:
        eval(expr, config.rdfBuiltIns, localBuiltIns)

    - rdf_builtins: {'__builtins__': { ...whitelisted builtins... }}
    - local_builtins: variables/modules you want available to the code being run
                      (e.g., session, util, queues, json, re, datetime, next, __import__).
    """
    rdf_builtins: Dict[str, Any] = field(default_factory=_default_rdf_builtins)
    local_builtins: Dict[str, Any] = field(default_factory=dict)
    freeze_env: bool = True  # when True, locals are exposed via MappingProxyType (read-only view)

    @classmethod
    def from_defaults(
        cls,
        local_built_ins: Optional[Dict[str, Any]] = None,
        extra_builtins: Optional[Dict[str, Any]] = None,
        freeze_env: bool = True,
    ) -> "SafeRunner":
        """
        Convenience constructor. You can pass:
          - local_built_ins: your session/util/queues/etc.
          - extra_builtins: to extend the builtin whitelist *deliberately*.
        """
        rdf = _default_rdf_builtins()
        if extra_builtins:
            # Merge in a controlled way; do NOT blindly copy everything.
            rdf_bi = dict(rdf["__builtins__"])
            rdf_bi.update(extra_builtins)
            rdf = {"__builtins__": rdf_bi}
        return cls(rdf_builtins=rdf, local_builtins=local_built_ins or {}, freeze_env=freeze_env)

    def _locals_view(self, overrides: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Combine runner locals with optional overrides. Optionally expose as a read-only view.
        Note: underlying objects (like dicts) are still mutable by reference; if you truly
        need immutability, pass copies of your objects in local_builtins.
        """
        merged = dict(self.local_builtins)
        if overrides:
            merged.update(overrides)
        return MappingProxyType(merged) if self.freeze_env else merged

    # -----------------------------
    # Public API
    # -----------------------------
    def eval_expr(self, expr: str, locals_override: Optional[Dict[str, Any]] = None) -> Any:
        """
        Evaluate a Python expression (single value).
        Eg: 'queues.checkAppBusHours()' or 'session.get("menu_loop") == "true"'
        """
        try:
            return eval(expr, self.rdf_builtins, self._locals_view(locals_override))
        except Exception as ex1:
            logger.error("❌ EVAL EXPR: " + str(expr))
            logger.error("❌ EVAL ERROR: " + str(ex1))
            return expr

    def exec_stmt(self, code: str, locals_override: Optional[Dict[str, Any]] = None) -> None:
        """
        Execute statements (no return). Eg:
            'session["menu_loop"] = "true"\nmenu = util.convert(blockAction)'
        """
        exec(code, self.rdf_builtins, self._locals_view(locals_override))

    def call(self, dotted_name: str, *args, **kwargs) -> Any:
        """
        Convenience to call a function by dotted path available in locals.
        Eg: call('queues.checkAppBusHours')
        """
        env = self._locals_view()
        obj: Any = env
        for part in dotted_name.split("."):
            obj = obj[part] if isinstance(obj, dict) else getattr(obj, part)
        if not callable(obj):
            raise TypeError(f"{dotted_name!r} is not callable")
        return obj(*args, **kwargs)

    # -----------------------------
    # Optional helpers
    # -----------------------------
    def update_locals(self, **new_items: Any) -> None:
        """Add or replace items in the runner's local namespace."""
        self.local_builtins.update(new_items)

    def set_builtin(self, name: str, value: Any) -> None:
        """Add or replace a single whitelisted builtin (be careful)."""
        self.rdf_builtins["__builtins__"][name] = value


# -----------------------------
# CLI/Example usage
# -----------------------------
def _example_locals() -> Dict[str, Any]:
    """
    Build a sample local environment without importing your app modules.
    Replace with your real objects in Lambda (session/util/queues/etc.).
    """
    # Keeping imports *inside* the function to respect your Lambda pattern.
    json = __import__("json")
    re = __import__("re")
    datetime = __import__("datetime")

    session = {"menu_loop": "false", "captured_input": ""}

    class Queues:
        def checkAppBusHours(self) -> bool:
            # Fake implementation; replace with your real one.
            return True

    def util_convert(value):
        # Dummy util.convert() example
        return {"converted": value}

    util = type("util", (), {"convert": staticmethod(util_convert)})

    return {
        "session": session,
        "util": util,
        "queues": Queues(),
        "json": json,
        "re": re,
        "datetime": datetime,
        "next": next,
        "__import__": __import__,
    }


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Run a quick SafeRunner demo.")
    parser.add_argument("--eval", help="Evaluate a Python expression in the safe environment.")
    parser.add_argument("--exec", dest="exec_code", help="Execute Python statements in the safe environment.")
    parser.add_argument("--show-session", action="store_true", help="Print the demo session dict after running.")
    args = parser.parse_args()

    runner = SafeRunner.from_defaults(local_built_ins=_example_locals())

    if args.exec_code:
        runner.exec_stmt(args.exec_code)

    if args.eval:
        result = runner.eval_expr(args.eval)
        print(result)

    if args.show_session:
        print(runner.local_builtins.get("session"))

if __name__ == "__main__":
    main()
