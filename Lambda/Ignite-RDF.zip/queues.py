import json
import boto3
import datetime
import config
import util
import time
import random
import pytz
import os

#def checkHoliday():
#    jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, config.holidayFile, 'DATE')
#    dt = datetime.datetime.now()
#    return(str('{dt.month}/{dt.day}/{dt.year}'.format(dt = datetime.datetime.now())) in jsonContent)

def checkHoliday():
    holiday = False
    holidayContent = util.readCache(config.region, config.s3BucketName, config.instanceID, config.holidayFile, 'DATE')
    dt = datetime.datetime.now()
    today = str('{dt.month}/{dt.day}/{dt.year}'.format(dt = datetime.datetime.now()))
    today_other = '{:02d}'.format(dt.month) + '/' + '{:02d}'.format(dt.day) + '/' + str(dt.year) #dates that contain leading zero's in the month and day
    if today in holidayContent or today_other in holidayContent: #check if date exists in Holiday file
        holiday = True
        try: #checks if there are special holiday hours
            currentTime= datetime.time(int(dt.strftime("%H")), int(dt.strftime("%M")), int(dt.strftime("%S")))
            startTimeParts = holidayContent[today]['START'].split(':')
            endTimeParts = holidayContent[today]['END'].split(':')
            startTime = datetime.time(int(startTimeParts[0]), int(startTimeParts[1]))
            endTime = datetime.time(int(endTimeParts[0]), int(endTimeParts[1]))
            if currentTime>startTime and currentTime<endTime:
                holiday = False
        except:
            pass

    return(holiday)

def connectClient(region, account):
    sts_client = boto3.client('sts')
    sts_session = sts_client.assume_role(RoleArn='arn:aws:iam::'+account+':role/xaccount-rdf-role',
                                      RoleSessionName='cross_acct_lambda')

    KEY_ID = sts_session['Credentials']['AccessKeyId']
    ACCESS_KEY = sts_session['Credentials']['SecretAccessKey']
    TOKEN = sts_session['Credentials']['SessionToken']

    connect_client = boto3.client('connect',
        region_name=region,
        aws_access_key_id=KEY_ID,
        aws_secret_access_key=ACCESS_KEY,
        aws_session_token=TOKEN)
    
    return(connect_client)

def checkBusinessHours():
    holidayContent = util.readCache(config.region, config.s3BucketName, config.instanceID, config.holidayFile, 'DATE')
    jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, config.queueID, 'KEY')
    dt = datetime.datetime.now(pytz.timezone(jsonContent[config.queueID]['TIMEZONE']))
    today = str('{dt.month}/{dt.day}/{dt.year}'.format(dt = datetime.datetime.now()))
    if today in holidayContent: #check if date exists in Holiday file
        config.businessHours = False
        try: #checks if there are special holiday hours
            currentTime= datetime.time(int(dt.strftime("%H")), int(dt.strftime("%M")), int(dt.strftime("%S")))
            startTimeParts = holidayContent[today]['START'].split(':')
            endTimeParts = holidayContent[today]['END'].split(':')
            startTime = datetime.time(int(startTimeParts[0]), int(startTimeParts[1]))
            endTime = datetime.time(int(endTimeParts[0]), int(endTimeParts[1]))
            if currentTime>startTime and currentTime<endTime:
                config.businessHours = True
        except:
            pass
    else:
        try:
            #jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, config.queueID, 'KEY')
            hoursConfig = json.loads(jsonContent[config.queueID]['HOURS'])
            dt = datetime.datetime.now(pytz.timezone(jsonContent[config.queueID]['TIMEZONE']))
            currentTime= datetime.time(int(dt.strftime("%H")), int(dt.strftime("%M")), int(dt.strftime("%S")))
            daysOfWeek = ['MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY','SUNDAY']

            startTime = datetime.time(0,0,0)
            endTime = datetime.time(0,0,0)

            for n in hoursConfig:
                if n['Day']==daysOfWeek[dt.weekday()]:
                    startTime= datetime.time(n['StartTime']['Hours'],n['StartTime']['Minutes'])
                    endTime = datetime.time(n['EndTime']['Hours'],n['EndTime']['Minutes'])
                    if str(endTime)=='00:00:00':
                        endTime = datetime.time(23,59,59)

            config.businessHours = currentTime>startTime and currentTime<endTime
            print('#####   BUSINESS HOURS FOR: ' + str(config.tenant.upper()) + ' IS ' + str(config.businessHours) + ' CONTACTID: ' + config.contactID  + '    #####')
        except Exception as Ex1:
            print('#####   BUSINESS HOURS EXCEPTION: ' + str(Ex1) + ' CONTACTID: ' + config.contactID  + '    #####')

    return(config.businessHours)

def chkBusHrsRemaining():
    busHrsRemaining = 0
    try:
        jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, config.queueID, 'KEY')
        hoursConfig = json.loads(jsonContent[config.queueID]['HOURS'])
        dt = datetime.datetime.now()
        currentTime= datetime.time(int(dt.strftime("%H")), int(dt.strftime("%M")), int(dt.strftime("%S")))
        daysOfWeek = ['MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY','SUNDAY']

        startTime = datetime.time(0,0,0)
        endTime = datetime.time(0,0,0)

        for n in hoursConfig:
            if n['Day']==daysOfWeek[dt.weekday()]:
                startTime= datetime.time(n['StartTime']['Hours'],n['StartTime']['Minutes'])
                endTime = datetime.time(n['EndTime']['Hours'],n['EndTime']['Minutes'])
                if str(endTime)=='00:00:00':
                    endTime = datetime.time(23,59,59)

        t1 = datetime.datetime.strptime(str(currentTime), "%H:%M:%S")
        t2 = datetime.datetime.strptime(str(endTime), "%H:%M:%S")

        if currentTime>startTime and currentTime<endTime:
            #busHrsRemaining = (endTime - currentTime).total_seconds() / 60.0
            busHrsRemaining = int((t2 - t1).total_seconds() / 60.0)

        print('#####   BUSINESS HOURS REMAINING FOR: ' + str(config.tenant.upper()) + ' IS ' + str(busHrsRemaining) + ' minutes CONTACTID: ' + config.contactID  + '    #####')
    except Exception as Ex1:
        print('#####   BUSINESS HOURS REMAINING EXCEPTION: ' + str(Ex1) + ' CONTACTID: ' + config.contactID  + '    #####')

    return(busHrsRemaining)

#def checkBusinessHours():
#    if checkHoliday():
#        config.businessHours = False
#    else:
#        try:
#            jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, config.queueID, 'KEY')
#            hoursConfig = json.loads(jsonContent[config.queueID]['HOURS'])
#            dt = datetime.datetime.now()
#            currentTime= datetime.time(int(dt.strftime("%H")), int(dt.strftime("%M")), int(dt.strftime("%S")))
#            daysOfWeek = ['MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY','SUNDAY']
#            
#            startTime = datetime.time(0,0,0)
#            endTime = datetime.time(0,0,0)
#
#            for n in hoursConfig:
#                if n['Day']==daysOfWeek[dt.weekday()]:
#                    startTime= datetime.time(n['StartTime']['Hours'],n['StartTime']['Minutes'])
#                    endTime = datetime.time(n['EndTime']['Hours'],n['EndTime']['Minutes'])
#                    if str(endTime)=='00:00:00':
#                        endTime = datetime.time(23,59,59)
#
#            config.businessHours = currentTime>startTime and currentTime<endTime
#            print('#####   BUSINESS HOURS FOR: ' + str(config.tenant.upper()) + ' IS ' + str(config.businessHours) + ' CONTACTID: ' + config.contactID  + '    #####')
#        except Exception as Ex1:
#            print('#####   BUSINESS HOURS EXCEPTION: ' + str(Ex1) + ' CONTACTID: ' + config.contactID  + '    #####')
#        
#    return(config.businessHours)

def setQueue(session):
    try:
        queueContent = util.readCache(config.region, config.s3BucketName, config.instanceID, 'queues.csv', 'KEY')
        config.queueID = queueContent[session['queue']]['VALUE']
    except Exception as Ex1:
        #An exception occurred likely due to a new queue being recently added and not in cache.  Reload cache.
        print("#####   RELOADING QUEUE CACHE DUE TO ERROR: " + str(Ex1) + "    #####")
        os.chdir('/tmp')
        filePath = os.path.join(os.getcwd(), config.instanceID, 'queues.csv')
        os.remove(filePath)
        queueContent = util.readCache(config.region, config.s3BucketName, config.instanceID, 'queues.csv', 'KEY')
        config.queueID = queueContent[session['queue']]['VALUE']

    session['queueID'] = queueContent[session['queue']]['VALUE']
    jsonContent = util.readCache(config.region, config.s3BucketName, config.instanceID, config.queueID, 'KEY')
    session['agentTip']=jsonContent[config.queueID]['DESCRIPTION']
    config.holidayFile = jsonContent[config.queueID]['HOLIDAY']
    session['holidayFile'] = jsonContent[config.queueID]['HOLIDAY']

    return(session)

def getQueueMetrics(queueID):
    #if 'session' in queueID:
    #    queueID = eval(queueID)
    retry = True
    retries = 0
    while retry and retries < 3:
        print('#####   QUEUE METRICS ATTEMPT: ' + str(retries)+ ' QUEUEID: ' + queueID + ' CONTACTID: ' + config.contactID  + '    #####')
        time.sleep(random.randint(0,5)**retries*100/1000)
        client = connectClient(config.region, config.account)
        try:
            nextToken=""
            metricsResponse = client.get_current_metric_data(
                InstanceId=config.instanceID,
                Filters={
                    'Queues': [
                        queueID
                    ],
                    'Channels': [
                        'VOICE'
                    ]
                },
                Groupings=[
                    'QUEUE'
                ],
                CurrentMetrics=[
                    {
                        #'Name': 'AGENTS_ONLINE'|'AGENTS_AVAILABLE'|'AGENTS_ON_CALL'|'AGENTS_NON_PRODUCTIVE'|'AGENTS_AFTER_CONTACT_WORK'|'AGENTS_ERROR'|'AGENTS_STAFFED'|'CONTACTS_IN_QUEUE'|'OLDEST_CONTACT_AGE'|'CONTACTS_SCHEDULED'|'AGENTS_ON_CONTACT'|'SLOTS_ACTIVE'|'SLOTS_AVAILABLE',
                        #'Unit': 'SECONDS'|'COUNT'|'PERCENT'
                        'Name': 'AGENTS_ONLINE',
                        'Unit': 'COUNT'
                    },
                    {
                        'Name': 'AGENTS_STAFFED',
                        'Unit': 'COUNT'               
                    },
                    {
                        'Name': 'AGENTS_AVAILABLE',
                        'Unit': 'COUNT'               
                    },
                    {
                        'Name': 'SLOTS_AVAILABLE',
                        'Unit': 'COUNT'               
                    },
                    {
                        'Name': 'CONTACTS_IN_QUEUE',
                        'Unit': 'COUNT'               
                    },
                    {
                        'Name': 'OLDEST_CONTACT_AGE',
                        'Unit': 'SECONDS'               
                    }
                ],
                NextToken=nextToken,
                MaxResults=10
            )
            print(metricsResponse)
            metricCollections = metricsResponse['MetricResults'][0]['Collections']
            metricsData={}
            for n in metricCollections:
                if n['Metric']['Name']=='AGENTS_ONLINE':
                    metricsData['agentsOnline']=n['Value']
                if n['Metric']['Name']=='AGENTS_STAFFED':
                    metricsData['agentsStaffed']=n['Value']
                if n['Metric']['Name']=='AGENTS_AVAILABLE':
                    metricsData['agentsAvailable']=n['Value']
                if n['Metric']['Name']=='SLOTS_AVAILABLE':
                    metricsData['slotsAvailable']=n['Value']
                if n['Metric']['Name']=='CONTACTS_IN_QUEUE':
                    metricsData['contactsInQueue']=n['Value']
                if n['Metric']['Name']=='OLDEST_CONTACT_AGE':
                    metricsData['OldestContactAge']=n['Value']
            retry = False
        except Exception as Ex1:
            retries += 1
            print('#####   QUEUE METRICS EXCEPTION: ' + str(Ex1) + '    #####')
            metricsData = {
                'agentsOnline':0,
                'agentsStaffed':0,
                'agentsAvailable':0,
                'slotsAvailable':0,
                'contactsInQueue':0,
                'OldestContactAge':0
            }
    return(metricsData)

#def getHistoricalMetricData(queueID):
#    startTime = datetime.datetime(2022, 12, 21, 8, 30, 0).strftime('%s')
#    endTime = datetime.datetime(2022, 12, 21, 17, 0, 0).strftime('%s')
#    print('time = ' + str(startTime))
#    
#    nextToken=""
#    client = connectClient(config.region, config.account)
#    metricsResponse = client.get_metric_data(
#        InstanceId=config.instanceID,
#        StartTime=startTime,
#        EndTime=endTime,
#        Filters={
#            'Queues': [
#                queueID,
#            ],
#            'Channels': [
#                'VOICE',
#            ]
#        },
#        Groupings=[
#            'QUEUE',
#        ],
#        HistoricalMetrics=[
#            {
#                'Name': 'HANDLE_TIME',
#                'Threshold': {
#                    'Comparison': 'LT',
#                    'ThresholdValue': 123.0
#                },
#                'Statistic': 'AVG',
#                'Unit': 'SECONDS'
#            },
#        ],
#        NextToken=nextToken,
#        MaxResults=10
#    )
#    
#    return(metricsResponse)

def agentsOnline():
    result = getQueueMetrics(config.queueID)['agentsOnline']
    print('#####   CHECK AGENTS ONLINE FOR QUEUE: ' + config.queueID + ' VALUE IS: ' + str(result) + '   #####')
    return(result>0)

def agentsStaffed():
    result = getQueueMetrics(config.queueID)['agentsStaffed']
    print('#####   CHECK AGENTS STAFFED FOR QUEUE: ' + config.queueID + ' VALUE IS: ' + str(result) + '   #####')
    return(result>0)

def agentsAvailable():
    result = getQueueMetrics(config.queueID)['agentsAvailable']
    print('#####   CHECK AGENTS AVAILABLE FOR QUEUE: ' + config.queueID + ' VALUE IS: ' + str(result) + '   #####')
    return(result>0)

def slotsAvailable():
    result = getQueueMetrics(config.queueID)['slotsAvailable']
    print('#####   CHECK SLOTS AVAILABLE FOR QUEUE: ' + config.queueID + ' VALUE IS: ' + str(result) + '   #####')
    return(result>0)

def withinQueueCapacity(threshold):
    result = getQueueMetrics(config.queueID)['contactsInQueue']
    print('#####   CHECK QUEUE CAPACITY FOR QUEUE: ' + config.queueID + ' VALUE IS: ' + str(result) + '   #####')
    return(result<=threshold)

def withinWaitCapacity(threshold):
    result = getQueueMetrics(config.queueID)['OldestContactAge']
    print('#####   CHECK WAIT THRESHOLD FOR QUEUE: ' + config.queueID + ' VALUE IS: ' + str(result) + '   #####')
    return(result<=threshold)
