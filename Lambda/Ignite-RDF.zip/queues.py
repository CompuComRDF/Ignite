import json
from context import ctx
import datetime
import util
import time
import random
import pytz
import logger

def check_business_hours(file_name):
    ctx.shared_modules.set([*ctx.shared_modules.get(), f"{file_name}-bushours.csv"])
    ctx.shared_modules.set([*ctx.shared_modules.get(), f"{file_name}-holidays.csv"])
    #session['shared_modules'] = ctx.shared_modules.get()

    holiday_content = util.read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), f"{file_name}-holidays.csv", 'DATE')
    bushours_content = util.read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), f"{file_name}-bushours.csv", 'DAY')
    dt = datetime.datetime.now(pytz.timezone(bushours_content['TIMEZONE']['START']))
    today = str('{dt.month}/{dt.day}/{dt.year}'.format(dt = datetime.datetime.now()))
    today_formatted = '{:02d}/{:02d}/{:4d}'.format(datetime.datetime.now().month,
                                     datetime.datetime.now().day,
                                     datetime.datetime.now().year)  

    if today in holiday_content or today_formatted in holiday_content: #check if date exists in Holiday file
        ctx.business_hours.set(False)
        try: #checks if there are special holiday hours
            current_time= datetime.time(int(dt.strftime("%H")), int(dt.strftime("%M")), int(dt.strftime("%S")))
            start_time_parts = holiday_content[today]['START'].split(':')
            end_time_parts = holiday_content[today]['END'].split(':')
            start_time = datetime.time(int(start_time_parts[0]), int(start_time_parts[1]))
            end_time = datetime.time(int(end_time_parts[0]), int(end_time_parts[1]))
            if current_time>start_time and current_time<end_time:
                ctx.business_hours.set(True)
        except:
            pass
    else:
        try:
            dt = datetime.datetime.now(pytz.timezone(bushours_content['TIMEZONE']['START']))
            current_time= datetime.time(int(dt.strftime("%H")), int(dt.strftime("%M")), int(dt.strftime("%S")))
            days_of_week = ['MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY','SUNDAY']

            start_time = datetime.time(0,0,0)
            end_time = datetime.time(0,0,0)
            for day in bushours_content:
                if day == dt.strftime('%A').upper():
                    start_time_parts = bushours_content[day]['START'].split(':')
                    end_time_parts = bushours_content[day]['END'].split(':')
                    start_time = datetime.time(int(start_time_parts[0]), int(start_time_parts[1]))
                    end_time = datetime.time(int(end_time_parts[0]), int(end_time_parts[1]))
                    if str(end_time)=='00:00:00':
                        end_time = datetime.time(23,59,59)

            ctx.business_hours.set(current_time>start_time and current_time<end_time)
        except Exception as Ex1:
            logger.error(f"❌ BUSINESS HOURS EXCEPTION: {str(Ex1)}")

    return(ctx.business_hours.get())

def check_hours_remaining():
    bushours_remaining = 0
    try:
        queue_content = util.read_cache(ctx.region.get(), ctx.s3_bucket_name.get(), ctx.instance_id.get(), ctx.queue_id.get(), 'KEY')
        hours_config = json.loads(queue_content[ctx.queue_id.get()]['HOURS'])
        dt = datetime.datetime.now()
        current_time= datetime.time(int(dt.strftime("%H")), int(dt.strftime("%M")), int(dt.strftime("%S")))
        days_of_week = ['MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY','SUNDAY']

        start_time = datetime.time(0,0,0)
        end_time = datetime.time(0,0,0)

        for n in hours_config:
            if n['Day']==days_of_week[dt.weekday()]:
                start_time= datetime.time(n['StartTime']['Hours'],n['StartTime']['Minutes'])
                end_time = datetime.time(n['EndTime']['Hours'],n['EndTime']['Minutes'])
                if str(end_time)=='00:00:00':
                    end_time = datetime.time(23,59,59)

        t1 = datetime.datetime.strptime(str(current_time), "%H:%M:%S")
        t2 = datetime.datetime.strptime(str(end_time), "%H:%M:%S")

        if current_time>start_time and current_time<end_time:
            bushours_remaining = int((t2 - t1).total_seconds() / 60.0)

    except Exception as Ex1:
        logger.error(f"❌ BUSINESS HOURS REMAINING EXCEPTION: {str(Ex1)}")

    return(bushours_remaining)

def getQueueMetrics(queue_id):
    retry = True
    retries = 0
    while retry and retries < 3:
        logger.warning(f"⚠️ QUEUE METRICS ATTEMPT: {retries} QUEUEID: {queue_id}")
        time.sleep(random.randint(0,5)**retries*100/1000)
        client = util.get_client('connect', ctx.region.get(), ctx.account.get())
        try:
            nextToken=""
            metricsResponse = client.get_current_metric_data(
                InstanceId=ctx.instance_id.get(),
                Filters={
                    'Queues': [
                        queue_id
                    ],
                    'Channels': [
                        'VOICE'
                    ]
                },
                Groupings=[
                    'QUEUE'
                ],
                CurrentMetrics=[
                    {
                        'Name': 'AGENTS_ONLINE',
                        'Unit': 'COUNT'
                    },
                    {
                        'Name': 'AGENTS_STAFFED',
                        'Unit': 'COUNT'               
                    },
                    {
                        'Name': 'AGENTS_AVAILABLE',
                        'Unit': 'COUNT'               
                    },
                    {
                        'Name': 'SLOTS_AVAILABLE',
                        'Unit': 'COUNT'               
                    },
                    {
                        'Name': 'CONTACTS_IN_QUEUE',
                        'Unit': 'COUNT'               
                    },
                    {
                        'Name': 'OLDEST_CONTACT_AGE',
                        'Unit': 'SECONDS'               
                    }
                ],
                NextToken=nextToken,
                MaxResults=10
            )
            metricCollections = metricsResponse['MetricResults'][0]['Collections']
            metricsData={}
            for n in metricCollections:
                if n['Metric']['Name']=='AGENTS_ONLINE':
                    metricsData['agentsOnline']=n['Value']
                if n['Metric']['Name']=='AGENTS_STAFFED':
                    metricsData['agentsStaffed']=n['Value']
                if n['Metric']['Name']=='AGENTS_AVAILABLE':
                    metricsData['agentsAvailable']=n['Value']
                if n['Metric']['Name']=='SLOTS_AVAILABLE':
                    metricsData['slotsAvailable']=n['Value']
                if n['Metric']['Name']=='CONTACTS_IN_QUEUE':
                    metricsData['contactsInQueue']=round(n['Value']+1)
                if n['Metric']['Name']=='OLDEST_CONTACT_AGE':
                    metricsData['OldestContactAge']=round(n['Value'])
            if metricsData['agentsOnline'] > 0:
                metricsData['EstimatedWaitTime'] = int((metricsData['contactsInQueue']/metricsData['agentsOnline']) * metricsData['OldestContactAge'])
            else:
                metricsData['EstimatedWaitTime'] = 0
            retry = False

        except Exception as Ex1:
            retries += 1
            logger.error(f"❌ QUEUE METRICS EXCEPTION: {str(Ex1)}")
            metricsData = {
                'agentsOnline':0,
                'agentsStaffed':0,
                'agentsAvailable':0,
                'slotsAvailable':0,
                'contactsInQueue':0,
                'OldestContactAge':0
            }
    return(metricsData)

def agentsOnline():
    result = getQueueMetrics(ctx.queue_id.get())['agentsOnline']
    return(result>0)

def agentsStaffed():
    result = getQueueMetrics(ctx.queue_id.get())['agentsStaffed']
    return(result>0)

def agentsAvailable():
    result = getQueueMetrics(ctx.queue_id.get())['agentsAvailable']
    return(result>0)

def slotsAvailable():
    result = getQueueMetrics(ctx.queue_id.get())['slotsAvailable']
    return(result>0)

def withinQueueCapacity(threshold):
    result = getQueueMetrics(ctx.queue_id.get())['contactsInQueue']
    return(result<=threshold)

def withinWaitCapacity(threshold):
    result = getQueueMetrics(ctx.queue_id.get())['OldestContactAge']
    return(result<=threshold)

def set_routing_proficiency(routing_attribute, routing_value):
    steps = {
            "Steps": [
                {
                    "Expression": {
                        "AttributeCondition": {
                            "Name": f"connect:{routing_attribute}",
                            "Value": f"connect:{routing_value}",
                            "ProficiencyLevel": 5,
                            "ComparisonOperator": "NumberGreaterOrEqualTo"
                        }
                    },
                    "Expiry": {
                    "DurationInSeconds": 90
                    }
                },
                {
                    "Expression": {
                        "AttributeCondition": {
                            "Name": f"connect:{routing_attribute}",
                            "Value": f"connect:{routing_value}",
                            "ProficiencyLevel": 4,
                            "ComparisonOperator": "NumberGreaterOrEqualTo"
                        }
                    },
                    "Expiry": {
                    "DurationInSeconds": 90
                    }
                },
                {
                    "Expression": {
                        "AttributeCondition": {
                            "Name": f"connect:{routing_attribute}",
                            "Value": f"connect:{routing_value}",
                            "ProficiencyLevel": 3,
                            "ComparisonOperator": "NumberGreaterOrEqualTo"
                        }
                    },
                    "Expiry": {
                    "DurationInSeconds": 90
                    }
                },
                {
                    "Expression": {
                        "AttributeCondition": {
                            "Name": f"connect:{routing_attribute}",
                            "Value": f"connect:{routing_value}",
                            "ProficiencyLevel": 2,
                            "ComparisonOperator": "NumberGreaterOrEqualTo"
                        }
                    },
                    "Expiry": {
                    "DurationInSeconds": 90
                    }
                },
                {
                    "Expression": {
                        "AttributeCondition": {
                            "Name": f"connect:{routing_attribute}",
                            "Value": f"connect:{routing_value}",
                            "ProficiencyLevel": 1,
                            "ComparisonOperator": "NumberGreaterOrEqualTo"
                        }
                    },
                    "Expiry": {
                    "DurationInSeconds": 90
                    }
                }
            ]
        }
    
    return steps

def get_active_agents_in_queue(queue_id):
    """
    Returns a list of active agent user IDs for a given queue
    """
    result = util.connect_jitter('get_current_user_data', queue_id)
    active_agents = []
 
    for user in result:
        # Agent must be logged in and not offline
        if user["Status"]["StatusName"] != "Offline":
            active_agents.append(user["User"]["Id"])
 
    return active_agents
 
def agent_has_language_proficiency(user_id, language):
    """
    Checks whether an agent has the required language proficiency
    """
    result = util.connect_jitter('list_user_proficiencies', user_id)

    for prof in result:
        if (
            prof["AttributeName"] == "connect:Language"
            and prof["AttributeValue"] == f"connect:{language}"
        ):
            return True
 
    return False
 
def check_agents_with_language(queue_id, language):
    agents = get_active_agents_in_queue(queue_id)
 
    for agent_id in agents:
        if agent_has_language_proficiency(agent_id, language):
            return True
 
    return False
