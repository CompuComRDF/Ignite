import json
import boto3
import os
import time
import datetime
import urllib.parse

client = boto3.client('lambda')

def lambda_handler(event, context):
    try:
        #S3 Event = aws:s3
        eventSource = event['Records'][0]['eventSource'] 
    except: 
        try:
            #Amazon Connect Contact Event = aws.connect
            eventSource = event['source']
        except:
            #Amazon Connect Contact Flow Event
            eventSource = 'ContactFlow'

    if eventSource == 'ContactFlow':
        print(event)
        instanceARN = event['Details']['ContactData']['InstanceARN']
        instanceDetails = instanceARN.split(":")
        region = instanceDetails[3]
        account = instanceDetails[4]
        instanceARNindex = (instanceDetails[5].find('/')+1)
        instanceID = instanceDetails[5][instanceARNindex:]
        s3BucketName = "amazon-connect-" + instanceDetails[5][instanceARNindex:]
    
        latest_stream_arn = event['Details']['ContactData']['MediaStreams']['Customer']['Audio']['StreamARN']
        contactId = event['Details']['ContactData']['ContactId']
        startFragmentNumber = event['Details']['ContactData']['MediaStreams']['Customer']['Audio']['StartFragmentNumber']
        session = json.loads(event['Details']['Parameters']['session'])
        print('#####    KINESIS VIDEO STREAM START FRAGMENT: ' + startFragmentNumber + '   #####')
        print('#####    S3 BUCKET: ' + s3BucketName + '   #####')
        s3TempFile = 'audio/VM-' + contactId + '.tmp' 
        body = 'save|' + session['queueFlowID'] + '|' + session['queue']
        s3Resource = boto3.resource('s3', region)
        s3Resource.Object(s3BucketName, s3TempFile).put(Body=body)

        inputParams = {
            "streamARN": latest_stream_arn,
            "startFragmentNum": startFragmentNumber,
            "connectContactId": contactId,
            "languageCode": "en-US",
            "transcriptionEnabled": "true",
            "saveCallRecording": "true",
            "streamAudioFromCustomer": "true",
            "streamAudioToCustomer": "false"
        }
    
        responseFromKVSTransFunction = client.invoke(
            #FunctionName = 'arn:aws:lambda:ca-central-1:003143589821:function:kvs_Converter',
            FunctionName = 'arn:aws:lambda:ca-central-1:' + account + ':function:kvs_Converter',
            InvocationType = 'RequestResponse',
            Payload = json.dumps(inputParams)
        )
        #InvokeResult = json.load(responseFromKVSTransFunction['Payload'])
        print('#####    KINESIS VIDEO STREAM COMPLETE: ' + str(responseFromKVSTransFunction) + '    #####')
        #print(responseFromKVSTransFunction)
        #print(InvokeResult)
    
    elif eventSource == 'aws:s3':
        print(event)
        session =''
        s3BucketName = event['Records'][0]['s3']['bucket']['name']
        region = event['Records'][0]['awsRegion'] 
        eventTime = event['Records'][0]['eventTime'] 
        vmail = urllib.parse.unquote(event['Records'][0]['s3']['object']['key']) 

        s3Client = boto3.client('s3', region)
        try:
        #if responseFromKVSTransFunction['StatusCode'] == 200:
        #    response = s3Client.list_objects_v2(
        #        Bucket = s3BucketName,
        #        MaxKeys = 1,
        #        Prefix = 'audio/' + contactId,
        #    )
        #    vmail = response['Contents'][0]['Key']
            if 'VM-' in vmail:
                raise Exception('skip')
            print('#####   NEW VOICEMAIL FOUND: ' + vmail + '   #####')
            os.chdir('/tmp')
            filePath = os.path.join(os.getcwd(), eventTime, vmail)
            s3Resource = boto3.resource('s3', region)

            if not os.path.exists(filePath):
                if not os.path.exists(eventTime):
                    os.makedirs(eventTime)
                    os.chdir(eventTime)
                    if not os.path.exists('audio'):
                        os.makedirs('audio')
                else:
                    os.chdir(eventTime)
                    if not os.path.exists('audio'):
                        os.makedirs('audio')
                s3Resource.meta.client.download_file(s3BucketName, vmail, filePath)

                # Delete original voice mail
                print('#####   DELETING ORIGINAL VOICEMAIL: ' + vmail + '   #####')
                response = s3Client.delete_object(
                    Bucket=s3BucketName,
                    Key=vmail
                )

                toFile = '/tmp/'+ eventTime + '/' +vmail
                contactIdIndex = vmail.find('/')+1
                contactId = vmail[contactIdIndex:contactIdIndex+36]
                s3File = 'audio/VM-' + contactId + '.wav' 
                import pydub
                from os import path
                from pydub import AudioSegment
                AudioSegment.converter = '/var/task/ffmpeg'
                AudioSegment.from_wav(filePath).export(toFile, format="wav", codec="pcm_mulaw", parameters=["-ar","8000"])
                print('#####    VOICEMAIL CONVERSION COMPLETE: ' + s3File + '   #####')
                #s3Resource.Object(s3BucketName, vmail).put(Body=open(toFile, 'rb'))
                s3Resource.Object(s3BucketName, s3File).put(Body=open(toFile, 'rb'))

        except Exception as ex1:
            if 'skip' not in str(ex1):
                print('#####    VOICEMAIL CONVERSION ERROR: ' + str(ex1) + '    #####')
    else:
        # This part of the code handles caller DISCONNECT to determine if vmail exists and creates Amazon Connect Task
        session = ''
        import time
        instanceARN = event['resources'][0]
        instanceDetails = instanceARN.split(":")
        region = instanceDetails[3]
        account = instanceDetails[4]
        instanceARNindex = (instanceDetails[5].find('/')+1)
        instanceID = instanceDetails[5][instanceARNindex:]
        s3BucketName = "amazon-connect-" + instanceID

        contactId = event['detail']['contactId']
        s3Client = boto3.client('s3', region)

        if event['detail']['eventType'] == 'DISCONNECTED' and event['detail']['channel'] == 'VOICE':
            #Handle Voice Disconnect Event
            #Check to see if Event = DISCONNECTED
            #Check to see if .tmp file exists
            #if .tmp files exists, then wait and loop until .wav file is found.  Then create Amazon Connect Task and delete tmp file
            tmpFile = 'not found'
            vmail = 'not found' 
            tmpFilePrefix = 'audio/VM-' + contactId + '.tmp' 
            try:
                response = s3Client.list_objects_v2(
                    Bucket = s3BucketName,
                    MaxKeys = 1,
                    Prefix = tmpFilePrefix,
                )
                tmpFile = response['Contents'][0]['Key']
            except:
                pass

            if 'not found' not in tmpFile:
                print(event)
                print('#####    VOICE MAIL TMP FILE WAS FOUND: ' + tmpFile + '   #####')
                response = s3Client.get_object(Bucket=s3BucketName, Key=tmpFile)
                #tmpContents = json.loads(obj['Body'].read().decode('utf-8'))
                #tmpContents = obj.get()['Body'].read().decode('utf-8')
                tmpContents = response['Body'].read().decode('utf-8').split('|')
                print('#####    VOICE MAIL TMP FILE CONTENTS: ' + str(tmpContents) + '   #####')
                print('#####    NOW DELETING TMP FILE: ' + tmpFile + '   #####')
                response = s3Client.delete_object(
                    Bucket=s3BucketName,
                    Key=tmpFile
                )

                if tmpContents[0] == 'cancel':
                    vmail = 'already deleted'

                while vmail == 'not found':
                    try:
                        response = s3Client.list_objects_v2(
                            Bucket = s3BucketName,
                            MaxKeys = 1,
                            Prefix = 'audio/VM-' + contactId + '.wav',
                        )
                        vmail = response['Contents'][0]['Key']
                        print('#####    VOICE MAIL WAS FOUND: ' + vmail + '   #####')
                        if tmpContents[0] == 'save':
                            #CREATE AMAZON CONNECT TASK
                            connectClient = boto3.client('connect')
                            #connectClient = setConnectClient(region, account)
                            response = connectClient.start_task_contact(
                                InstanceId = instanceID,
                                ContactFlowId = tmpContents[1],
                                Attributes={
                                    'CONTACTID': contactId,
                                    'QUEUE': tmpContents[2]
                                #    'VOICEMAIL': vmail,
                                },
                                Name='NEW VOICE MAIL',
                                #References={
                                #    'VOICEMAIL': {
                                #        'Value': vmailUrl,
                                #        'Type': 'URL'
                                #        #'Type': 'URL'|'ATTACHMENT'|'NUMBER'|'STRING'|'DATE'|'EMAIL'
                                #    }
                                #},
                                Description='A new voice mail was found',
                                #ClientToken='string',
                                #ScheduledTime=datetime(2015, 1, 1),
                                #TaskTemplateId='string',
                                #QuickConnectId='string',
                                #RelatedContactId='string'
                            )
                            # Copy original email to new Task ContactId 
                            print('#####    AMAZON TASK CREATED: ' + str(response) + '   #####')

                            vmailRenamed = 'audio/VM-' + response['ContactId'] + '.wav'
                            vmailUrl = 'https://' + s3BucketName + '.s3.' + region + '.amazonaws.com/' + vmailRenamed
                            copySource = {'Bucket': s3BucketName, 'Key': vmail}
                            s3Client.copy_object(Bucket = s3BucketName, CopySource = copySource, Key = vmailRenamed)
                            s3Client.delete_object(Bucket = s3BucketName, Key = vmail)

                            response = connectClient.update_contact(
                                InstanceId=instanceID,
                                ContactId=response['ContactId'],
                                Name='NEW VOICE MAIL',
                                Description='A new voice mail has arrived',
                                References={
                                    'VOICEMAIL': {
                                        'Value': vmailUrl,
                                        'Type': 'URL'
                                    }
                                }
                            )

                            #response = connectClient.update_contact_attributes(
                            #    InitialContactId = response['ContactId'],
                            #    InstanceId = instanceID,
                            #    Attributes={
                            #        'VOICEMAIL': vmailUrl 
                            #    }
                            #)
                            print('#####    AMAZON TASK UPDATED: ' + str(response) + '   #####')
                        elif tmpContents[0] == 'delete':
                            print('#####    DELETING VOICE MAIL: ' + vmail + '    #####')
                            s3Client.delete_object(Bucket = s3BucketName, Key = vmail)

                    except Exception as ex1:
                        print('#####    AMAZON TASK EXCEPTION: ' + str(ex1) + '   #####')
                    
                    time.sleep(10)

        if event['detail']['eventType'] == 'DISCONNECTED' and event['detail']['channel'] == 'TASK' and event['detail']['initiationMethod'] == 'API':
            #Delete voice mail
            print(event)
            vmailRenamed = 'audio/VM-' + contactId + '.wav'
            print('#####    AMAZON TASK COMPLETED.  DELETING VOICE MAIL: ' + vmailRenamed + '    #####')
            s3Client.delete_object(Bucket = s3BucketName, Key = vmailRenamed)

    return {
        "statusCode": "200",
        "session": session
    }

