rm ../ConnectKVS2Audio.zip
zip -r -X ../ConnectKVS2Audio.zip . 
/usr/local/bin/aws s3 cp ../ConnectKVS2Audio.zip s3://compucom-rdf
