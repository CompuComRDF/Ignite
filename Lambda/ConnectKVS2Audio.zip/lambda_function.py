import json
import boto3
import os
import time
import datetime
import urllib.parse
import random
from botocore.config import Config

client = boto3.client('lambda')

def lambda_handler(event, context):
    print(event)
    try:
        #S3 Event = aws:s3
        eventSource = event['Records'][0]['eventSource'] 
    except:
        try:
            #Amazon Connect Contact Event = aws.connect
            eventSource = event['source']
            instanceARN = event['resources'][0]
            instanceDetails = instanceARN.split(":")
            region = instanceDetails[3]
            account = instanceDetails[4]
            instanceARNindex = (instanceDetails[5].find('/')+1)
            instanceID = instanceDetails[5][instanceARNindex:]            
            if event['detail']['eventType'] == 'CONNECTED_TO_AGENT' and event['detail']['contactDetails']['Name'] == 'NEW VOICE MAIL':
                eventSource = 'PresignedURL'
        except:
            #Amazon Connect Contact Flow Event
            eventSource = 'ContactFlow'

    if eventSource == 'PresignedURL':
        session = ''
       
        s3Config = Config(signature_version = 'v4')
        s3Client = boto3.client('s3', region, config=s3Config)
        s3BucketName = "amazon-connect-" + instanceID
        contactId = event['detail']['contactId']
        vmailUrl = s3Client.generate_presigned_url(
            ClientMethod='get_object',
            Params = {'Bucket': s3BucketName, 'Key': 'audio/VM-' + contactId + '.wav'},
            ExpiresIn=1800)        

        params = {
            'btn_play': vmailUrl 
        }
        connect_jitter('update_contact_attributes', params, contactId, instanceID)
        clearContactAttributes(instanceID, contactId, 'VOICEMAIL')

    elif eventSource == 'ContactFlow':
        instanceARN = event['Details']['ContactData']['InstanceARN']
        instanceDetails = instanceARN.split(":")
        region = instanceDetails[3]
        account = instanceDetails[4]
        instanceARNindex = (instanceDetails[5].find('/')+1)
        instanceID = instanceDetails[5][instanceARNindex:]        
        s3BucketName = "amazon-connect-" + instanceDetails[5][instanceARNindex:]
        ani = event['Details']['ContactData']['CustomerEndpoint']['Address'][1:]    

        latest_stream_arn = event['Details']['ContactData']['MediaStreams']['Customer']['Audio']['StreamARN']
        contactId = event['Details']['ContactData']['ContactId']
        startFragmentNumber = event['Details']['ContactData']['MediaStreams']['Customer']['Audio']['StartFragmentNumber']
        session = json.loads(event['Details']['Parameters']['session'])
        print('#####    KINESIS VIDEO STREAM START FRAGMENT: ' + startFragmentNumber + '   #####')
        print('#####    S3 BUCKET: ' + s3BucketName + '   #####')

        response = connect_jitter('list_contact_flows', {}, contactId, instanceID)

        flowID = ''
        for flow in response['ContactFlowSummaryList']:
            if flow['Name'] == 'Connect-RDF-Init':
                flowID = flow['Id']

        s3TempFile = 'audio/VM-' + contactId + '.tmp' 
        #body = 'save|' + session['queueFlowID'] + '|' + session['queue'] + '|' + ani + '|' + vmQueueName+ '|' session['agentTip']
        try:
            vmQueueName = session['vmQueueName']
        except:
            vmQueueName = 'NOT SET'
        body = 'save|' + flowID + '|' + session['queue'] + '|' + ani + '|' + vmQueueName + '|' + session['agentTip']
        s3Resource = boto3.resource('s3', region)
        s3Resource.Object(s3BucketName, s3TempFile).put(Body=body)

        inputParams = {
            "streamARN": latest_stream_arn,
            "startFragmentNum": startFragmentNumber,
            "connectContactId": contactId,
            "languageCode": "en-US",
            "transcriptionEnabled": "true",
            "saveCallRecording": "true",
            "streamAudioFromCustomer": "true",
            "streamAudioToCustomer": "false"
        }
    
        responseFromKVSTransFunction = client.invoke(
            #FunctionName = 'arn:aws:lambda:ca-central-1:003143589821:function:kvs_Converter',
            #FunctionName = 'arn:aws:lambda:ca-central-1:' + account + ':function:kvs_Converter',
            FunctionName = 'arn:aws:lambda:' + region + ':' + account + ':function:kvs_Converter',
            InvocationType = 'RequestResponse',
            Payload = json.dumps(inputParams)
        )
        print('#####    KINESIS VIDEO STREAM COMPLETE: ' + str(responseFromKVSTransFunction) + '    #####')

    elif eventSource == 'aws:s3':
        session =''
        s3BucketName = event['Records'][0]['s3']['bucket']['name']
        region = event['Records'][0]['awsRegion'] 
        eventTime = event['Records'][0]['eventTime'] 
        vmail = urllib.parse.unquote(event['Records'][0]['s3']['object']['key']) 

        s3Client = boto3.client('s3', region)
        try:
            if 'VM-' in vmail:
                raise Exception('skip')
            print('#####   NEW VOICEMAIL FOUND: ' + vmail + '   #####')
            os.chdir('/tmp')
            filePath = os.path.join(os.getcwd(), eventTime, vmail)
            s3Resource = boto3.resource('s3', region)

            if not os.path.exists(filePath):
                if not os.path.exists(eventTime):
                    os.makedirs(eventTime)
                    os.chdir(eventTime)
                    if not os.path.exists('audio'):
                        os.makedirs('audio')
                else:
                    os.chdir(eventTime)
                    if not os.path.exists('audio'):
                        os.makedirs('audio')
                s3Resource.meta.client.download_file(s3BucketName, vmail, filePath)

                # Delete original voice mail
                print('#####   DELETING ORIGINAL VOICEMAIL: ' + vmail + '   #####')
                response = s3Client.delete_object(
                    Bucket=s3BucketName,
                    Key=vmail
                )

                toFile = '/tmp/'+ eventTime + '/' +vmail
                contactIdIndex = vmail.find('/')+1
                contactId = vmail[contactIdIndex:contactIdIndex+36]
                s3File = 'audio/VM-' + contactId + '.wav' 
                import pydub
                from os import path
                from pydub import AudioSegment
                AudioSegment.converter = '/var/task/ffmpeg'
                AudioSegment.from_wav(filePath).export(toFile, format="wav", codec="pcm_mulaw", parameters=["-ar","8000"])
                print('#####    VOICEMAIL CONVERSION COMPLETE: ' + s3File + '   #####')
                s3Resource.Object(s3BucketName, s3File).put(Body=open(toFile, 'rb'))

        except Exception as ex1:
            if 'skip' not in str(ex1):
                print('#####    VOICEMAIL CONVERSION ERROR: ' + str(ex1) + '    #####')

    else:
        # This part of the code handles caller DISCONNECT to determine if vmail exists and creates Amazon Connect Task
        session = ''
        import time
        s3Config = Config(signature_version = 'v4')

        #instanceARN = event['resources'][0]
        #instanceDetails = instanceARN.split(":")
        #region = instanceDetails[3]
        #account = instanceDetails[4]
        #instanceARNindex = (instanceDetails[5].find('/')+1)
        #instanceID = instanceDetails[5][instanceARNindex:]
        s3BucketName = "amazon-connect-" + instanceID

        contactId = event['detail']['contactId']
        s3Client = boto3.client('s3', region, config=s3Config)

        if event['detail']['eventType'] == 'DISCONNECTED' and event['detail']['channel'] == 'VOICE':
            #Handle Voice Disconnect Event
            #Check to see if Event = DISCONNECTED
            #Check to see if .tmp file exists
            #if .tmp files exists, then wait and loop until .wav file is found.  Then create Amazon Connect Task and delete tmp file
            #print(event)
            tmpFile = 'not found'
            vmail = 'not found' 
            tmpFilePrefix = 'audio/VM-' + contactId + '.tmp' 
            try:
                response = s3Client.list_objects_v2(
                    Bucket = s3BucketName,
                    MaxKeys = 1,
                    Prefix = tmpFilePrefix,
                )
                tmpFile = response['Contents'][0]['Key']
            except:
                pass

            if 'not found' not in tmpFile:
                print(event)
                print('#####    VOICE MAIL TMP FILE WAS FOUND: ' + tmpFile + '   #####')
                response = s3Client.get_object(Bucket=s3BucketName, Key=tmpFile)
                tmpContents = response['Body'].read().decode('utf-8').split('|')
                #print('#####    VOICE MAIL TMP FILE CONTENTS: ' + str(tmpContents) + '   #####')
                #print('#####    NOW DELETING TMP FILE: ' + tmpFile + '   #####')
                response = s3Client.delete_object(
                    Bucket=s3BucketName,
                    Key=tmpFile
                )

                if tmpContents[0] == 'cancel':
                    vmail = 'already deleted'

                while vmail == 'not found':
                    try:
                        response = s3Client.list_objects_v2(
                            Bucket = s3BucketName,
                            MaxKeys = 1,
                            Prefix = 'audio/VM-' + contactId + '.wav',
                        )
                        vmail = response['Contents'][0]['Key']
                        print('#####    VOICE MAIL RECORDING WAS FOUND: ' + vmail + '   #####')
                        if tmpContents[0] == 'save':
                            #Get Voice Mail transcription
                            print('#####    READING DYNAMO FOR TRANSCRIPTION USING KEY: ' + contactId + '    #####')
                            vmTranscription = ''
                            try: 
                                vmTranscription = readRecords('ivr-recording-contactTranscriptSegments', contactId, region)
                            except Exception as ex1:
                                print('#####    GET TRANSCRIPTION EXCEPTION: ' + str(ex1) + '    #####')
                                vmTranscription = 'No transcription available'

                            #CREATE AMAZON CONNECT TASK
                            connectClient = boto3.client('connect')
                            response = connectClient.start_task_contact(
                                InstanceId = instanceID,
                                ContactFlowId = tmpContents[1],
                                Attributes={
                                    'contactID': contactId,
                                    'QUEUE': tmpContents[2],
                                    'PHONE': '+' + tmpContents[3],
                                    'VMQUEUE': tmpContents[4],
                                    'agentTip': tmpContents[5]
                                },
                                Name='VOICE MAIL FROM ' + tmpContents[3],
                                #Description='New voice mail was found',
                                Description=vmTranscription,
                            )
                            # Copy original email to new Task ContactId 
                            print('#####    AMAZON TASK CREATED: ' + str(response) + '   #####')

                            vmailRenamed = 'audio/VM-' + response['ContactId'] + '.wav'
                           
                            copySource = {'Bucket': s3BucketName, 'Key': vmail}
                            s3Client.copy_object(Bucket = s3BucketName, CopySource = copySource, Key = vmailRenamed)
                            s3Client.delete_object(Bucket = s3BucketName, Key = vmail)

                            initialContactID = response['ContactId']
                            response = connectClient.update_contact(
                                InstanceId=instanceID,
                                ContactId=initialContactID,
                                Name='NEW VOICE MAIL',
                                Description= 'Voice Mail received from ' + tmpContents[3] + '.  Press PLAY.',
                                References={
                                    'Transcription': {
                                        'Value': vmTranscription,
                                        'Type': 'STRING'
                                    }
                                }
                            )
                            
                            params = {
                                'voiceMail': vmailRenamed 
                            }
                            connect_jitter('update_contact_attributes', params, initialContactID, instanceID)

                            print('#####    AMAZON TASK UPDATED: ' + str(response) + '   #####')

                            #Delete Voice Mail transcription
                            try: 
                                deleteRecords('ivr-recording-contactTranscriptSegments', contactId, region)
                            except Exception as ex1:
                                print('#####    DELETE TRANSCRIPTION EXCEPTION: ' + str(ex1) + '    #####')

                        elif tmpContents[0] == 'delete':
                            print('#####    DELETING VOICE MAIL: ' + vmail + '    #####')
                            s3Client.delete_object(Bucket = s3BucketName, Key = vmail)

                            #Delete Voice Mail transcription
                            try: 
                                deleteRecords('ivr-recording-contactTranscriptSegments', contactId, region)
                            except Exception as ex1:
                                print('#####    DELETE TRANSCRIPTION EXCEPTION: ' + str(ex1) + '    #####')

                    except Exception as ex1:
                        print('#####    AMAZON TASK EXCEPTION: ' + str(ex1) + '   #####')
                    
                    time.sleep(10)

            #Clean up Contact Attributes not required for post contact processing            
            clearContactAttributes(instanceID, contactId, event['detail']['initiationMethod'])

        if event['detail']['eventType'] == 'DISCONNECTED' and event['detail']['channel'] == 'TASK' and event['detail']['initiationMethod'] == 'API':
            #Delete voice mail
            print(event)
            clearContactAttributes(instanceID, contactId, event['detail']['initiationMethod'])
            try:
                if event['detail']['agentInfo']['agentArn']:
                    vmailRenamed = 'audio/VM-' + contactId + '.wav'
                    print('#####    AMAZON TASK COMPLETED.  DELETING VOICE MAIL: ' + vmailRenamed + '    #####')
                    s3Client.delete_object(Bucket = s3BucketName, Key = vmailRenamed)
            except:
                pass
    return {
        "statusCode": "200",
        "session": session
    }

def readRecords(tableName, key, region):
    from boto3.dynamodb.conditions import Key

    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(tableName)

    try:
        dynamodb_response = table.query(
            KeyConditionExpression=Key('ContactId').eq(key)
        )
        print('#####    DYNAMODB RESPONSE: ' + str(dynamodb_response) + '    #####')
        print(dynamodb_response['Items'][0]['ContactId']) #Creates Exception if key doesn't exist

        full_response = ''
        for i in range(len(dynamodb_response['Items'])):
            full_response += dynamodb_response['Items'][i]['Transcript']
            full_response += ' ' 
        return(full_response)

    except Exception as ex1:
        print('#####    DYNAMODB READ EXCEPTION: ' + str(ex1) + '    #####')
        return("Transcription is not available")

def deleteRecords(tableName, key, region):
    from boto3.dynamodb.conditions import Key

    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(tableName)

    try:
        dynamodb_response = table.query(
            KeyConditionExpression=Key('ContactId').eq(key)
        )
        print('#####    DYNAMODB RESPONSE: ' + str(dynamodb_response) + '    #####')
        print(dynamodb_response['Items'][0]['ContactId']) #Creates Exception if key doesn't exist

        items_to_delete = []
        for i in range(len(dynamodb_response['Items'])):
            item = {}
            item['ContactId']=dynamodb_response['Items'][i]['ContactId']
            item['StartTime']=dynamodb_response['Items'][i]['StartTime']
            print('item: ' + str(item))
            items_to_delete.append(item) 

        print('items to delete: ' + str(items_to_delete))
        
        with table.batch_writer() as batch:
            for j in items_to_delete:
                response = batch.delete_item(Key={
                    "ContactId": j["ContactId"], # Change key and value names
                    "StartTime": j["StartTime"]
                })
                print('#####    DYNAMODB RESPONSE: ' + str(response) + '    #####')
    except Exception as ex1:
        print('#####    DYNAMODB DELETE EXCEPTION: ' + str(ex1) + '    #####')

    return()

def clearContactAttributes(instanceID, contactId, initiationMethod):
    qc=''
    clearAttributes = False
    attributesToUpdate = {
        "session": "",
        "RDF": "",
        "blockAction": "",
        "blockParam": "",
        "promptIndex": "",
        "promptSize": "",
        "blockType": "",
        "actionTrue": "",
        "actionFalse": "",
        "resetQueue": "",
        "barge": "",
        "globalInputTerm": "",
        "inputLength": "",
        "maxAction": "",
        "menuLoop": "",
        "prompt": "",
        "promptLoop": "",
        "promptType": "",
        "errorMessage": "",
        "ConnectRDFInitID": "",
        "ConnectRDFLanguagesID": "",
        "ConnectRDFMainID": "",
        "ConnectRDFPlayID": "",
        "ConnectRDFRecordID": "",
        "sequenceParam": "",
        "sequenceValue": "",
        "sequencePrompt": "",
        "sequenceARN": "",
        "sequenceKeyID": "",
        "sequenceProjID": "",
        "sequenceKeyCert": ""
    }

    get_contact_attributes_response = connect_jitter('get_contact_attributes', {}, contactId, instanceID)    

    try:
        qc = get_contact_attributes_response['Attributes'].get('qc','')
    except:
        pass
    
    if qc != 'Secure IVR Payment':
        if initiationMethod == 'INBOUND' or initiationMethod == 'CALLBACK':
            clearAttributes = True
            time.sleep(8)
        elif initiationMethod == 'VOICEMAIL':
            clearAttributes = True

    if clearAttributes:
        try:
            connect_jitter('update_contact_attributes', attributesToUpdate, contactId, instanceID)
        except:
            print("Failed to clear attributes.")

    s3Client = boto3.client('s3')
    try:
        s3Client.delete_object(
            Bucket="amazon-connect-" + instanceID,
            Key='tmp/' + contactID + '.tmp'
        )
        print("DELETING TMP FILE: " + 'tmp/' + contactID + '.tmp')
    except:
        pass

def connect_jitter(function, params, contactId, instanceID):
    connectClient = boto3.client('connect')
    max_tries = 5
    prev_delay = 1.0
    response = {}

    for attempt in range(max_tries):
        try:
            if attempt > 0:
                print(f'#####   {function} Reattempt {attempt}' + '   #####')

            if function == 'get_contact_attributes':
                response = connectClient.get_contact_attributes(
                    InitialContactId=contactId,
                    InstanceId=instanceID,
                )

            elif function == 'update_contact_attributes':
                response = connectClient.update_contact_attributes(
                    InitialContactId=contactId,
                    InstanceId=instanceID,
                    Attributes=params
                )
                print("UPDATED CONTACT ATTRIBUTES: " +str(params))

            elif function == 'list_contact_flows':
                response = connectClient.list_contact_flows(
                    InstanceId = instanceID,
                    ContactFlowTypes = ['CONTACT_FLOW'],
                    MaxResults=100
                )

            if attempt > 0:
                print(f'#####   {function} Reattempt {attempt} success' + '   #####')

            break
        except Exception as Ex1:
            print(f'#####   {function} Exception: ' + str(Ex1) + '   #####')
            if attempt == max_tries -1:
                break
            #Exponential backoff with full jitter
            prev_delay=decorrelated_jitter(prev_delay)
            print(f'#####   {function} Retrying in {prev_delay:.2f} seconds' + '   #####')
            time.sleep(prev_delay)

    return response

def decorrelated_jitter(prev_delay, base=1.0, cap=4.0):
    return min(cap, random.uniform(base, prev_delay * 3))
