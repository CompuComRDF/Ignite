import json
import boto3
import synthesize
import logger
import util
import config
import tenants
import queues
import instances
import phonenumbers
import datetime
import users
import csv
from io import StringIO
import os
#from datetime import datetime
from boto3.dynamodb.conditions import Attr

dynamodb_client = boto3.client('dynamodb')
dynamodb_resource = boto3.resource('dynamodb')

def get_tenant_apps(s3_client, ou, tenant_id, connect_id):
    logger.info(f"GETTING APPLICATIONS LIST: {tenant_id}")
    tenant_app_list = []
    
    try:
        response = dynamodb_client.scan(
            TableName='Tenants-' + ou
        )
        
        for tenant_app in response['Items']:
            if tenant_id == util.get_tenant_id(tenant_app['Tenant']['S']):
                greeting = {"en-US": ""}
                business_hours = 'Default'
                holidays = 'Default'
                call_flow = ''
                contact_flow = ''

                flow_control = {}
                raw_control = json.loads(tenant_app.get('FlowControl', {}).get('S'))

                for flow in raw_control:
                    if isinstance(raw_control[flow], dict):
                        flow_control[flow] = next(iter(raw_control[flow]))
                        if next(iter(raw_control[flow])) == 'Greeting':
                            greeting = raw_control[flow]['Greeting']
                        if next(iter(raw_control[flow])) == 'OfficeHours':
                            business_hours = 'Default' if raw_control[flow]['OfficeHours'] == 'Tenant' else raw_control[flow]['OfficeHours']
                            holidays = 'Default' if raw_control[flow]['OfficeHours'] == 'Tenant' else raw_control[flow]['OfficeHours']
                        if next(iter(raw_control[flow])) == 'CallFlow':
                            call_flow = raw_control[flow]['CallFlow']
                        if next(iter(raw_control[flow])) == 'Custom':
                            call_flow = raw_control[flow]['Custom']
                        if next(iter(raw_control[flow])) == 'ContactFlow':
                            contact_flow = raw_control[flow]['ContactFlow']
                    else:
                        flow_control[flow] = raw_control[flow]

                versions = list_application_versions(s3_client, f"amazon-connect-{connect_id}", tenant_app['Tenant']['S'])

                tenant_app_list.append({
                    "AppID" : util.get_app_id(tenant_app['Tenant']['S']),
                    "Language" : tenant_app.get('Language', {}).get('S'),
                    "CallFlow" : call_flow,
                    "ContactFlow" : contact_flow,
                    "DNIS": tenant_app.get('DNIS', {}).get('S'),
                    "Greeting": json.dumps(greeting),
                    "Queues": json.dumps([]),
                    "Description": tenant_app.get('Description', {}).get('S'),
                    "flowControl":json.dumps(flow_control),
                    "BusinessHours": business_hours,
                    "Holidays": holidays,
                    "Prompts": tenants.read_tts(s3_client, tenant_id, util.get_app_id(tenant_app['Tenant']['S']), ['pleasehold', 'monitor', 'noagents', 'busy1', 'busy2', 'busy3', 'callbackmenu', 'entercallback', 'callbacknotice', 'highvolume', 'stillbusy', 'goodbye']),
                    "Versions": versions
                })

        tenant_app_list = sorted(tenant_app_list, key=lambda x: x["AppID"])    

        logger.info(f"TENANT APP LIST: {tenant_app_list}")
    except Exception as Ex1:
        logger.info("get_tenant_apps EXCEPTION: " + str(Ex1))

    return(tenant_app_list)

def get_tenant_apps_v2(s3_client, ou, tenant_id, connect_id):
    logger.info(f"GETTING APPLICATIONS LIST: {tenant_id}")
    tenant_app_list = []
    
    try:
        response = dynamodb_client.scan(
            TableName='Tenants-' + ou
        )
        
        for tenant_app in response['Items']:
            if tenant_id == util.get_tenant_id(tenant_app['Tenant']['S']):
                versions = list_application_versions(s3_client, f"amazon-connect-{connect_id}", tenant_app['Tenant']['S'])

                tenant_app_list.append({
                    "AppID" : util.get_app_id(tenant_app['Tenant']['S']),
                    "Language" : json.loads(tenant_app.get('Language', {}).get('S')),
                    "DNIS": json.loads(tenant_app.get('DNIS', {}).get('S')),
                    "Description": tenant_app.get('Description', {}).get('S'),
                    "flowControl":json.loads(tenant_app.get('FlowControl', {}).get('S')),
                    "Prompts": tenants.read_tts(s3_client, tenant_id, util.get_app_id(tenant_app['Tenant']['S']), ['pleasehold', 'monitor', 'noagents', 'busy1', 'busy2', 'busy3', 'callbackmenu', 'entercallback', 'callbacknotice', 'highvolume', 'stillbusy', 'goodbye']),
                    "Versions": versions
                })

        tenant_app_list = sorted(tenant_app_list, key=lambda x: x["AppID"])    

        logger.info(f"TENANT APP LIST: {tenant_app_list}")
    except Exception as Ex1:
        logger.info("get_tenant_apps EXCEPTION: " + str(Ex1))

    return(tenant_app_list)

def insert_app_record(event, s3_client, s3_resource, role_credentials, connect_id):
    ou = event.get('Env')
    tenant_id = event.get('TenantID')
    app_id = event.get('AppID')
    app_folder = f"{tenant_id}-{app_id}"
    description = event.get('Description')
    dnis_array = event.get('DNIS')
    default_greeting = f"You've reached the {app_id} application."
    multi_languages, _ = instances.get_languages(ou, tenant_id)
    greeting = {}

    s3_central_client = boto3.client('s3')
    s3_central_bucket = instances.get_central_bucket(s3_central_client)   
    s3_bucket = f"amazon-connect-{connect_id}"
    
    logger.info(f"CREATING NEW APPLICATION: {app_folder}")
    
    files_to_copy = get_file_list(s3_central_client, s3_central_bucket, 'IVR', False)
    deploy_files(s3_central_client, s3_resource, s3_central_bucket, s3_bucket, files_to_copy, app_folder)

    # Rename menutree files
    copy_source = {"Bucket": s3_bucket, "Key": f"{app_folder}/config/ivr-menutree.csv"}
    s3_client.copy_object(Bucket=s3_bucket, CopySource=copy_source, Key=f"{app_folder}/config/{app_id}-menutree.csv")
    s3_client.delete_object(Bucket=s3_bucket, Key=f"{app_folder}/config/ivr-menutree.csv")    
    copy_source = {"Bucket": s3_bucket, "Key": f"{app_folder}/config/ivr-menutree-flow.json"}
    s3_client.copy_object(Bucket=s3_bucket, CopySource=copy_source, Key=f"{app_folder}/config/{app_id}-menutree-flow.json")
    s3_client.delete_object(Bucket=s3_bucket, Key=f"{app_folder}/config/ivr-menutree-flow.json")

    for language in multi_languages:
        greeting[language] = util.translate_text(default_greeting, 'en-US', language)

    greeting = create_language_menu(ou, tenant_id, app_id, s3_client, greeting, multi_languages, ['en-US'])

    flow_control = {'0' : {'Greeting' : greeting}, '1': {'Queue' : ''}}

    try:
        current_time = datetime.datetime.now(datetime.timezone.utc)
        table = boto3.resource('dynamodb', region_name=config.region).Table('Tenants-' + ou)
 
        table.put_item(Item= {
            'Tenant': app_folder, 
            'Language': json.dumps(multi_languages, ensure_ascii=False),
            'Description': description, 
            'DNIS': dnis_array, 
            'FlowControl': json.dumps(flow_control),
            'LastUpdated':current_time.isoformat()
        })

    except Exception as ex1:
        logger.info(f"insert_app_record EXCEPTION FOUND: {ex1}")

    prompts = tenants.read_tts(s3_client, tenant_id, app_id, [])
    new_prompts = {}
    for prompt in prompts:
        new_prompts[prompt] = {}
        for language in multi_languages:
            if language == 'en-US':
                new_prompts[prompt][language] = prompts[prompt]['en-US']
            else:
                new_prompts[prompt][language] = util.translate_text(prompts[prompt]['en-US'], 'en-US', language)

    tenants.update_tts(s3_client, s3_resource, tenant_id, app_id, new_prompts, role_credentials)
    
    s3_client.put_object(Bucket=instances.get_tenant_bucket(s3_client), Key=tenant_id + '-' + app_id + '/Project Repository/ReadMe.txt', Body=app_id + " was created on " + str(datetime.datetime.now()))

    return {
        "Language": multi_languages,
        "Greeting": greeting,
        "flowControl": '{"0":"Greeting", "1":"Queue"}',
        'Prompts': prompts
    }

def update_app_record(event, s3_client, s3_resource, role_credentials, connect_id):
    status = 'Success'
    ou = event['Env']
    tenant_id = event['TenantID']
    app_id = event['AppID']
    app_folder = f"{tenant_id}-{app_id}"
    prompts = event.get('Prompts', [])
    description = event['Description']
    old_language = json.loads(event['PreviousLanguage'])
    new_language = json.loads(event['Language'])
    greeting = json.loads(event['Greeting'])
    call_flow = event.get('CallFlow')
    raw_control = json.loads(event['flowControl'])
    business_hours = 'Tenant' if event.get('BusinessHours', 'Tenant') == 'Default' else app_id
    dnis_array = event.get('DNIS')
    contact_flow = event.get('ContactFlow')
    flow_control = {}
    table = boto3.resource('dynamodb', region_name=config.region).Table(f"Tenants-{ou}")

    logger.info('UPDATING APPLICATION: ' + app_folder)

    save_application_version(s3_resource, connect_id, table, app_folder, json.dumps(old_language), False)

    multi_languages = new_language
    greeting = create_language_menu(ou, tenant_id, app_id, s3_client, greeting, multi_languages, old_language)

    logger.info(f"GREETING: {greeting}")

    for flow in raw_control:
        if raw_control[flow] == 'Greeting':
            flow_control[flow] = {raw_control[flow] : greeting}
        elif raw_control[flow] == 'OfficeHours':
            flow_control[flow] = {raw_control[flow] : business_hours}
        elif raw_control[flow] == 'MenuTree':
            flow_control[flow] = {raw_control[flow] : f"{app_id}-menutree"}
        elif raw_control[flow] == 'CallFlow':
            flow_control[flow] = {raw_control[flow] : call_flow}
        elif raw_control[flow] == 'ContactFlow':
            flow_control[flow] = {raw_control[flow] : contact_flow}
        elif raw_control[flow] == 'Custom':
            flow_control[flow] = {raw_control[flow] : call_flow}
        else:
            flow_control[flow] = {raw_control[flow] : ''}

    try:
        current_time = datetime.datetime.now(datetime.timezone.utc)
        
        #table.delete_item(Key={"Tenant": app_folder, "Language": old_language})
 
        table.put_item(Item= {
                'Tenant': app_folder, 
                'Language': json.dumps(new_language), 
                'Description': description, 
                'DNIS': dnis_array, 
                'FlowControl': json.dumps(flow_control, ensure_ascii=False),
                'LastUpdated':current_time.isoformat()
            })

    except Exception as ex1:
        status = "Failed to update app"
        logger.info('update_app_record EXCEPTION FOUND: ' + str(ex1))

    if prompts:
        tenants.update_tts(s3_client, s3_resource, tenant_id, app_id, prompts, role_credentials)

    return status

def update_app_record_v2(event, s3_client, s3_resource, role_credentials, connect_id):
    status = 'Success'
    ou = event['Env']
    tenant_id = event['TenantID']
    app_id = event['AppID']
    app_folder = f"{tenant_id}-{app_id}"
    prompts = event.get('Prompts', [])
    description = event['Description']
    flow_control = event['flowControl']
    dnis_array = event.get('DNIS')
    old_language = event['PreviousLanguage']
    new_language = event['Language']

    greeting = None
    for flow_item in flow_control.values():
        if "Greeting" in flow_item:
            greeting = flow_item["Greeting"]
            break

    table = boto3.resource('dynamodb', region_name=config.region).Table(f"Tenants-{ou}")
    logger.info('UPDATING APPLICATION: ' + app_folder)

    save_application_version(s3_resource, connect_id, table, app_folder, old_language, False)

    multi_languages = new_language
    greeting = create_language_menu(ou, tenant_id, app_id, s3_client, greeting, multi_languages, old_language)
    logger.info(f"GREETING: {greeting}")

    try:
        current_time = datetime.datetime.now(datetime.timezone.utc)
        table.put_item(Item= {
                'Tenant': app_folder, 
                'Language': json.dumps(new_language, ensure_ascii=False), 
                'Description': description, 
                'DNIS': json.dumps(dnis_array, ensure_ascii=False), 
                'FlowControl': json.dumps(flow_control, ensure_ascii=False),
                'LastUpdated':current_time.isoformat()
            })

    except Exception as ex1:
        status = "Failed to update app"
        logger.info('update_app_record EXCEPTION FOUND: ' + str(ex1))

    if prompts:
        tenants.update_tts(s3_client, s3_resource, tenant_id, app_id, prompts, role_credentials)

    return status

def delete_app_record(event, s3_client, connect_id):
    status = 'Success'
    ou = event['Env']
    tenant_id = event.get('TenantID')
    app_id = event.get('AppID')    
    app_folder = f"{tenant_id}-{app_id}"
    language = json.loads(event['Language'])

    logger.info(f"DELETING APPLICATION: {app_folder}")

    try:
        table = boto3.resource('dynamodb', region_name=config.region).Table('Tenants-' + ou)
        table.delete_item(Key={"Tenant": app_folder, "Language": json.dumps(language)})
    except Exception as ex1:
        status = f"delete_app_record EXCEPTION FOUND: {ex1}"
        logger.error(status)

    app_files = get_file_list(s3_client, f"amazon-connect-{connect_id}", app_folder, True)
    undeploy_files(s3_client, connect_id, app_files)

    return status

def deploy_app(event, s3_source_client, s3_target_resource, connect_target_client, source_instance_details, target_instance_details, source_connect_id, target_connect_id):
    source_ou = event['SourceEnv']
    target_ou = event['TargetEnv']
    tenant_id = event['TenantID']
    app_id = event['AppID']
    dnis_array = event['DNIS']
    deploy_tenant = event['DeployTenant']
    deploy_users = event['DeployUsers']

    logger.info(f"DEPLOYING APPLICATION: {app_id} FOR TENANT: {tenant_id} FROM: {source_ou} TO: {target_ou}")
    status = 'Success'
    app_folder = f"{tenant_id}-{app_id}"

    if not phonenumbers.check_assigned_phone_number(target_ou, app_folder, dnis_array):
        status = 'Failed:  Phone number already assigned to another application'
        logger.info(status)
        
        return status
    
    dnis_id = next(
        iter(next((o for o in (json.loads(dnis_array) if isinstance(dnis_array, str) else dnis_array)
                if isinstance(o, dict) and o), {}).values()),
        None
    )
    try:
        current_time = datetime.datetime.now(datetime.timezone.utc).isoformat()
        #Deploy DynamoDB record
        source_table = dynamodb_resource.Table(f"Tenants-{source_ou}")
        dynamodb_response = source_table.scan(FilterExpression=Attr('Tenant').eq(app_folder))
        #Create copy of source item and update DNIS and LastUpdated for target
        source_item = dynamodb_response['Items'][0]
        source_item['DNIS'] = dnis_array
        source_item['LastUpdated'] = current_time

        target_table = boto3.resource('dynamodb', region_name=config.region).Table(f"Tenants-{target_ou}")
        save_application_version(s3_target_resource, target_connect_id, target_table, app_folder, source_item['Language'], True)
        target_table.put_item(Item=source_item)

        #Deploy S3 objects
        app_files = get_file_list(s3_source_client, f"amazon-connect-{source_connect_id}", app_folder, False)
        deploy_files(s3_source_client, s3_target_resource, f"amazon-connect-{source_connect_id}", f"amazon-connect-{target_connect_id}", app_files, app_folder)

        shared_files = get_shared_files(source_ou, s3_source_client, source_connect_id, json.loads(source_item['FlowControl']), app_folder, tenant_id, app_id)
        if shared_files:
            logger.info(f"FOUND SHARED MODULES TO DEPLOY: {shared_files}")
            deploy_files(s3_source_client, s3_target_resource, f"amazon-connect-{source_connect_id}", f"amazon-connect-{target_connect_id}", shared_files, 'shared')

        #Deploy Voice and Queue Settings
        if deploy_tenant:
            logger.info(f"DEPLOYING TENANT SETTINGS FOR: {tenant_id} FROM: {source_ou} TO: {target_ou}")
            voice_config_active = tenants.get_voices(source_ou, tenant_id) 
            tenants.set_voices(connect_target_client, target_connect_id, target_ou, tenant_id, voice_config_active['Active'])  
            queues.deploy_queues(tenant_id, source_instance_details, target_ou, connect_target_client, target_instance_details, dnis_id)
        #Deploy Users
        if deploy_users:
            logger.info(f"DEPLOYING USERS FOR: {tenant_id} FROM: {source_ou} TO: {target_ou}")
            users.deploy_users(source_ou, target_ou, tenant_id)

    except Exception as ex1:
        status = "Failed to deploy app"
        logger.info('deploy_app EXCEPTION FOUND: ' + str(ex1))
        
    return status

def get_file_list(s3_client, s3_bucket, app_folder, include_versions=False):
    #This function retrieves a file list used to determine the list of files from app_folder that needs to get copied
    prefix = app_folder if include_versions else f"{app_folder}/"
    logger.info(f"GETTING APPLICATION FILES FROM: {prefix}")

    app_files = []
    token = None

    try:
        while True:
            params = {
                "Bucket": s3_bucket,
                "Prefix": prefix,
                "MaxKeys": 1000,
            }
            if token:
                params["ContinuationToken"] = token

            resp = s3_client.list_objects_v2(**params)
            for obj in resp.get("Contents", []):
                app_files.append(obj["Key"])

            if not resp.get("IsTruncated"):
                break
            token = resp.get("NextContinuationToken")

    except Exception as Ex1:
        logger.info("get_file_list EXCEPTION: " + str(Ex1))

    return app_files    

def get_shared_files(source_ou, s3_source_client, source_connect_id, flow_control, app_folder, tenant_id, app_id):
    # This function is used for Deployment.  It checks an application's references to tenant configurations such as Office Hours 
    # and Call Flows that needs to get copied from the shared folder.  This is accomplished from looking in the FlowControl variable, MenuTree file,
    # and QueuesData 
    logger.info(f"GETTING REQUIRED SHARED MODULES FOR: {app_folder}")
    menutree_found = False
    shared_files = []
    target_folder = 'shared/'

    #Check FlowControl variable
    for flow_index in flow_control:
        flow_control_key, flow_control_value = next(iter(flow_control[flow_index].items()))
        if flow_control_key == 'OfficeHours':
            shared_files.append(f"{target_folder}{flow_control_value}-bushours.csv")
            shared_files.append(f"{target_folder}{flow_control_value}-holidays.csv")
        if flow_control_key == 'CallFlow' or flow_control_key == 'Custom':
            call_flow_name = f"{target_folder}{flow_control_value}-callflow.csv"
            if call_flow_name not in shared_files:
                shared_files.append(call_flow_name)

    #Check MenuTree file
    try:
        obj = s3_source_client.get_object(Bucket=f"amazon-connect-{source_connect_id}", Key=f"{app_folder}/config/{app_id}-menutree.csv")
        body = obj["Body"].read().decode('utf-8-sig')
        menutree_found = True
    except Exception as e:
        logger.info(f"No Menutree found for application {app_id}: {e}")

    if menutree_found:
        try:
            csv_reader = csv.DictReader(StringIO(body))
            menutree_contents = {row['BLOCK']: row for row in csv_reader}

            for key in menutree_contents:
                action_dict = util.convert(menutree_contents[key]['ACTION'])
                call_flow = action_dict.get('callflow', None)
                if call_flow:
                    call_flow_name = f"{target_folder}{call_flow}-callflow.csv"
                    if call_flow_name not in shared_files:
                        shared_files.append(call_flow_name)
        except:
            pass

    #Check QueuesData
    try:
        queue_data = util.get_queue_data(source_ou, tenant_id)
        if queue_data:
            queue_tags = queue_data.get('QueueTags', {})
            for queue_tag in queue_tags:
                if queue_tag == 'QueueHours' and queue_tags.get('QueueHours', '') != '':
                    office_hours_file = f"{target_folder}{queue_tags['QueueHours']}-bushours.csv"
                    holidays_file = f"{target_folder}{queue_tags['QueueHours']}-holidays.csv"
                    if office_hours_file not in shared_files:
                        shared_files.append(office_hours_file)
                    if holidays_file not in shared_files:
                        shared_files.append(holidays_file)
                if queue_tag == 'callflow' and queue_tags.get('callflow', '') != '':
                    call_flow_name = f"{target_folder}{queue_tags['callflow']}-callflow.csv"
                    if call_flow_name not in shared_files:
                        shared_files.append(call_flow_name)

    except Exception as e:
        logger.info(f"No custom queues in QueueData for {app_id}: {e}")

    return (shared_files)

def deploy_files(s3_source_client, s3_target_resource, source_bucket, target_bucket, source_file_list, target_folder):
    #This function is used to copy objects from a source S3 bucket to a destination S3 bucket
    try:
        for source_file in source_file_list:
            obj = s3_source_client.get_object(Bucket=source_bucket, Key=source_file)
            target_file = obj['Body'].read()
            logger.info(f"UPLOADING FILE: {source_file}")
            file_name = source_file[source_file.find('/')+1:]
            s3_target_resource.Object(target_bucket, f"{target_folder}/{file_name}").put(Body=target_file)            

    except Exception as Ex1:
        logger.info("deploy_files EXCEPTION: " + str(Ex1))   

def undeploy_files(s3_client, connect_id, files_to_delete):
    #This function is used to delete objects from a S3 bucket.  Objects must contain full path.
    delete_objects = []
    try:
        for source_file in files_to_delete:
            logger.info(f"DELETING FILE: {source_file}")
            delete_objects.append({
                'Key': source_file,
            })
          
        s3_client.delete_objects(
            Bucket=f"amazon-connect-{connect_id}",
            Delete={
                'Objects': delete_objects
            }
        )
 
    except Exception as Ex1:
        logger.info("undeploy_files EXCEPTION: " + str(Ex1))

def create_language_menu(ou, tenant_id, app_id, s3_client, greeting, multi_languages, old_language):
    logger.info("CREATING LANGUAGE MENU")
    new_greeting = {}
    language_menu = {}
    language_menu['greeting'] = ''
    lang_menu_opt = 0
    translation_language = old_language[0]

    logger.info("OLD GREETING: " + str(greeting))
    logger.info("TRANSLATION LANGUAGE: " + str(translation_language))
    language_menu['default'] = multi_languages[0]

    for lang in multi_languages:
        lang_menu_opt += 1
        if lang_menu_opt > 1:
            language_menu['greeting'] += '|'
        try:
            new_greeting[lang] = greeting[lang]
            language_menu['greeting'] += lang + ':' + greeting[lang]
        except:
            new_greeting[lang] = util.translate_text(greeting[translation_language], translation_language, lang)
            language_menu['greeting'] += lang + ':' + new_greeting[lang]
            
        if not new_greeting[lang].endswith(".") and not len(new_greeting[lang])==0:
            language_menu['greeting'] += '.'
        if len(multi_languages) > 1:
            language = tenants.get_voices(ou, "")['Available'][lang]['Name']
            language_parts = language.split(" ")
            language_name = language_parts[len(language_parts) - 1]            
            language_menu['greeting'] += ' ' + util.translate_text("For service in " + language_name + ", press " + str(lang_menu_opt), "en-US", lang)

    logger.info("NEW GREETING: " + str(new_greeting))

    _, active_languages = instances.get_languages(ou, tenant_id)
    synthesize.create_and_upload_combined_wav(
        language_menu,
        active_languages,
        s3_client,
        s3_bucket=instances.get_tenant_bucket(s3_client),
        s3_key=f"{tenant_id}-{app_id}/prompts/{language_menu['default']}/greeting.wav"
    )

    return new_greeting

def update_menu_tree(ou, role_credentials, s3_client, s3_resource, tenant_id, app_id, content):
    logger.info("UPDATING MENU TREE")
    import csv
    import codecs
    from io import StringIO

    data={}
    csv_buffer = StringIO()
    new_contents = []
    new_contents.append('LABEL')
    new_contents.append('QUEUE')
    languages, _ = instances.get_languages(ou, tenant_id)

    for language in languages:
        new_contents.append(language)
    
    csv_writer = csv.writer(csv_buffer, quoting=csv.QUOTE_NONNUMERIC)
    csv_writer.writerow(new_contents)

    
    if type(content) is str:
        for row in csv.DictReader(content.splitlines()):
            record = row['LABEL']
            data[record] = row
    else:
        for row in csv.DictReader(codecs.getreader("utf-8-sig")(content)):
            record = row['LABEL']
            data[record] = row

    for menu_key in data:
        new_contents = []
        new_contents.append(menu_key)
        new_contents.append(data[menu_key]['QUEUE'])
        for language in languages:
            if language in data[menu_key]:
                new_contents.append(data[menu_key][language])
            else:
                try:
                #if data[menu_key]['en-US']:
                    new_contents.append(util.translate_text(data[menu_key]['en-US'], 'en-US', language))
                    logger.info('TRANSLATING: ' + str(data[menu_key]['en-US']))
                except:
                    new_contents.append("")   
                
        csv_writer.writerow(new_contents)

    return(csv_buffer.getvalue())

def list_menu_actions(s3_client, connect_client, connect_id, connect_instance_details, ou, tenant_id, app_id):
    menu_actions = {}
    queue = queues.get_tenant_queues(tenant_id, connect_instance_details['QueueSummaryList'])
    list_contact_flows = tenants.list_contact_flows(connect_client, connect_id)
    contactflow = []
    for flow in list_contact_flows:
        contactflow.append(flow['Name'])
    callflow = util.get_callflows(s3_client, connect_id)
    
    app= []
    component = []
    tenant_apps = get_tenant_apps(s3_client, ou, tenant_id, connect_id)
    for tenant_app in tenant_apps:
        if tenant_app['AppID'] == app_id:
            flow_control = json.loads(tenant_app['flowControl'])
            for flow_type in flow_control:
                component.append(flow_control[flow_type])
        else:
            app.append(tenant_app['AppID'])

    transfer = []    
    for quick_connect in connect_instance_details['quickConnectList']['QuickConnectSummaryList']:
        if quick_connect['QuickConnectType'] == 'PHONE_NUMBER':
            describe_qc_response = connect_client.describe_quick_connect(
                InstanceId=connect_id,
                QuickConnectId=quick_connect['Id']
            )         
            transfer.append(describe_qc_response['QuickConnect']['QuickConnectConfig']['PhoneConfig']['PhoneNumber'].replace('+', ''))


    #This is for demo purposes
    menu_actions['aiagent'] = ['Support Agent']
    menu_actions['lex'] = ['User Directory']

    if app:
        menu_actions['app'] = app
    #if component:
    #    menu_actions['component'] = component
    if transfer:
        menu_actions['transfer'] = transfer
    if queue:
        menu_actions['queue'] = queue
        menu_actions['menu'] = queue + ['Dynamic']
        menu_actions['play'] = queue + ['Dynamic']
    if callflow:
        menu_actions['callflow'] = callflow
    if contactflow:
        menu_actions['contactflow'] = contactflow

    return(menu_actions)

def backup_s3_folder(s3_resource, bucket_name, app_folder, app_db_entry, time_stamp, delete):
    bucket = s3_resource.Bucket(bucket_name)
    backup_folder = f"{app_folder}-{time_stamp}"

    objects = list(bucket.objects.filter(Prefix=f"{app_folder}/"))
    if objects:
        for obj in objects:
            old_key = obj.key
            new_key = old_key.replace(app_folder, backup_folder, 1)

            # Copy object to new key
            s3_resource.Object(bucket_name, new_key).copy_from(CopySource=f'{bucket_name}/{old_key}')

            # Delete original object
            if delete:
                s3_resource.Object(bucket_name, old_key).delete()

        if app_db_entry:
            db_backup_file = f"{backup_folder}/db_backup.json"
            s3_resource.Object(bucket_name, db_backup_file).put(Body=json.dumps(app_db_entry))

        print(f"Backed up application to : {backup_folder}")

def list_application_versions_with_resource(s3_resource, bucket_name, app_folder):
    bucket = s3_resource.Bucket(bucket_name)

    versions = set()

    for obj in bucket.objects.all():
        parts = obj.key.split('/')
        if len(parts) > 1:
            if app_folder in parts[0]:
                if app_folder == parts[0]:
                    versions.add('Latest')
                else:
                    versions.add(parts[0].replace(f"{app_folder}-", ''))

    return sorted(versions) 

import boto3

def list_application_versions(s3_client, bucket_name, app_folder):
    versions = set()
    response = s3_client.list_objects_v2(
        Bucket=bucket_name,
        Delimiter='/',  # Important: groups results by "folders"
        Prefix=''       # Root level
    )

    folders = [prefix['Prefix'].rstrip('/') for prefix in response.get('CommonPrefixes', [])]

    #for folder in folders:
    #    if app_folder in folder:
    #        if folder == app_folder:
    #            versions.add('Latest')
    #        else:
    #            versions.add(folder.replace(f"{app_folder}-", ''))

    for folder in folders:
        if folder == app_folder:
            versions.add('Latest')
        elif folder.startswith(f"{app_folder}-"):
            suffix = folder.replace(f"{app_folder}-", '')
            try:
                # Check if it's a valid ISO date
                datetime.datetime.fromisoformat(suffix)
                versions.add(suffix)
            except ValueError:
                pass  # Ignore non-date suffixes

    def sort_key(item):
        if item == "Latest":
            return (0, None)  # Comes first
        else:
            dt = datetime.datetime.fromisoformat(item)
            return (1, -dt.timestamp())  # Newest dates first

    sorted_versions = sorted(versions, key=sort_key)

    return sorted_versions

def save_application_version(s3_resource, connect_id, table, app_folder, language, delete):
    try:
        # Get current application
        response = table.get_item(Key={"Tenant": app_folder, "Language": language})
        existing_item = response.get('Item')
        last_updated = existing_item.get('LastUpdated', datetime.datetime.now(datetime.timezone.utc).isoformat())

        # If the item exists, delete it
        if existing_item:
            logger.info(f"Deleting existing application record: {app_folder}")
            table.delete_item(Key={"Tenant": app_folder, "Language": language})

    except Exception as e:
        last_updated = None
        existing_item = None

    #Backup Current application if it exists
    if existing_item:
        backup_s3_folder(s3_resource, f"amazon-connect-{connect_id}", app_folder, existing_item, last_updated, delete)

