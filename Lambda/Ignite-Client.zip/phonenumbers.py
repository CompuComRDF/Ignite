import json
import boto3
import logger
from time import sleep
import random

dynamodb_client = boto3.client('dynamodb')

def release_phone_number(connect_client, phone_number_id):
    logger.info('RELEASING PHONE NUMBER ID: ' + phone_number_id)
    
    try:
        connect_client.release_phone_number(
            PhoneNumberId=phone_number_id
        )  
    except Exception as ex1:
        logger.info('release_phone_number EXCEPTION: ' + str(ex1))

def list_available_phone_numbers(connect_client, connect_id, ou, tenant_id):
    assigned_phone_numbers = []
    available_phone_numbers = []

    list_phone_numbers_response = connect_client.list_phone_numbers(
        InstanceId=connect_id
    )

    list_apps_response = dynamodb_client.scan(
        TableName='Tenants-' + ou
    )

    for tenant_app in list_apps_response['Items']:
        if tenant_id in tenant_app['Tenant']['S']:
            dnis_list = json.loads(tenant_app.get('DNIS','{}').get('S'))
            for dnis_obj in dnis_list:
                for dnis in dnis_obj:
                    assigned_phone_numbers.append(dnis) 

    for phone_record in list_phone_numbers_response['PhoneNumberSummaryList']:
        if phone_record['PhoneNumber'] not in assigned_phone_numbers:
            phone_obj = {}
            phone_obj['PhoneNumber'] = phone_record['PhoneNumber']
            phone_obj['ID'] = phone_record['Id']
            phone_obj['Type'] = phone_record['PhoneNumberType']
            phone_obj['Country'] = phone_record['PhoneNumberCountryCode']
            
            available_phone_numbers.append(phone_obj)

    return(available_phone_numbers)

def list_phone_numbers(connect_client, connect_id):
    available_phone_numbers = []

    list_phone_numbers_response = connect_client.list_phone_numbers(
        InstanceId=connect_id
    )

    for phone_record in list_phone_numbers_response['PhoneNumberSummaryList']:
        phone_obj = {}
        phone_obj['PhoneNumber'] = phone_record['PhoneNumber']
        phone_obj['ID'] = phone_record['Id']
        phone_obj['Type'] = phone_record['PhoneNumberType']
        phone_obj['Country'] = phone_record['PhoneNumberCountryCode']
        
        available_phone_numbers.append(phone_obj)

    return(available_phone_numbers)

def check_assigned_phone_number(ou, app_folder, dnis_array):
    allowed = True
    list_apps_response = dynamodb_client.scan(
        TableName='Tenants-' + ou
    )

    requested_phone_numbers_to_assign = [list(item.keys())[0] for item in json.loads(dnis_array)]

    for tenant_app in list_apps_response['Items']:
        assigned_phone_numbers = json.loads(tenant_app.get('DNIS','{}').get('S'))
        for dnis_obj in assigned_phone_numbers:
            for dnis in dnis_obj:
                if dnis in requested_phone_numbers_to_assign and app_folder != tenant_app['Tenant']['S']:
                    allowed = False

    return(allowed)

def get_phone_number(connect_client, connect_id, tenant_id, country, dnis_type):
    retry = True
    retries = 0
    phone_number = ""
    phone_number_id=""

    while retry and retries < 3:
        logger.info('SEARCH AND CLAIM PHONE NUMBER ATTEMPT: ' + str(retries))
        sleep(random.randint(0,5)**retries*100/1000)
        try:
            response = connect_client.search_available_phone_numbers(
                TargetArn=connect_id,
                PhoneNumberCountryCode=country,
                PhoneNumberType=dnis_type,
                MaxResults=1
            )
            phone_number = response['AvailableNumbersList'][0]['PhoneNumber']
            logger.info('CLAIMING NEW PHONE NUMBER: ' + phone_number)
        
            response = connect_client.claim_phone_number(
                TargetArn=connect_id,
                PhoneNumber=phone_number,
                PhoneNumberDescription= 'Tenant: ' + tenant_id,
            )
            phone_number_id = response['PhoneNumberId']
            retry = False
        except Exception as ex1:
            retries += 1
            logger.info('claim_phone_number EXCEPTION: ' + str(ex1))

    retry = True
    retries = 0    

    while retry and retries < 3:
        logger.info('ASSOCIATE PHONE NUMBER ATTEMPT: ' + str(retries))

        try:
            contact_flow_list = connect_client.list_contact_flows(
                InstanceId=connect_id,
                ContactFlowTypes=['CONTACT_FLOW'],
                MaxResults=100
            )

            for flow in contact_flow_list['ContactFlowSummaryList']:
                if flow['Name'] == 'Connect-RDF-Init':
                    response = connect_client.associate_phone_number_contact_flow(
                        PhoneNumberId=phone_number_id,
                        InstanceId=connect_id,
                        ContactFlowId=flow['Id']
                    )
            retry = False
        except Exception as ex1:
            sleep(3)
            retries += 1
            logger.info('get_phone_number EXCEPTION: ' + str(ex1))

    return{
        "PhoneNumber" : phone_number,
        "PhoneNumberID": phone_number_id
    }

def update_phone_number(connect_client, connect_id, tenant_id, country, dnis_type, previous_id):
    logger.info('UPDATING PHONE NUMBER')

    try:
        connect_client.release_phone_number(
            PhoneNumberId=previous_id
        )  
    except Exception as ex1:
        logger.info('release_phone_number EXCEPTION: ' + str(ex1))

    
    return get_phone_number(connect_client, connect_id, tenant_id, country, dnis_type)

    