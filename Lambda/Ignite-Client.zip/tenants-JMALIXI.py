import json
import boto3
import util
import config
import instances
import logger
 
def load_tenants_from_S3(s3_filename):

    tenant_records = util.read_csv(s3_filename, 'Tenant', 'Language')
    
    try:
        table = boto3.resource('dynamodb', region_name=config.region).Table('Tenants-' + ou)
 
        for record in tenant_records:
            logger.info('INSERTING NEW TENANT RECORD: ' + tenant_records[record]['Tenant'] + ' WITH LANGUAGE: ' + tenant_records[record]['Language'])
            table.put_item(Item= {'Tenant': tenant_records[record]['Tenant'], 
                'Language': tenant_records[record]['Language'], 
                'Description': tenant_records[record]['Description'], 
                'Greeting': tenant_records[record]['Greeting'], 
                'CallFlow': tenant_records[record]['CallFlow'], 
                })

    except Exception as ex1:
        logger.info('load_tenants_from_S3 EXCEPTION: ' + str(ex1))

def update_tts(s3_client, s3_resource, tenant_id, app_id, prompts, role_credentials):
    import csv
    import codecs
    from io import StringIO, BytesIO

    logger.info('UPDATING TTS: ' + str(prompts))
    
    data = {}
    string_buffer = StringIO()
    csv_writer = csv.writer(string_buffer, quoting=csv.QUOTE_NONNUMERIC)

    # Write header
    header = ['LABEL']
    prompt_key = next(iter(prompts))
    for language in prompts[prompt_key]:
        header.append(language)
    csv_writer.writerow(header)

    # Get existing ivr-tts.csv from S3
    key_prefix = f"{tenant_id}-{app_id}" if app_id != 'Default' else "default"
    s3_key = f"{key_prefix}/config/ivr-tts.csv"
    s3_response = s3_client.get_object(Bucket=instances.get_tenant_bucket(s3_client), Key=s3_key)

    for row in csv.DictReader(codecs.getreader("utf-8-sig")(s3_response['Body'])):
        label = row['LABEL']
        data[label] = row

    # Update existing records
    for tts_record in data:
        row_data = [tts_record]
        if tts_record in prompts:
            for language in prompts[tts_record]:
                row_data.append(prompts[tts_record][language])
        else:
            for language in prompts[prompt_key]:
                if language in data[tts_record]:
                    row_data.append(data[tts_record][language])
                else:
                    logger.info('TRANSLATING: ' + str(data[tts_record]['en-US']))
                    row_data.append(util.translate_text(data[tts_record]['en-US'], 'en-US', language))
        csv_writer.writerow(row_data)

    # Add new records not present in existing data
    for prompt in prompts:
        if prompt not in data:
            row_data = [prompt]
            for language in prompts[prompt]:
                row_data.append(prompts[prompt].get(language) or util.translate_text(prompts[prompt]['en-US'], 'en-US', language))
            csv_writer.writerow(row_data)

    # Encode CSV content with UTF-8 BOM for Excel compatibility
    csv_content = string_buffer.getvalue()
    byte_buffer = BytesIO()
    byte_buffer.write('\ufeff'.encode('utf-8'))  # UTF-8 BOM
    byte_buffer.write(csv_content.encode('utf-8'))
    byte_buffer.seek(0)

    # Upload to S3
    s3_resource.Object(
        instances.get_tenant_bucket(s3_client),
        f"{key_prefix}/config/ivr-tts.csv"
    ).put(Body=byte_buffer.getvalue())

def read_tts(s3_client, tenant_id, app_id, prompt_keys):
    import csv
    import codecs
    data = {}
    prompts={}

    if app_id != 'Default':
        filename = tenant_id + "-" + app_id + "/config/ivr-tts.csv"
    else:
        filename = "default/config/ivr-tts.csv"

    try:
        s3_response = s3_client.get_object(Bucket=instances.get_tenant_bucket(s3_client), Key= filename)

        for row in csv.DictReader(codecs.getreader("utf-8-sig")(s3_response['Body'])):
            record = row['LABEL']
            data[record] = row

        if prompt_keys:
            for prompt_key in prompt_keys:
                prompts[prompt_key]={}
        else:
            for prompt_key in data:
                prompts[prompt_key]={}

        for tts_record in data:
            #for prompt_key in prompt_keys:
            for prompt_key in prompts:
                if tts_record == prompt_key:
                    for language in data[tts_record]:
                        if 'LABEL' not in language:
                            prompts[prompt_key][language] = data[tts_record][language]

    except Exception as Ex1:
        logger.info("read_tts EXCEPTION: " + str(Ex1))
               
    return(prompts)

def get_language_name(ou, language):
    language_full_name = get_voices(ou, "")['Available'][language]['Name']
    language_parts = language_full_name.split(" ")
    language_name = language_parts[len(language_parts) - 1]

    return(language_name)

def get_voices(ou, tenant_id):
    list_voices = []
    polly_client = boto3.client('polly')
    describe_voices_response = polly_client.describe_voices(
        IncludeAdditionalLanguageCodes=False
    )

    list_voices = describe_voices_response['Voices']

    while 'NextToken' in describe_voices_response:
        describe_voices_response = polly_client.describe_voices(
            IncludeAdditionalLanguageCodes=False,
            NextToken=describe_voices_response['NextToken']
        )
        list_voices.extend(describe_voices_response['Voices'])        

    voices = {}
    voices['Available'] = {}

    for voice in list_voices:
        if voice['LanguageCode'] not in voices['Available']:
            voices['Available'][voice['LanguageCode']] = {}
            voices['Available'][voice['LanguageCode']]['Name'] = voice['LanguageName']
            voices['Available'][voice['LanguageCode']]['Voices'] = []
            voices['Available'][voice['LanguageCode']]['Voices'].append(voice['Id'])
        else:
            voices['Available'][voice['LanguageCode']]['Voices'].append(voice['Id'])

    if tenant_id:
        dynamodb_client = boto3.client('dynamodb')
        try:
            response = dynamodb_client.scan(
                TableName='Instances-' + ou
            )

            for tenant_key in response['Items']:
                if tenant_id in tenant_key['Tenant']['S']:
                    active_voices = json.loads(tenant_key['ActiveVoices']['S'])

            voices['Active'] = active_voices
            
        except Exception as Ex1:
            logger.info("get_voices EXCEPTION: " + str(Ex1))
    else:
        voices['Active'] = config.default_voices

    return(voices)

def set_voices(connect_client, connect_id, ou, tenant_id, active_voices):
    import os
    polly_client = boto3.client('polly')

    if config.bcp_install and ou == 'PROD':
        ou = 'BCP'

    tenant_name = ou.lower() + os.environ['ORGANIZATION_NAME'] + '-' + tenant_id

    list_contact_modules_response = connect_client.list_contact_flow_modules(
        InstanceId=connect_id,
        ContactFlowModuleState='ACTIVE'
    )

    language_identifiers={}

    for contact_module in list_contact_modules_response['ContactFlowModulesSummaryList']:
        if contact_module['Name'] == 'Connect-RDF-Languages':
            logger.info("UPDATING LANGUAGES FOR: " + contact_module['Name'])
            
            get_contact_module_response = connect_client.describe_contact_flow_module(
                InstanceId=connect_id,
                ContactFlowModuleId=contact_module['Id']
            )
            
            flow = json.loads(get_contact_module_response['ContactFlowModule']['Content'])
            new_flow = {}
            new_flow['Version'] = flow['Version']
            new_flow['StartAction'] = flow['StartAction']
            new_flow['Metadata'] = flow['Metadata']
            new_flow['Settings'] = flow['Settings']
            new_flow['Actions'] = []
            temp_actions = []
            cond_counter = 0

            for action in flow['Actions']:
                for voice_index in config.case_actions:
                    if action['Identifier'] == config.case_actions[voice_index]:
                        try:
                            describe_voice_response = polly_client.describe_voices(
                                LanguageCode=active_voices[voice_index]["Language"],
                                IncludeAdditionalLanguageCodes=False
                            )
                            for voice in describe_voice_response['Voices']:
                                if active_voices[voice_index]['Voice'] == voice['Id']:
                                    supported_engines = voice['SupportedEngines']

                            action['Parameters']['TextToSpeechVoice'] = active_voices[voice_index]['Voice']
                            if 'neural' in supported_engines:                            
                                action['Parameters']['TextToSpeechEngine'] = 'Neural'
                                action['Parameters']['TextToSpeechStyle'] = 'None'
                            else:
                                try:
                                    del action['Parameters']['TextToSpeechEngine']
                                    del action['Parameters']['TextToSpeechStyle']
                                except:
                                    pass
                        except:
                            action['Parameters']['TextToSpeechVoice'] = 'Stephen'
                        language_identifiers[voice_index] = action['Transitions']['NextAction']
                    if action['Type'] == "Compare":
                        for condition in action['Transitions']['Conditions']:
                            if condition['NextAction'] == config.case_actions[voice_index]:
                                try:
                                    condition['Condition']['Operands'] = [active_voices[voice_index]["Language"]]
                                except:
                                    cond_counter += 1
                                    condition['Condition']['Operands'] = ['notused_' + str(cond_counter)] 

                temp_actions.append(action)

            for action in temp_actions:
                for voice_index in config.case_actions:
                    if action['Identifier'] == language_identifiers[voice_index]:
                        try:
                            action['Parameters']['LanguageCode'] = active_voices[voice_index]["Language"]
                        except:
                            action['Parameters']['LanguageCode'] = 'en-US'

                new_flow['Actions'].append(action)

            flow = json.dumps(new_flow)

            connect_client.update_contact_flow_module_content(
                InstanceId=connect_id,
                ContactFlowModuleId=contact_module['Id'],
                Content=flow
            )

    try:
        table = boto3.resource('dynamodb', region_name=config.region).Table('Instances-' + ou)

        table.update_item(
                Key = {
                    'Tenant': tenant_name
                },
                UpdateExpression='SET #attr1 = :val1',
                ExpressionAttributeNames={'#attr1': 'ActiveVoices'},
                ExpressionAttributeValues={':val1': json.dumps(active_voices)}
            )

    except Exception as Ex1:
        logger.info("update voices EXCEPTION: " + str(Ex1)) 

def list_objects(s3_client, connect_id, tenant_id, app_id, object_type, language):
    if language:
        prefix = tenant_id + '-' + app_id + '/' + object_type + '/ivr/' + language + '/'
    else:
        prefix = tenant_id + '-' + app_id + '/' + object_type + '/'

    list_objects = []
    list_objects_response = s3_client.list_objects_v2(
        Bucket='amazon-connect-' + connect_id,
        Prefix= prefix
    )

    if list_objects_response['KeyCount'] > 0:
        for object in list_objects_response['Contents']:
            found_object = {}
            found_object['Name'] = object['Key'][object['Key'].find('/')+1:]
            date_object = str(object['LastModified'])
            found_object['Date'] = date_object[0:date_object.find('+')]
            found_object['Size'] = str(object['Size']) + ' bytes'
            list_objects.append(found_object)
    else:
        list_objects.append('Not Found')

    return(list_objects)

def get_binary_object(s3_resource, connect_id, tenant_id, app_id, object_type, filename, language):
    import io
    import base64

    if object_type == 'prompts':
        object_key = tenant_id + '-' + app_id + '/' + object_type + '/ivr/' + language + '/' + filename
    else:
        object_key = tenant_id + '-' + app_id + '/' + object_type + '/' + filename

    obj = s3_resource.Object('amazon-connect-' + connect_id, object_key)
    data = io.BytesIO()
    obj.download_fileobj(data)

    return(base64.b64encode(data.getvalue()).decode())

def put_binary_object(s3_resource, connect_id, tenant_id, app_id, object_type, filename, language, content):
    import io
    import base64

    if object_type == 'prompts':
        object_key = tenant_id + '-' + app_id + '/' + object_type + '/ivr/' + language + '/' + filename
    else:
        object_key = tenant_id + '-' + app_id + '/' + object_type + '/' + filename

    s3_resource.Object('amazon-connect-' + connect_id, object_key).put(Body=base64.b64decode(content))

def delete_object(s3_client, connect_id, tenant_id, app_id, object_type, filename, language):
    if object_type == 'prompts':
        object_key = tenant_id + '-' + app_id + '/' + object_type + '/ivr/' + language + '/' + filename
    else:
        object_key = tenant_id + '-' + app_id + '/' + object_type + '/' + filename

    response = s3_client.delete_object(
        Bucket='amazon-connect-' + connect_id,
        Key=object_key
    )

def list_contact_flows(connect_client, connect_id):
    contact_flow_list = []

    list_contact_flows_response = connect_client.list_contact_flows(
            InstanceId=connect_id,
            ContactFlowTypes=['CONTACT_FLOW'],
            MaxResults=100
        )

    for flow in list_contact_flows_response['ContactFlowSummaryList']:
        if 'Sample' not in flow['Name'] and 'Connect-RDF' not in flow['Name']:
            contact_flow_list.append(flow['Name'])
    
    return(contact_flow_list)

def list_contact_flow_modules(connect_client, connect_id):
    contact_flow_module_list = []

    list_contact_flow_modules_response = connect_client.list_contact_flow_modules(
        InstanceId=connect_id,
        MaxResults=100,
        ContactFlowModuleState='ACTIVE'
    )

    for flow in list_contact_flow_modules_response['ContactFlowModulesSummaryList']:
        if 'Connect-RDF' not in flow['Name']:
            contact_flow_module_list.append(flow['Name'])
    
    return(contact_flow_module_list)

def synthesize_speech(language, voice, text):
    import base64
    import io
    client = boto3.client('polly')

    if "Hello, my name is" in text:
        text = util.translate_text(text, 'en-US', language)

    describe_voice_response = client.describe_voices(
        LanguageCode=language,
        IncludeAdditionalLanguageCodes=False
    )
    for voice_id in describe_voice_response['Voices']:
        if voice == voice_id['Id']:
            supported_engines = voice_id['SupportedEngines']
            if 'neural' in supported_engines:
                engine_type = 'neural'
            else:
                engine_type = 'standard'

    logger.info(engine_type)
    response = client.synthesize_speech(
        Engine=engine_type,
        LanguageCode=language,
        OutputFormat='mp3',
        Text='<speak>' + text + '</speak>',
        TextType='ssml',
        VoiceId=voice
    )

    stream = response['AudioStream'].read()
    content = base64.b64encode(stream)
    
    return(content)

def get_callflow(s3_client, tenant_id, callflow, app_id):
    return_object = {}
    return_object['Prompts'] = {}

    try:
        s3_response = s3_client.get_object(Bucket=instances.get_tenant_bucket(s3_client), Key= f"shared/{callflow}-callflow.csv")
        return_object['FileContents'] = s3_response['Body'].read().decode('utf-8-sig')
    except:
        return_object['FileContents'] = ''

    try:
        s3_response = s3_client.get_object(Bucket=instances.get_tenant_bucket(s3_client), Key= f"shared/{callflow}-callflow.json")
        return_object['JsonContents'] = s3_response['Body'].read().decode('utf-8-sig')
    except:
        return_object['JsonContents'] = ''

    if app_id:
        return_object['Prompts'] = read_tts(s3_client, tenant_id, app_id, [])    

    return(return_object)

def put_callflow(s3_client, s3_resource, role_credentials, content, json_content, tenant_id, callflow, app_id, prompts):
    logger.info(f"UPDATING CALLFLOW: {app_id}")

    body = content.replace(",undefined", "").encode("utf-8-sig")
    s3_resource.Object(instances.get_tenant_bucket(s3_client), f"shared/{callflow}-callflow.csv").put(Body=body)

    body = json_content.encode("utf-8-sig")
    s3_resource.Object(instances.get_tenant_bucket(s3_client), f"shared/{callflow}-callflow.json").put(Body=body)

    if app_id and prompts:
        logger.info('UPDATING TTS: ' + str(prompts))
        update_tts(s3_client, s3_resource, tenant_id, app_id, prompts, role_credentials) 

