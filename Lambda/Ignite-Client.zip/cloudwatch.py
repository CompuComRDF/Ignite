import boto3
import json
import time
from datetime import datetime, timedelta
import re

# Configuration
#log_group_name = "/aws/your/log/group"  # Change this to your CloudWatch log group
#log_stream_prefix = None  # Optional: Filter by prefix if you want
#REGION_NAME = "us-east-1"  # Replace with your AWS region
#POLL_INTERVAL = 5  # Seconds between polling

# AWS client


def get_latest_log_streams(log_client, log_group_name, prefix=None):
    kwargs = {
        "logGroupName": log_group_name,
        "orderBy": "LastEventTime",
        "descending": True,
        "limit": 5
    }
    if prefix:
        kwargs["logStreamNamePrefix"] = prefix
    response = log_client.describe_log_streams(**kwargs)
    return [stream["logStreamName"] for stream in response["logStreams"]]

def tail_logs(log_client, log_group_name, log_stream_prefix):
    print(f"Tailing logs for group: {log_group_name}...")
    poll_interval = 5 

    # Get most recent stream(s)
    log_streams = get_latest_log_streams(log_client, log_group_name, log_stream_prefix)
    if not log_streams:
        print("No log streams found.")
        return

    next_tokens = {stream: None for stream in log_streams}
    
    while True:
        for stream_name in log_streams:
            kwargs = {
                "logGroupName": log_group_name,
                "logStreamName": stream_name,
                "startFromHead": False,
            }
            if next_tokens[stream_name]:
                kwargs["nextToken"] = next_tokens[stream_name]
            try:
                response = log_client.get_log_events(**kwargs)
                events = response["events"]
                next_tokens[stream_name] = response["nextForwardToken"]
                for event in events:
                    timestamp = datetime.fromtimestamp(event["timestamp"] / 1000)
                    message = event["message"]
                    print(f"[{timestamp}] {message.strip()}")
            except Exception as e:
                print(f"Error reading from stream {stream_name}: {e}")
        time.sleep(poll_interval)

def get_latest_log_stream(log_client, log_group_name):
    kwargs = {
        "logGroupName": log_group_name,
        "orderBy": "LastEventTime",
        "descending": True,
        "limit": 1
    }

    response = log_client.describe_log_streams(**kwargs)
    streams = response.get("logStreams", [])
    return streams[0]["logStreamName"] if streams else None
 
def get_recent_log_events(log_client, log_group, stream_name, dnis_list, limit=50):
    response = log_client.get_log_events(
        logGroupName=log_group,
        logStreamName=stream_name,
        limit=limit,
        startFromHead=False
    )
    logs = []
    pattern = r'^\[([^\]]+)]\s*\[([^\]]+)]\s*\[([^\]]+)]\s*(.*)'

    for event in response["events"]:
        log_line = event["message"]
        match = re.match(pattern, log_line)
        if match:
            log_level = match.group(1)
            dnis = match.group(2)
            contact_id = match.group(3)
            message = match.group(4).strip()

            if dnis in dnis_list:
                logs.append({
                    "timestamp": datetime.fromtimestamp(event["timestamp"] / 1000).isoformat(),
                    "log_level": log_level,
                    "dnis": dnis,
                    "contact_id": contact_id,
                    "message": message
                })

    return logs

def tail_log_old(log_client, log_group_name, dnis_list):
    try:
        stream_name = get_latest_log_stream(log_client, log_group_name)
        if not stream_name:
            return {"error": "No log streams found."}

        logs = get_recent_log_events(log_client, log_group_name, stream_name, dnis_list)
 
        return logs
 
    except Exception as e:
        return {"error": str(e)}

def get_logs_in_time_window(log_client, log_group, start_time_ms, end_time_ms, dnis_list):
    logs = []
    pattern = r'^\[([^\]]+)]\s*\[([^\]]+)]\s*\[([^\]]+)]\s*(.*)'
    paginator = log_client.get_paginator("filter_log_events")
 
    response_iterator = paginator.paginate(
        logGroupName=log_group,
        startTime=start_time_ms,
        endTime=end_time_ms,
        interleaved=True
    )
 
    for page in response_iterator:
        for event in page["events"]:
            log_line = event["message"]
            match = re.match(pattern, log_line)
            if match:
                log_level = match.group(1)
                dnis = match.group(2)
                contact_id = match.group(3)
                message = match.group(4).strip()

                if dnis in dnis_list:
                    logs.append({
                        "log_time": datetime.fromtimestamp(event["timestamp"] / 1000).isoformat(),
                        "log_level": log_level,
                        "dnis": dnis,
                        "contact_id": contact_id,
                        "message": message
                    })            
 
    return logs

def tail_log(log_client, log_group_name, start_ts, dnis_list):
    default_minutes = 1
    max_minutes = 5
    try:
        minutes = default_minutes
 
        if start_ts:
            start_time_ms = int(start_ts)
        else:
            minutes = max(1, min(minutes, max_minutes))  # Clamp between 1 and MAX
            now_ms = int(time.time() * 1000)
            start_time_ms = now_ms - (minutes * 60 * 1000)
 
        end_time_ms = int(time.time() * 1000)
 
        logs = get_logs_in_time_window(log_client, log_group_name, start_time_ms, end_time_ms, dnis_list)
        now_ms = int(time.time() * 1000)
 
        return {
            'timestamp':now_ms, 
            'logs':logs
        }
 
    except Exception as e:
        return {"error": str(e)}