import os
import traceback

# Default log level mapping
LOG_LEVELS = {
    'CRITICAL': 50,
    'ERROR': 40,
    'WARNING': 30,
    'INFO': 20,
    'DEBUG': 10,
    'NOTSET': 0
}

# Safely get log level from environment or fallback
trace_mode = os.getenv('TRACE_MODE', 'INFO').upper()
current_level = LOG_LEVELS.get(trace_mode, 20)

def _log(level: int, message: str):
    if current_level <= level:
        print(f"[{trace_mode}] {message}")

def debug(message):    _log(10, message)
def info(message):     _log(20, message)
def warning(message):  _log(30, message)
def error(message):    _log(40, message)
def critical(message): _log(50, message)

def log_exception(prefix='❌ Exception'):
    """Prints the traceback with an optional prefix."""
    print(f"{prefix}: {traceback.format_exc()}")


