import json
import boto3
import traceback
import ast
import util
import config

def removeAgentRecord(event, connectClient, connectInstanceDetails):
    oldImage = event['Records'][0]['dynamodb']['OldImage']
    
    name = oldImage['name']['S']
    email = oldImage['email']['S']
    #role = ast.literal_eval(oldImage['role']['S'])
    #agent_skills = ast.literal_eval(oldImage['priority']['S'])['levels']
    try:
        role = oldImage['role']['L']
    except:
        role = []
    try:
        agent_skills = oldImage['priority']['M']['levels']['M']
    except:
        agent_skills = {}
        
    agentID = util.getUserID(connectInstanceDetails['agentList'], email)
    print('REMOVING AGENT: ' + name + ' EMAIL: ' + email + ' ROLE: ' + json.dumps(role) + ' QUEUE: ' + json.dumps(agent_skills))
    removeConnectUserProfile(connectClient, connectInstanceDetails, name, email, agentID)
    
def insertAgentRecord(event, connectClient, connectInstanceDetails):
    dynamodb_client = boto3.client('dynamodb')
    #Set Languages
    English = '_En'
    French = '_Fr'
    Spanish = '_Es'
    Portuguese = '_Pt'
    
    #Get all company abbreviations
    tempList = []
    response = dynamodb_client.scan(TableName='Companies')
    for item in response['Items']:
        tempList.append(item.get('companyID')['S'])
        quickConnects = json.loads(item.get('quickConnects')['S'])
        for quickConnect in quickConnects:
            if not quickConnect.replace("+","").isnumeric():
                tempList.append(quickConnect)        
    companies = []
    for i in tempList:
        if i not in companies:
            companies.append(i)
    
    newImage = event['Records'][0]['dynamodb']['NewImage']
    name = newImage['name']['S']
    email = newImage['email']['S']
    try:
        #role = ast.literal_eval(newImage['role']['S'])
        role = newImage['role']['L']
    except:
        role = []
    try:
        #agent_skills = ast.literal_eval(newImage['priority']['S'])['levels']
        agent_skills = newImage['priority']['M']['levels']['M']
    except:
        agent_skills = {}
        
    print('ADDING AGENT: ' + name + ' EMAIL: ' + email + ' ROLE: ' + json.dumps(role) + ' QUEUE: ' + json.dumps(agent_skills))

    securityProfiles = util.getSecurityProfiles(connectInstanceDetails['securityProfileList'], role)

    queueConfigs = {}
    queueConfigCtr = 0
    queueConfigs[queueConfigCtr] = []
    assignedQueues = []

    
    for skill in agent_skills:
        Found = False
        for queue_prefix in companies:
            if skill.find(queue_prefix) != -1:
                Found = True
        if not Found:
            if skill != "wrapTimer":
                util.logError('User: ' + name + ' is assigned to a non-existent queue: ' + skill)
	
    for queue_prefix in companies:
        for skill in agent_skills:
            if skill.find(queue_prefix) != -1 and skill.find(English) != -1:
                queueID = util.getQueueID(connectInstanceDetails['queueList'], queue_prefix + 'GEN' + English)
                if queueID != 'NOT FOUND':
                    print('Assigning to Queue: ' + queue_prefix + 'GEN' + English + ' QUEUEID: ' + queueID)
                    queueConfig = util.getQueueConfig(queueID,'VOICE')
                    queueConfigs[queueConfigCtr].append(queueConfig)
                    queueConfig = util.getQueueConfig(queueID, 'TASK')
                    queueConfigs[queueConfigCtr].append(queueConfig)
                    if len(queueConfigs[queueConfigCtr]) == 10:
                        queueConfigCtr += 1
                        queueConfigs[queueConfigCtr] = []
                    assignedQueues.append(queueID)
                else:
                    util.logError('User: ' + name + ' is assigned to a non-existent queue: ' + queue_prefix + 'GEN' + English)
                break
        for skill in agent_skills:
            if skill.find(queue_prefix) != -1 and skill.find(French) != -1:
                queueID = util.getQueueID(connectInstanceDetails['queueList'], queue_prefix + 'GEN' + French)
                if queueID != 'NOT FOUND':
                    print('Assigning to Queue: ' + queue_prefix + 'GEN' + French + ' QUEUEID: ' + queueID)
                    queueConfig = util.getQueueConfig(queueID, 'VOICE')
                    queueConfigs[queueConfigCtr].append(queueConfig)                     			
                    queueConfig = util.getQueueConfig(queueID, 'TASK')
                    queueConfigs[queueConfigCtr].append(queueConfig)
                    if len(queueConfigs[queueConfigCtr]) == 10:
                        queueConfigCtr += 1
                        queueConfigs[queueConfigCtr] = []
                    assignedQueues.append(queueID)
                else:
                    util.logError('User: ' + name + ' is assigned to a non-existent queue: ' + queue_prefix + 'GEN' + French)
                break
        for skill in agent_skills:
            if skill.find(queue_prefix) != -1 and skill.find(Spanish) != -1:
                queueID = util.getQueueID(connectInstanceDetails['queueList'], queue_prefix + 'GEN' + Spanish)
                if queueID != 'NOT FOUND':
                    print('Assigning to Queue: ' + queue_prefix + 'GEN' + Spanish + ' QUEUEID: ' + queueID)
                    queueConfig = util.getQueueConfig(queueID, 'VOICE')
                    queueConfigs[queueConfigCtr].append(queueConfig)     
                    queueConfig = util.getQueueConfig(queueID, 'TASK')
                    queueConfigs[queueConfigCtr].append(queueConfig)
                    if len(queueConfigs[queueConfigCtr]) == 10:
                        queueConfigCtr += 1
                        queueConfigs[queueConfigCtr] = []
                    assignedQueues.append(queueID)
                else:
                    util.logError('User: ' + name + ' is assigned to a non-existent queue: ' + queue_prefix + 'GEN' + Spanish)
                break
        for skill in agent_skills:
            if skill.find(queue_prefix) != -1 and skill.find(Portuguese) != -1:
                queueID = util.getQueueID(connectInstanceDetails['queueList'], queue_prefix + 'GEN' + Portuguese)
                if queueID != 'NOT FOUND':
                    print('Assigning to Queue: ' + queue_prefix + 'GEN' + Portuguese + ' QUEUEID: ' + queueID)
                    queueConfig = util.getQueueConfig(queueID, 'VOICE')
                    queueConfigs[queueConfigCtr].append(queueConfig)     
                    queueConfig = util.getQueueConfig(queueID, 'TASK')
                    queueConfigs[queueConfigCtr].append(queueConfig)
                    if len(queueConfigs[queueConfigCtr]) == 10:
                        queueConfigCtr += 1
                        queueConfigs[queueConfigCtr] = []
                    assignedQueues.append(queueID)
                else:
                    util.logError('User: ' + name + ' is assigned to a non-existent queue: ' + queue_prefix + 'GEN' + Spanish)
                break

    if len(queueConfigs) == 1 and queueConfigCtr == 0:
        queueID = util.getQueueID(connectInstanceDetails['queueList'], 'BasicQueue')
        queueConfig = util.getQueueConfig(queueID, 'VOICE')
        queueConfigs[0].append(queueConfig)

    result = createConnectUserProfile(connectClient, connectInstanceDetails, name, email, securityProfiles, queueConfigs[0])

    #Can only add 10 queueConfigs per request.
    if len(queueConfigs) > 1:
        for queueConfig in queueConfigs:
            if queueConfig != 0:
                if len(queueConfigs[queueConfig]) != 0:
                    addQueuetoRP(connectClient, connectInstanceDetails, result['rpID'], queueConfigs[queueConfig])
                
    try:
        for queue in assignedQueues:
            response = connectClient.associate_queue_quick_connects(
                InstanceId=connectInstanceDetails['instanceID'],
                QueueId=queue,
                QuickConnectIds=[result['qcID']]
            )
    except Exception as ex1:
        print('#####   ASSOCIATE QUEUE QUICK CONNECTS EXCEPTION FOUND: ' + str(ex1) + '   #####')
        
def removeConnectUserProfile(connectClient, connectInstanceDetails, name, email, userID):
    try:
        response = connectClient.delete_user(
            InstanceId=connectInstanceDetails['instanceID'],
            UserId=userID
        )
    except Exception as ex1:
        util.logError('#####   DELETE USER EXCEPTION FOUND: ' + str(ex1) + '   #####')

    try:        
        #routingProfileName = ''.join(name.split()).replace(',','-') + '-RP'
        routingProfileName = email.split('@')[0] + '-RP'

        routingProfileID = util.getRoutingProfileID(connectInstanceDetails['routingProfileList'], routingProfileName)

        response = connectClient.delete_routing_profile(
            InstanceId=connectInstanceDetails['instanceID'],
            RoutingProfileId=routingProfileID
        )    
    except Exception as ex1:
        util.logError('#####   DELETE ROUTING PROFILE EXCEPTION FOUND: ' + str(ex1) + '   #####')

    qcID = util.getQuickConnectID(connectInstanceDetails['quickConnectList'], name + '_QC')
    
    try:
        response = connectClient.delete_quick_connect(
            InstanceId=connectInstanceDetails['instanceID'],
            QuickConnectId=qcID
        )
    except Exception as ex1:
        util.logError('#####   DELETE AGENT QUICK CONNECT EXCEPTION FOUND: ' + str(ex1) + '   #####')
    
def createConnectUserProfile(connectClient, connectInstanceDetails, name, email, securityProfiles, queueConfigs):
    qcID = ''
    if name.find(',') != -1:
        fullName = name.split(',')
        firstName = fullName[1]
        lastName = fullName[0]
    else:
        fullName = name.split(' ')
        firstName = fullName[1]
        lastName = fullName[0]
    
    try:
        response = connectClient.create_routing_profile(
            InstanceId=connectInstanceDetails['instanceID'], 
            #Name=''.join(name.split()).replace(',','-') + '-RP',
            Name=email.split('@')[0] + '-RP',
            Description='Routing Profile for ' + name,
            DefaultOutboundQueueId=connectInstanceDetails['outboundQueueID'],
            QueueConfigs= queueConfigs,
            MediaConcurrencies=[
                {
                    'Channel': 'VOICE',
                    'Concurrency': 1,
                    'CrossChannelBehavior': {
                        'BehaviorType': 'ROUTE_CURRENT_CHANNEL_ONLY'
                    }
                },
                {
                    'Channel': 'TASK',
                    'Concurrency': 1,
                    'CrossChannelBehavior': {
                        'BehaviorType': 'ROUTE_CURRENT_CHANNEL_ONLY'
                    }
                }                
            ],
            #AgentAvailabilityTimer='TIME_SINCE_LAST_INBOUND'
        )
        routingProfileID = response['RoutingProfileId']
        
    except Exception as ex1:
        util.logError('#####   CREATE ROUTING PROFILE EXCEPTION FOUND: ' + str(ex1) + '   #####')
        routingProfileName = email.split('@')[0] + '-RP'
        routingProfileID = util.getRoutingProfileID(connectInstanceDetails['routingProfileList'], routingProfileName)

    try:
        response = connectClient.create_user(
            Username=email,
            IdentityInfo={
                'FirstName': firstName,
                'LastName': lastName,
            },
            PhoneConfig={
                'PhoneType': 'SOFT_PHONE',
                'AutoAccept': False,
                'AfterContactWorkTimeLimit': 10
            },
            SecurityProfileIds= securityProfiles,
            RoutingProfileId=routingProfileID,
            InstanceId=connectInstanceDetails['instanceID']
        )

        userID = response['UserId']
    

        response = connectClient.create_quick_connect(
            InstanceId=connectInstanceDetails['instanceID'],
            Name= name + '_QC',
            Description='Created by AgentSync',
            QuickConnectConfig={
                'QuickConnectType': 'USER',
                'UserConfig': {
                    'UserId': userID,
                    'ContactFlowId': connectInstanceDetails['agentTransferFlowID']
                }
            }
        )

        qcID = response['QuickConnectId']
        
    except Exception as ex1:
        util.logError('#####   CREATE CONNECT USER PROFILE EXCEPTION FOUND: ' + str(ex1) + '   #####')

    #return(qcID)
    return {
        'rpID': routingProfileID,
        'qcID': qcID
    }

def addQueuetoRP(connectClient, connectInstanceDetails,rpID, queueConfigs):
    print("ADDING QUEUES TO ROUTING PROFILE")
    try:
        response = connectClient.associate_routing_profile_queues(
            InstanceId=connectInstanceDetails['instanceID'],
            RoutingProfileId=rpID,
            QueueConfigs=queueConfigs
        )
    except Exception as ex1:
        util.logError('#####   ASSOCIATE ROUTING PROFILE QUEUES EXCEPTION FOUND: ' + str(ex1) + '   #####')
        
def loadAgentsfromS3(s3FileName):

    agentRecords = util.readCSV(s3FileName, 'email', '')
    
    try:
        table = boto3.resource('dynamodb').Table('Agents')
 
        for record in agentRecords:
            print('INSERTING NEW AGENT RECORD: ' + agentRecords[record]['email'])
            table.put_item(Item= {'email': agentRecords[record]['email'], 
                'name': agentRecords[record]['name'], 
                'role': json.loads(agentRecords[record]['role']), 
                'priority': json.loads(agentRecords[record]['priority'])})

    except Exception as ex1:
        util.logError('#####   UPDATE AGENTS TABLE EXCEPTION FOUND: ' + str(ex1) + '   #####')