import json
import boto3
import logger
import util
import tenants
import datetime
import os
import time
import config
import instances
import officehours
import applications
import users

def list_queue_configs(connect_client, connect_id, s3_client, connect_instance_details, ou, tenant_id):
    result ={}
    result['Queues'] = []
    result['PhoneNumbers'] = []
    result['QueueHours'] = officehours.list_office_hours(s3_client, connect_id)
    result['QueueActions'] = list_queue_actions(s3_client, connect_client, connect_id, connect_instance_details, ou, tenant_id)
    duplicates = []
    queue_list = []

    try:
        list_phone_numbers_response = connect_client.list_phone_numbers(
            InstanceId=connect_id,
            MaxResults=100
        )
        phone_list = list_phone_numbers_response['PhoneNumberSummaryList']

        while "NextToken" in list_phone_numbers_response:
            list_phone_numbers_response = connect_client.list_phone_numbers(
                InstanceId=connect_id,
                NextToken=list_phone_numbers_response["NextToken"],
                MaxResults=100
            ) 
            phone_list.extend(list_phone_numbers_response['PhoneNumberSummaryList'])

        for phone in phone_list:
            phone_config = {}
            phone_config['PhoneNumber'] = phone['PhoneNumber'].replace('+','')
            phone_config['PhoneId'] = phone['Id']
            result['PhoneNumbers'].append(phone_config)

        search_queues_response = connect_client.search_queues(
            InstanceId=connect_id,
            MaxResults=100
        )

        queue_list = search_queues_response['Queues']

        while "NextToken" in search_queues_response:
            search_queues_response = connect_client.search_queues(
                InstanceId=connect_id,
                NextToken=search_queues_response["NextToken"],
                MaxResults=100
            ) 
            queue_list.extend(search_queues_response['Queues'])

        for queue in queue_list:
            queue_name = queue['Name'] 
            if queue_name not in duplicates:
                duplicates.append(queue_name)
                queue_config = {}               
                queue_config['Name'] = queue_name
                queue_config['Id'] = queue['QueueId']
                if queue['OutboundCallerConfig']:
                    queue_config['CallerID'] = queue['OutboundCallerConfig'].get('OutboundCallerIdName', '')
                    queue_config['PhoneId'] = queue['OutboundCallerConfig'].get('OutboundCallerIdNumberId', '')
                    for phone in phone_list:
                        if phone['Id'] == queue_config['PhoneId']:
                            queue_config['PhoneNumber'] = phone['PhoneNumber'].replace('+','')
                else:
                    queue_config['CallerID'] = ''
                    queue_config['PhoneId'] = ''
                    queue_config['PhoneNumber'] = ''            

                queue_config['CallBack'] = queue['Tags'].get('CallBack','off')
                queue_config['VoiceMail'] = queue['Tags'].get('VoiceMail','off')
                queue_config['QueueHours'] = queue['Tags'].get('QueueHours','') 
                for queue_tag in queue['Tags']:
                    if queue_tag not in ['CallBack', 'VoiceMail', 'QueueHours']:
                        queue_config[queue_tag] = queue['Tags'].get(queue_tag)

                result['Queues'].append(queue_config)

        logger.info(result)

    except Exception as ex1:
        logger.info("search_queues EXCEPTION: " + str(ex1))

    return(result)   

def list_queue_configs_v2(connect_client, connect_id, s3_client, connect_instance_details, ou, tenant_id):
    result ={}
    result['Queues'] = []
    result['PhoneNumbers'] = []
    result['QueueHours'] = officehours.list_office_hours(s3_client, connect_id)
    result['QueueActions'] = list_queue_actions(s3_client, connect_client, connect_id, connect_instance_details, ou, tenant_id)
    duplicates = []
    queue_list = []

    try:
        list_phone_numbers_response = connect_client.list_phone_numbers(
            InstanceId=connect_id,
            MaxResults=100
        )
        phone_list = list_phone_numbers_response['PhoneNumberSummaryList']

        while "NextToken" in list_phone_numbers_response:
            list_phone_numbers_response = connect_client.list_phone_numbers(
                InstanceId=connect_id,
                NextToken=list_phone_numbers_response["NextToken"],
                MaxResults=100
            ) 
            phone_list.extend(list_phone_numbers_response['PhoneNumberSummaryList'])

        for phone in phone_list:
            phone_config = {}
            phone_config['PhoneNumber'] = phone['PhoneNumber'].replace('+','')
            phone_config['PhoneId'] = phone['Id']
            result['PhoneNumbers'].append(phone_config)

        search_queues_response = connect_client.search_queues(
            InstanceId=connect_id,
            MaxResults=100
        )

        queue_list = search_queues_response['Queues']

        while "NextToken" in search_queues_response:
            search_queues_response = connect_client.search_queues(
                InstanceId=connect_id,
                NextToken=search_queues_response["NextToken"],
                MaxResults=100
            ) 
            queue_list.extend(search_queues_response['Queues'])

        for queue in queue_list:
            queue_name = queue['Name'] 
            if queue_name not in duplicates:
                duplicates.append(queue_name)
                queue_config = {}               
                queue_config['Name'] = queue_name
                queue_config['Id'] = queue['QueueId']
                if queue['OutboundCallerConfig']:
                    queue_config['CallerID'] = queue['OutboundCallerConfig'].get('OutboundCallerIdName', '')
                    queue_config['PhoneId'] = queue['OutboundCallerConfig'].get('OutboundCallerIdNumberId', '')
                    for phone in phone_list:
                        if phone['Id'] == queue_config['PhoneId']:
                            queue_config['PhoneNumber'] = phone['PhoneNumber'].replace('+','')
                else:
                    queue_config['CallerID'] = ''
                    queue_config['PhoneId'] = ''
                    queue_config['PhoneNumber'] = ''            

                queue_config['QueueTags'] = {}
                queue_config['QueueTags']['CallBack'] = queue['Tags'].get('CallBack','off')
                queue_config['QueueTags']['VoiceMail'] = queue['Tags'].get('VoiceMail','off')
                queue_config['QueueTags']['QueueHours'] = queue['Tags'].get('QueueHours','') 
                for queue_tag in queue['Tags']:
                    if queue_tag not in ['CallBack', 'VoiceMail', 'QueueHours']:
                        queue_config['QueueTags'][queue_tag] = queue['Tags'].get(queue_tag)

                result['Queues'].append(queue_config)

        logger.info(result)

    except Exception as ex1:
        logger.info("search_queues EXCEPTION: " + str(ex1))

    return(result)   

def list_queue_actions(s3_client, connect_client, connect_id, connect_instance_details, ou, tenant_id):
    queue_actions = {}
    contactflow = tenants.list_contact_flows(connect_client, connect_id)
    callflow = util.get_callflows(s3_client, connect_id)
    app= []
    tenant_apps = applications.get_tenant_apps(s3_client, ou, tenant_id, connect_id)
    for tenant_app in tenant_apps:
        app.append(tenant_app['AppID'])
    
    if app:
        queue_actions['app'] = app
    if callflow:
        queue_actions['callflow'] = callflow
        queue_actions['agentassist'] = callflow
    if contactflow:
        queue_actions['contactflow'] = contactflow

    return(queue_actions)

def get_tenant_queues(tenant_id, queue_summary_list):
    queues_list = []
    logger.info("GETTING QUEUE LIST FOR TENANT: " + tenant_id)

    for queue in queue_summary_list:
        queue_name = queue['Name']

        if queue_name not in queues_list:
            queues_list.append(queue_name)

    return(queues_list)   

def create_queues(ou, tenant_id, s3_client, connect_instance_details, connect_client, connect_id, queue_list):
    #This function both creates and updates a Queue
    queues_to_update = util.get_queues_to_update(connect_instance_details)
    quick_connects_to_update = util.get_quick_connects_to_update(connect_instance_details)
    queue_data = util.get_queue_data(ou, tenant_id)
    queue_actions = list_queue_actions(s3_client, connect_client, connect_id, connect_instance_details, ou, tenant_id)
    queue_keys = list(queue_actions)
    queue_keys.extend(["CallBack", "VoiceMail", "QueueHours"])
    
    for queue in queue_list:
        queue_name = queue['Name']
        queue_tags = queue.get('QueueTags')

        #This is temporary until Ignite Console gets updated
        if not queue_tags:
            queue_tags = {k: queue[k] for k in queue_keys if queue.get(k) not in (None, "")}

        #Update QueueTags in case Queue is being updated
        if queue_name in queue_data:
            queue_data[queue_name]['QueueTags']= queue_tags
            queue_data[queue_name].pop('VoiceMail', None)
            queue_data[queue_name].pop('CallBack', None)
            queue_data[queue_name].pop('QueueHours', None)
            queue_data[queue_name].pop('CallFlow', None)
        else:
            queue_data[queue_name] = {'ID': queue['Id'], 'QueueTags':queue_tags}

        create_queue_response = create_queue(connect_client, connect_instance_details, queue_name, queue['CallerID'], queue['PhoneId'], queue_tags)
        #Only add when a queue is created
        if create_queue_response['result']:
            queue_data[queue_name]={
                'ID': create_queue_response['QueueId'],
                'QueueTags': queue_tags
            }
            queues_to_update, quick_connects_to_update = deploy_quick_connect(queue_name, create_queue_response['QueueId'], queues_to_update, quick_connects_to_update, connect_client, connect_instance_details)

    #Add any user & external quick connects
    for qc in connect_instance_details['quickConnectList']['QuickConnectSummaryList']:
        if qc['QuickConnectType'] in ['PHONE_NUMBER', 'USER']:
            if qc['Id'] not in quick_connects_to_update['External']:
                quick_connects_to_update['External'].append(qc['Id'])

    write_queue_data(tenant_id, ou, queue_data)
    assign_quick_connects(connect_client, connect_instance_details, queues_to_update, quick_connects_to_update)

def deploy_queues(tenant_id, source_instance_details, target_ou, connect_target_client, target_instance_details, dnis_id):
    queues_created = {"VoiceQueues":[], "EmailQueues": [], "ToDoQueues": [], "External":[]}
    quick_connects_created = {"VoiceQueues":[], "EmailQueues": [], "ToDoQueues": [], "External": []}
    queue_data = {}

    for queue_found in source_instance_details['QueueSummaryList']:
        create_queue_response = create_queue(connect_target_client, target_instance_details, queue_found['Name'], os.environ['CALLERID'], dnis_id, queue_found['Tags'])
        queue_data[queue_found['Name']]={
            'ID': create_queue_response['QueueId'],
            'QueueTags': queue_found['Tags']
        }
        queues_created, quick_connects_created = deploy_quick_connect(queue_found['Name'], create_queue_response['QueueId'], queues_created, quick_connects_created, connect_target_client, target_instance_details)

    #Add any user & external quick connects
    for qc in target_instance_details['quickConnectList']['QuickConnectSummaryList']:
        if qc['QuickConnectType'] in ['PHONE_NUMBER', 'USER']:
            if qc['Id'] not in quick_connects_created['External']:
                quick_connects_created['External'].append(qc['Id'])

    write_queue_data(tenant_id, target_ou, queue_data)
    assign_quick_connects(connect_target_client, target_instance_details, queues_created, quick_connects_created)

def deploy_quick_connect(queue_name, queue_id, queues_created, quick_connects_created, connect_target_client, target_instance_details):
    if '- Email' not in queue_name and '- ToDo' not in queue_name:
        if queue_id not in queues_created['VoiceQueues']:
            queues_created['VoiceQueues'].append(queue_id)
            create_qc_response = create_quick_connect(connect_target_client, target_instance_details, queue_name, queue_id)
            if create_qc_response['qcID'] not in quick_connects_created['VoiceQueues']:
                quick_connects_created['VoiceQueues'].append(create_qc_response['qcID'])
    if '- ToDo' in queue_name:
        if queue_id not in queues_created['ToDoQueues']:
            queues_created['ToDoQueues'].append(queue_id)
            create_qc_response = create_quick_connect(connect_target_client, target_instance_details, queue_name, queue_id)
            if create_qc_response['qcID'] not in quick_connects_created['ToDoQueues']:
                 quick_connects_created['ToDoQueues'].append(create_qc_response['qcID'])
    if '- Email' in queue_name:
        if queue_id not in queues_created['EmailQueues']:
            queues_created['EmailQueues'].append(queue_id)
            create_qc_response = create_quick_connect(connect_target_client, target_instance_details, queue_name, queue_id)
            if create_qc_response['qcID'] not in quick_connects_created['EmailQueues']:
                quick_connects_created['EmailQueues'].append(create_qc_response['qcID'])
    
    return queues_created, quick_connects_created

def assign_quick_connects(connect_client, connect_instance_details, queues_created, quick_connects_created):
    logger.info("ASSIGNING QUICK CONNECTS TO VOICE QUEUES")
    for voice_queue in queues_created['VoiceQueues']:
        try:
            for chunk in util.chunk_list(quick_connects_created['VoiceQueues'],50):
                connect_client.associate_queue_quick_connects(
                    InstanceId=connect_instance_details['instanceID'],
                    QueueId=voice_queue,
                    QuickConnectIds=chunk
                )
            
            for chunk in util.chunk_list(quick_connects_created['External'],50):
                connect_client.associate_queue_quick_connects(
                    InstanceId=connect_instance_details['instanceID'],
                    QueueId=voice_queue,
                    QuickConnectIds=chunk
                )
            time.sleep(1)
        except Exception as ex1:
            logger.info("VOICE associate_queue_quick_connects EXCEPTION: " + str(ex1))

    logger.info("ASSIGNING TODO QUICK CONNECTS TO TODO QUEUES")
    for todo_queue in queues_created['ToDoQueues']:
        try:
            for chunk in util.chunk_list(quick_connects_created['ToDoQueues'],50):
                connect_client.associate_queue_quick_connects(
                    InstanceId=connect_instance_details['instanceID'],
                    QueueId=todo_queue,
                    QuickConnectIds=chunk
                )
            time.sleep(1)
        except Exception as ex1:
            logger.info("TODO associate_queue_quick_connects EXCEPTION: " + str(ex1))

    logger.info("ASSIGNING EMAIL QUICK CONNECTS TO EMAIL QUEUES")
    for email_queue in queues_created['EmailQueues']:
        try:
            for chunk in util.chunk_list(quick_connects_created['EmailQueues'],50):
                connect_client.associate_queue_quick_connects(
                    InstanceId=connect_instance_details['instanceID'],
                    QueueId=email_queue,
                    QuickConnectIds=chunk
                )
            time.sleep(1)
        except Exception as ex1:
            logger.info("EMAIL associate_queue_quick_connects EXCEPTION: " + str(ex1))

def write_queue_data(tenant_id, target_ou, queue_data):
    #Save queue data to Instances Table
    tenant_name = f"{target_ou.lower()}{os.environ['ORGANIZATION_NAME']}-{tenant_id}"
    logger.info(f"WRITING QUEUE DATA TO INSTANCES TABLE FOR: {tenant_name}")
    try:
        table = boto3.resource('dynamodb').Table('Instances-' + target_ou)
        current_time = datetime.datetime.now(datetime.timezone.utc)
        table.update_item(
                Key = {'Tenant': tenant_name},
                UpdateExpression='SET #attr1 = :val1, #attr2 = :val2',
                ExpressionAttributeNames={'#attr1': 'QueueData', '#attr2': 'LastUpdated'},
                ExpressionAttributeValues={':val1': json.dumps(queue_data), ':val2': current_time.isoformat()}
            )

    except Exception as Ex1:
        logger.info("update_instance EXCEPTION: " + str(Ex1)) 

def create_queue(connect_client, connect_instance_details, queue_name, description, dnis_id, queue_tags):
    result = False
    queue_id = ''
    queue_arn = ''
    queue_exists = False

    for queue in connect_instance_details['QueueSummaryList']:
        if queue_name == queue['Name']:
            queue_exists = True
            queue_id = queue['QueueId']
            queue_arn = queue['QueueArn']

    description = queue_name if not description else description
    param_tags = {k: v for k, v in queue_tags.items() if v not in (None, "")}
            
    if not queue_exists:    
        logger.info(f"CREATING QUEUE: {queue_name}")
        try:
            params = {
                'InstanceId':connect_instance_details['instanceID'],
                'Name':queue_name,
                'Description':queue_name,
                'OutboundCallerConfig':{
                    'OutboundCallerIdName': description,
                    'OutboundCallerIdNumberId': dnis_id,
                    'OutboundFlowId': connect_instance_details['outboundFlowID']
                },
                'HoursOfOperationId':connect_instance_details['business_hours_id'],
                'Tags':param_tags
            }
            if '- Email' not in queue_name:
                params['MaxContacts'] = 75

            response = connect_client.create_queue(**params)
            result = True
            queue_id = response['QueueId']
        except Exception as ex1:
            logger.info('create_queue EXCEPTION: ' + str(ex1))
    else:
        logger.info(f"QUEUE ALREADY EXISTS.  UPDATING QUEUE: {queue_name}")
        if dnis_id:
            try:
                connect_client.update_queue_outbound_caller_config(
                    InstanceId=connect_instance_details['instanceID'],
                    QueueId=queue_id,
                    OutboundCallerConfig={
                        'OutboundCallerIdName': description,
                        'OutboundCallerIdNumberId': dnis_id,
                        'OutboundFlowId': connect_instance_details['outboundFlowID']
                    }
                )
            except Exception as ex1:
                logger.info('update_queue_outbound_caller_config EXCEPTION: ' + str(ex1))

        try:
            replace_queue_tags(connect_client, queue_arn, param_tags)            
        except Exception as ex1:
            logger.info('tag_resource EXCEPTION: ' + str(ex1))

    return {
        'result': result,
        'QueueId': queue_id
    }

def replace_queue_tags(connect_client, resource_arn, new_tags):
    current = connect_client.list_tags_for_resource(
        resourceArn=resource_arn
    )
    current_tags = current.get("tags", {})
    remove_keys = [k for k in current_tags.keys() if k not in new_tags]

    if remove_keys:
        connect_client.untag_resource(
            resourceArn=resource_arn,
            tagKeys=remove_keys
        )

    if new_tags:
        connect_client.tag_resource(
            resourceArn=resource_arn,
            tags=new_tags
        )

def delete_queues(event, connect_client, connect_instance_details, queues_to_delete):
    status = 'Success'

    for queue_name in queues_to_delete:
        if '+' not in queue_name: #Queues + Quick Connects
            queue_id = util.get_queue_id(connect_instance_details['QueueSummaryList'], queue_name)
            logger.info("DELETING QUEUE: " + queue_name)
            qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], queue_name)
            remove_quick_connect(connect_client, connect_instance_details, qc_id, queue_name)

            status = remove_queue(event, connect_client, connect_instance_details, queue_id, queue_name)
        
        else:
            qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], queue_name)
            if qc_id != "NOT FOUND":
                remove_quick_connect(connect_client, connect_instance_details, qc_id, queue_name)

    return status
    
def remove_queue(event, connect_client, connect_instance_details, queue_id, queue):
    status = "Success"
    dynamodb_client = boto3.client('dynamodb', region_name=config.region)
    ou = event['Env']
    tenant_id = event['TenantID']

    #SEARCH ALL ROUTING PROFILES AND REMOVE QUEUE FROM PROFILES
    for routing_profile in connect_instance_details['routingProfileList']['RoutingProfileSummaryList']:

        try:
            routing_queues = connect_client.list_routing_profile_queues(
                InstanceId=connect_instance_details['instanceID'],
                RoutingProfileId=routing_profile['Id'],
                MaxResults=100
            )
    
            for routing_queue in routing_queues['RoutingProfileQueueConfigSummaryList']:
                if routing_queue['QueueId'] == queue_id:
                    connect_client.disassociate_routing_profile_queues(
                        InstanceId=connect_instance_details['instanceID'],
                        RoutingProfileId=routing_profile['Id'],
                        QueueReferences=[
                            {
                                'QueueId': queue_id,
                                'Channel': 'VOICE'
                            },
                            {
                                'QueueId': queue_id,
                                'Channel': 'TASK'
                            }                            
                        ]
                    )
          
        except Exception as ex1:
            logger.info('disassociate_routing_profile_queues EXCEPTION: ' + str(ex1))

    #UPDATE USERS TABLE TO REMOVE QUEUE
    
    try:
        get_users_response = dynamodb_client.scan(
            TableName='Users-' + ou
        )
        #logger.info("DB RESPONSE: " + str(get_users_response))

        for user_record in get_users_response['Items']:
            update = False
            if tenant_id == user_record['Tenant']['S']:
                old_priority = json.loads(user_record['Priority']['S'])
                new_priority = {}
                for assigned_queue in old_priority:
                    if assigned_queue == queue:
                        update = True
                    else:
                        new_priority[assigned_queue] = old_priority[assigned_queue]
                
                if update:
                    logger.info("UPDATING USERS TABLE: " + full_name)
                    full_name = user_record['Name']['S']
                    last_name = full_name[0:full_name.find(',')]
                    first_name = full_name[full_name.find(',')+1:]
                    users.update_user(ou, tenant_id, user_record['Email']['S'], first_name, last_name, json.loads(user_record['Languages']['S']), json.loads(user_record['Role']['S']), new_priority, "")

    except Exception as ex1:
        logger.info('delete queue from user table EXCEPTION: ' + str(ex1))

    try:
        connect_client.delete_queue(
            InstanceId=connect_instance_details['instanceID'],
            QueueId=queue_id
        )
 
    except Exception as ex1:
        status = 'remove_queue EXCEPTION: ' + str(ex1)
        logger.info(status)
    
    return status

def remove_quick_connect(connect_client, connect_instance_details, quickConnectID, qc_name):
    logger.info("REMOVING QUICK CONNECT: " + str(qc_name))
    try:
        connect_client.delete_quick_connect(
            InstanceId=connect_instance_details['instanceID'],
            QuickConnectId=quickConnectID
        )
    except Exception as ex1:
        logger.info('delete_quick_connect EXCEPTION: ' + str(ex1))
        
def create_quick_connect(connect_client, connect_instance_details, qc_name, queue_id):
    result = False
    qc_exists = False
    qc_id = ''
    qc_list = []

    try:
        list_qc_response = connect_client.list_quick_connects(
            InstanceId=connect_instance_details['instanceID'],
            QuickConnectTypes=[
                'QUEUE'
            ]
        )
        qc_list = list_qc_response['QuickConnectSummaryList']

        while 'NextToken' in list_qc_response:
            list_qc_response = connect_client.list_quick_connects(
                InstanceId=connect_instance_details['instanceID'],
                NextToken=list_qc_response['NextToken'],
                QuickConnectTypes=[
                    'QUEUE'
                ]
            )
            qc_list.extends(list_qc_response['QuickConnectSummaryList'])

        for qc in qc_list:
            if qc_name == qc['Name']:
                qc_exists = True
                qc_id = qc['Id']

        if not qc_exists:
            logger.info(f"CREATING QUICK CONNECT: {qc_name}")
            response = connect_client.create_quick_connect(
                InstanceId=connect_instance_details['instanceID'],
                Name=qc_name,
                Description='Created by Ignite',
                QuickConnectConfig={
                    'QuickConnectType': 'QUEUE',
                    'QueueConfig': {
                        'QueueId': queue_id,
                        'ContactFlowId': connect_instance_details['agentQueueFlowID']
                    }
                }
            )
            qc_id = response['QuickConnectId']
            result = True
        else:
            logger.info(f"QUICK CONNECT ALREADY EXISTS: {qc_name}")
            connect_client.update_quick_connect_config(
                InstanceId=connect_instance_details['instanceID'],
                QuickConnectId=qc_id,
                QuickConnectConfig={
                    'QuickConnectType': 'QUEUE',
                    'QueueConfig': {
                        'QueueId': queue_id,
                        'ContactFlowId': connect_instance_details['agentQueueFlowID']
                    }
                }
            )            
    except Exception as ex1:
        result = False
        logger.info('create_quick_connect EXCEPTION: ' + str(ex1))
            
    return {
        'result': result,
        'qcID': qc_id
    }

def create_phone_quick_connect(connect_client, connect_instance_details, qc_name):
    import re
    result = False
    qc_exists = False
    qc_id = ''
    qc_list = []

    phone_number = '+' + re.search(r'\d+', qc_name).group() if re.search(r'\d+', qc_name) else None
    #qc_name = ''.join(re.findall(r'[a-zA-Z]+', qc_full_name))

    try:
        list_qc_response = connect_client.list_quick_connects(
            InstanceId=connect_instance_details['instanceID'],
            QuickConnectTypes=[
                'PHONE_NUMBER'
            ]
        )
        qc_list = list_qc_response['QuickConnectSummaryList']

        while 'NextToken' in list_qc_response:
            list_qc_response = connect_client.list_quick_connects(
                InstanceId=connect_instance_details['instanceID'],
                NextToken=list_qc_response['NextToken'],
                QuickConnectTypes=[
                    'PHONE_NUMBER'
                ]
            )
            qc_list.extends(list_qc_response['QuickConnectSummaryList'])

        for qc in qc_list:
            if qc_name in qc['Name']:
                qc_exists = True
                qc_id = qc['Id']

        if not qc_exists:
            logger.info("CREATING PHONE QUICK CONNECT: " + qc_name)
           
            response = connect_client.create_quick_connect(
                InstanceId=connect_instance_details['instanceID'],
                Name=qc_name,
                Description=qc_name,
                QuickConnectConfig={
                    'QuickConnectType': 'PHONE_NUMBER',
                    'PhoneConfig': {
                        'PhoneNumber': phone_number
                    }
                }
            )
            result = True
            qc_id = response['QuickConnectId']
        else:
            logger.info("PHONE QUICK CONNECT ALREADY EXISTS: " + qc_name)

    except Exception as ex1:
        logger.info('create_phone_quick_connect EXCEPTION: ' + str(ex1))


    return {
        'result': result,
        'qcID': qc_id
    }
   
def manual_delete_queue(connect_client, connect_id, queue_name):
    queue_list = util.get_queue_summary_list(connect_client, connect_id)
    queue_id = util.get_queue_id(queue_list, queue_name)

    for queue in queue_list:
        if queue_name in queue['Name']:
            logger.info('DELETING QUEUE: ' + queue['Name'])
            queue_id = queue['QueueId']

            try:
                connect_client.delete_queue(
                    InstanceId=connect_id,
                    QueueId=queue_id
                )
            except Exception as ex1:
                logger.info('delete_queue EXCEPTION: ' + str(ex1))

