import json
import boto3
#import requests
import time
import logger

def get_lex_bots(lex_client):
    lex_bots = {}

    bots = list_bots(lex_client)
    for bot in bots:
        bot_name = bot['botName']
        bot_id = bot['botId']

        if bot_name not in lex_bots:
            lex_bots[bot_name] = {
                'bot_id': bot_id,
                'versions': {}
            }

        versions = list_bot_versions(lex_client, bot_id)
        for version in versions:
            bot_version = version['botVersion']
            if bot_version not in lex_bots[bot_name]['versions']:
                lex_bots[bot_name]['versions'][bot_version] = {}

            locales = list_locales_for_bot(lex_client, bot_id, bot_version)
            for locale in locales:
                locale_name = locale['localeName']
                locale_id = locale['localeId']

                if locale_name not in lex_bots[bot_name]['versions'][bot_version]:
                    lex_bots[bot_name]['versions'][bot_version][locale_name] = {
                        'locale_id': locale_id,
                        'intents': {}
                    }

                intents = list_intents_for_locale(lex_client, bot_id, bot_version, locale_id)
                for intent in intents:
                    intent_name = intent['intentName']
                    intent_id = intent['intentId']

                    if intent_name not in lex_bots[bot_name]['versions'][bot_version][locale_name]['intents']:
                        lex_bots[bot_name]['versions'][bot_version][locale_name]['intents'][intent_name] = {
                            'intent_id': intent_id,
                            'slots': {}
                        }

                    slots = list_slots_for_intent(lex_client, bot_id, bot_version, locale_id, intent_id)
                    for slot in slots:
                        slot_name = slot['slotName']
                        slot_id = slot['slotId']

                        lex_bots[bot_name]['versions'][bot_version][locale_name]['intents'][intent_name]['slots'][slot_name] = slot_id

    return lex_bots


def list_bots(lex_client):
    bots = []
    next_token = None

    while True:
        if next_token:
            response = lex_client.list_bots(nextToken=next_token)
        else:
            response = lex_client.list_bots()

        bots.extend(response.get('botSummaries', []))
        next_token = response.get('nextToken')
        if not next_token:
            break

    return bots


def list_bot_versions(lex_client, bot_id):
    bot_versions = []
    next_token = None

    while True:
        if next_token:
            response = lex_client.list_bot_versions(botId=bot_id, nextToken=next_token)
        else:
            response = lex_client.list_bot_versions(botId=bot_id)

        bot_versions.extend(response.get('botVersionSummaries', []))
        next_token = response.get('nextToken')
        if not next_token:
            break

    return bot_versions


def list_locales_for_bot(lex_client, bot_id, bot_version):
    locales = []
    next_token = None

    while True:
        if next_token:
            response = lex_client.list_bot_locales(
                botId=bot_id,
                botVersion=bot_version,
                nextToken=next_token
            )
        else:
            response = lex_client.list_bot_locales(
                botId=bot_id,
                botVersion=bot_version
            )

        locales.extend(response.get('botLocaleSummaries', []))
        next_token = response.get('nextToken')
        if not next_token:
            break

    return locales


def list_intents_for_locale(lex_client, bot_id, bot_version, locale_id):
    intents = []
    next_token = None

    while True:
        if next_token:
            response = lex_client.list_intents(
                botId=bot_id,
                botVersion=bot_version,
                localeId=locale_id,
                nextToken=next_token
            )
        else:
            response = lex_client.list_intents(
                botId=bot_id,
                botVersion=bot_version,
                localeId=locale_id
            )

        intents.extend(response.get('intentSummaries', []))
        next_token = response.get('nextToken')
        if not next_token:
            break

    return intents


def list_slots_for_intent(lex_client, bot_id, bot_version, locale_id, intent_id):
    slots = []
    next_token = None

    while True:
        if next_token:
            response = lex_client.list_slots(
                botId=bot_id,
                botVersion=bot_version,
                localeId=locale_id,
                intentId=intent_id,
                nextToken=next_token
            )
        else:
            response = lex_client.list_slots(
                botId=bot_id,
                botVersion=bot_version,
                localeId=locale_id,
                intentId=intent_id
            )

        slots.extend(response.get('slotSummaries', []))
        next_token = response.get('nextToken')
        if not next_token:
            break

    return slots

def deploy_lex_bot(lex_source_client, lex_target_client, bot_name, bot_id, bot_locale, bot_version, alias_name, lex_execution_role_arn):
    """
    Transfers a Lex V2 bot from a source client to a target client.

    :param lex_source_client: boto3 LexV2 client for the source account.
    :param lex_target_client: boto3 LexV2 client for the target account.
    :param bot_id: ID of the bot to export.
    :param bot_locale: Locale ID (e.g., 'en_US').
    :param bot_version: 'DRAFT' or a published version.
    :param bot_name: Name of the new bot in the target account.
    :param lex_execution_role_arn: IAM role ARN in the target account for Lex to assume.
    :param file_password: Optional password for zip encryption.
    """

    # Step 1: Export bot from source
    logger.info("🔄 Starting export from source account...")

    export_resp = lex_source_client.create_export(
        resourceSpecification={
            'botExportSpecification': {
                'botId': bot_id,
                'botVersion': bot_version,
                'localeId': bot_locale
            }
        },
        fileFormat='LexJson',
        exportType='Bot'
    )

    export_id = export_resp['exportId']

    # Poll until export completes
    while True:
        export_status = lex_source_client.describe_export(exportId=export_id)['exportStatus']
        print(f"⏳ Export status: {export_status}")
        if export_status in ['Completed', 'Failed']:
            break
        time.sleep(5)

    if export_status != 'Completed':
        raise Exception("❌ Export failed in source account.")

    download_url = lex_source_client.describe_export(exportId=export_id)['downloadUrl']
    zip_data = requests.get(download_url).content
    logger.info("✅ Export completed and ZIP downloaded.")

    # Step 2: Upload ZIP to Lex import URL in target account
    logger.info("📤 Uploading ZIP to target account...")

    upload_url_resp = lex_target_client.create_upload_url()
    upload_url = upload_url_resp['uploadUrl']
    import_id = upload_url_resp['importId']

    upload_resp = requests.put(upload_url, data=zip_data, headers={"Content-Type": "application/zip"})
    if upload_resp.status_code != 200:
        raise Exception(f"❌ Upload failed: {upload_resp.status_code} - {upload_resp.text}")

    logger.info("✅ ZIP uploaded successfully.")

    # Step 3: Start import
    logger.info(f"🚀 Starting import in target account with bot name '{bot_name}'...")
    import_resp = lex_target_client.start_import(
        importId=import_id,
        resourceSpecification={
            'botImportSpecification': {
                'botName': bot_name,
                'roleArn': lex_execution_role_arn
            }
        },
        mergeStrategy='Overwrite'
    )

    # Step 4: Wait for import to complete
    while True:
        import_status = lex_target_client.describe_import(importId=import_id)['importStatus']
        logger.info(f"⏳ Import status: {import_status}")
        if import_status in ['Completed', 'Failed']:
            break
        time.sleep(5)

    if import_status == 'Completed':
        logger.info("🎉 Bot successfully transferred to target account!")
    else:
        raise Exception("❌ Import failed in target account.")

    response = lex_target_client.create_bot_version(
        botId=bot_id,
        description="Imported Bot"
    )

    response = lex_target_client.create_bot_alias(
        botAliasName=alias_name,
        botId=bot_id,
        botVersion=bot_version,
        botAliasLocaleSettings={
            locale_id: {
                'enabled': True
            }
        },
        sentimentAnalysisSettings={
            'detectSentiment': False  # Optional
        },
        botAliasTags={
            'env': alias_name
        },
        conversationLogSettings={
            'audioLogSettings': [],
            'textLogSettings': []
        },
        roleArn=runtime_role_arn
    )

    print(f"✅ Created alias '{alias_name}' pointing to version '{bot_version}'")

    version_id = response['botVersion']
