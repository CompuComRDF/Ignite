import json
import boto3
import os
import util
import config
from time import sleep
import sys

def createTenantInstance(event, ou):
    principal_arn = os.environ['PRINCIPAL_ARN']  
    newImage = event['Records'][0]['dynamodb']['NewImage']
    account_name = newImage['Tenant']['S']
    email_domain = newImage['EmailDomain']['S']
    instance_type = newImage['InstanceType']['S']

    if not check_instance_exists(account_name):
        if '@' not in email_domain:
            account_email = account_name + "-" + "@" + email_domain
        else:
            account_email = email_domain
            
        util.logger('USING ACCOUNT EMAIL ADDRESS: ' + account_email)

        account_id  = get_account_id(account_name)
        if account_id == 'None':
            account_id = create_account(account_name, account_email, ou, principal_arn)
        else:
            util.logger(account_name + ' ALREADY EXISTS WITH ACCOUNT NUMBER: ' + account_id)

        if account_id != 'None':
            role_credentials = assume_role(account_id)
            create_db_table(role_credentials, "ivr-recording-contactTranscriptSegments")
            create_db_table(role_credentials, "ivr-recording-contactDetails")

            create_xaccount_role(role_credentials)
            tenant_kms_key = create_tenant_kms_key(role_credentials, account_name)

            create_s3_bucket(role_credentials,account_name.lower() + '-callrecordings', tenant_kms_key) #Caller Recordings
            create_s3_bucket(role_credentials, account_name.lower() + '-reports', tenant_kms_key) #Caller Reports

            instance_arn = create_connect_instance(role_credentials, account_name, instance_type)

            if instance_arn != 'None':
                instance_id = instance_arn.split(":")[5][(instance_arn.split(":")[5].find('/')+1):]

                associate_s3_bucket(role_credentials, instance_id, account_name.lower(), '-callrecordings', tenant_kms_key) #Caller Recordings
                associate_s3_bucket(role_credentials, instance_id, account_name.lower(), '-reports', tenant_kms_key) #Caller Reports
                associate_kinesis_video(role_credentials, instance_id, tenant_kms_key)

                rdf_kms_key = create_rdf_kms_key(role_credentials, "xaccount-s3-rdf-kms", account_id)
                create_s3_bucket(role_credentials, 'amazon-connect-' + instance_id, rdf_kms_key) #RDF Application

                util.logger("Updating S3 Bucket Resource Policy: ")
                s3_bucket_policy = config.s3_main_bucket_policy.replace('<RDF_ROLE>', get_rdf_role())
                s3_bucket_policy = s3_bucket_policy.replace('<S3BUCKETNAME>', 'amazon-connect-' + instance_id)
                s3_bucket_policy = s3_bucket_policy.replace('<TENANT_ACCOUNT>', account_id)
                s3_bucket_policy = s3_bucket_policy.replace('<INSTANCE_ARN>', instance_arn)
                
                s3_client = boto3.client('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                s3_client.put_bucket_policy(
                    Bucket='amazon-connect-' + instance_id,
                    Policy=s3_bucket_policy
                )

                upload_rdf_application_files(role_credentials, 'amazon-connect-' + instance_id)

                kvs_converter_exec_role = config.lambda_exec_policy.replace('<AWS_REGION>', config.region).replace('<AWS_ACCOUNT_ID>', account_id).replace('<FUNCTION_NAME>', 'kvs_Converter')
                create_policy(role_credentials, 'AWSLambdaBasicExecutionRole-' + 'kvs_Converter', kvs_converter_exec_role)
                config.lambda_functions['kvs_Converter']['environment']['Variables']['APP_REGION'] = config.region
                config.lambda_functions['kvs_Converter']['environment']['Variables']['TRANSCRIBE_REGION'] = config.region
                config.lambda_functions['kvs_Converter']['environment']['Variables']['RECORDINGS_BUCKET_NAME'] = 'amazon-connect-' + instance_id                    
                create_lambda_function(role_credentials, 'kvs_Converter', 'amazon-connect-' + instance_id)

                ckvs2_converter_exec_role = config.lambda_exec_policy.replace('<AWS_REGION>', config.region).replace('<AWS_ACCOUNT_ID>', account_id).replace('<FUNCTION_NAME>', 'ConnectKVS2Audio')
                create_policy(role_credentials, 'AWSLambdaBasicExecutionRole-' + 'ConnectKVS2Audio', ckvs2_converter_exec_role)                     
                (role_arn, function_arn) = create_lambda_function(role_credentials, 'ConnectKVS2Audio', 'amazon-connect-' + instance_id)
                add_S3_trigger(role_credentials, 'ConnectKVS2Audio', 'amazon-connect-' + instance_id, account_id, function_arn)
                add_event_bridge_rule(role_credentials, function_arn)

                create_contact_flows(role_credentials, account_id, instance_arn)

                associate_lambda_function(role_credentials, instance_id, function_arn)

                add_rdf_invoke_permissions(account_id, account_name, instance_arn, ou)

                update_instance_record(account_name, account_id, instance_arn, ou)

                #create_kinesis_stream()

        #INSERT THESE VALUES INTO TENANTS TABLE
        #tenantID = newImage['tenantID']['S']
        #tenantName = newImage['tenantName']['S']
        #greeting = json.loads(newImage['greeting']['S'])
        #language = newImage['language']['S']
        #relatedQueues = json.loads(newImage['quickConnects']['S'])
        #queuesCreated = []
        #quickConnectIds=[]

def check_instance_exists(tenant_name):
    dynamodb_client = boto3.client('dynamodb')
    instanceExists = False

    #response = dynamodb_client.query(
    #    TableName='Instances-DEV',
    #    KeyConditionExpression='Tenant = :tenant_name',
    #    ExpressionAttributeValues={
    #        ':tenant_name': {'S': tenant_name}
    #    }
    #)

    #try:
    #    print("INSTANCE ALREADY EXISTS: " + str(response['Items']))
    #    instanceExists = True
    #except:
    #    pass

    try:
        get_item_response = dynamodb_client.get_item(TableName='Instances-DEV', Key={"Tenant": {"S":tenant_name}})
        print("INSTANCE ALREADY EXISTS: " + str(get_item_response['Items']))
        instanceExists = True
    except Exception as Ex1:
        #util.logger("check_instance_exists EXCEPTION: " + str(Ex1))
        pass

    return(instanceExists)
    
def create_account(account_name, account_email, ou, principal_arn):
    #INVOKE Ignite-Factory lambda function to provision Tenant account
    util.logger('INVOKING IGNITE FACTORY TO CREATE ACCOUNT: ' + account_name)
    account_id = 'None'
    factory_account_id = principal_arn.split(':')[4]
    factory_role = principal_arn.split(':')[5]
    #sts_client = boto3.client('sts')
    #sts_session = sts_client.assume_role(RoleArn='arn:aws:iam::' + factory_account_id + ':role/Test39-role',
    #                                RoleSessionName='create-instance-session')

    principal_arn = os.environ['PRINCIPAL_ARN']
    
    lambda_client = boto3.client('lambda', region_name=config.region,
        aws_access_key_id=os.environ['ACCESS_KEY_ID'],
        aws_secret_access_key=os.environ['SECRET_ACCESS_KEY']
    )

    payload = {
        "AccountName":account_name,
        "AccountEmail":account_email,
        "OrganizationUnitName":ou,
        "PrincipalARN":principal_arn,
        "CentralAccountID": config.AWS_ACCOUNT_ID
        }

    lambda_client.invoke(
        FunctionName='Ignite-Factory',
        InvocationType='Event',
        LogType='Tail',
        Payload= bytes(json.dumps(payload), encoding='utf8'),
    )
    wait_counter = 0
    while(wait_counter < 3):
        util.logger('ACCOUNT CREATION UNDER CHANGE: Iteration ' + str(wait_counter))
        account_id = get_account_id(account_name)
        if account_id == 'None':
            sleep(30)
            wait_counter += 1
        else:
            break

    if account_id != "None":
        util.logger('ACCOUNT CREATION COMPLETED: ' + account_id)
    else:
        util.logger('UNABLE TO CREATE ACCOUNT: ' + account_name)        

    return(account_id)

def get_account_id(account_name):
    org_client = boto3.client('organizations',
        aws_access_key_id=os.environ['ACCESS_KEY_ID'],
        aws_secret_access_key=os.environ['SECRET_ACCESS_KEY']
    )

    account_id = "None"
    list_accounts = []
    list_account_ids = []
    list_account_names = []
    account_name_to_id = {}

    try:
        list_of_accounts_response = org_client.list_accounts()
        list_accounts = list_of_accounts_response['Accounts']

        while "NextToken" in list_of_accounts_response:
            list_of_accounts_response = org_client.list_accounts(
                    NextToken=list_of_accounts_response['NextToken']
            )
            list_accounts.extend(list_of_accounts_response['Accounts'])

        for account in list_accounts:
            list_account_ids.append(account['Id'])
            list_account_names.append(account['Name'])

        for i in range(len(list_account_names)):
            account_name_to_id[list_account_names[i]] = list_account_ids[i]

        if account_name in list_account_names:
            account_id = account_name_to_id[account_name]

    except Exception as Ex1:
        util.logger("get_account_id EXCEPTION: " + str(Ex1))

    return account_id

def assume_role(account_id):
    util.logger("ASSUMING Ignite-Client ROLE OF ACCOUNT: " + account_id)

    role_credentials = {}

    wait_counter = 0
    sts_client = boto3.client('sts')
    while(wait_counter <= 3):
        try:
            sts_session = sts_client.assume_role(RoleArn='arn:aws:iam::' + account_id + ':role/Ignite-Client',
                                            RoleSessionName='initialization-session')
            
            role_credentials['KEY_ID'] = sts_session['Credentials']['AccessKeyId']
            role_credentials['ACCESS_KEY'] = sts_session['Credentials']['SecretAccessKey']
            role_credentials['TOKEN'] = sts_session['Credentials']['SessionToken']
            util.logger("ASSUMED ROLE Ignite-Client SUCCESSFULLY: {}" + format(role_credentials['KEY_ID']))
            break
        except Exception as Ex1:
            util.logger('WAITING FOR ACCOUNT SERVICES TO BE READY')
            wait_counter += 1
            sleep(30)
            pass
    else:
        util.logger("UNABLE TO ASSUME ROLE Ignite-Client.  PLEASE TRY AGAIN.")
        sys.exit(1)
    
    return(role_credentials)

def create_xaccount_role(role_credentials):
    util.logger("CREATING xaccount-rdf-role")
    iam_client = boto3.client('iam', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    try:
        found_role = False
        list_roles_response = iam_client.list_roles()

        list_roles = list_roles_response['Roles']
        
        while "Marker" in list_roles_response:
            list_roles_response = iam_client.list_roles(
                Marker=list_roles_response['Marker'],
            )
            
            list_roles.extend(list_roles_response['Roles'])

        for role in list_roles:
            if 'xaccount-rdf-role' in role['RoleName']:
                found_role = True
                result = role['Arn']

        if not found_role:

            assume_role_policy = config.assume_role_policy_document.replace('<ACCOUNT_ID>', config.AWS_ACCOUNT_ID)
                        
            iam_client.create_role(
                Path='/',
                RoleName='xaccount-rdf-role',
                AssumeRolePolicyDocument=assume_role_policy,
                Description='Cross Account Role used by Ignite-RDF',
                MaxSessionDuration=3600,
                #PermissionsBoundary='string',
            )

            list_policies_response = iam_client.list_policies(
                Scope='AWS',
                OnlyAttached=False,
                PathPrefix='/',
                PolicyUsageFilter='PermissionsPolicy',
                #Marker='string',
                MaxItems=100
            )

            list_policies =  list_policies_response['Policies']

            while 'Marker' in list_policies_response:
                list_policies_response = iam_client.list_policies(
                    Scope='AWS',
                    OnlyAttached=False,
                    PathPrefix='/',
                    PolicyUsageFilter='PermissionsPolicy',
                    Marker=list_policies_response['Marker'],
                    MaxItems=100
                )
            
                list_policies.extend(list_policies_response['Policies'])

            for policy in list_policies:
                if policy['PolicyName'] == 'AmazonConnect_FullAccess' or policy['PolicyName'] == 'AmazonDynamoDBFullAccess':
                    iam_client.attach_role_policy(
                        RoleName='xaccount-rdf-role',
                        PolicyArn=policy['Arn']
                    )
        else:
            util.logger("xaccount-rdf-role ALREADY EXISTS " + result)

    except Exception as Ex1:
        result = 'None'
        util.logger("create_xaccount_role EXCEPTION: " + str(Ex1))

def get_rdf_role():
    util.logger("GETTING RDF ROLE ARN")
    role_arn = 'None'
    iam_client = boto3.client('iam')
    try:
        get_rdf_role_response = iam_client.list_roles(
            PathPrefix='/'
        )

        list_roles = get_rdf_role_response['Roles']

        while 'Marker' in get_rdf_role_response:
            get_rdf_role_response = iam_client.list_roles(
                PathPrefix='/',
                Marker=get_rdf_role_response['Marker']
            )

            list_roles.extend(get_rdf_role_response['Roles'])

        for role in list_roles:
            if 'Ignite-RDF' in role['RoleName']:
                role_arn = role['Arn']

    except Exception as Ex1:
        result = 'None'
        util.logger("get_rdf_role EXCEPTION: " + str(Ex1))

    return role_arn

def create_tenant_kms_key(role_credentials, alias):
    util.logger("CREATING KMS KEY: " + alias)
    kms_client = boto3.client('kms', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    key_exists = False

    try:
        list_kms_aliases_response = kms_client.list_aliases(Limit=100)

        for key in list_kms_aliases_response['Aliases']:
            if 'alias/' + alias in key['AliasName']:
                util.logger("EXISTING KMS KEY: " + key['AliasName'])
                key_exists = True
                describe_key_response = kms_client.describe_key(
                    KeyId=key['TargetKeyId']
                )
                kms_arn = describe_key_response['KeyMetadata']['Arn']

        if not key_exists:
            kms_response = kms_client.create_key(
                Description='KMS KEY for ' + alias,
                KeyUsage='ENCRYPT_DECRYPT',
                KeySpec='SYMMETRIC_DEFAULT',
                Origin='AWS_KMS',
                MultiRegion=False,
            )

            kms_client.create_alias(
                AliasName='alias/' + alias,
                TargetKeyId=kms_response['KeyMetadata']['KeyId']
            )

            kms_arn = kms_response['KeyMetadata']['Arn']
            util.logger("CREATED KMS KEY: " + kms_arn)

    except Exception as Ex1:
        util.logger("create_tenant_kms_key EXCEPTION: " + str(Ex1))

    return(kms_arn)

def create_rdf_kms_key(role_credentials, alias, account_id):
    util.logger("CREATING KMS KEY: " + alias)
    kms_client = boto3.client('kms', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    key_exists = False

    try:
        list_kms_aliases_response = kms_client.list_aliases(Limit=100)

        for key in list_kms_aliases_response['Aliases']:
            if 'alias/' + alias in key['AliasName']:
                util.logger("EXISTING KMS KEY: " + key['AliasName'])
                key_exists = True
                describe_key_response = kms_client.describe_key(
                    KeyId=key['TargetKeyId']
                )
                kms_arn = describe_key_response['KeyMetadata']['Arn']

        if not key_exists:            
            kms_key_policy = config.kms_key_policy.replace('<TENANT_ACCOUNT>', account_id)
            kms_key_policy = kms_key_policy.replace('<CENTRAL_ACCOUNT>', config.AWS_ACCOUNT_ID)

            kms_response = kms_client.create_key(
                Policy=kms_key_policy,
                Description='KMS KEY for ' + alias,
                KeyUsage='ENCRYPT_DECRYPT',
                KeySpec='SYMMETRIC_DEFAULT',
                Origin='AWS_KMS',
                MultiRegion=False,
            )

            kms_client.create_alias(
                AliasName='alias/' + alias,
                TargetKeyId=kms_response['KeyMetadata']['KeyId']
            )

            kms_arn = kms_response['KeyMetadata']['Arn']
            util.logger("CREATED KMS KEY " + kms_arn)

    except Exception as Ex1:
        util.logger("create_rdf_kms_key EXCEPTION: " + str(Ex1))

    return(kms_arn)

def create_s3_bucket(role_credentials, bucket_name, kms_key_id):
    s3_client = boto3.client('s3', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    bucket_exists = False

    list_of_s3_buckets_response = s3_client.list_buckets()

    for bucket in list_of_s3_buckets_response['Buckets']:
        if bucket_name in bucket['Name']:
            util.logger("EXISTING S3 BUCKET: " + bucket['Name'])
            bucket_exists = True
            bucket_name =  bucket['Name']
            
    if not bucket_exists:
        util.logger("CREATING S3 BUCKET: " + bucket_name)
        try:
            s3_client.create_bucket(
                Bucket=bucket_name,
                CreateBucketConfiguration={
                    'LocationConstraint': config.region 
                }
            )        

            s3_client.put_bucket_encryption(
                Bucket=bucket_name,
                ServerSideEncryptionConfiguration={
                    'Rules': [
                        {
                            'ApplyServerSideEncryptionByDefault': {
                                'SSEAlgorithm': 'aws:kms',
                                'KMSMasterKeyID': kms_key_id
                            },
                            'BucketKeyEnabled': True
                        },
                    ]
                },
                #ExpectedBucketOwner='string'
            )

        except Exception as Ex1:
            util.logger("get_s3_bucket EXCEPTION: " + str(Ex1))
        
    return(bucket_name)

def create_db_table(role_credentials, table_name):
    wait_counter = 0
    while(wait_counter <= 3):
        try:
            db_client = boto3.client('dynamodb', region_name=config.region,
                aws_access_key_id=role_credentials['KEY_ID'],
                aws_secret_access_key=role_credentials['ACCESS_KEY'],
                aws_session_token=role_credentials['TOKEN'])
            
            list_of_tables_response = db_client.list_tables(
                Limit=100
            )        
            
            break
        except Exception as Ex1:
            util.logger('WAITING FOR DYNAMODB SERVICES TO BE READY: '  + str(Ex1))
            wait_counter += 1
            sleep(30)
            pass          
    else:
        util.logger("UNABLE TO CREATE DYNAMODB TABLES.  PLEASE TRY AGAIN.")
        sys.exit(1)

    list_table_names = []

    list_of_tables_response = db_client.list_tables(
        Limit=100
    )

    list_table_names = list_of_tables_response['TableNames']
    
    while "LastEvaluatedTableName" in list_of_tables_response:
        list_of_tables_response = db_client.client.list_tables(
            ExclusiveStartTableName=list_of_tables_response['LastEvaluatedTableName'],
            Limit=100
        )
        list_table_names.extend(list_of_tables_response['TableNames'])

    if(table_name not in list_table_names):
        util.logger("CREATING DYNAMODB TABLE: {}".format(table_name))

        db_client.create_table(
            AttributeDefinitions=config.db_tables[table_name]['attribute_definitions'],
            TableName=table_name,
            KeySchema=config.db_tables[table_name]['key_schema'],
            ProvisionedThroughput={
                'ReadCapacityUnits': 5,
                'WriteCapacityUnits': 5
            },
            SSESpecification={
                'Enabled': True,
                'SSEType': 'KMS'
                #'KMSMasterKeyId': 'string'
            },
            TableClass='STANDARD',
            DeletionProtectionEnabled=True
        )
                
    else:
        util.logger("EXISTING DYNAMODB TABLE: " + table_name)

def create_connect_instance(role_credentials, account_name, instance_type):
    util.logger("CREATING AMAZON CONNECT INSTANCE: " + account_name)
    connect_client = boto3.client('connect', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    connect_instance_exists = False
    connect_instance_arn = 'None'
    try:
        list_connect_instances = connect_client.list_instances(
            MaxResults=10
        )

        for instance in list_connect_instances['InstanceSummaryList']:
            if account_name.lower() == instance['InstanceAlias']:
                util.logger("EXISTING CONNECT INSTANCE: " + account_name)
                connect_instance_exists = True
                connect_instance_arn = instance['Arn']

        if not connect_instance_exists:
            create_connect_response = connect_client.create_instance(
                #ClientToken='string',
                IdentityManagementType=instance_type,
                InstanceAlias=account_name,
                #DirectoryId='string',
                InboundCallsEnabled=True,
                OutboundCallsEnabled=True,
            )
            connect_instance_arn = create_connect_response['Arn']
            wait_counter = 0

            while(wait_counter <= 10):
                describe_instance_response = connect_client.describe_instance(
                    InstanceId=create_connect_response['Id']
                )
                if describe_instance_response['Instance']['InstanceStatus'] == 'ACTIVE':
                    util.logger('AMAZON CONNECT INSTANCE CREATION COMPLETED: ' + connect_instance_arn)
                    break
                elif describe_instance_response['Instance']['InstanceStatus'] == 'CREATION_FAILED':
                    util.logger('AMAZON CONNECT INSTANCE CREATION FAILED')
                    sys.exit(1) 
                else:
                    util.logger('AMAZON CONNECT INSTANCE CREATION IN PROGRESS')
                    wait_counter += 1
                    sleep(30)
            else:
                util.logger("UNABLE TO CREATE AMAZON CONNECT INSTANCE.  PLEASE TRY AGAIN.")
                sys.exit(1)

    except Exception as Ex1:
        util.logger("create_connect_instance EXCEPTION: " + str(Ex1))
        sys.exit(1)

    return(connect_instance_arn)

def associate_s3_bucket(role_credentials, instance_id, bucket_prefix, bucket_suffix, tenant_kms_key):
    bucket_name = bucket_prefix + bucket_suffix
    util.logger("ASSOCIATING S3 BUCKET TO AMAZON CONNECT INSTANCE: " + bucket_name)
    connect_client = boto3.client('connect', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    if 'recordings' in bucket_name:
        resource_type = 'CALL_RECORDINGS'
    else:
        resource_type = 'SCHEDULED_REPORTS'

    try:
        connect_client.associate_instance_storage_config(
            InstanceId=instance_id,
            ResourceType=resource_type,
            StorageConfig={
                'StorageType': 'S3',
                'S3Config': {
                    'BucketName': bucket_name,
                    'BucketPrefix': 'connect/' + bucket_prefix,
                    'EncryptionConfig': {
                        'EncryptionType': 'KMS',
                        'KeyId': tenant_kms_key
                    }
                }
            }
        )

    except Exception as Ex1:
        util.logger("associate_s3_bucket EXCEPTION: " + str(Ex1))

def associate_kinesis_video(role_credentials, instance_id, tenant_kms_key):
    util.logger("ASSOCIATING KINESIS VIDEO STREAM TO AMAZON CONNECT INSTANCE")
    connect_client = boto3.client('connect', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    try:
        connect_client.associate_instance_storage_config(
            InstanceId=instance_id,
            ResourceType='MEDIA_STREAMS',
            StorageConfig={
                'StorageType': 'KINESIS_VIDEO_STREAM',
                'KinesisVideoStreamConfig': {
                    'Prefix': 'ivr-recording',
                    'RetentionPeriodHours': 96,
                    'EncryptionConfig': {
                        'EncryptionType': 'KMS',
                        'KeyId': tenant_kms_key
                    }
                }
            }
        )
    except Exception as Ex1:
        util.logger("associate_kinesis_video EXCEPTION: " + str(Ex1))

def create_policy(role_credentials, policy_name, policy_doc):
    util.logger('CREATING IAM POLICY: ' + policy_name)
    iam_client = boto3.client('iam',
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])
    
    try:
        found_policy = False
        list_policies_response = iam_client.list_policies()

        list_policies = list_policies_response['Policies']
        
        while "Marker" in list_policies_response:
            list_policies_response = iam_client.list_policies(
                Marker=list_policies_response['Marker'],
            )
            
            list_policies.extend(list_policies_response['Policies'])

        for policy in list_policies:
            if policy_name in policy['PolicyName']:
                found_policy = True

        if not found_policy:        
            iam_client.create_policy(
                PolicyName=policy_name,
                Path='/',
                PolicyDocument=policy_doc,
                Description=policy_name,
            )
        else:
            util.logger("IAM POLICY ALREADY EXISTS " + policy_name)

    except Exception as Ex1:
        util.logger("create_policy EXCEPTION: " + str(Ex1))

def create_lambda_function(role_credentials, function_name, bucket_name):
    s3_client = boto3.client('s3')
    iam_client = boto3.client('iam',
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])
    lambda_client = boto3.client('lambda', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    function_arn = 'None'
    (role_arn, function_arn) = check_function_exists(lambda_client, function_name) 

    if not role_arn:
        try:
            role_name = function_name + '-role-' + util.create_random_suffix(8)
            role_arn = create_role(iam_client, role_name, 'IAM Role for ' + function_name)
            util.logger('CREATING LAMBDA FUNCTION ROLE: ' + role_arn)

            if role_arn != 'None':
                for permission in config.lambda_functions[function_name]['permissions_to_attach']:
                    attach_permission_policy(iam_client, role_name, get_policy_arn(iam_client, permission))

                sleep(10)
                response = s3_client.get_object(Bucket=get_central_bucket(s3_client), Key='Lambda/' + function_name+'.zip')
                decoded_file = response['Body'].read()

                create_function_response = lambda_client.create_function(
                    FunctionName=function_name,
                    Runtime=config.lambda_functions[function_name]['runtime'],
                    Role=role_arn,
                    Handler=config.lambda_functions[function_name]['handler'],
                    Code={
                        'ZipFile': decoded_file,
                    },
                    Description=function_name,
                    Timeout=config.lambda_functions[function_name]['timeout'],
                    MemorySize=config.lambda_functions[function_name]['memory'],
                    Publish=True,
                    PackageType='Zip',
                    Environment=config.lambda_functions[function_name]['environment'],                    
                    Architectures=[
                        'x86_64'
                    ],
                    EphemeralStorage={
                        'Size': config.lambda_functions[function_name]['ephemeral']
                    }
                    #LoggingConfig={
                    #    'LogFormat': 'JSON',
                    #    'ApplicationLogLevel': 'INFO',
                    #    'SystemLogLevel': 'INFO',
                    #    'LogGroup': '/aws/lambda/' + function_name
                    #}
                )

                function_arn = create_function_response['FunctionArn']

        except Exception as Ex1:
            util.logger("create_lambda_function EXCEPTION: " + str(Ex1))
    else:
        util.logger("LAMBDA FUNCTION ALREADY EXISTS: " + function_name)

    return (role_arn, function_arn)

def get_central_bucket(s3_client):
    central_bucket_name = ''
    try:
        list_of_s3_buckets_response = s3_client.list_buckets()

        for bucket in list_of_s3_buckets_response['Buckets']:
            if "central" in bucket['Name']:
                central_bucket_name =  bucket['Name']
    except Exception as Ex1:
        util.logger("ERROR READING CENTRAL S3 BUCKET: " + str(Ex1))

    return(central_bucket_name)

def check_function_exists(lambda_client, function_name):
    function_role_arn = ''
    function_arn = ''

    try:

        list_of_lambdas_response = lambda_client.list_functions(
            MaxItems=100
        )

        list_lambdas = list_of_lambdas_response['Functions']
        
        while "Marker" in list_of_lambdas_response:
            list_of_lambdas_response = lambda_client.list_functions(
                Marker=list_of_lambdas_response['Marker'],
                MaxItems=100
            )
            
            list_lambdas.extend(list_of_lambdas_response['Functions'])

        for function in list_lambdas:
            if function['FunctionName'] == function_name:
                function_role_arn = function['Role']
                function_arn = function['FunctionArn']
        
        if not function_role_arn:
            util.logger("CREATING LAMBDA FUNCTION: " + function_name)
        else:
            util.logger("LAMBDA FUNCTION ROLE ALREADY EXISTS: " + function_role_arn)

    except Exception as Ex1:
        util.logger("check_function_exists EXCEPTION: " + str(Ex1))
        
    return(function_role_arn, function_arn)

def create_role(iam_client, role_name, description):
    util.logger('CREATING IAM ROLE: ' + role_name)
    try:
        found_role = False
        list_roles_response = iam_client.list_roles()

        list_roles = list_roles_response['Roles']
        
        while "Marker" in list_roles_response:
            list_roles_response = iam_client.list_roles(
                Marker=list_roles_response['Marker'],
            )
            
            list_roles.extend(list_roles_response['Roles'])

        for role in list_roles:
            if role_name in role['RoleName']:
                found_role = True
                result = role['Arn']

        if not found_role:
            create_iam_role_response = iam_client.create_role(
                Path='/',
                RoleName=role_name,
                AssumeRolePolicyDocument=config.assume_role_policy,
                Description=description,
            )
            result = create_iam_role_response['Role']['Arn'] 
        else:
            util.logger("IAM ROLE ALREADY EXISTS " + result)

    except Exception as Ex1:
        result = 'None'
        util.logger("create_role EXCEPTION: " + str(Ex1))

    return(result)

def attach_permission_policy(iam_client, role_name, policy_arn):
    util.logger('ATTACHING IAM POLICY ARN: ' + policy_arn + ' TO ROLE: ' + role_name)
    try:
        iam_client.attach_role_policy(
            RoleName=role_name,
            PolicyArn=policy_arn
        )
    except Exception as Ex1:
        util.logger("attach_permission_policy EXCEPTION: " + str(Ex1))

def get_policy_arn(iam_client, iam_policy_name):
    util.logger('GETTING IAM POLICY ARN: ' + iam_policy_name)
    iam_policy_arn = 'None'
    list_permission_policies = []
    list_permission_arns = []
    list_permission_names = []
    permissions_name_to_arn = {}

    try:
        list_of_permissions_response = iam_client.list_policies(
            Scope='All',
            OnlyAttached=False,
            PathPrefix='/',
            PolicyUsageFilter='PermissionsPolicy',
            MaxItems=100
        )

        list_permission_policies = list_of_permissions_response['Policies']
        
        while "Marker" in list_of_permissions_response:
            list_of_permissions_response = iam_client.list_policies(
                Scope='All',
                OnlyAttached=False,
                PathPrefix='/',
                PolicyUsageFilter='PermissionsPolicy',
                Marker=list_of_permissions_response['Marker'],
                MaxItems=100
            )
            
            list_permission_policies.extend(list_of_permissions_response['Policies'])

        for permission_policy in list_permission_policies:
            list_permission_arns.append(permission_policy['Arn'])
            list_permission_names.append(permission_policy['PolicyName'])

        for i in range(len(list_permission_names)):
            permissions_name_to_arn[list_permission_names[i]] = list_permission_arns[i]

        iam_policy_arn = permissions_name_to_arn[iam_policy_name]
    except Exception as Ex1:
        util.logger("get_policy_arn EXCEPTION: " + str(Ex1))
        
    return(iam_policy_arn)

def create_contact_flows(role_credentials, account_id, instance_id):
    util.logger("UPLOADING IGNITE-RDF BASE CONTACT FLOWS TO AMAZON CONNECT INSTANCE: " + instance_id)
    connect_client = boto3.client('connect', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    try:
        list_contact_flows_response = connect_client.list_contact_flows(
            InstanceId=instance_id,
        )
        installed_contact_flow_list = list_contact_flows_response['ContactFlowSummaryList']

        while 'NextToken' in list_contact_flows_response:
            list_contact_flows_response = connect_client.list_contact_flows(
                InstanceId=instance_id,
                NextToken=list_contact_flows_response['NextToken']
            )

            installed_contact_flow_list.extend(list_contact_flows_response['ContactFlowSummaryList'])

        print(installed_contact_flow_list)
    except Exception as Ex1:
        util.logger("ERROR LISTING CONTACT FLOWS: " + str(Ex1))

    installed_contact_flow_list_names = {}
    for installed_flow in installed_contact_flow_list:
        installed_contact_flow_list_names[installed_flow['Name']] = installed_flow['Id']

    beep_prompt_arn = get_beep_prompt_arn(connect_client, instance_id)

    for contact_flow in config.contact_flows:
        contact_flow_name = contact_flow[contact_flow.find('/')+1:]
        
        try:
            contact_flow_file = get_contact_flow(account_id, contact_flow)
            contact_flow_file = contact_flow_file.replace('<REGION>', config.region)
            contact_flow_file = contact_flow_file.replace('<ACCOUNT_ID>', account_id)
            contact_flow_file = contact_flow_file.replace('<RDF_ACCOUNT>', config.AWS_ACCOUNT_ID)
            contact_flow_file = contact_flow_file.replace('<BEEP_PROMPT>', beep_prompt_arn)
            if contact_flow_name in installed_contact_flow_list_names:
                util.logger("UPDATING EXISTING CONTACT FLOW: " + contact_flow_name + " WITH TYPE: " + config.contact_flows[contact_flow])
                connect_client.update_contact_flow_content(
                    InstanceId=instance_id,
                    ContactFlowId=installed_contact_flow_list_names[contact_flow_name],
                    Content=contact_flow_file
                )                    
            else:
                util.logger("INSTALLING NEW CONTACT FLOW: " + contact_flow_name + " AS TYPE: " + config.contact_flows[contact_flow])
                connect_client.create_contact_flow(
                    InstanceId=instance_id,
                    Name=contact_flow_name,
                    Type=config.contact_flows[contact_flow],
                    Description='USED BY IGNITE-RDF',
                    Content=contact_flow_file,
                )            

        except Exception as Ex1:
            util.logger("ERROR CREATING CONTACT FLOWS: " + str(Ex1))
            pass

def get_contact_flow(account_id, contact_flow):
    s3_client = boto3.client('s3')

    try:
        s3_response = s3_client.get_object(Bucket=get_central_bucket(s3_client), Key=contact_flow)
        decoded_file = s3_response['Body'].read().decode('utf-8')
        #decoded_file = s3_response['Body'].read()

        if contact_flow == 'Connect-RDF-Agent' or contact_flow == 'Connect-RDF-Main':
            decoded_file = decoded_file.replace('<ACCOUNT_ID', account_id)

    except Exception as Ex1:
        util.logger("ERROR DOWNLOADING CONTACT FLOW FROM S3: " + str(Ex1)) 

    return(decoded_file)

def upload_rdf_application_files(role_credentials, tenant_bucket_name):
    util.logger("UPLOADING IGNITE-RDF APPLICATION FILES TO AMAZON CONNECT S3 BUCKET")
    s3_central_client = boto3.client('s3')
    s3_tenant_client = boto3.resource('s3', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])
            
    try:
        rdf_file_list = []
        list_s3_buckets_response = s3_central_client.list_objects(
            Bucket=get_central_bucket(s3_central_client),
            Prefix='IVR/'
        )

        if "Contents" in list_s3_buckets_response:
            rdf_file_list = list_s3_buckets_response['Contents']

            while list_s3_buckets_response['IsTruncated']:
                list_s3_buckets_response = s3_central_client.list_objects(
                    Marker=list_s3_buckets_response['NextMarker'],
                    MaxItems=100
                )
                
                rdf_file_list.extend(list_s3_buckets_response['Contents'])

        for rdf_file in rdf_file_list:
            s3_get_file_response = s3_central_client.get_object(Bucket=get_central_bucket(s3_central_client), Key=rdf_file['Key'])
            #decoded_file = s3_get_file_response['Body'].read().decode('utf-8')
            upload_file = s3_get_file_response['Body'].read()
            util.logger("UPLOADING FILE: " + rdf_file['Key'][rdf_file['Key'].find('/')+1:])
            s3_tenant_client.Object(tenant_bucket_name, rdf_file['Key'][rdf_file['Key'].find('/')+1:]).put(Body=upload_file)            

    except Exception as Ex1:
        util.logger("upload_rdf_application_files EXCEPTION: " + str(Ex1))      

def associate_lambda_function(role_credentials, instance_id, function_arn):
    util.logger('ASSOCIATING FUNCTION: ' + function_arn + ' TO AMAZON CONNECT INSTANCE FOR VOICEMAIL')
    connect_client = boto3.client('connect', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])
    
    try:
        connect_client.associate_lambda_function(
            InstanceId=instance_id,
            FunctionArn=function_arn
        )

    except Exception as Ex1:
        util.logger("associate_lambda_function EXCEPTION: " + str(Ex1))   

def add_rdf_invoke_permissions(account_id, account_name, instance_arn, ou):
    util.logger('ADDING INVOKE PERMISSIONS FOR CONNECT INSTANCE: ' + instance_arn + ' TO IGNITE-RDF')
    lambda_client = boto3.client('lambda')

    try:
        lambda_client.add_permission(
            FunctionName='Ignite-RDF',
            StatementId=account_name,
            Action='lambda:InvokeFunction',
            Principal='connect.amazonaws.com',
            SourceArn=instance_arn,
            Qualifier=ou.lower(),
            #SourceAccount=account_id,
            #EventSourceToken='string',
            #RevisionId='string',
            #PrincipalOrgID='connect.amazonaws.com',
            #FunctionUrlAuthType='NONE'|'AWS_IAM'
        )
    
    except Exception as Ex1:
        util.logger("ERROR WHEN ADDING INVOKE PERMISSIONS TO IGNITE-RDF: " + str(Ex1)) 

def get_beep_prompt_arn(connect_client, instance_id):
    beep_prompt_arn = 'None'
    try:
        list_prompts_response = connect_client.list_prompts(
            InstanceId=instance_id,
        )

        list_prompts = list_prompts_response['PromptSummaryList']

        while 'NextToken' in list_prompts_response:
            list_prompts_response = connect_client.list_prompts(
                InstanceId=instance_id,
                NextToken=list_prompts_response['NextToken'],
            )

            list_prompts.extend(list_prompts_response['PromptSummaryList'])
        
        for prompt in list_prompts:
            if prompt['Name'] == 'Beep.wav':
                 beep_prompt_arn = prompt['Arn']

    except Exception as Ex1:
        util.logger("get_beep_prompt_arn EXCEPTION: " + str(Ex1)) 
    
    return beep_prompt_arn

def add_S3_trigger(role_credentials,function_name, bucket_name, account_id, function_arn):
    util.logger('ADDING S3 TRIGGER FOR: ' + function_name)
    lambda_client = boto3.client('lambda', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    s3_client = boto3.client('s3', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])
    
    try:
        lambda_client.add_permission(
            FunctionName=function_name,
            StatementId='lambda-' + util.create_random_suffix(12),
            Action='lambda:InvokeFunction',
            Principal='s3.amazonaws.com',
            SourceArn='arn:aws:s3:::'+ bucket_name,
            SourceAccount=account_id
        )

        sleep(10)
        s3_client.put_bucket_notification_configuration(
            Bucket=bucket_name,
            NotificationConfiguration={
                'LambdaFunctionConfigurations': [
                    {
                        'LambdaFunctionArn': function_arn,
                        'Events': [
                            's3:ObjectCreated:*'
                        ],
                        'Filter': {
                            'Key': {
                                'FilterRules': [
                                    {
                                        'Name': 'prefix',
                                        'Value': 'audio/'
                                    },
                                    {
                                        'Name': 'suffix',
                                        'Value': '.wav'
                                    },
                                ]
                            }
                        }
                    },
                ]
            }
        )       
    except Exception as Ex1:
        util.logger("add_S3_trigger EXCEPTION: " + str(Ex1))

def add_event_bridge_rule(role_credentials, function_arn):
    util.logger('ADDING EVENTBRIDGE RULE FOR VOICEMAIL ')
    eb_client = boto3.client('events', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    lambda_client = boto3.client('lambda', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])
        
    found_rule = False
    event_rule_arn = 'None'   
    try:
        list_rules_response = eb_client.list_rules()
        list_rules = list_rules_response['Rules']

        while 'NextToken' in list_rules_response:
            list_rules_response = eb_client.list_prompts(
                NextToken=list_rules_response['NextToken'],
            )

            list_rules.extend(list_rules_response['Rules'])
        
        for rule in list_rules:
            if rule['Name'] == 'VoiceMail':
                 found_rule = True
                 event_rule_arn = rule['Arn']

        if not found_rule:
            put_rule_response = eb_client.put_rule(
                Name='VoiceMail',
                EventPattern=config.connect_event_rule,
                State='ENABLED',
                Description='Checks to see if a voice mail was created for a contact',
                #RoleArn='string',
            )
            event_rule_arn = put_rule_response['RuleArn']

            eb_client.put_targets(
                Rule='VoiceMail',
                Targets=[
                    {
                        'Id': 'ConnectKVS2Audio',
                        'Arn': function_arn
                    }
                ]
            )

            lambda_client.add_permission(
                FunctionName='ConnectKVS2Audio',
                StatementId='AWSEvents_VoiceMail_' + util.create_random_suffix(12),
                Action='lambda:InvokeFunction',
                Principal='events.amazonaws.com',
                SourceArn=event_rule_arn
            )

        else:
            util.logger("VOICEMAIL EVENTBRIDGE RULE ALREADY EXISTS")                        

    except Exception as Ex1:
        util.logger("add_event_bridge_rule EXCEPTION: " + str(Ex1)) 
    
    return event_rule_arn                

def insert_instance_record(ou, tenant_id, instance_type, email_domain):
    organization_name =  os.environ['ORGANIZATION_NAME']
    tenant_name = ou.lower() + organization_name + '-' + tenant_id
    util.logger("INSERTING NEW INSTANCE RECORD IN: " + ou + " FOR TENANT: " + tenant_name)

    try:
        table = boto3.resource('dynamodb').Table('Instances-' + ou)

        table.put_item(Item= {'Tenant': tenant_name,
            'EmailDomain': email_domain,
            'InstanceType': instance_type})

    except Exception as Ex1:
        util.logger("insert_instance_record EXCEPTION: " + str(Ex1))

def update_instance_record(tenant_name, account_id, instance_arn, ou):
    util.logger("UPDATING INSTANCE RECORD IN: " + ou + " FOR TENANT: " + tenant_name + " WITH ACCOUNT ID: " + account_id + " AND AMAZON CONNECT INSTANCE ARN: " + instance_arn)
    try:
        table = boto3.resource('dynamodb').Table('Instances-' + ou)

        table.update_item(
                Key = {
                    'Tenant': tenant_name
                },
                UpdateExpression='SET #attr1 = :val1, #attr2 = :val2',
                ExpressionAttributeNames={'#attr1': 'AccountID', '#attr2': 'InstanceARN'},
                ExpressionAttributeValues={':val1': account_id, ':val2': instance_arn}
            )

    except Exception as Ex1:
        util.logger("update_instance_record EXCEPTION: " + str(Ex1)) 