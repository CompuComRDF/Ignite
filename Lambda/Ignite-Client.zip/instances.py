import json
import boto3
import os
import util
import config
from time import sleep
import sys

def createTenantInstance(event):
    organization_name =  os.environ['ORGANIZATION_NAME']
    principal_arn = os.environ['PRINCIPAL_ARN']  
    tenantID = event['TenantID'] 
    email_domain = event['EmailDomain']
    instanceType = event['InstanceType'] #'SAML'|'CONNECT_MANAGED'|'EXISTING_DIRECTORY'

    #tenantName = event['TenantName'] 
    #greeting = event['Greeting']
    #language = event['Language']
    #relatedQueues = event['Queues']
    #queuesCreated = []
    #quickConnectIds=[]
        
    organizational_units = ['DEV', 'UAT', 'PROD']

    for ou in organizational_units:
        account_name = ou.lower() + organization_name + '-' + tenantID
        if not check_instance_exists(account_name):
            if '@' not in email_domain:
                account_email = account_name + "-" + "@" + email_domain
            else:
                account_email = email_domain
                
            util.logger('USING ACCOUNT EMAIL ADDRESS: ' + account_email)

            account_id = create_account(account_name, account_email, ou, principal_arn)

            if account_id != 'None':
                role_credentials = util.assume_role(account_id)
                create_db_table(role_credentials, "Tenants")
                create_db_table(role_credentials, "Users")
                create_db_table(role_credentials, "ivr-recording-contactTranscriptSegments")
                create_db_table(role_credentials, "ivr-recording-contactTranscriptSegmentsToCustomer")

                create_xaccount_role(role_credentials)
                tenant_kms_key = create_tenant_kms_key(role_credentials, account_name)

                create_s3_bucket(account_name + '-callrecordings', tenant_kms_key) #Caller Recordings
                create_s3_bucket(account_name + '-reports', tenant_kms_key) #Caller Reports

                instance_arn = create_connect_instance(role_credentials, account_name, instanceType)

                if instance_arn != 'None':
                    instance_id = instance_arn.split(":")[5][(instance_arn.split(":")[5].find('/')+1):]

                    associate_s3_bucket(role_credentials, instance_id, account_name + '-callrecordings', tenant_kms_key) #Caller Recordings
                    associate_s3_bucket(role_credentials, instance_id, account_name + '-reports', tenant_kms_key) #Caller Reports

                    rdf_kms_key = create_rdf_kms_key(role_credentials, "Cross Account KMS Key", account_id)
                    create_s3_bucket('amazon-connect-' + instance_id, rdf_kms_key) #RDF Application
                    
                    create_lambda_function(role_credentials, 'kvs_Converter', 'amazon-connect-' + instance_id)
                    create_lambda_function(role_credentials, 'ConnectKVS2Audio', 'amazon-connect-' + instance_id)

                    create_contact_flows(role_credentials, account_id, instance_arn)

                    #ADD INVOKE PERMISSIONS FOR NEW TENANT TO IGNITE-RDF
                    add_rdf_invoke_permissions(account_id, account_name, instance_arn)

                    #create_kinesis_stream()

            #INSERT THESE VALUES INTO TENANTS TABLE
            #tenantID = newImage['tenantID']['S']
            #tenantName = newImage['tenantName']['S']
            #greeting = json.loads(newImage['greeting']['S'])
            #language = newImage['language']['S']
            #relatedQueues = json.loads(newImage['quickConnects']['S'])
            #queuesCreated = []
            #quickConnectIds=[]

def check_instance_exists(tenant_name):
    dynamodb_client = boto3.client('dynamodb')
    instanceExists = False

    #response = dynamodb_client.query(
    #    TableName='Instances-DEV',
    #    KeyConditionExpression='Tenant = :tenant_name',
    #    ExpressionAttributeValues={
    #        ':tenant_name': {'S': tenant_name}
    #    }
    #)

    #try:
    #    print("INSTANCE ALREADY EXISTS: " + str(response['Items']))
    #    instanceExists = True
    #except:
    #    pass

    try:
        get_item_response = dynamodb_client.get_item(TableName='Instances-DEV', Key={"Tenant": {"S":tenant_name}})
        print("INSTANCE ALREADY EXISTS: " + str(get_item_response['Items']))
        instanceExists = True
    except Exception as Ex1:
        #util.logger("check_instance_exists EXCEPTION: " + str(Ex1))
        pass

    return(instanceExists)
    
def create_account(account_name, account_email, ou, principal_arn):
    #INVOKE Ignite-Factory lambda function to provision Tenant account
    util.logger('INVOKING IGNITE FACTORY TO CREATE ACCOUNT: ' + account_name)
    account_id = 'None'
    factory_account_id = principal_arn.split(':')[4]
    factory_role = principal_arn.split(':')[5]
    #sts_client = boto3.client('sts')
    #sts_session = sts_client.assume_role(RoleArn='arn:aws:iam::' + factory_account_id + ':role/Test39-role',
    #                                RoleSessionName='create-instance-session')

    principal_arn = os.environ['PRINCIPAL_ARN']
    
    lambda_client = boto3.client('lambda', region_name=config.region,
        aws_access_key_id=os.environ['ACCESS_KEY_ID'],
        aws_secret_access_key=os.environ['SECRET_ACCESS_KEY']
    )

    payload = {
        "AccountName":account_name,
        "AccountEmail":account_email,
        "OrganizationUnitName":ou,
        "PrincipalARN":principal_arn
        }

    lambda_client.invoke(
        FunctionName='Ignite-Factory',
        InvocationType='Event',
        LogType='Tail',
        Payload= bytes(json.dumps(payload), encoding='utf8'),
    )
    wait_counter = 0
    while(wait_counter < 3):
        util.logger('ACCOUNT CREATION UNDER CHANGE: Iteration ' + str(wait_counter))
        account_id = get_account_id(account_name)
        if account_id == 'None':
            sleep(30)
            wait_counter += 1
        else:
            break

    if account_id != "None":
        util.logger('ACCOUNT CREATION COMPLETED: ' + account_id)
    else:
        util.logger('UNABLE TO CREATE ACCOUNT: ' + account_name)        

    return(account_id)

def get_account_id(account_name):
    org_client = boto3.client('organizations',
        aws_access_key_id=os.environ['ACCESS_KEY_ID'],
        aws_secret_access_key=os.environ['SECRET_ACCESS_KEY']
    )

    account_id = "None"
    list_accounts = []
    list_account_ids = []
    list_account_names = []
    account_name_to_id = {}

    try:
        list_of_accounts_response = org_client.list_accounts()
        list_accounts = list_of_accounts_response['Accounts']

        while "NextToken" in list_of_accounts_response:
            list_of_accounts_response = org_client.list_accounts(
                    NextToken=list_of_accounts_response['NextToken']
            )
            list_accounts.extend(list_of_accounts_response['Accounts'])

        for account in list_accounts:
            list_account_ids.append(account['Id'])
            list_account_names.append(account['Name'])

        for i in range(len(list_account_names)):
            account_name_to_id[list_account_names[i]] = list_account_ids[i]

        if account_name in list_account_names:
            account_id = account_name_to_id[account_name]

    except Exception as Ex1:
        util.logger("get_account_id EXCEPTION: " + str(Ex1))

    return account_id

def assume_role(account_id):
    util.logger("ASSUMING AWSControlTowerAdmin ROLE OF ACCOUNT: " + account_id)

    role_credentials = {}

    wait_counter = 0
    sts_client = boto3.client('sts')
    while(wait_counter <= 3):
        try:
            sts_session = sts_client.assume_role(RoleArn='arn:aws:iam::' + account_id + ':role/AWSControlTowerExecution',
                                            RoleSessionName='initialization-session')
            
            role_credentials['KEY_ID'] = sts_session['Credentials']['AccessKeyId']
            role_credentials['ACCESS_KEY'] = sts_session['Credentials']['SecretAccessKey']
            role_credentials['TOKEN'] = sts_session['Credentials']['SessionToken']
            util.logger("ASSUMED ROLE AWSControlTowerAdmin SUCCESSFULLY: {}" + format(config.KEY_ID))
            break
        except Exception as Ex1:
            util.logger('WAITING FOR ACCOUNT SERVICES TO BE READY')
            wait_counter += 1
            sleep(30)
            pass
    else:
        util.logger("UNABLE TO ASSUME ROLE AWSControlTowerAdmin.  PLEASE TRY AGAIN.")
    
    return(role_credentials)

def create_xaccount_role(role_credentials):
    util.logger("CREATING xaccount-rdf-role")
    iam_client = boto3.client('iam', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    config.assume_role_policy_document.replace('<ACCOUNT_ID>', config.AWS_ACCOUNT_ID)
                
    iam_client.create_role(
        Path='/',
        RoleName='xaccount-rdf-role',
        AssumeRolePolicyDocument=config.assume_role_policy_document,
        Description='Cross Account Role used by Ignite-RDF',
        MaxSessionDuration=3600,
        #PermissionsBoundary='string',
    )

    list_policies_response = iam_client.list_policies(
        Scope='AWS',
        OnlyAttached=False,
        PathPrefix='/',
        PolicyUsageFilter='PermissionsPolicy',
        #Marker='string',
        MaxItems=100
    )

    list_policies =  list_policies_response['Policies']

    while 'Marker' in list_policies_response:
        list_policies_response = iam_client.list_policies(
            Scope='AWS',
            OnlyAttached=False,
            PathPrefix='/',
            PolicyUsageFilter='PermissionsPolicy',
            Marker=list_policies_response['Marker'],
            MaxItems=100
        )
    
    list_policies.extend(list_policies_response['Policies'])

    for policy in list_policies:
        if policy['PolicyName'] == 'AmazonConnect_FullAccess' or policy['PolicyName'] == 'AmazonDynamoDBFullAccess':
            iam_client.attach_role_policy(
                RoleName='xaccount-rdf-role',
                PolicyArn=policy['Arn']
            )

def create_tenant_kms_key(role_credentials, alias):
    util.logger("CREATING KMS KEY: " + alias)
    kms_client = boto3.client('kms', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    kms_response = kms_client.create_key(
        Description='KMS KEY for ' + alias,
        KeyUsage='ENCRYPT_DECRYPT',
        KeySpec='SYMMETRIC_DEFAULT',
        Origin='AWS_KMS',
        MultiRegion=False,
    )

    kms_client.create_alias(
        AliasName='alias/' + alias,
        TargetKeyId=kms_response['KeyMetadata']['KeyId']
    )

    util.logger("CREATED KMS KEY: " + kms_response['KeyMetadata']['Arn'])

    return(kms_response['KeyMetadata']['Arn'])

def create_rdf_kms_key(role_credentials, alias, account_id):
    util.logger("CREATING KMS KEY: " + alias)
    kms_client = boto3.client('kms', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    kms_key_policy = config.kms_key_policy.replace('<TENANT_ACCOUNT>', account_id)
    kms_key_policy = kms_key_policy.replace('<CENTRAL_ACCOUNT>', config.AWS_ACCOUNT_ID)

    kms_response = kms_client.create_key(
        Policy=kms_key_policy,
        Description='KMS KEY for ' + alias,
        KeyUsage='ENCRYPT_DECRYPT',
        KeySpec='SYMMETRIC_DEFAULT',
        Origin='AWS_KMS',
        MultiRegion=False,
    )

    kms_client.create_alias(
        AliasName='alias/' + alias,
        TargetKeyId=kms_response['KeyMetadata']['KeyId']
    )

    util.logger("CREATED KMS KEY " + kms_response['KeyMetadata']['Arn'])

    return(kms_response['KeyMetadata']['Arn'])

def create_s3_bucket(role_credentials, bucket_name, kms_key_id):
    util.logger("CREATING S3 BUCKET: " + bucket_name)
    s3_client = boto3.client('s3', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    bucket_exists = False

    list_of_s3_buckets_response = s3_client.list_buckets()

    for bucket in list_of_s3_buckets_response['Buckets']:
        if bucket_name in bucket['Name']:
            util.logger("EXISTING S3 BUCKET: " + bucket['Name'])
            bucket_exists = True
            bucket_name =  bucket['Name']
            
    if not bucket_exists:
        util.logger("CREATING S3 BUCKET: " + bucket_name)

        try:
            s3_client.create_bucket(
                Bucket=bucket_name,
                CreateBucketConfiguration={
                    'LocationConstraint': config.region 
                }
            )        

            s3_client.put_bucket_encryption(
                Bucket=bucket_name,
                ServerSideEncryptionConfiguration={
                    'Rules': [
                        {
                            'ApplyServerSideEncryptionByDefault': {
                                'SSEAlgorithm': 'aws:kms',
                                'KMSMasterKeyID': kms_key_id
                            },
                            'BucketKeyEnabled': True
                        },
                    ]
                },
                #ExpectedBucketOwner='string'
            )

            if 'amazon-connect' in bucket_name:
                s3_bucket_policy = config.s3_main_bucket_policy.replace('<AWS_ACCOUNT_ID>',config.AWS_ACCOUNT_ID)
                s3_bucket_policy = s3_bucket_policy.replace('<S3BUCKETNAME>',bucket_name)
                util.logger("Updating S3 Bucket Resource Policy: ")

                s3_client.put_bucket_policy(
                    Bucket=bucket_name,
                    Policy=s3_bucket_policy
                )
            
        except Exception as Ex1:
            util.logger("get_s3_bucket EXCEPTION: " + str(Ex1))
        
    return(bucket_name)

def create_db_table(role_credentials, table_name):

    wait_counter = 0
    while(wait_counter <= 3):
        try:
            db_client = boto3.client('dynamodb', region_name=config.region,
                aws_access_key_id=role_credentials['KEY_ID'],
                aws_secret_access_key=role_credentials['ACCESS_KEY'],
                aws_session_token=role_credentials['TOKEN'])
            
            list_of_tables_response = db_client.list_tables(
                Limit=100
            )        
            
            util.logger("CREATING DYNAMODB TABLES")
            break
        except Exception as Ex1:
            util.logger('WAITING FOR DYNAMODB SERVICES TO BE READY')
            wait_counter += 1
            sleep(30)
            pass          
    else:
        util.logger("UNABLE TO CREATE DYNAMODB TABLES.  PLEASE TRY AGAIN.")
        sys.exit(1)

    list_table_names = []

    list_of_tables_response = db_client.list_tables(
        Limit=100
    )

    list_table_names = list_of_tables_response['TableNames']
    
    while "LastEvaluatedTableName" in list_of_tables_response:
        list_of_tables_response = db_client.client.list_tables(
            ExclusiveStartTableName=list_of_tables_response['LastEvaluatedTableName'],
            Limit=100
        )
        list_table_names.extend(list_of_tables_response['TableNames'])

    if(table_name not in list_table_names):
        util.logger("CREATING DYNAMODB TABLE: {}".format(table_name))

        db_client.create_table(
            AttributeDefinitions=config.db_tables[table_name]['attribute_definitions'],
            TableName=table_name,
            KeySchema=config.db_tables[table_name]['key_schema'],
            ProvisionedThroughput={
                'ReadCapacityUnits': 5,
                'WriteCapacityUnits': 5
            },
            SSESpecification={
                'Enabled': True,
                'SSEType': 'KMS'
                #'KMSMasterKeyId': 'string'
            },
            TableClass='STANDARD',
            DeletionProtectionEnabled=True
        )
                
    else:
        util.logger("EXISTING DYNAMODB TABLE: " + table_name)

def create_connect_instance(role_credentials, account_name, instanceType):
    util.logger("CREATING AMAZON CONNECT INSTANCE: " + account_name)

    connect_client = boto3.client('connect', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    connect_instance_arn = 'None'
    try:
        create_connect_response = connect_client.create_instance(
            #ClientToken='string',
            IdentityManagementType=instanceType,
            InstanceAlias=account_name,
            #DirectoryId='string',
            InboundCallsEnabled=True,
            OutboundCallsEnabled=True,
        )

        connect_instance_arn = create_connect_response['Arn']
    
    except Exception as Ex1:
        util.logger("FAILED TO CREATE CONNECT INSTANCE: " + str(Ex1))

    return(connect_instance_arn)

def associate_s3_bucket(role_credentials, instanceID, bucket_name, tenant_kms_key):
    util.logger("ASSOCIATING S3 BUCKET TO AMAZON CONNECT INSTANCE: " + bucket_name)

    connect_client = boto3.client('connect', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    if 'recordings' in bucket_name:
        resource_type = 'CALL_RECORDINGS'
    else:
        resource_type = 'SCHEDULED_REPORTS'

    connect_client.associate_instance_storage_config(
        InstanceId=instanceID,
        ResourceType=resource_type,
        StorageConfig={
            'StorageType': 'S3',
            'S3Config': {
                'BucketName': bucket_name,
                #'BucketPrefix': 'string',
                'EncryptionConfig': {
                    'EncryptionType': 'KMS',
                    'KeyId': tenant_kms_key
                }
            }
            #'KinesisStreamConfig': {
            #    'StreamArn': 'string'
            #},
            #'KinesisFirehoseConfig': {
            #    'FirehoseArn': 'string'
            #}
        }
    )

def create_lambda_function(role_credentials, function_name, bucket_name):
    s3_client = boto3.client('s3')
    iam_client = boto3.client('iam',
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])
    lambda_client = boto3.client('lambda', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    role_arn = check_function_exists(lambda_client, function_name)   
    if not role_arn:
        try:
            role_name = function_name + '-role-' + util.create_random_suffix(8)
            role_arn = create_role(iam_client, role_name, 'IAM Role for ' + function_name)
            util.logger('CREATING LAMBDA FUNCTION ROLE: ' + role_arn)

            if role_arn != 'None':
                for permission in config.lambda_functions[function_name]['permissions_to_attach']:
                    attach_permission_policy(iam_client, role_name, get_policy_arn(iam_client, permission))

                sleep(10)
                response = s3_client.get_object(Bucket=get_central_bucket(s3_client), Key=function_name+'.zip')
                decoded_file = response['Body'].read().decode('utf-8')

                lambda_client.create_function(
                    FunctionName=function_name,
                    Runtime=config.lambda_functions[function_name]['runtime'],
                    Role=role_arn,
                    Handler=config.lambda_functions[function_name]['handler'],
                    Code={
                        'ZipFile': decoded_file,
                    },
                    Description=function_name,
                    Timeout=config.lambda_functions[function_name]['timeout'],
                    MemorySize=256,
                    Publish=True,
                    PackageType='Zip',
                    Environment=config.lambda_functions[function_name]['environment'],                    
                    Architectures=[
                        'x86_64'
                    ],
                    EphemeralStorage={
                        'Size': 1024
                    },
                    LoggingConfig={
                        'LogFormat': 'JSON',
                        'ApplicationLogLevel': 'TRACE',
                        'SystemLogLevel': 'DEBUG',
                        'LogGroup': '/aws/lambda/' + function_name
                    }
                )

        except Exception as Ex1:
            util.logger("create_lambda_function EXCEPTION: " + str(Ex1))
    else:
        util.logger("LAMBDA FUNCTION ALREADY EXISTS: " + function_name)

    return role_arn

def get_central_bucket(s3_client):
    central_bucket_name = ''
    try:
        list_of_s3_buckets_response = s3_client.list_buckets()

        for bucket in list_of_s3_buckets_response['Buckets']:
            if "central" in bucket['Name']:
                central_bucket_name =  bucket['Name']
    except Exception as Ex1:
        util.logger("ERROR READING CENTRAL S3 BUCKET")

    return(central_bucket_name)

def check_function_exists(lambda_client, function_name):
    function_role_arn = ''
    
    list_of_lambdas_response = lambda_client.list_functions(
        MaxItems=100
    )

    list_lambdas = list_of_lambdas_response['Functions']
    
    while "Marker" in list_of_lambdas_response:
        list_of_lambdas_response = lambda_client.list_functions(
            Marker=list_of_lambdas_response['Marker'],
            MaxItems=100
        )
        
        list_lambdas.extend(list_of_lambdas_response['Functions'])

    for function in list_lambdas:
        if function['FunctionName'] == function_name:
            function_role_arn = function['Role']
    
    if not function_role_arn:
        util.logger("CREATING LAMBDA FUNCTION: " + function_name)
    else:
        util.logger("LAMBDA FUNCTION ROLE ALREADY EXISTS: " + function_role_arn)
        
    return(function_role_arn)

def create_role(iam_client, role_name, description):
    util.logger('CREATING IAM ROLE: ' + role_name)
    try:
        found_role = False
        list_roles_response = iam_client.list_roles()

        list_roles = list_roles_response['Roles']
        
        while "Marker" in list_roles_response:
            list_roles_response = iam_client.list_roles(
                Marker=list_roles_response['Marker'],
            )
            
            list_roles.extend(list_roles_response['Roles'])

        for role in list_roles:
            if role_name in role['RoleName']:
                found_role = True
                result = role['Arn']

        if not found_role:
            create_iam_role_response = iam_client.create_role(
                Path='/',
                RoleName=role_name,
                AssumeRolePolicyDocument=config.assume_role_policy,
                Description=description,
            )
            result = create_iam_role_response['Role']['Arn'] 
        else:
            util.logger("IAM ROLE ALREADY EXISTS " + result)

    except Exception as Ex1:
        result = 'None'
        util.logger("create_role EXCEPTION: " + str(Ex1))

    return(result)

def attach_permission_policy(iam_client, role_name, policy_arn):
    util.logger('ATTACHING IAM POLICY ARN: ' + policy_arn + ' TO ROLE: ' + role_name)
    try:
        iam_client.attach_role_policy(
            RoleName=role_name,
            PolicyArn=policy_arn
        )
    except Exception as Ex1:
        util.logger("attach_permission_policy EXCEPTION: " + str(Ex1))

def get_policy_arn(iam_client, iam_policy_name):
    util.logger('GETTING IAM POLICY ARN: ' + iam_policy_name)
    iam_policy_arn = 'None'
    list_permission_policies = []
    list_permission_arns = []
    list_permission_names = []
    permissions_name_to_arn = {}

    try:
        list_of_permissions_response = iam_client.list_policies(
            Scope='All',
            OnlyAttached=False,
            PathPrefix='/',
            PolicyUsageFilter='PermissionsPolicy',
            MaxItems=100
        )

        list_permission_policies = list_of_permissions_response['Policies']
        
        while "Marker" in list_of_permissions_response:
            list_of_permissions_response = iam_client.list_policies(
                Scope='All',
                OnlyAttached=False,
                PathPrefix='/',
                PolicyUsageFilter='PermissionsPolicy',
                Marker=list_of_permissions_response['Marker'],
                MaxItems=100
            )
            
            list_permission_policies.extend(list_of_permissions_response['Policies'])

        for permission_policy in list_permission_policies:
            list_permission_arns.append(permission_policy['Arn'])
            list_permission_names.append(permission_policy['PolicyName'])

        for i in range(len(list_permission_names)):
            permissions_name_to_arn[list_permission_names[i]] = list_permission_arns[i]

        iam_policy_arn = permissions_name_to_arn[iam_policy_name]
    except Exception as Ex1:
        util.logger("get_policy_arn EXCEPTION: " + str(Ex1))
        
    return(iam_policy_arn)

def create_contact_flows(role_credentials, account_id, instance_id):
    util.logger("UPLOADING IGNITE-RDF BASE CONTACT FLOWS TO AMAZON CONNECT INSTANCE: " + instance_id)
    connect_client = boto3.client('connect', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])
        
    try:
        for contact_flow in config.contact_flows:
            util.logger("UPLOADING: " + contact_flow)
            contact_flow_file = get_contact_flow(account_id, contact_flow)

            connect_client_response = connect_client.create_contact_flow(
                InstanceId=instance_id,
                Name=contact_flow,
                Type=config.contact_flows[contact_flow],
                Description='USED BY IGNITE-RDF',
                Content=contact_flow_file,
            )            

    except Exception as Ex1:
        util.logger("ERROR CREATING CONTACT FLOWS: " + str(Ex1)) 

def get_contact_flow(account_id, contact_flow):
    s3_client = boto3.client('s3')

    try:
        s3_response = s3_client.get_object(Bucket=get_central_bucket(s3_client), Key=contact_flow)
        decoded_file = s3_response['Body'].read().decode('utf-8')

        if contact_flow == 'Connect-RDF-Agent' or contact_flow == 'Connect-RDF-Main':
            decoded_file = decoded_file.replace('<ACCOUNT_ID', account_id)

    except Exception as Ex1:
        util.logger("ERROR DOWNLOADING CONTACT FLOW FROM S3: " + str(Ex1)) 

    return(decoded_file)

def add_rdf_invoke_permissions(account_id, account_name, instance_arn):
    util.logger('ADDING INVOKE PERMISSIONS FOR CONNECT INSTANCE: ' + instance_id + ' TO IGNITE-RDF')
    lambda_client = boto3.client('lambda')

    try:
        lambda_client.add_permission(
            FunctionName='Ignite-RDF',
            StatementId=account_name,
            Action='lambda:InvokeFunction',
            Principal='connect.amazonaws.com',
            SourceArn=instance_arn,
            #SourceAccount=account_id,
            #EventSourceToken='string',
            #Qualifier='string',
            #RevisionId='string',
            #PrincipalOrgID='connect.amazonaws.com',
            #FunctionUrlAuthType='NONE'|'AWS_IAM'
        )
    
    except Exception as Ex1:
        util.logger("ERROR WHEN ADDING INVOKE PERMISSIONS TO IGNITE-RDF: " + str(Ex1)) 