import json
import boto3
import os
import util
import config
from time import sleep
import sys
import datetime
import applications
import tenants
import logger
import queues
#import lexbots

def insert_instance_record(ou, tenant_id, instance_type, email_domain, active_voices):
    organization_name =  os.environ['ORGANIZATION_NAME']
    bcp_region = os.environ['BCP_REGION']
    tenant_name = ou.lower() + organization_name + '-' + tenant_id
    current_time = datetime.datetime.now(datetime.timezone.utc)

    try:
        table = boto3.resource('dynamodb', region_name=config.region).Table('Instances-' + ou)

        if not check_instance_exists(tenant_name, ou, config.region):
            logger.info("INSERTING NEW INSTANCE RECORD IN: " + ou + " FOR TENANT ACCOUNT: " + tenant_name)
            table.put_item(Item= {'Tenant': tenant_name,
                'EmailDomain': email_domain,
                'InstanceType': instance_type,
                'Region': config.region,
                'AccountID':'',
                'InstanceARN':'',
                'ActiveVoices' : json.dumps(active_voices),
                'QueueData':'{}',
                'CallFlows':'{}',
                'LastUpdated':current_time.isoformat(),
                'Status': 'IN PROGRESS'})

        if bcp_region and ou == 'PROD':
            if not check_instance_exists(tenant_name.replace('prod', 'bcp'), ou, bcp_region):
                logger.info("INSERTING NEW INSTANCE RECORD IN: BCP" + " FOR TENANT ACCOUNT: " + tenant_name)
                bcp_table = boto3.resource('dynamodb', region_name=bcp_region).Table('Instances-' + ou)

                bcp_table.put_item(Item= {'Tenant': tenant_name.replace('prod', 'bcp'),
                    'EmailDomain': email_domain,
                    'InstanceType': instance_type,
                    'Region': bcp_region,
                    'AccountID':'',
                    'InstanceARN':'',
                    'ActiveVoices' : json.dumps(active_voices),
                    'QueueData':'{}',
                    'CallFlows':'{}',
                    'LastUpdated':current_time.isoformat(),
                    'Status': 'IN PROGRESS'})

    except Exception as Ex1:
        logger.info("insert_instance_record EXCEPTION: " + str(Ex1))

def create_tenant_instance(event, ou):
    principal_arn = os.environ['PRINCIPAL_ARN']
    config.bcp_region = os.environ['BCP_REGION']
    config.bcp_data_region = os.environ['BCP_DATA_REGION']

    newImage = event['Records'][0]['dynamodb']['NewImage']
    account_name = newImage['Tenant']['S']
    email_domain = newImage['EmailDomain']['S']
    instance_type = newImage['InstanceType']['S']
    active_voices = json.loads(newImage['ActiveVoices']['S'])
    ignite_region = config.region

    secret_client = boto3.client('secretsmanager')
    get_secret_value_response = secret_client.get_secret_value(
        SecretId='ACCESS_KEY'
    )
    secret_json = json.loads(get_secret_value_response['SecretString'])
    config.ACCESS_KEY_ID = list(secret_json.keys())[0]
    config.SECRET_ACCESS_KEY = list(secret_json.values())[0]
    config.region = newImage['Region']['S']

    if newImage['Region']['S'] == config.bcp_region: #This checks to see if we're creating BCP instance
        config.bcp_install = True

    if not check_instance_exists(account_name.replace('bcp', 'prod'), 'DEV', config.region): #PROD AND BCP instances exists on the same account
        if '@' not in email_domain:
            account_email = account_name + "@" + email_domain
        else:
            account_email = email_domain

        account_id  = get_account_id(account_name.replace('bcp', 'prod')) #PROD AND BCP instances exists on the same account
        if account_id == 'None':
            retry = True
            retries = 0
            while retry and retries < 3:
                if config.bcp_install:
                    logger.info('WAITING FOR PRODUCTION ACCOUNT TO BE CREATED FOR BCP')
                    account_id  = get_account_id(account_name.replace('bcp', 'prod'))
                    sleep(30)
                else:
                    logger.info('USING ACCOUNT EMAIL ADDRESS: ' + account_email)
                    account_id = create_account(account_name, account_email, ou, principal_arn, ignite_region)

                if account_id != 'None':
                    update_instance_status(account_name, account_id, "", ou, 'IN PROGRESS', {})
                    retry = False
                else:
                    update_instance_status(account_name, account_id, "", ou, 'FAILED', {})  
                    retries += 1
                    logger.info('create_account FAILED.  Re-try Attempt: ' + str(retries))
        else:
            logger.info(account_name.replace('bcp', 'prod') + ' ALREADY EXISTS WITH ACCOUNT NUMBER: ' + account_id)

        if account_id != 'None':
            role_credentials = assume_role(account_id)
            create_db_table(role_credentials, "ivr-recording-contactTranscriptSegments")
            create_db_table(role_credentials, "ivr-recording-contactDetails")

            create_xaccount_role(role_credentials)
            tenant_kms_key = create_tenant_kms_key(role_credentials, account_name)

            create_s3_bucket(config.region, role_credentials,account_name.lower() + '-callrecordings', tenant_kms_key) #Caller Recordings
            create_s3_bucket(config.region, role_credentials, account_name.lower() + '-reports', tenant_kms_key) #Caller Reports

            instance_arn = create_connect_instance(role_credentials, account_name, instance_type)

            if instance_arn != 'None':
                instance_id = instance_arn.split(":")[5][(instance_arn.split(":")[5].find('/')+1):]

                associate_s3_bucket(role_credentials, instance_id, account_name.lower(), '-callrecordings', tenant_kms_key) #Caller Recordings
                associate_s3_bucket(role_credentials, instance_id, account_name.lower(), '-reports', tenant_kms_key) #Caller Reports
                associate_kinesis_video(role_credentials, instance_id)

                kvs_converter_exec_role = config.lambda_exec_policy.replace('<AWS_REGION>', config.region).replace('<AWS_ACCOUNT_ID>', account_id).replace('<FUNCTION_NAME>', 'kvs_Converter')
                create_policy(role_credentials, 'AWSLambdaBasicExecutionRole-' + 'kvs_Converter', kvs_converter_exec_role)
                config.lambda_functions['kvs_Converter']['environment']['Variables']['APP_REGION'] = config.region
                config.lambda_functions['kvs_Converter']['environment']['Variables']['TRANSCRIBE_REGION'] = config.region
                config.lambda_functions['kvs_Converter']['environment']['Variables']['RECORDINGS_BUCKET_NAME'] = 'amazon-connect-' + instance_id                    
                (kvs_role_arn, kvs_function_arn) = create_lambda_function(role_credentials, 'kvs_Converter', 'amazon-connect-' + instance_id)

                ckvs2_converter_exec_role = config.lambda_exec_policy.replace('<AWS_REGION>', config.region).replace('<AWS_ACCOUNT_ID>', account_id).replace('<FUNCTION_NAME>', 'ConnectKVS2Audio')
                create_policy(role_credentials, 'AWSLambdaBasicExecutionRole-' + 'ConnectKVS2Audio', ckvs2_converter_exec_role)                     
                (ckvs_role_arn, ckvs_function_arn) = create_lambda_function(role_credentials, 'ConnectKVS2Audio', 'amazon-connect-' + instance_id)

                rdf_kms_key = create_rdf_kms_key(role_credentials, "xaccount-s3-rdf-kms", account_id, kvs_role_arn, ckvs_role_arn)
                create_s3_bucket(config.region, role_credentials, 'amazon-connect-' + instance_id, rdf_kms_key) #RDF Application

                logger.info("Updating S3 Bucket Resource Policy: ")
                s3_bucket_policy = config.s3_main_bucket_policy.replace('<RDF_ROLE>', get_rdf_role())
                s3_bucket_policy = s3_bucket_policy.replace('<S3BUCKETNAME>', 'amazon-connect-' + instance_id)
                s3_bucket_policy = s3_bucket_policy.replace('<TENANT_ACCOUNT>', account_id)
                s3_bucket_policy = s3_bucket_policy.replace('<INSTANCE_ARN>', instance_arn)
                
                s3_client = boto3.client('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])

                s3_resource = boto3.resource('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                                
                s3_client.put_bucket_policy(
                    Bucket='amazon-connect-' + instance_id,
                    Policy=s3_bucket_policy
                )

                s3_central_client = boto3.client('s3')
                central_bucket_name = get_central_bucket(s3_central_client)

                lex_client = boto3.client('lexv2-models', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                                
                #files_to_upload = applications.get_file_list(s3_central_client, central_bucket_name, 'IVR')
                #applications.deploy_files(s3_central_client, s3_resource, central_bucket_name, f"amazon-connect-{instance_id}", files_to_upload, 'default')
                
                files_to_upload = applications.get_file_list(s3_central_client, central_bucket_name, 'shared')
                applications.deploy_files(s3_central_client, s3_resource, central_bucket_name, f"amazon-connect-{instance_id}", files_to_upload, 'shared')

                #applications.upload_rdf_application_files(role_credentials, 'amazon-connect-' + instance_id, "", "default", [])

                add_S3_trigger(role_credentials, 'ConnectKVS2Audio', 'amazon-connect-' + instance_id, account_id, ckvs_function_arn)
                add_event_bridge_rule(role_credentials, ckvs_function_arn)

                save_contact_flows = create_contact_flows(role_credentials, account_id, instance_arn, ou, config.contact_flows)
                #lex_bots = lexbots.get_lex_bots(lex_client)

                associate_lambda_function(role_credentials, instance_id, ckvs_function_arn)

                add_rdf_invoke_permissions(account_id, account_name, instance_arn, ou)

                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])

                tenant_id = account_name[account_name.find('-') + 1:]
                tenants.set_voices(connect_client, instance_arn[instance_arn.find('/')+1:], ou, tenant_id, active_voices)
                #prompts = tenants.read_tts(s3_client, tenant_id, 'Default', config.default_prompts)

                #new_prompts = {}

                #for prompt in prompts:
                #    new_prompts[prompt] = {}
                #    for language_index in active_voices:
                #        if active_voices[language_index]['Language'] == 'en-US':
                #            new_prompts[prompt][active_voices[language_index]['Language']] = prompts[prompt]['en-US']
                #        else:
                #            new_prompts[prompt][active_voices[language_index]['Language']] = util.translate_text(prompts[prompt]['en-US'], 'en-US', active_voices[language_index]['Language'])

                #tenants.update_tts(s3_client, s3_resource, tenant_id, 'Default', new_prompts, role_credentials)

                update_instance_status(account_name, account_id, instance_arn, ou, 'ACTIVE', save_contact_flows)
                sleep(5)

                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(ou, tenant_id)
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)
                basic_queue_id = queues.get_queue_id(connect_client, connect_id, 'BasicQueue')
                queue_list = [{'Id': basic_queue_id, 'Name': 'BasicQueue', 'CallerID': '', 'PhoneId': '', 'PhoneNumber': '', 'CallBack': 'off', 'VoiceMail': 'off', 'QueueHours': None}]
                
                queues.create_queues(ou, tenant_id, s3_client, connect_instance_details, connect_client, connect_id, queue_list)
                

def check_instance_exists(tenant_name, ou, region):
    dynamodb_client = boto3.client('dynamodb', region_name=region)
    instanceExists = False

    try:
        get_item_response = dynamodb_client.get_item(TableName='Instances-' + ou, Key={"Tenant": {"S":tenant_name}})
        print("INSTANCE ALREADY EXISTS: " + str(get_item_response['Items']))
        instanceExists = True
    except Exception as Ex1:
        pass

    return(instanceExists)
    
def create_account(account_name, account_email, ou, principal_arn, ignite_region):
    #INVOKE Ignite-Factory lambda function to provision Tenant account
    if 'bcp' not in account_name: #Do not create account for BCP since it will run on PROD account. 
        logger.info('INVOKING IGNITE FACTORY TO CREATE ACCOUNT: ' + account_name)
        account_id = 'None'
        factory_account_id = principal_arn.split(':')[4]
        factory_role = principal_arn.split(':')[5]

        principal_arn = os.environ['PRINCIPAL_ARN']
        
        lambda_client = boto3.client('lambda', region_name=ignite_region,
            aws_access_key_id=config.ACCESS_KEY_ID,
            aws_secret_access_key=config.SECRET_ACCESS_KEY            
        )

        payload = {
            "AccountName":account_name,
            "AccountEmail":account_email,
            "OrganizationUnitName":ou,
            "PrincipalARN":principal_arn,
            "CentralAccountID": config.AWS_ACCOUNT_ID
            }

        lambda_client.invoke(
            FunctionName='Ignite-Factory',
            InvocationType='Event',
            LogType='Tail',
            Payload= bytes(json.dumps(payload), encoding='utf8'),
        )

    wait_counter = 0
    while(wait_counter < 3):
        logger.info('ACCOUNT CREATION UNDER CHANGE: Iteration ' + str(wait_counter))
        account_id = get_account_id(account_name)
        if account_id == 'None':
            sleep(30)
            wait_counter += 1
        else:
            break

    if account_id != "None":
        logger.info('ACCOUNT CREATION COMPLETED: ' + account_id)
    else:
        logger.info('UNABLE TO CREATE ACCOUNT: ' + account_name) 

    return(account_id)

def get_account_id(account_name):
    logger.info('GETTING ACCOUNT ID FOR: ' + account_name)

    org_client = boto3.client('organizations',
        aws_access_key_id=config.ACCESS_KEY_ID,
        aws_secret_access_key=config.SECRET_ACCESS_KEY          
    )

    account_id = "None"
    list_accounts = []
    list_account_ids = []
    list_account_names = []
    account_name_to_id = {}

    try:
        list_of_accounts_response = org_client.list_accounts()
        list_accounts = list_of_accounts_response['Accounts']

        while "NextToken" in list_of_accounts_response:
            list_of_accounts_response = org_client.list_accounts(
                    NextToken=list_of_accounts_response['NextToken']
            )
            list_accounts.extend(list_of_accounts_response['Accounts'])

        for account in list_accounts:
            list_account_ids.append(account['Id'])
            list_account_names.append(account['Name'])

        for i in range(len(list_account_names)):
            account_name_to_id[list_account_names[i]] = list_account_ids[i]

        if account_name in list_account_names:
            account_id = account_name_to_id[account_name]

    except Exception as Ex1:
        logger.info("get_account_id EXCEPTION: " + str(Ex1))

    return account_id

def assume_role(account_id):
    role_credentials = {}

    wait_counter = 0
    sts_client = boto3.client('sts')
    while(wait_counter <= 3):
        try:
            sts_session = sts_client.assume_role(RoleArn='arn:aws:iam::' + account_id + ':role/Ignite-Client',
                                            RoleSessionName='initialization-session')
            
            role_credentials['KEY_ID'] = sts_session['Credentials']['AccessKeyId']
            role_credentials['ACCESS_KEY'] = sts_session['Credentials']['SecretAccessKey']
            role_credentials['TOKEN'] = sts_session['Credentials']['SessionToken']
            logger.info("ASSUMED ROLE Ignite-Client SUCCESSFULLY: {}" + format(role_credentials['KEY_ID']))
            break
        except Exception as Ex1:
            logger.info('WAITING FOR ACCOUNT SERVICES TO BE READY')
            wait_counter += 1
            sleep(30)
            pass
    else:
        logger.info("UNABLE TO ASSUME ROLE Ignite-Client.  PLEASE TRY AGAIN.")
        sys.exit(1)
    
    return(role_credentials)

def create_xaccount_role(role_credentials):
    logger.info("CREATING xaccount-rdf-role")
    iam_client = boto3.client('iam', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    try:
        found_role = False
        list_roles_response = iam_client.list_roles()

        list_roles = list_roles_response['Roles']
        
        while "Marker" in list_roles_response:
            list_roles_response = iam_client.list_roles(
                Marker=list_roles_response['Marker'],
            )
            
            list_roles.extend(list_roles_response['Roles'])

        for role in list_roles:
            if 'xaccount-rdf-role' in role['RoleName']:
                found_role = True
                result = role['Arn']

        if not found_role:

            assume_role_policy = config.assume_role_policy_document.replace('<ACCOUNT_ID>', config.AWS_ACCOUNT_ID)
                        
            iam_client.create_role(
                Path='/',
                RoleName='xaccount-rdf-role',
                AssumeRolePolicyDocument=assume_role_policy,
                Description='Cross Account Role used by Ignite-RDF',
                MaxSessionDuration=3600,
                #PermissionsBoundary='string',
            )

            list_policies_response = iam_client.list_policies(
                Scope='AWS',
                OnlyAttached=False,
                PathPrefix='/',
                PolicyUsageFilter='PermissionsPolicy',
                #Marker='string',
                MaxItems=100
            )

            list_policies =  list_policies_response['Policies']

            while 'Marker' in list_policies_response:
                list_policies_response = iam_client.list_policies(
                    Scope='AWS',
                    OnlyAttached=False,
                    PathPrefix='/',
                    PolicyUsageFilter='PermissionsPolicy',
                    Marker=list_policies_response['Marker'],
                    MaxItems=100
                )
            
                list_policies.extend(list_policies_response['Policies'])

            for policy in list_policies:
                if policy['PolicyName'] == 'AmazonConnect_FullAccess' or policy['PolicyName'] == 'AmazonDynamoDBFullAccess':
                    iam_client.attach_role_policy(
                        RoleName='xaccount-rdf-role',
                        PolicyArn=policy['Arn']
                    )
        else:
            logger.info("xaccount-rdf-role ALREADY EXISTS " + result)

    except Exception as Ex1:
        result = 'None'
        logger.info("create_xaccount_role EXCEPTION: " + str(Ex1))

def get_rdf_role():
    logger.info("GETTING RDF ROLE ARN")
    role_arn = 'None'
    iam_client = boto3.client('iam')
    try:
        get_rdf_role_response = iam_client.list_roles(
            PathPrefix='/'
        )

        list_roles = get_rdf_role_response['Roles']

        while 'Marker' in get_rdf_role_response:
            get_rdf_role_response = iam_client.list_roles(
                PathPrefix='/',
                Marker=get_rdf_role_response['Marker']
            )

            list_roles.extend(get_rdf_role_response['Roles'])

        for role in list_roles:
            if 'Ignite-RDF' in role['RoleName']:
                role_arn = role['Arn']

    except Exception as Ex1:
        result = 'None'
        logger.info("get_rdf_role EXCEPTION: " + str(Ex1))

    return role_arn

def create_tenant_kms_key(role_credentials, alias):
    logger.info("CREATING KMS KEY: " + alias)

    kms_client = boto3.client('kms', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    key_exists = False

    try:
        list_kms_aliases_response = kms_client.list_aliases(Limit=100)

        for key in list_kms_aliases_response['Aliases']:
            if 'alias/' + alias in key['AliasName']:
                logger.info("EXISTING KMS KEY: " + key['AliasName'])
                key_exists = True
                describe_key_response = kms_client.describe_key(
                    KeyId=key['TargetKeyId']
                )
                kms_arn = describe_key_response['KeyMetadata']['Arn']

        if not key_exists:
            if 'bcp' in alias:
                multi_region = True
            else:
                multi_region = False

            kms_response = kms_client.create_key(
                Description='KMS KEY for ' + alias,
                KeyUsage='ENCRYPT_DECRYPT',
                KeySpec='SYMMETRIC_DEFAULT',
                Origin='AWS_KMS',
                MultiRegion=multi_region,
            )

            kms_client.create_alias(
                AliasName='alias/' + alias,
                TargetKeyId= kms_response['KeyMetadata']['KeyId']
            )

            kms_arn = kms_response['KeyMetadata']['Arn']
            logger.info("CREATED KMS KEY: " + kms_arn)

    except Exception as Ex1:
        logger.info("create_tenant_kms_key EXCEPTION: " + str(Ex1))

    return(kms_arn)

def create_tenant_replica_kms_key(role_credentials, alias):
    kms_client = boto3.client('kms', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    try:
        list_kms_aliases_response = kms_client.list_aliases(Limit=100)

        for key in list_kms_aliases_response['Aliases']:
            if 'alias/' + alias in key['AliasName']:
                logger.info("REPLICATING KEY: " + key['AliasName'])
                describe_key_response = kms_client.describe_key(
                    KeyId=key['TargetKeyId']
                )
                kms_id = describe_key_response['KeyMetadata']['KeyId']

        kms_response = kms_client.replicate_key(
            KeyId=kms_id,
            ReplicaRegion=config.region,
            Description='REPLICA KMS KEY for ' + alias
        )

        kms_client.create_alias(
            AliasName='alias/' + alias,
            TargetKeyId= kms_response['ReplicaKeyMetadata']['KeyId']
        )

        kms_arn = kms_response['ReplicaKeyMetadata']['Arn']
        logger.info("CREATED REPLICA KMS KEY: " + kms_arn)

    except Exception as Ex1:
        logger.info("create_tenant_kms_key EXCEPTION: " + str(Ex1))

    return(kms_arn)

def create_rdf_kms_key(role_credentials, alias, account_id, kvs_role_arn, ckvs_role_arn):
    logger.info("CREATING KMS KEY: " + alias)
    kms_client = boto3.client('kms', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    key_exists = False

    try:
        list_kms_aliases_response = kms_client.list_aliases(Limit=100)

        for key in list_kms_aliases_response['Aliases']:
            if 'alias/' + alias in key['AliasName']:
                logger.info("EXISTING KMS KEY: " + key['AliasName'])
                key_exists = True
                describe_key_response = kms_client.describe_key(
                    KeyId=key['TargetKeyId']
                )
                kms_arn = describe_key_response['KeyMetadata']['Arn']

        if not key_exists:            
            kms_key_policy = config.kms_key_policy.replace('<TENANT_ACCOUNT>', account_id)
            kms_key_policy = kms_key_policy.replace('<CENTRAL_ACCOUNT>', config.AWS_ACCOUNT_ID)
            kms_key_policy = kms_key_policy.replace('<CONNECT_KVS_ROLE_ARN>', ckvs_role_arn)
            kms_key_policy = kms_key_policy.replace('<KVS_CONV_ROLE_ARN>', kvs_role_arn)

            kms_response = kms_client.create_key(
                Policy=kms_key_policy,
                Description='KMS KEY for ' + alias,
                KeyUsage='ENCRYPT_DECRYPT',
                KeySpec='SYMMETRIC_DEFAULT',
                Origin='AWS_KMS',
                MultiRegion=False,
            )

            kms_client.create_alias(
                AliasName='alias/' + alias,
                TargetKeyId=kms_response['KeyMetadata']['KeyId']
            )

            kms_arn = kms_response['KeyMetadata']['Arn']
            logger.info("CREATED KMS KEY " + kms_arn)

    except Exception as Ex1:
        logger.info("create_rdf_kms_key EXCEPTION: " + str(Ex1))

    return(kms_arn)

def create_s3_bucket(data_region, role_credentials, bucket_name, kms_key_id):
    s3_client = boto3.client('s3', region_name=data_region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    bucket_exists = False

    list_of_s3_buckets_response = s3_client.list_buckets()

    for bucket in list_of_s3_buckets_response['Buckets']:
        if bucket_name in bucket['Name']:
            logger.info("EXISTING S3 BUCKET: " + bucket['Name'])
            bucket_exists = True
            bucket_name =  bucket['Name']
            
    if not bucket_exists:
        logger.info("CREATING S3 BUCKET: " + bucket_name)
        try:
            if config.region == 'us-east-1':
                s3_client.create_bucket(
                    Bucket=bucket_name,
                )                    
            else:
                s3_client.create_bucket(
                    Bucket=bucket_name,
                    CreateBucketConfiguration={
                        'LocationConstraint': config.region 
                    }
                )        

            s3_client.put_bucket_encryption(
                Bucket=bucket_name,
                ServerSideEncryptionConfiguration={
                    'Rules': [
                        {
                            'ApplyServerSideEncryptionByDefault': {
                                'SSEAlgorithm': 'aws:kms',
                                'KMSMasterKeyID': kms_key_id
                            },
                            'BucketKeyEnabled': True
                        },
                    ]
                },
            )

        except Exception as Ex1:
            logger.info("get_s3_bucket EXCEPTION: " + str(Ex1))
        
    return(bucket_name)

def create_db_table(role_credentials, table_name):
    wait_counter = 0
    while(wait_counter <= 3):
        try:
            db_client = boto3.client('dynamodb', region_name=config.region,
                aws_access_key_id=role_credentials['KEY_ID'],
                aws_secret_access_key=role_credentials['ACCESS_KEY'],
                aws_session_token=role_credentials['TOKEN'])
            
            list_of_tables_response = db_client.list_tables(
                Limit=100
            )        
            
            break
        except Exception as Ex1:
            logger.info('WAITING FOR DYNAMODB SERVICES TO BE READY: '  + str(Ex1))
            wait_counter += 1
            sleep(30)
            pass          
    else:
        logger.info("UNABLE TO CREATE DYNAMODB TABLES.  PLEASE TRY AGAIN.")
        sys.exit(1)

    list_table_names = []

    list_of_tables_response = db_client.list_tables(
        Limit=100
    )

    list_table_names = list_of_tables_response['TableNames']
    
    while "LastEvaluatedTableName" in list_of_tables_response:
        list_of_tables_response = db_client.client.list_tables(
            ExclusiveStartTableName=list_of_tables_response['LastEvaluatedTableName'],
            Limit=100
        )
        list_table_names.extend(list_of_tables_response['TableNames'])

    if(table_name not in list_table_names):
        logger.info("CREATING DYNAMODB TABLE: {}".format(table_name))

        db_client.create_table(
            AttributeDefinitions=config.db_tables[table_name]['attribute_definitions'],
            TableName=table_name,
            KeySchema=config.db_tables[table_name]['key_schema'],
            ProvisionedThroughput={
                'ReadCapacityUnits': 5,
                'WriteCapacityUnits': 5
            },
            SSESpecification={
                'Enabled': True,
                'SSEType': 'KMS'
                #'KMSMasterKeyId': 'string'
            },
            TableClass='STANDARD',
            DeletionProtectionEnabled=True
        )
                
    else:
        logger.info("EXISTING DYNAMODB TABLE: " + table_name)

def create_connect_instance(role_credentials, account_name, instance_type):
    logger.info("CREATING AMAZON CONNECT INSTANCE: " + account_name)

    connect_client = boto3.client('connect', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    connect_instance_exists = False
    connect_instance_arn = 'None'
    try:
        list_connect_instances = connect_client.list_instances(
            MaxResults=10
        )

        for instance in list_connect_instances['InstanceSummaryList']:
            if account_name.lower() == instance['InstanceAlias']:
                logger.info("EXISTING CONNECT INSTANCE: " + account_name)
                connect_instance_exists = True
                connect_instance_arn = instance['Arn']

        if not connect_instance_exists:
            create_connect_response = connect_client.create_instance(
                IdentityManagementType=instance_type,
                InstanceAlias=account_name,
                InboundCallsEnabled=True,
                OutboundCallsEnabled=True,
            )
            connect_instance_arn = create_connect_response['Arn']
            wait_counter = 0

            while(wait_counter <= 10):
                describe_instance_response = connect_client.describe_instance(
                    InstanceId=create_connect_response['Id']
                )
                if describe_instance_response['Instance']['InstanceStatus'] == 'ACTIVE':
                    logger.info('AMAZON CONNECT INSTANCE CREATION COMPLETED: ' + connect_instance_arn)
                    logger.info('ENABLING CONTACT FLOW LOGS')
                    sleep(5)
                    connect_client.update_instance_attribute(
                        InstanceId=create_connect_response['Id'],
                        AttributeType='CONTACTFLOW_LOGS',
                        Value='true'
                    )                    
                    break
                elif describe_instance_response['Instance']['InstanceStatus'] == 'CREATION_FAILED':
                    logger.info('AMAZON CONNECT INSTANCE CREATION FAILED')
                    sys.exit(1) 
                else:
                    logger.info('AMAZON CONNECT INSTANCE CREATION IN PROGRESS')
                    wait_counter += 1
                    sleep(30)
            else:
                logger.info("UNABLE TO CREATE AMAZON CONNECT INSTANCE.  PLEASE TRY AGAIN.")
                sys.exit(1)

    except Exception as Ex1:
        logger.info("create_connect_instance EXCEPTION: " + str(Ex1))
        sys.exit(1)

    return(connect_instance_arn)

def associate_s3_bucket(role_credentials, instance_id, bucket_prefix, bucket_suffix, tenant_kms_key):
    bucket_name = bucket_prefix + bucket_suffix
    logger.info("ASSOCIATING S3 BUCKET TO AMAZON CONNECT INSTANCE: " + bucket_name)
    connect_client = boto3.client('connect', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    if 'recordings' in bucket_name:
        resource_type = 'CALL_RECORDINGS'
    else:
        resource_type = 'SCHEDULED_REPORTS'

    try:
        connect_client.associate_instance_storage_config(
            InstanceId=instance_id,
            ResourceType=resource_type,
            StorageConfig={
                'StorageType': 'S3',
                'S3Config': {
                    'BucketName': bucket_name,
                    'BucketPrefix': 'connect/' + bucket_prefix,
                    'EncryptionConfig': {
                        'EncryptionType': 'KMS',
                        'KeyId': tenant_kms_key
                    }
                }
            }
        )

    except Exception as Ex1:
        logger.info("associate_s3_bucket EXCEPTION: " + str(Ex1))

def associate_kinesis_video(role_credentials, instance_id):
    logger.info("ASSOCIATING KINESIS VIDEO STREAM TO AMAZON CONNECT INSTANCE")
    kvs_kms_key = ''

    connect_client = boto3.client('connect', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])
    kms_client = boto3.client('kms', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    try:
        kms_alias_response = kms_client.list_aliases(
            Limit=100
        )
        for kms_alias in kms_alias_response['Aliases']:
            if 'kinesisvideo' in kms_alias['AliasName']:
                kvs_kms_key = kms_alias['AliasArn']
            
        connect_client.associate_instance_storage_config(
            InstanceId=instance_id,
            ResourceType='MEDIA_STREAMS',
            StorageConfig={
                'StorageType': 'KINESIS_VIDEO_STREAM',
                'KinesisVideoStreamConfig': {
                    'Prefix': 'ivr-recording',
                    'RetentionPeriodHours': 96,
                    'EncryptionConfig': {
                        'EncryptionType': 'KMS',
                        'KeyId': kvs_kms_key
                    }
                }
            }
        )
    except Exception as Ex1:
        logger.info("associate_kinesis_video EXCEPTION: " + str(Ex1))

def create_policy(role_credentials, policy_name, policy_doc):
    logger.info('CREATING IAM POLICY: ' + policy_name)
    iam_client = boto3.client('iam',
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])
    
    try:
        found_policy = False
        list_policies_response = iam_client.list_policies()

        list_policies = list_policies_response['Policies']
        
        while "Marker" in list_policies_response:
            list_policies_response = iam_client.list_policies(
                Marker=list_policies_response['Marker'],
            )
            
            list_policies.extend(list_policies_response['Policies'])

        for policy in list_policies:
            if policy_name in policy['PolicyName']:
                found_policy = True

        if not found_policy:        
            iam_client.create_policy(
                PolicyName=policy_name,
                Path='/',
                PolicyDocument=policy_doc,
                Description=policy_name,
            )
        else:
            logger.info("IAM POLICY ALREADY EXISTS " + policy_name)

    except Exception as Ex1:
        logger.info("create_policy EXCEPTION: " + str(Ex1))

def create_lambda_function(role_credentials, function_name, bucket_name):
    s3_client = boto3.client('s3')
    iam_client = boto3.client('iam',
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])
    lambda_client = boto3.client('lambda', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    function_arn = 'None'
    (role_arn, function_arn) = check_function_exists(lambda_client, function_name) 

    if not role_arn:
        try:
            role_name = function_name + '-role-' + util.create_random_suffix(8)
            role_arn = create_role(iam_client, role_name, 'IAM Role for ' + function_name)
            logger.info('CREATING LAMBDA FUNCTION ROLE: ' + role_arn)

            if role_arn != 'None':
                for permission in config.lambda_functions[function_name]['permissions_to_attach']:
                    attach_permission_policy(iam_client, role_name, get_policy_arn(iam_client, permission))

                sleep(10)
                response = s3_client.get_object(Bucket=get_central_bucket(s3_client), Key='Lambda/' + function_name+'.zip')
                decoded_file = response['Body'].read()

                create_function_response = lambda_client.create_function(
                    FunctionName=function_name,
                    Runtime=config.lambda_functions[function_name]['runtime'],
                    Role=role_arn,
                    Handler=config.lambda_functions[function_name]['handler'],
                    Code={
                        'ZipFile': decoded_file,
                    },
                    Description=function_name,
                    Timeout=config.lambda_functions[function_name]['timeout'],
                    MemorySize=config.lambda_functions[function_name]['memory'],
                    Publish=True,
                    PackageType='Zip',
                    Environment=config.lambda_functions[function_name]['environment'],                    
                    Architectures=[
                        'x86_64'
                    ],
                    EphemeralStorage={
                        'Size': config.lambda_functions[function_name]['ephemeral']
                    }
                )

                function_arn = create_function_response['FunctionArn']

        except Exception as Ex1:
            logger.info("create_lambda_function EXCEPTION: " + str(Ex1))
    else:
        logger.info("LAMBDA FUNCTION ALREADY EXISTS: " + function_name)

    return (role_arn, function_arn)

def get_central_bucket(s3_client):
    central_bucket_name = ''
    try:
        list_of_s3_buckets_response = s3_client.list_buckets()

        for bucket in list_of_s3_buckets_response['Buckets']:
            if config.bcp_install:
                if "central-bcp" in bucket['Name']:
                    central_bucket_name =  bucket['Name']
            else:
                if "central-main" in bucket['Name']:
                    central_bucket_name =  bucket['Name']                
    except Exception as Ex1:
        logger.info("get_central_bucket EXCEPTION: " + str(Ex1))

    return(central_bucket_name)

def check_function_exists(lambda_client, function_name):
    function_role_arn = ''
    function_arn = ''

    try:

        list_of_lambdas_response = lambda_client.list_functions(
            MaxItems=100
        )

        list_lambdas = list_of_lambdas_response['Functions']
        
        while "Marker" in list_of_lambdas_response:
            list_of_lambdas_response = lambda_client.list_functions(
                Marker=list_of_lambdas_response['Marker'],
                MaxItems=100
            )
            
            list_lambdas.extend(list_of_lambdas_response['Functions'])

        for function in list_lambdas:
            if function['FunctionName'] == function_name:
                function_role_arn = function['Role']
                function_arn = function['FunctionArn']
        
        if not function_role_arn:
            logger.info("CREATING LAMBDA FUNCTION: " + function_name)
        else:
            logger.info("LAMBDA FUNCTION ROLE ALREADY EXISTS: " + function_role_arn)

    except Exception as Ex1:
        logger.info("check_function_exists EXCEPTION: " + str(Ex1))
        
    return(function_role_arn, function_arn)

def create_role(iam_client, role_name, description):
    logger.info('CREATING IAM ROLE: ' + role_name)
    try:
        found_role = False
        list_roles_response = iam_client.list_roles()

        list_roles = list_roles_response['Roles']
        
        while "Marker" in list_roles_response:
            list_roles_response = iam_client.list_roles(
                Marker=list_roles_response['Marker'],
            )
            
            list_roles.extend(list_roles_response['Roles'])

        for role in list_roles:
            if role_name in role['RoleName']:
                found_role = True
                result = role['Arn']

        if not found_role:
            create_iam_role_response = iam_client.create_role(
                Path='/',
                RoleName=role_name,
                AssumeRolePolicyDocument=config.assume_role_policy,
                Description=description,
            )
            result = create_iam_role_response['Role']['Arn'] 
        else:
            logger.info("IAM ROLE ALREADY EXISTS " + result)

    except Exception as Ex1:
        result = 'None'
        logger.info("create_role EXCEPTION: " + str(Ex1))

    return(result)

def attach_permission_policy(iam_client, role_name, policy_arn):
    logger.info('ATTACHING IAM POLICY ARN: ' + policy_arn + ' TO ROLE: ' + role_name)
    try:
        iam_client.attach_role_policy(
            RoleName=role_name,
            PolicyArn=policy_arn
        )
    except Exception as Ex1:
        logger.info("attach_permission_policy EXCEPTION: " + str(Ex1))

def get_policy_arn(iam_client, iam_policy_name):
    logger.info('GETTING IAM POLICY ARN: ' + iam_policy_name)
    iam_policy_arn = 'None'
    list_permission_policies = []
    list_permission_arns = []
    list_permission_names = []
    permissions_name_to_arn = {}

    try:
        list_of_permissions_response = iam_client.list_policies(
            Scope='All',
            OnlyAttached=False,
            PathPrefix='/',
            PolicyUsageFilter='PermissionsPolicy',
            MaxItems=100
        )

        list_permission_policies = list_of_permissions_response['Policies']
        
        while "Marker" in list_of_permissions_response:
            list_of_permissions_response = iam_client.list_policies(
                Scope='All',
                OnlyAttached=False,
                PathPrefix='/',
                PolicyUsageFilter='PermissionsPolicy',
                Marker=list_of_permissions_response['Marker'],
                MaxItems=100
            )
            
            list_permission_policies.extend(list_of_permissions_response['Policies'])

        for permission_policy in list_permission_policies:
            list_permission_arns.append(permission_policy['Arn'])
            list_permission_names.append(permission_policy['PolicyName'])

        for i in range(len(list_permission_names)):
            permissions_name_to_arn[list_permission_names[i]] = list_permission_arns[i]

        iam_policy_arn = permissions_name_to_arn[iam_policy_name]
    except Exception as Ex1:
        logger.info("get_policy_arn EXCEPTION: " + str(Ex1))
        
    return(iam_policy_arn)

def create_contact_flows(role_credentials, account_id, instance_id, ou, flows_to_update):
    logger.info("UPLOADING IGNITE-RDF BASE CONTACT FLOWS TO AMAZON CONNECT INSTANCE: " + instance_id)

    connect_client = boto3.client('connect', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    try:
        #GET CONTACT FLOWS
        list_contact_flows_response = connect_client.list_contact_flows(
            InstanceId=instance_id,
        )
        installed_contact_flow_list = list_contact_flows_response['ContactFlowSummaryList']

        while 'NextToken' in list_contact_flows_response:
            list_contact_flows_response = connect_client.list_contact_flows(
                InstanceId=instance_id,
                NextToken=list_contact_flows_response['NextToken']
            )

            installed_contact_flow_list.extend(list_contact_flows_response['ContactFlowSummaryList'])

        #GET CONTACT FLOW MODULES
        list_contact_flows_response = connect_client.list_contact_flow_modules(
            InstanceId=instance_id,
        )
        installed_contact_flow_list.extend(list_contact_flows_response['ContactFlowModulesSummaryList'])

    except Exception as Ex1:
        logger.info("list_contact_flows EXCEPTION: " + str(Ex1))

    save_contact_flows = {}
    installed_contact_flow_list_names = {}

    for installed_flow in installed_contact_flow_list:
        if 'ContactFlows/' + installed_flow['Name'] in config.contact_flows:
            installed_contact_flow_list_names[installed_flow['Name']] = installed_flow['Id']

    save_contact_flows = installed_contact_flow_list_names

    beep_prompt_arn = get_beep_prompt_arn(connect_client, instance_id)

    for contact_flow in flows_to_update:
        contact_flow_name = contact_flow[contact_flow.find('/')+1:]
        try:
            contact_flow_file = get_contact_flow(account_id, contact_flow)
            new_contact_flow_file = update_contact_flow(contact_flow_file, account_id, ou, beep_prompt_arn)

            if config.contact_flows[contact_flow]=='MODULE':
                if contact_flow_name in installed_contact_flow_list_names:
                    logger.info("UPDATING EXISTING CONTACT FLOW MODULE: " + contact_flow_name)

                    connect_client.update_contact_flow_module_content(
                        InstanceId=instance_id,
                        ContactFlowModuleId=installed_contact_flow_list_names[contact_flow_name],
                        Content=contact_flow_file
                    )

                else:
                    logger.info("INSTALLING NEW CONTACT FLOW MODULE: " + contact_flow_name)
                    create_contact_flow_module_response = connect_client.create_contact_flow_module(
                        InstanceId=instance_id,
                        Name=contact_flow_name,
                        Description='USED BY IGNITE-RDF',
                        Content=contact_flow_file
                    )
                    save_contact_flows[contact_flow_name] =  create_contact_flow_module_response['Id']                     
            else:        
                if contact_flow_name in installed_contact_flow_list_names:
                    logger.info("UPDATING EXISTING CONTACT FLOW: " + contact_flow_name + " AS TYPE: " + config.contact_flows[contact_flow])
                    connect_client.update_contact_flow_content(
                        InstanceId=instance_id,
                        ContactFlowId=installed_contact_flow_list_names[contact_flow_name],
                        Content=new_contact_flow_file
                    )
                else:
                    logger.info("INSTALLING NEW CONTACT FLOW: " + contact_flow_name + " AS TYPE: " + config.contact_flows[contact_flow])
                    create_contact_flow_response = connect_client.create_contact_flow(
                        InstanceId=instance_id,
                        Name=contact_flow_name,
                        Type=config.contact_flows[contact_flow],
                        Description='USED BY IGNITE-RDF',
                        Content=new_contact_flow_file
                    )
                    save_contact_flows[contact_flow_name] =  create_contact_flow_response['ContactFlowId']            

        except Exception as Ex1:
            logger.info("create_contact_flow EXCEPTION: " + str(Ex1))
            pass

    return save_contact_flows

def get_contact_flow(account_id, contact_flow):
    s3_client = boto3.client('s3')

    try:
        s3_response = s3_client.get_object(Bucket=get_central_bucket(s3_client), Key=contact_flow)
        decoded_file = s3_response['Body'].read().decode('utf-8')

    except Exception as Ex1:
        logger.info("get_contact_flow EXCEPTION: " + str(Ex1)) 

    return(decoded_file)

def update_contact_flow(contact_flow_file, account_id, ou, beep_prompt_arn):
    contact_flow = json.loads(contact_flow_file)
    rdf_arn = 'arn:aws:lambda:' + config.region + ':' + config.AWS_ACCOUNT_ID + ':function:Ignite-RDF:' + ou.lower()
    kvs_arn = 'arn:aws:lambda:' + config.region + ':' + account_id + ':function:ConnectKVS2Audio'

    new_contact_flow = {}
    new_contact_flow['Version'] = contact_flow['Version']
    new_contact_flow['StartAction'] = contact_flow['StartAction']
    new_contact_flow['Metadata'] = contact_flow['Metadata']
    new_contact_flow['Actions'] = []

    for item in contact_flow['Actions']:
        try:
            if 'PromptId' in item['Parameters']:
                item['Parameters']['PromptId'] = beep_prompt_arn
            if 'LambdaFunctionARN' in item['Parameters']:
                if 'ConnectKVS2Audio' in item['Parameters']['LambdaFunctionARN']:
                    item['Parameters']['LambdaFunctionARN'] = kvs_arn
            if 'Attributes' in item['Parameters']:
                for attr in item['Parameters']['Attributes']:
                    if attr=='RDF':
                        item['Parameters']['Attributes']['RDF'] = rdf_arn
            new_contact_flow['Actions'].append(item)
        except:
            pass

    return(json.dumps(new_contact_flow))

def associate_lambda_function(role_credentials, instance_id, function_arn):
    logger.info('ASSOCIATING FUNCTION: ' + function_arn + ' TO AMAZON CONNECT INSTANCE FOR VOICEMAIL')

    connect_client = boto3.client('connect', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])
    
    try:
        connect_client.associate_lambda_function(
            InstanceId=instance_id,
            FunctionArn=function_arn
        )

    except Exception as Ex1:
        logger.info("associate_lambda_function EXCEPTION: " + str(Ex1))   

def add_rdf_invoke_permissions(account_id, account_name, instance_arn, ou):
    logger.info('ADDING INVOKE PERMISSIONS FOR CONNECT INSTANCE: ' + instance_arn + ' TO IGNITE-RDF')
    lambda_client = boto3.client('lambda')

    try:
        lambda_client.add_permission(
            FunctionName='Ignite-RDF',
            StatementId=account_name,
            Action='lambda:InvokeFunction',
            Principal='connect.amazonaws.com',
            SourceArn=instance_arn,
            Qualifier=ou.lower(),
        )
    
    except Exception as Ex1:
        logger.info("add_rdf_invoke_permissions EXCEPTION: " + str(Ex1)) 

def get_beep_prompt_arn(connect_client, instance_id):
    beep_prompt_arn = 'None'
    try:
        list_prompts_response = connect_client.list_prompts(
            InstanceId=instance_id,
        )

        list_prompts = list_prompts_response['PromptSummaryList']

        while 'NextToken' in list_prompts_response:
            list_prompts_response = connect_client.list_prompts(
                InstanceId=instance_id,
                NextToken=list_prompts_response['NextToken'],
            )

            list_prompts.extend(list_prompts_response['PromptSummaryList'])
        
        for prompt in list_prompts:
            if prompt['Name'] == 'Beep.wav':
                 beep_prompt_arn = prompt['Arn']

    except Exception as Ex1:
        logger.info("get_beep_prompt_arn EXCEPTION: " + str(Ex1)) 
    
    return beep_prompt_arn

def add_S3_trigger(role_credentials,function_name, bucket_name, account_id, function_arn):
    logger.info('ADDING S3 TRIGGER FOR: ' + function_name)

    lambda_client = boto3.client('lambda', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    s3_client = boto3.client('s3', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])
    
    try:
        lambda_client.add_permission(
            FunctionName=function_name,
            StatementId='lambda-' + util.create_random_suffix(12),
            Action='lambda:InvokeFunction',
            Principal='s3.amazonaws.com',
            SourceArn='arn:aws:s3:::'+ bucket_name,
            SourceAccount=account_id
        )

        sleep(10)
        s3_client.put_bucket_notification_configuration(
            Bucket=bucket_name,
            NotificationConfiguration={
                'LambdaFunctionConfigurations': [
                    {
                        'LambdaFunctionArn': function_arn,
                        'Events': [
                            's3:ObjectCreated:*'
                        ],
                        'Filter': {
                            'Key': {
                                'FilterRules': [
                                    {
                                        'Name': 'prefix',
                                        'Value': 'audio/'
                                    },
                                    {
                                        'Name': 'suffix',
                                        'Value': '.wav'
                                    },
                                ]
                            }
                        }
                    },
                ]
            }
        )       
    except Exception as Ex1:
        logger.info("add_S3_trigger EXCEPTION: " + str(Ex1))

def add_event_bridge_rule(role_credentials, function_arn):
    logger.info('ADDING EVENTBRIDGE RULE FOR VOICEMAIL ')
    eb_client = boto3.client('events', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])

    lambda_client = boto3.client('lambda', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])
        
    found_rule = False
    event_rule_arn = 'None'   
    try:
        list_rules_response = eb_client.list_rules()
        list_rules = list_rules_response['Rules']

        while 'NextToken' in list_rules_response:
            list_rules_response = eb_client.list_prompts(
                NextToken=list_rules_response['NextToken'],
            )

            list_rules.extend(list_rules_response['Rules'])
        
        for rule in list_rules:
            if rule['Name'] == 'VoiceMail':
                 found_rule = True
                 event_rule_arn = rule['Arn']

        if not found_rule:
            put_rule_response = eb_client.put_rule(
                Name='VoiceMail',
                EventPattern=config.connect_event_rule,
                State='ENABLED',
                Description='Checks to see if a voice mail was created for a contact',
                #RoleArn='string',
            )
            event_rule_arn = put_rule_response['RuleArn']

            eb_client.put_targets(
                Rule='VoiceMail',
                Targets=[
                    {
                        'Id': 'ConnectKVS2Audio',
                        'Arn': function_arn
                    }
                ]
            )

            lambda_client.add_permission(
                FunctionName='ConnectKVS2Audio',
                StatementId='AWSEvents_VoiceMail_' + util.create_random_suffix(12),
                Action='lambda:InvokeFunction',
                Principal='events.amazonaws.com',
                SourceArn=event_rule_arn
            )

        else:
            logger.info("VOICEMAIL EVENTBRIDGE RULE ALREADY EXISTS")                        

    except Exception as Ex1:
        logger.info("add_event_bridge_rule EXCEPTION: " + str(Ex1)) 
    
    return event_rule_arn                

def update_instance_status(tenant_name, account_id, instance_arn, ou, status, save_contact_flows):
    logger.info("UPDATING INSTANCE STATUS IN: " + ou + " FOR TENANT: " + tenant_name + " WITH ACCOUNT ID: " + account_id + " AND AMAZON CONNECT INSTANCE ARN: " + instance_arn)
    try:
        table = boto3.resource('dynamodb').Table('Instances-' + ou)

        #This will retain previous contact_flow_id's
        get_item_response = table.get_item(Key={'Tenant': tenant_name})
        if 'Item' in get_item_response:
            old_call_flows = json.loads(get_item_response['Item'].get('CallFlows', '{}'))

        for old_call_flow in old_call_flows:
            if old_call_flow not in save_contact_flows:
                save_contact_flows[old_call_flow] = old_call_flows[old_call_flow]

        current_time = datetime.datetime.now(datetime.timezone.utc)
        table.update_item(
                Key = {
                    'Tenant': tenant_name
                },
                UpdateExpression='SET #attr1 = :val1, #attr2 = :val2, #attr3 = :val3, #attr4 = :val4, #attr5 = :val5',
                ExpressionAttributeNames={'#attr1': 'AccountID', '#attr2': 'InstanceARN', '#attr3':'Status', '#attr4':'CallFlows', '#attr5':'LastUpdated'},
                ExpressionAttributeValues={':val1': account_id, ':val2': instance_arn, ':val3': status, ':val4': json.dumps(save_contact_flows), ':val5': current_time.isoformat()}
            )

    except Exception as Ex1:
        logger.info("update_instance_status EXCEPTION: " + str(Ex1)) 

def get_tenant_status(ou, tenant_id):
    status = ''
    logger.info("GETTING INSTANCE STATUS IN OU: " + ou + " FOR TENANT: " + tenant_id )
    dynamodb_client = boto3.client('dynamodb', region_name=config.region)
    try:
        response = dynamodb_client.get_item(
                TableName='Instances-' + ou,
                Key={
                    'Tenant': {'S': tenant_id}
                }
            )

        status = response['Item']['Status']
    
    except Exception as Ex1:
        logger.info("get_tenant_status EXCEPTION: " + str(Ex1))

    return(status)

def get_tenants(ou):
    tenant_list = []
    connect_id = ""
    dynamodb_client = boto3.client('dynamodb')
    try:
        response = dynamodb_client.scan(
            TableName='Instances-' + ou
        )

        for tenant_key in response['Items']:
            if tenant_key['InstanceARN']['S']:
                connect_id = tenant_key['InstanceARN']['S'].split(":")[5][tenant_key['InstanceARN']['S'].split(":")[5].find('/')+1:]

            tenant_list.append({
                "id" : tenant_key['Tenant']['S'][tenant_key['Tenant']['S'].find('-')+1:],
                "region" : tenant_key['Region']['S'],
                "account" : tenant_key['AccountID']['S'],
                "connectid" : connect_id,
                "instance_type": tenant_key['InstanceType']['S'],
                "email": tenant_key['Tenant']['S'] + '@' + tenant_key['EmailDomain']['S'],
                "status" : tenant_key['Status']['S']
            })
    
    except Exception as Ex1:
        logger.info("get_tenants EXCEPTION: " + str(Ex1))

    return(tenant_list)

def get_tenant_object(s3_client, filename, tenant_id, app_id):
    tenant_object = {}
    logger.info("GETTING TENANT S3 OBJECT")
    if app_id == 'Default':
        app_folder = 'default'
    else:
        app_folder = f"{tenant_id}-{app_id}"
    
    if filename.find('/') >= 0:
        s3_response = s3_client.get_object(Bucket=get_tenant_bucket(s3_client), Key= f"{app_folder}/{filename}")
    else:
        s3_response = s3_client.get_object(Bucket=get_tenant_bucket(s3_client), Key= f"{app_folder}/config/{filename}")

    tenant_object['FileContents'] = s3_response['Body'].read().decode('utf-8')

    if filename == 'ivr-holidays.csv': 
        tenant_object['Prompts'] = tenants.read_tts(s3_client, tenant_id, app_id, ['holiday'])
    elif filename == 'ivr-sysadmin.csv':
        tenant_object['Prompts'] = tenants.read_tts(s3_client, tenant_id, app_id, ['EM01', 'BM01', 'BM02', 'BM03', 'surveygreet', 'SQ01', 'SQ02', 'SQ03', 'SQ04', 'SQ05', 'SQ06', 'SQ07', 'SQ08', 'SQ09', 'SQ10', 'surveyend', 'surveyerror'])
    elif filename == 'config.csv':
        tenant_object['Prompts'] = tenants.read_tts(s3_client, tenant_id, app_id, ['InvalidInput1', 'InvalidInput2', 'NoInput1', 'NoInput2', 'MaxInputXfer', 'monitor', 'busy1', 'busy2', 'busy3', 'stillbusy', 'pleasehold'])
    else:
        tenant_object['Prompts'] = tenants.read_tts(s3_client, tenant_id, app_id, [])

    return(tenant_object) 

def get_tenant_bucket(s3_client):
    tenant_bucket_name = ''
    buckets_found = {}
    try:
        list_of_s3_buckets_response = s3_client.list_buckets()

        for bucket in list_of_s3_buckets_response['Buckets']:
            if "amazon-connect" in bucket['Name'] and len(bucket['Name'])==51:
                location_response = s3_client.get_bucket_location(
                    Bucket=bucket['Name']
                )
                buckets_found[bucket['Name']] = location_response['LocationConstraint']

        if len(buckets_found) > 1:
            for bucket_name, bucket_region in buckets_found.items():
                if bucket_region == config.region:
                    tenant_bucket_name = bucket_name
        else:
            tenant_bucket_name = next(iter(buckets_found))

    except Exception as Ex1:
        logger.info("get_tenant_bucket EXCEPTION: " + str(Ex1))

    return(tenant_bucket_name)

def put_tenant_object(s3_client, s3_resource, role_credentials, filename, content, tenant_id, app_id, prompts, ou):
    import io

    logger.info("UPDATING TENANT S3 OBJECT")

    app_folder = 'default' if app_id == 'Default' else f"{tenant_id}-{app_id}"

    # Always encode with UTF-8 BOM
    #if isinstance(content, str):
    if '.csv' in filename:
        cleaned_content = content.replace(',undefined', '')
        byte_buffer = io.BytesIO()
        byte_buffer.write('\ufeff'.encode('utf-8'))  # UTF-8 BOM
        byte_buffer.write(cleaned_content.encode('utf-8'))
        byte_buffer.seek(0)
        body = byte_buffer.getvalue()
    else:
        body = content  # Assume already bytes

    # Build full S3 key
    if '/' in filename:
        s3_key = f"{app_folder}/{filename}"
    else:
        s3_key = f"{app_folder}/config/{filename}"

    # Upload to S3
    s3_resource.Object(get_tenant_bucket(s3_client), s3_key).put(Body=body)

    if prompts:
        logger.info('UPDATING TTS: ' + str(prompts))
        tenants.update_tts(s3_client, s3_resource, tenant_id, app_id, prompts, role_credentials)

def get_languages(ou, tenant_id):
    tenant_name = ou.lower() + os.environ['ORGANIZATION_NAME'] + '-' + tenant_id
    list_languages = []
    logger.info("GETTING ACTIVE LANGUAGES")
    dynamodb_client = boto3.client('dynamodb', region_name=config.region)
    try:
        response = dynamodb_client.scan(
            TableName='Instances-' + ou
        )

        for instance in response['Items']:
            if instance['Tenant']['S'] == tenant_name:
                active_languages = json.loads(instance['ActiveVoices']['S'])
                for active_language in active_languages:
                    list_languages.append(active_languages[active_language]['Language'])
    
    except Exception as Ex1:
        logger.info("get_languages EXCEPTION: " + str(Ex1))

    return(list_languages, active_languages)

def update_instance_record(role_credentials, account_id, connect_id, instance_arn, ou, s3_target_resource, tenant_name, tenant_id, contact_flows_update, config_files_update):
    #This function is used to update a tenant's contact flows and config files from Central account
    if contact_flows_update:
        flows_to_update = {}

        for contact_flow in config.contact_flows:
            if contact_flow[contact_flow.find('/')+1:] in contact_flows_update:
                flows_to_update[contact_flow] = config.contact_flows[contact_flow]

        save_contact_flows = create_contact_flows(role_credentials, account_id, connect_id, ou, flows_to_update)
        #lex_bots = lexbots.get_lex_bots(lex_client)
        update_instance_status(tenant_name, account_id, instance_arn, ou, 'ACTIVE', save_contact_flows)

    if config_files_update:
        s3_central_client = boto3.client('s3')
        central_bucket_name = get_central_bucket(s3_central_client)
        target_bucket = f"amazon-connect-{connect_id}"

        files_to_update = applications.get_file_list(s3_central_client, central_bucket_name, 'IVR')
        for file in files_to_update:
            if file not in config_files_update:
                files_to_update.remove(file)

        applications.deploy_files(s3_central_client, s3_target_resource, central_bucket_name, target_bucket, files_to_update, 'default')
        #applications.upload_rdf_application_files(role_credentials, 'amazon-connect-' + connect_id, tenant_id, "default", files_to_update)

        

