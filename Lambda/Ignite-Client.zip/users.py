import json
import boto3
import util
import csv
import tenants
import instances
import config
import time
import queues
import logger

def remove_user_record(event, connect_client, connect_instance_details, ou, event_type):
    old_image = event['Records'][0]['dynamodb']['OldImage']
    name = old_image['Name']['S']
    email = old_image['Email']['S']
    tenant_id = old_image['Tenant']['S']
    list_tenants = instances.get_tenants(ou)
    instance_type = next((t['instance_type'] for t in list_tenants if tenant_id == t['id']), '')
    user_id = util.get_user_id(connect_instance_details['userList'], email)

    try:
        describe_user_response = connect_client.describe_user(
            UserId=user_id,
            InstanceId=connect_instance_details['instanceID']
        )

        routing_profile_id = describe_user_response['User'].get('RoutingProfileId', '')
        hierarchy_group_id = describe_user_response['User'].get('HierarchyGroupId', '')

        logger.info(f"REMOVING USER: {email}")
        remove_connect_user_profile(connect_client, connect_instance_details, name, email, user_id, event_type, instance_type)
    except:
        logger.error(f"REMOVE USER: {email} WAS NOT FOUND.")
        routing_profile_id = ''
        hierarchy_group_id = ''
    
    return(routing_profile_id, hierarchy_group_id)

def update_user_record(event, connect_client, connect_id, connect_instance_details, ou):
    old_image = event['Records'][0]['dynamodb']['OldImage']
    new_image = event['Records'][0]['dynamodb']['NewImage']
    tenant_id = old_image['Tenant']['S']
    email = old_image['Email']['S']
    user_queue_arn = new_image.get('QueueId', {}).get('S')
    user_extension = new_image.get('Extension', {}).get('S')

    user_id = util.get_user_id(connect_instance_details['userList'], email)
    tenant_languages, _ = instances.get_languages(ou, tenant_id)

    updates = {}
    all_keys = set(old_image.keys()) | set(new_image.keys())  # union of all keys
    for key in all_keys:
        old_val = old_image.get(key, {}).get('S')
        new_val = new_image.get(key, {}).get('S')

        if old_val != new_val:
            updates[key] = {
                'old': old_val,
                'new': new_val
            }

    # Move "Name" to the top if it exists
    if "Name" in updates:
        updates = {"Name": updates["Name"], **{k: v for k, v in updates.items() if k != "Name"}}


    '''
    EXAMPLE:
    updates =
    {
        'Role': {
            'old': '["Admin"]',
            'new': '["Agent"]'
        }
    }
    '''    
    
    for update in updates:
        if update == 'Name':
            old_name = old_image['Name']['S']
            routing_profile_id = util.get_routing_profile_id(connect_instance_details['routingProfileList'], old_name)
            qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], old_name)
            name = new_image['Name']['S']
            logger.info(f"UPDATING USER: {email} NAME: {name}")
            update_user_name(connect_client, connect_instance_details, name, user_id, routing_profile_id, qc_id)

        if update == 'Role':
            role_str = new_image.get('Role', {}).get('S')
            role = json.loads(role_str) if role_str else []
            logger.info(f"UPDATING USER: {email} ROLE: {role}")            
            security_profiles = util.get_security_profiles(connect_instance_details['securityProfileList'], role)
            connect_client.update_user_security_profiles(
                SecurityProfileIds=security_profiles,
                UserId=user_id,
                InstanceId=connect_instance_details['instanceID']
            )

        if update == 'Priority':
            name = old_image['Name']['S']
            qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], name)
            routing_profile_id = util.get_routing_profile_id(connect_instance_details['routingProfileList'], name)

            #Remove old queues from Routing Profile and disassociate quick connect from old queues
            agent_skills_str = old_image.get('Priority', {}).get('S')
            agent_skills = json.loads(agent_skills_str) if agent_skills_str else {}
            logger.info(f"UPDATING USER: {email} REMOVING QUEUES: {agent_skills}")
            assigned_queues = get_assigned_queues(connect_instance_details, agent_skills)
            remove_queues_from_routing_profile(connect_client, connect_instance_details, routing_profile_id, agent_skills, name)
            remove_quick_connect_from_queues(connect_client, connect_instance_details, assigned_queues, qc_id)

            #Add new queues to Routing Profile and associate quick connect to new queues            
            agent_skills_str = new_image.get('Priority', {}).get('S')
            agent_skills = json.loads(agent_skills_str) if agent_skills_str else {}
            logger.info(f"UPDATING USER: {email} ADDING QUEUES: {agent_skills}")
            assigned_queues = get_assigned_queues(connect_instance_details, agent_skills)            
            queue_configs = assign_queues(connect_instance_details, agent_skills, name)
            add_queues_to_routing_profile(connect_client, connect_instance_details, routing_profile_id, queue_configs)
            add_quick_connect_to_queues(connect_client, connect_instance_details, assigned_queues, qc_id)

        if update == 'Languages':
            old_languages = json.loads(old_image['Languages']['S'])
            new_languages = json.loads(new_image['Languages']['S'])
            logger.info(f"UPDATING USER: {email} LANGUAGES: {new_languages}")

            if len(tenant_languages) > 1:
                for language in old_languages:
                    remove_language_proficiency(connect_client, connect_instance_details, user_id, language, ou)
                for language in new_languages:
                    add_language_proficiency(connect_client, connect_instance_details, user_id, language, ou)

    if not user_queue_arn or not user_extension:
        user_queue_arn = f"arn:aws:connect:{config.region}:{config.AWS_ACCOUNT_ID}:instance/{connect_id}/queue/agent/{user_id}"
        user_extension = generate_extension(ou, tenant_id, start=1000, end=9999)
        add_user_queue_extension(ou, email, user_queue_arn, user_extension)

def insert_user_record(event, connect_client, connect_id, connect_instance_details, ou, routing_profile_id, hierarchy_group_id, event_type):
    new_image = event['Records'][0]['dynamodb']['NewImage']
    name = new_image['Name']['S']
    email = new_image['Email']['S']
    tenant_id = new_image['Tenant']['S']
    list_tenants = instances.get_tenants(ou)
    tenant_languages, _ = instances.get_languages(ou, tenant_id)
    languages = json.loads(new_image['Languages']['S'])
    instance_type = next((t['instance_type'] for t in list_tenants if tenant_id == t['id']), '')

    role_str = new_image.get('Role', {}).get('S')
    role = json.loads(role_str) if role_str else []
    agent_skills_str = new_image.get('Priority', {}).get('S')
    agent_skills = json.loads(agent_skills_str) if agent_skills_str else {}
    
    security_profiles = util.get_security_profiles(connect_instance_details['securityProfileList'], role)

    logger.info(f"ADDING USER: {email} NAME: {name} ROLE: {json.dumps(role)} QUEUES: {json.dumps(agent_skills)}")

    queue_configs = assign_queues(connect_instance_details, agent_skills, name)
    outbound_queue_id = get_outbound_queue_id(connect_instance_details, agent_skills)
    assigned_queues = get_assigned_queues(connect_instance_details, agent_skills)
                        
    result = create_connect_user_profile(connect_client, connect_instance_details, name, email, security_profiles, instance_type, outbound_queue_id, routing_profile_id, hierarchy_group_id, event_type)
    add_queues_to_routing_profile(connect_client, connect_instance_details, result['rpID'], queue_configs)
    add_quick_connect_to_queues(connect_client, connect_instance_details, assigned_queues, result['qcID'])
    if len(tenant_languages) > 1:
        for language in languages:
            add_language_proficiency(connect_client, connect_instance_details, result['userID'], language, ou)
    user_queue_arn = f"arn:aws:connect:{config.region}:{config.AWS_ACCOUNT_ID}:instance/{connect_id}/queue/agent/{result['userID']}"
    user_extension = generate_extension(ou, tenant_id, start=1000, end=9999)
    add_user_queue_extension(ou, email, user_queue_arn, user_extension)

def remove_connect_user_profile(connect_client, connect_instance_details, name, email, userID, event_type, instance_type):
    logger.info(f"Removing Connect User: {email}")
    try:
        connect_client.delete_user(
            InstanceId=connect_instance_details['instanceID'],
            UserId=userID
        )

        if event_type == 'REMOVE':    
            routing_profile_id = util.get_routing_profile_id(connect_instance_details['routingProfileList'], name)
            connect_client.delete_routing_profile(
                InstanceId=connect_instance_details['instanceID'],
                RoutingProfileId=routing_profile_id
            )    

            qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], name)
            connect_client.delete_quick_connect(
                InstanceId=connect_instance_details['instanceID'],
                QuickConnectId=qc_id
            )

            if instance_type == 'CONNECT_MANAGED':
                secret_client = boto3.client('secretsmanager', region_name=config.region)
                list_secrets_response = secret_client.list_secrets(
                    MaxResults=1,
                    Filters=[
                        {
                            'Key': 'name',
                            'Values': [
                                email
                            ]
                        },
                    ]
                )

                secret_client.delete_secret(
                    SecretId=list_secrets_response['SecretList'][0]['ARN'],
                    ForceDeleteWithoutRecovery=True
                )            

    except Exception as ex1:
        logger.error('remove_connect_user_profile EXCEPTION: ' + str(ex1))
    
def create_connect_user_profile(connect_client, connect_instance_details, name, email, security_profiles, instance_type, outbound_queue_id, routing_profile_id, hierarchy_group_id, event_type):
    logger.info(f"Creating Connect User: {email}")
    qc_id = ''
    secret_id = ''
    last_name, first_name = [part.strip() for part in name.split(",", 1)]

    if event_type == 'INSERT':
        try:
            response = connect_client.create_routing_profile(
                InstanceId=connect_instance_details['instanceID'], 
                Name=name,
                Description=f"Routing Profile for {name}",
                DefaultOutboundQueueId=outbound_queue_id,
                MediaConcurrencies=[
                    {
                        'Channel': 'VOICE',
                        'Concurrency': 1,
                        'CrossChannelBehavior': {
                            'BehaviorType': 'ROUTE_CURRENT_CHANNEL_ONLY'
                        }
                    },
                    {
                        'Channel': 'TASK',
                        'Concurrency': 1,
                        'CrossChannelBehavior': {
                            'BehaviorType': 'ROUTE_CURRENT_CHANNEL_ONLY'
                        }
                    },
                    {
                        'Channel': 'CHAT',
                        'Concurrency': 1,
                        'CrossChannelBehavior': {
                            'BehaviorType': 'ROUTE_CURRENT_CHANNEL_ONLY'
                        }
                    }                 
                ],
            )
            routing_profile_id = response['RoutingProfileId']
            
        except Exception as ex1:
            logger.error('create_routing_profile EXCEPTION: ' + str(ex1))
            routing_profile_id = util.get_routing_profile_id(connect_instance_details['routingProfileList'], name)

        try:
            if instance_type:
                if instance_type == 'CONNECT_MANAGED':
                    secret_client = boto3.client('secretsmanager', region_name=config.region)
                    list_secrets_response = secret_client.list_secrets(
                        MaxResults=1,
                        Filters=[
                            {
                                'Key': 'name',
                                'Values': [
                                    email
                                ]
                            },
                        ]
                    )            

                    retrieve_response = secret_client.get_secret_value(
                        SecretId=list_secrets_response['SecretList'][0]['ARN']
                    )

                    secret_id = retrieve_response['SecretString']

                create_user_params = {
                    'Username': email,
                    'IdentityInfo': {
                        'FirstName': first_name,
                        'LastName': last_name,
                    },
                    'PhoneConfig': {
                        'PhoneType': 'SOFT_PHONE',
                        'AutoAccept': False,
                        'AfterContactWorkTimeLimit': 0
                    },
                    'SecurityProfileIds': security_profiles,
                    'RoutingProfileId': routing_profile_id,
                    'InstanceId': connect_instance_details['instanceID']
                }

                if hierarchy_group_id:
                    create_user_params['HierarchyGroupId'] = hierarchy_group_id

                if secret_id:
                    create_user_params['Password'] = secret_id

                response = connect_client.create_user(**create_user_params)

                userID = response['UserId']

                response = connect_client.create_quick_connect(
                    InstanceId=connect_instance_details['instanceID'],
                    Name= name,
                    Description='Created by Ignite',
                    QuickConnectConfig={
                        'QuickConnectType': 'USER',
                        'UserConfig': {
                            'UserId': userID,
                            'ContactFlowId': connect_instance_details['agentTransferFlowID']
                        }
                    }
                )

                qc_id = response['QuickConnectId']
            
        except Exception as ex1:
            logger.error(f"create_user EXCEPTION: {str(ex1)}")

    return {
        'userID': userID,
        'rpID': routing_profile_id,
        'qcID': qc_id
    }

def generate_extension(ou, tenant_id, start=1000, end=9999):
    existing_extensions = []
    user_list = get_users(ou, tenant_id)
    for user in user_list:
        if user['Extension']:
            existing_extensions.append(user['Extension'])

    for ext in range(start, end + 1):
        if str(ext) not in existing_extensions:
            return str(ext)
    raise Exception("No available 4-digit extensions.")

def get_outbound_queue_id(connect_instance_details, agent_skills):
    outbound_queue_id = None
    for queue_name in agent_skills:
        queue_id = util.get_queue_id(connect_instance_details['QueueSummaryList'], queue_name)
        if agent_skills[queue_name] == 1: #User's default queue
            outbound_queue_id = queue_id

    if not outbound_queue_id:
        outbound_queue_id = connect_instance_details['DefaultOutboundQueueId']
    
    return outbound_queue_id

def get_assigned_queues(connect_instance_details, agent_skills):
    assigned_queues = []
    for queue_name in agent_skills:
        if queue_name:
            queue_id = util.get_queue_id(connect_instance_details['QueueSummaryList'], queue_name)
            assigned_queues.append(queue_id)
    
    return assigned_queues
    
def assign_queues(connect_instance_details, agent_skills, name):
    queue_configs = {}
    queue_config_ctr = 0
    queue_configs[queue_config_ctr] = []

    for queue_name in agent_skills:
        if queue_name:
            queue_id = util.get_queue_id(connect_instance_details['QueueSummaryList'], queue_name)
            (_, voice_mail) = util.get_queue_tags(connect_instance_details['QueueSummaryList'], queue_name)

            if queue_id != 'NOT FOUND':
                logger.info('Assigning to Queue: ' + queue_name + ' QUEUEID: ' + queue_id)
                if 'Email' in queue_name:
                    queue_config = util.get_queue_config(queue_id, 'CHAT', 3)
                    queue_configs[queue_config_ctr].append(queue_config)                        
                elif 'ToDo' in queue_name:
                    queue_config = util.get_queue_config(queue_id, 'TASK', 2)
                    queue_configs[queue_config_ctr].append(queue_config)                        
                else:
                    queue_config = util.get_queue_config(queue_id,'VOICE', 1)
                    queue_configs[queue_config_ctr].append(queue_config)

                if voice_mail == 'on':
                    queue_config = util.get_queue_config(queue_id, 'TASK', 2)
                    queue_configs[queue_config_ctr].append(queue_config)                            

                if len(queue_configs[queue_config_ctr]) == 10:
                    queue_config_ctr += 1
                    queue_configs[queue_config_ctr] = []
            else:
                logger.info(f"User: {name} is assigned to a non-existent queue: {queue_name}")

    return queue_configs

def add_queues_to_routing_profile(connect_client, connect_instance_details, rpID, queue_configs):
    logger.info("Adding Queues to Routing Profile")
    try:
        for queue_config in queue_configs:
            if len(queue_configs[queue_config]) != 0:
                connect_client.associate_routing_profile_queues(
                    InstanceId=connect_instance_details['instanceID'],
                    RoutingProfileId=rpID,
                    QueueConfigs=queue_configs[queue_config]
                )
    except Exception as ex1:
        logger.error(f"add_queues_to_routing_profile EXCEPTION: {str(ex1)}")

def remove_queues_from_routing_profile(connect_client, connect_instance_details, rpID, agent_skills, name):
    queue_references = []
    try:
        for queue_name in agent_skills:
            if queue_name:
                queue_id = util.get_queue_id(connect_instance_details['QueueSummaryList'], queue_name)
                (_, voice_mail) = util.get_queue_tags(connect_instance_details['QueueSummaryList'], queue_name)

                if queue_id != 'NOT FOUND':
                    logger.info(f"Removing Queue from Routing Profile: {queue_name} QUEUEID: {queue_id}")

                    if 'Email' in queue_name:
                        queue_ref = {}
                        queue_ref['QueueId'] = queue_id
                        queue_ref['Channel'] = 'CHAT'
                        queue_references.append(queue_ref)
                    elif 'ToDo' in queue_name:
                        queue_ref = {}
                        queue_ref['QueueId'] = queue_id
                        queue_ref['Channel'] = 'TASK'
                        queue_references.append(queue_ref)
                    else:
                        queue_ref = {}
                        queue_ref['QueueId'] = queue_id
                        queue_ref['Channel'] = 'VOICE'
                        queue_references.append(queue_ref)

                        if voice_mail == 'on':
                            queue_ref = {}
                            queue_ref['QueueId'] = queue_id
                            queue_ref['Channel'] = 'TASK'
                            queue_references.append(queue_ref)

                else:
                    logger.info(f"User: {name} was assigned to a non-existent queue: {queue_name}")

        if queue_references:
            connect_client.disassociate_routing_profile_queues(
                InstanceId=connect_instance_details['instanceID'],
                RoutingProfileId=rpID,
                QueueReferences=queue_references
            )

    except Exception as ex1:
        logger.error(f"remove_queues_from_routing_profile EXCEPTION: {str(ex1)}")

def add_quick_connect_to_queues(connect_client, connect_instance_details, assigned_queues, quick_connect_id):
    logger.info("Adding User Quick Connect to assigned queues")
    try:
        for queue_id in assigned_queues:
            connect_client.associate_queue_quick_connects(
                InstanceId=connect_instance_details['instanceID'],
                QueueId=queue_id,
                QuickConnectIds=[quick_connect_id]
            )

    except Exception as ex1:
        logger.error(f"add_quick_connect_to_queues EXCEPTION: {str(ex1)}")

def remove_quick_connect_from_queues(connect_client, connect_instance_details, assigned_queues, quick_connect_id):
    logger.info("Removing User Quick Connect from previous queues")
    try:
        for queue_id in assigned_queues:
            connect_client.disassociate_queue_quick_connects(
                InstanceId=connect_instance_details['instanceID'],
                QueueId=queue_id,
                QuickConnectIds=[quick_connect_id]
            )

    except Exception as ex1:
        logger.error(f"remove_quick_connect_from_queues EXCEPTION: {str(ex1)}")

def add_language_proficiency(connect_client, connect_instance_details, user_id, lang, ou):
    language_name = tenants.get_language_name(ou, lang)
    logger.info(f"Adding Language Proficiency: {language_name}")
    
    try:
        connect_client.associate_user_proficiencies(
            InstanceId=connect_instance_details['instanceID'],
            UserId=user_id,
            UserProficiencies=[
                {
                    'AttributeName': 'connect:Language',
                    'AttributeValue': f"connect:{language_name}",
                    'Level': 5
                },
            ]
        )
    except Exception as ex1:
        logger.error(f"add_language_proficiency EXCEPTION: {str(ex1)}")    

def remove_language_proficiency(connect_client, connect_instance_details, user_id, lang, ou):
    language_name = tenants.get_language_name(ou, lang)
    logger.info(f"Removing Language Proficiency: {language_name}")
    try:
        connect_client.disassociate_user_proficiencies(
            InstanceId=connect_instance_details['instanceID'],
            UserId=user_id,
            UserProficiencies=[
                {
                    'AttributeName': 'connect:Language',
                    'AttributeValue': f"connect:{language_name}"
                },
            ]
        )
    except Exception as ex1:
        logger.error(f"remove_language_proficiency EXCEPTION: {str(ex1)}")    

def update_user_name(connect_client, connect_instance_details, name, user_id, routing_profile_id, qc_id):
    logger.info(f"Updating Name for user: {name}")
    last_name, first_name = [part.strip() for part in name.split(",", 1)]

    try:
        connect_client.update_user_identity_info(
            IdentityInfo={
                'FirstName': first_name,
                'LastName': last_name
            },
            UserId=user_id,
            InstanceId=connect_instance_details['instanceID']
        )
    
        connect_client.update_routing_profile_name(
            InstanceId=connect_instance_details['instanceID'],
            RoutingProfileId=routing_profile_id,
            Name=name,
            Description=f"Routing Profile for {name}" 
        )
        print("Routing Profile updated successfully.")

        connect_client.update_quick_connect_name(
            InstanceId=connect_instance_details['instanceID'],
            QuickConnectId=qc_id,
            Name=name,
            Description='Created by Ignite'
        )

    except Exception as ex1:
        print(f"update_user_name EXCEPTION: {ex1}")

def load_users_from_S3(s3FileName):
    user_records = util.read_csv(s3FileName, 'email', '')
    
    try:
        table = boto3.resource('dynamodb', region_name=config.region).Table('Users')
 
        for record in user_records:
            logger.info('INSERTING NEW AGENT RECORD: ' + user_records[record]['email'])
            table.put_item(Item= {'Email': user_records[record]['email'], 
                'Name': user_records[record]['name'], 
                'Role': json.loads(user_records[record]['role']), 
                'Priority': json.loads(user_records[record]['priority'])})

    except Exception as ex1:
        logger.info('load_users_from_S3 EXCEPTION: ' + str(ex1))

def get_users(ou, tenant_id):
    user_list = []
    logger.info("GETTING USER LIST")
    dynamodb_client = boto3.client('dynamodb', region_name=config.region)
    try:
        response = dynamodb_client.scan(
            TableName='Users-' + ou
        )
        logger.info("DB RESPONSE: " + str(response))

        for user in response['Items']:
            if user['Tenant']['S'] == tenant_id:
                user_list.append({
                    "FirstName" : user['Name']['S'][user['Name']['S'].find(',') + 1:],
                    "LastName" : user['Name']['S'][0:user['Name']['S'].find(',')],
                    "Languages": json.loads(user['Languages']['S']),
                    "Email" : user['Email']['S'],
                    "Role": json.loads(user['Role']['S']),
                    "Priority": json.loads(user['Priority']['S']),
                    "QueueId": user.get('QueueId', {}).get('S'),
                    "Extension": user.get('Extension', {}).get('S')
                })
    
    except Exception as Ex1:
        logger.info("get_users EXCEPTION: " + str(Ex1))

    return(user_list)

def get_roles(connect_client, connect_id):
    security_profiles = {}
    permissions = []
    
    roles_list = []
    get_roles_response = connect_client.list_security_profiles(
        InstanceId=connect_id
    )

    permissions_record = {}
    for role in get_roles_response['SecurityProfileSummaryList']:
        roles_list.append(role['Name'])

        get_permissions_response = connect_client.list_security_profile_permissions(
            SecurityProfileId=role['Id'],
            InstanceId=connect_id
            #NextToken='string',
            #MaxResults=123
        )
        permissions_record[role['Name']] = []
        for permission in get_permissions_response['Permissions']:
            permissions_record[role['Name']].append(permission)

    security_profiles['roles'] = roles_list
    security_profiles['permissions'] = permissions_record

    return(security_profiles)

def create_user(ou, tenant_id, email, first_name, last_name, languages, role, priority, password):
    full_name = last_name.replace(" ", "") + ", " + first_name.replace(" ", "")
    try:
        if password:
            secret_client = boto3.client('secretsmanager', region_name=config.region)
            secret_client.create_secret(
                Name=email,
                SecretString=password
            )

        table = boto3.resource('dynamodb', region_name=config.region).Table('Users-' + ou)

        if not languages:
            languages = ['en-US']
        
        if not role:
            role = ['Agent']

        table.put_item(Item= {'Email': email, 
            'Languages': json.dumps(languages), 
            'Name':full_name, 
            'Priority': json.dumps(priority), 
            'Role': json.dumps(role),
            'Tenant': tenant_id,
            'QueueId':'',
            'Extension':''
        })

    except Exception as ex1:
        logger.info('create_user EXCEPTION FOUND: ' + str(ex1))

def update_user(ou, tenant_id, email, first_name, last_name, languages, role, priority, password):
    full_name = last_name.replace(" ", "") + ", " + first_name.replace(" ", "")
    try:
        if password:
            secret_client = boto3.client('secretsmanager', region_name=config.region)

            list_secrets_response = secret_client.list_secrets(
                MaxResults=1,
                Filters=[
                    {
                        'Key': 'name',
                        'Values': [
                            email
                        ]
                    },
                ]
            )

            secret_client.update_secret(
                SecretId=list_secrets_response['SecretList'][0]['ARN'],
                SecretString=password
            )

        table = boto3.resource('dynamodb', region_name=config.region).Table('Users-' + ou)

        table.update_item(
                Key = {
                    'Email': email
                },
                UpdateExpression='SET #attr1 = :val1, #attr2 = :val2, #attr3 = :val3, #attr4 = :val4, #attr5 = :val5',
                ExpressionAttributeNames={'#attr1': 'Languages', '#attr2': 'Name', '#attr3': 'Priority', '#attr4': 'Role', '#attr5': 'Tenant'},
                ExpressionAttributeValues={':val1': json.dumps(languages), ':val2': full_name, ':val3': json.dumps(priority), ':val4': json.dumps(role), ':val5': tenant_id}
            )
    except Exception as ex1:
        logger.info('update_user EXCEPTION FOUND: ' + str(ex1))   

def delete_user(ou, email):
    try:
        table = boto3.resource('dynamodb', region_name=config.region).Table('Users-' + ou)
        table.delete_item(Key={"Email": email})

    except Exception as ex1:
        status = 'delete_user EXCEPTION FOUND: ' + str(ex1)
        logger.info(status)

def add_user_queue_extension(ou, email, queue_arn, extension):
    try:
        table = boto3.resource('dynamodb', region_name=config.region).Table(f"Users-{ou}")

        table.update_item(
                Key = {
                    'Email': email
                },
                UpdateExpression='SET #attr1 = :val1, #attr2 = :val2',
                ExpressionAttributeNames={'#attr1': 'QueueId', '#attr2': 'Extension'},
                ExpressionAttributeValues={':val1': queue_arn, ':val2': extension}
            )
        
    except Exception as ex1:
        logger.info('add_user_queue_extension EXCEPTION FOUND: ' + str(ex1))   

def load_users(ou, tenant_id, contents):
    user_records = {}
    csv_reader = csv.DictReader(contents)

    for rows in csv_reader:
        record = rows['Email']
        user_records[record] = rows
    
    try:
        table = boto3.resource('dynamodb', region_name=config.region).Table('Users-' + ou)
 
        for record in user_records:
            logger.info('INSERTING NEW AGENT RECORD: ' + user_records[record]['Email'])
            table.put_item(Item= {'Email': user_records[record]['Email'], 
                'Name': user_records[record]['LastName'] + ',' + user_records[record]['FirstName'], 
                'Role': json.dumps(user_records[record]['Role']),
                'Languages': json.dumps(user_records[record]['Languages']),
                'Tenant': tenant_id,  
                'Priority': json.dumps(user_records[record]['Priority'])})

    except Exception as ex1:
        logger.info('load_users EXCEPTION: ' + str(ex1))

def deploy_users(source_ou, target_ou, tenant_id):
    dynamodb_client = boto3.client('dynamodb')
    source_response = dynamodb_client.scan(TableName='Users-' + source_ou)
    target_table = boto3.resource('dynamodb', region_name=config.region).Table('Users-' + target_ou)

    for item in source_response['Items']:
        if item.get('Tenant')['S'] == tenant_id:
            logger.info('DEPLOYING USER RECORD: ' + item.get('Email')['S'])
            target_table.put_item(Item= {'Email': item.get('Email')['S'], 
                'Name': item.get('Name')['S'], 
                'Role': item.get('Role')['S'],
                'Languages': item.get('Languages')['S'],
                'Tenant': tenant_id,  
                'Priority': item.get('Priority')['S']})

def get_group_hierarchy(connect_client, connect_id):
    #list_user_hierarchy_groups_response = connect_client.list_user_hierarchy_groups(
    #    InstanceId=connect_id
    #)

    #hierarchy_groups = []
    #for hierarchy_group in list_user_hierarchy_groups_response['UserHierarchyGroupSummaryList']:
    #    group_info={}
    #    group_info['Name']=hierarchy_group['Name']
    #    group_info['Id']=hierarchy_group['Id']
    #    hierarchy_groups.append(group_info)

    #return(hierarchy_groups)    

    describe_user_hierarchy_structure_response = connect_client.describe_user_hierarchy_structure(
        InstanceId=connect_id
    )    

    print(describe_user_hierarchy_structure_response)

    describe_user_hierarchy_group_response = connect_client.describe_user_hierarchy_group(
        HierarchyGroupId='4feb03f5-08f3-429c-994d-fd05e9e07c49',
        InstanceId=connect_id
    )

    print(describe_user_hierarchy_group_response)

def get_connect_users(connect_client, connect_id):
    users = []
    list_users = []
    next_token = None
    while True:
        params = {'InstanceId': connect_id, 'MaxResults': 100}
        if next_token:
            params['NextToken'] = next_token
        response = connect_client.list_users(**params)

        users.extend(response['UserSummaryList'])
        next_token = response.get('NextToken')
        if not next_token:
            break

    for user in users:
        user_data = {}
        user_data['Id'] = user['Id']
        describe_user_response = connect_client.describe_user(
            UserId=user['Id'],
            InstanceId=connect_id
        )
        user_data['routing_profile_id'] = describe_user_response['User']['RoutingProfileId']

        describe_routing_profile_response = connect_client.describe_routing_profile(
            InstanceId=connect_id,
            RoutingProfileId=user_data['routing_profile_id']
        )

        if describe_routing_profile_response['RoutingProfile']['Name'] != 'Basic Routing Profile':
            user_data['routing_profile_name'] = describe_routing_profile_response['RoutingProfile']['Name']
            list_routing_profile_queues_response = connect_client.list_routing_profile_queues(
                InstanceId=connect_id,
                RoutingProfileId=user_data['routing_profile_id']
            )
            user_data['associated_queues'] = []
            for rp in list_routing_profile_queues_response['RoutingProfileQueueConfigSummaryList']:
                if rp['QueueName'] != 'BasicQueue' and '- ToDo' not in rp['QueueName'] and '- Email' not in rp['QueueName']:
                    user_data['associated_queues'].append(rp['QueueId'])
            list_users.append(user_data)   
  
    return (list_users)

def get_quick_connects(connect_client, connect_id):
    quick_connects = []
    next_token = None
    while True:
        params = {'InstanceId': connect_id, 'MaxResults': 100, 'QuickConnectTypes':['USER']}
        if next_token:
            params['NextToken'] = next_token
        response = connect_client.list_quick_connects(**params)
        quick_connects.extend(response['QuickConnectSummaryList'])
        next_token = response.get('NextToken')
        if not next_token:
            break
    
    qc_output = json.dumps(quick_connects, default=custom_serializer, indent=2)
    quick_connects = json.loads(qc_output)

    return (quick_connects)

def get_queue_quick_connects(connect_client, connect_id, queue_id):
    output_list = []
    queue_quick_connects = []
    next_token = None
    while True:
        params = {'InstanceId': connect_id, 'QueueId':queue_id, 'MaxResults': 100}
        if next_token:
            params['NextToken'] = next_token
        response = connect_client.list_queue_quick_connects(**params)
        queue_quick_connects.extend(response['QuickConnectSummaryList'])
        next_token = response.get('NextToken')
        if not next_token:
            break

    for qc in queue_quick_connects:
        output_list.append(qc['Id'])

    return (output_list)

def create_user_quick_connects(connect_client, connect_id, connect_instance_details):
    existing_qc_names = {}
    users = get_connect_users(connect_client, connect_id)
    quick_connects = get_quick_connects(connect_client, connect_id)
    for qc in quick_connects:
        existing_qc_names[qc['Name']] = qc['Id']
    
    print(existing_qc_names)

    for user in users:
        routing_profile_name = user['routing_profile_name']
        if f"{routing_profile_name}" not in existing_qc_names:
            print(f"Creating Quick Connect for {routing_profile_name}")
            create_quick_connect_response = connect_client.create_quick_connect(
                InstanceId=connect_id,
                Name=routing_profile_name,
                Description="Created by Ignite",
                QuickConnectConfig={
                    'QuickConnectType': 'USER',
                    'UserConfig': {
                        'UserId': user['Id'],
                        'ContactFlowId': connect_instance_details['agentTransferFlowID']
                    }
                }
            )
            qc_id = create_quick_connect_response['QuickConnectId']
        else:
            print(f"Quick Connect already exists for user: {routing_profile_name}")
            qc_id = existing_qc_names[routing_profile_name]

        print(f"{routing_profile_name} QUEUES: {user['associated_queues']}")
        for associated_queue in user['associated_queues']:
            queue_quick_connects = get_queue_quick_connects(connect_client, connect_id, associated_queue)
            
            if qc_id not in queue_quick_connects:     
                queue_quick_connects.append(qc_id)
            
            if queue_quick_connects:
                print(f"Associating Quick Connects: {queue_quick_connects}")

            try:
                for chunk in util.chunk_list(queue_quick_connects,50):
                    connect_client.associate_queue_quick_connects(
                        InstanceId=connect_id,
                        QueueId=associated_queue,
                        QuickConnectIds=chunk
                    )
                time.sleep(1)
            except Exception as ex1:
                logger.info("associate_queue_quick_connects EXCEPTION: " + str(ex1))

def custom_serializer(obj):
    from datetime import datetime
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Type {type(obj)} not serializable")