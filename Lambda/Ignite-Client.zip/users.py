import json
import boto3
import util
import csv
import tenants
import instances
import os

def remove_user_record(event, connect_client, connect_instance_details, ou, event_type):
    old_image = event['Records'][0]['dynamodb']['OldImage']
    
    name = old_image['Name']['S']
    email = old_image['Email']['S']
    tenant_id = old_image['Tenant']['S']
    list_tenants = instances.get_tenants(ou)

    instance_type = ''
    for tenant in list_tenants:
        if tenant_id == tenant['id']:
            instance_type = tenant['instance_type']

    try:
        #role = old_image['role']['L']
        role = json.loads(old_image['Role']['S'])
    except:
        role = []
    try:
        #agent_skills = old_image['priority']['M']['levels']['M']
        agent_skills = json.loads(old_image['Priority']['S'])
    except:
        agent_skills = {}
        
    user_id = util.get_user_id(connect_instance_details['userList'], email)
    util.logger('REMOVING AGENT: ' + name + ' EMAIL: ' + email + ' ROLE: ' + json.dumps(role) + ' QUEUE: ' + json.dumps(agent_skills))
    remove_connect_user_profile(connect_client, connect_instance_details, name, email, user_id, event_type, instance_type)
    
def insert_user_record(event, connect_client, connect_instance_details, ou):
    dynamodb_client = boto3.client('dynamodb')
    #Set Languages
    #english = '_En'
    #french = '_Fr'
    #spanish = '_Es'
    #portuguese = '_Pt'
    
    #Get all company abbreviations
    temp_list = []
    response = dynamodb_client.scan(TableName='Tenants-' + ou)
    for item in response['Items']:
        temp_list.append(item.get('Tenant')['S'])
        quick_connects = json.loads(item.get('Queues')['S'])
        for quick_connect in quick_connects:
            if not quick_connect.replace("+","").isnumeric():
                temp_list.append(quick_connect)        
    queues = []
    for i in temp_list:
        if i not in queues:
            queues.append(i)
    
    new_image = event['Records'][0]['dynamodb']['NewImage']
    name = new_image['Name']['S']
    email = new_image['Email']['S']
    tenant_id = new_image['Tenant']['S']
    list_tenants = instances.get_tenants(ou)

    instance_type = ''
    for tenant in list_tenants:
        if tenant_id == tenant['id']:
            instance_type = tenant['instance_type']

    languages = json.loads(new_image['Languages']['S'])

    try:
        #role = new_image['Role']['L']
        role = json.loads(new_image['Role']['S'])
    except:
        role = []
    try:
        #agent_skills = new_image['priority']['M']['levels']['M']
        agent_skills = json.loads(new_image['Priority']['S'])
    except:
        agent_skills = {}
        
    util.logger('ADDING AGENT: ' + name + ' EMAIL: ' + email + ' ROLE: ' + json.dumps(role) + ' QUEUE: ' + json.dumps(agent_skills))

    security_profiles = util.get_security_profiles(connect_instance_details['securityProfileList'], role)

    queue_configs = {}
    queue_config_ctr = 0
    queue_configs[queue_config_ctr] = []
    assigned_queues = []

    
    for skill in agent_skills:
        found = False
        for queue_prefix in queues:
            if skill.find(queue_prefix) != -1:
                found = True
        if not found:
            util.logger('User: ' + name + ' is assigned to a non-existent queue: ' + skill)
	
    for queue_prefix in queues:
        for skill in agent_skills:
            for language in languages:
                #language_abbrev = '_' + language[0].upper() + language[1].lower()
                language_name = tenants.get_language_name(ou, language)
                if skill.find(queue_prefix) != -1:
                    queue_id = util.get_queue_id(connect_instance_details['QueueSummaryList'], queue_prefix + ' ' + language_name)
                    if queue_id != 'NOT FOUND':
                        util.logger('Assigning to Queue: ' + queue_prefix + ' ' + language_name + ' QUEUEID: ' + queue_id)
                        queue_config = util.get_queue_config(queue_id,'VOICE', agent_skills[skill])
                        queue_configs[queue_config_ctr].append(queue_config)
                        queue_config = util.get_queue_config(queue_id, 'TASK', agent_skills[skill])
                        queue_configs[queue_config_ctr].append(queue_config)
                        if len(queue_configs[queue_config_ctr]) == 10:
                            queue_config_ctr += 1
                            queue_configs[queue_config_ctr] = []
                        assigned_queues.append(queue_id)
                    else:
                        util.logger('User: ' + name + ' is assigned to a non-existent queue: ' + queue_prefix + ' ' + language_name)
        '''

                    break
        for skill in agent_skills:
            if skill.find(queue_prefix) != -1 and skill.find(french) != -1:
                queue_id = util.get_queue_id(connect_instance_details['QueueSummaryList'], queue_prefix + french)
                if queue_id != 'NOT FOUND':
                    util.logger('Assigning to Queue: ' + queue_prefix + french + ' QUEUEID: ' + queue_id)
                    queue_config = util.get_queue_config(queue_id, 'VOICE', agent_skills[skill])
                    queue_configs[queue_config_ctr].append(queue_config)                     			
                    queue_config = util.get_queue_config(queue_id, 'TASK', agent_skills[skill])
                    queue_configs[queue_config_ctr].append(queue_config)
                    if len(queue_configs[queue_config_ctr]) == 10:
                        queue_config_ctr += 1
                        queue_configs[queue_config_ctr] = []
                    assigned_queues.append(queue_id)
                else:
                    util.logger('User: ' + name + ' is assigned to a non-existent queue: ' + queue_prefix + french)
                break
        for skill in agent_skills:
            if skill.find(queue_prefix) != -1 and skill.find(spanish) != -1:
                queue_id = util.get_queue_id(connect_instance_details['QueueSummaryList'], queue_prefix + spanish)
                if queue_id != 'NOT FOUND':
                    util.logger('Assigning to Queue: ' + queue_prefix + spanish + ' QUEUEID: ' + queue_id)
                    queue_config = util.get_queue_config(queue_id, 'VOICE', agent_skills[skill])
                    queue_configs[queue_config_ctr].append(queue_config)     
                    queue_config = util.get_queue_config(queue_id, 'TASK', agent_skills[skill])
                    queue_configs[queue_config_ctr].append(queue_config)
                    if len(queue_configs[queue_config_ctr]) == 10:
                        queue_config_ctr += 1
                        queue_configs[queue_config_ctr] = []
                    assigned_queues.append(queue_id)
                else:
                    util.logger('User: ' + name + ' is assigned to a non-existent queue: ' + queue_prefix + spanish)
                break
        for skill in agent_skills:
            if skill.find(queue_prefix) != -1 and skill.find(portuguese) != -1:
                queue_id = util.get_queue_id(connect_instance_details['QueueSummaryList'], queue_prefix + portuguese)
                if queue_id != 'NOT FOUND':
                    util.logger('Assigning to Queue: ' + queue_prefix + portuguese + ' QUEUEID: ' + queue_id)
                    queue_config = util.get_queue_config(queue_id, 'VOICE', agent_skills[skill])
                    queue_configs[queue_config_ctr].append(queue_config)     
                    queue_config = util.get_queue_config(queue_id, 'TASK', agent_skills[skill])
                    queue_configs[queue_config_ctr].append(queue_config)
                    if len(queue_configs[queue_config_ctr]) == 10:
                        queue_config_ctr += 1
                        queue_configs[queue_config_ctr] = []
                    assigned_queues.append(queue_id)
                else:
                    util.logger('User: ' + name + ' is assigned to a non-existent queue: ' + queue_prefix + portuguese)
                break
        '''

    if len(queue_configs) == 1 and queue_config_ctr == 0:
        queue_id = util.get_queue_id(connect_instance_details['QueueSummaryList'], 'BasicQueue')
        queue_config = util.get_queue_config(queue_id, 'VOICE', 1)
        queue_configs[0].append(queue_config)

    result = create_connect_user_profile(connect_client, connect_instance_details, name, email, security_profiles, queue_configs[0], instance_type)

    #Can only add 10 queue_configs per request.
    if len(queue_configs) > 1:
        for queue_config in queue_configs:
            if queue_config != 0:
                if len(queue_configs[queue_config]) != 0:
                    add_queue_to_rp(connect_client, connect_instance_details, result['rpID'], queue_configs[queue_config])
                
    try:
        for queue in assigned_queues:
            response = connect_client.associate_queue_quick_connects(
                InstanceId=connect_instance_details['instanceID'],
                QueueId=queue,
                QuickConnectIds=[result['qcID']]
            )
    except Exception as ex1:
        util.logger('insert_user_record EXCEPTION: ' + str(ex1))
        
def remove_connect_user_profile(connect_client, connect_instance_details, name, email, userID, event_type, instance_type):
    try:
        connect_client.delete_user(
            InstanceId=connect_instance_details['instanceID'],
            UserId=userID
        )
    
        #routing_profile_name = email.split('@')[0] + '-RP'
        routing_profile_name = name + ' RP'

        routing_profile_id = util.get_routing_profile_id(connect_instance_details['routingProfileList'], routing_profile_name)

        connect_client.delete_routing_profile(
            InstanceId=connect_instance_details['instanceID'],
            RoutingProfileId=routing_profile_id
        )    

        qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], name)

        connect_client.delete_quick_connect(
            InstanceId=connect_instance_details['instanceID'],
            QuickConnectId=qc_id
        )

        if instance_type == 'CONNECT_MANAGED' and event_type == 'REMOVE':
            secret_client = boto3.client('secretsmanager')
            list_secrets_response = secret_client.list_secrets(
                MaxResults=1,
                Filters=[
                    {
                        'Key': 'name',
                        'Values': [
                            email
                        ]
                    },
                ]
            )

            secret_client.delete_secret(
                SecretId=list_secrets_response['SecretList'][0]['ARN'],
                ForceDeleteWithoutRecovery=True
            )            

    except Exception as ex1:
        util.logger('remove_connect_user_profile EXCEPTION: ' + str(ex1))
    
def create_connect_user_profile(connect_client, connect_instance_details, name, email, security_profiles, queue_configs, instance_type):
    qc_id = ''
    if name.find(',') != -1:
        full_name = name.split(',')
        first_name = full_name[1]
        last_name = full_name[0]
    else:
        full_name = name.split(' ')
        first_name = full_name[1]
        last_name = full_name[0]
    
    try:
        response = connect_client.create_routing_profile(
            InstanceId=connect_instance_details['instanceID'], 
            #Name=''.join(name.split()).replace(',','-') + '-RP',
            Name=name + ' RP',
            Description='Routing Profile for ' + name,
            DefaultOutboundQueueId=connect_instance_details['outboundQueueID'],
            QueueConfigs= queue_configs,
            MediaConcurrencies=[
                {
                    'Channel': 'VOICE',
                    'Concurrency': 1,
                    'CrossChannelBehavior': {
                        'BehaviorType': 'ROUTE_CURRENT_CHANNEL_ONLY'
                    }
                },
                {
                    'Channel': 'TASK',
                    'Concurrency': 1,
                    'CrossChannelBehavior': {
                        'BehaviorType': 'ROUTE_CURRENT_CHANNEL_ONLY'
                    }
                }                
            ],
        )
        routing_profile_id = response['RoutingProfileId']
        
    except Exception as ex1:
        util.logger('create_routing_profile EXCEPTION: ' + str(ex1))
        routing_profile_name = name + ' RP'
        routing_profile_id = util.get_routing_profile_id(connect_instance_details['routingProfileList'], routing_profile_name)

    try:
        if instance_type == 'CONNECT_MANAGED':
            secret_client = boto3.client('secretsmanager')
            list_secrets_response = secret_client.list_secrets(
                MaxResults=1,
                Filters=[
                    {
                        'Key': 'name',
                        'Values': [
                            email
                        ]
                    },
                ]
            )            

            retrieve_response = secret_client.get_secret_value(
                SecretId=list_secrets_response['SecretList'][0]['ARN']
            )

            response = connect_client.create_user(
                Username=email,
                Password=retrieve_response['SecretString'],
                IdentityInfo={
                    'FirstName': first_name,
                    'LastName': last_name,
                },
                PhoneConfig={
                    'PhoneType': 'SOFT_PHONE',
                    'AutoAccept': False,
                    'AfterContactWorkTimeLimit': 10
                },
                SecurityProfileIds= security_profiles,
                RoutingProfileId=routing_profile_id,
                InstanceId=connect_instance_details['instanceID']
            )
        else:
            response = connect_client.create_user(
                Username=email,
                IdentityInfo={
                    'FirstName': first_name,
                    'LastName': last_name,
                },
                PhoneConfig={
                    'PhoneType': 'SOFT_PHONE',
                    'AutoAccept': False,
                    'AfterContactWorkTimeLimit': 10
                },
                SecurityProfileIds= security_profiles,
                RoutingProfileId=routing_profile_id,
                InstanceId=connect_instance_details['instanceID']
            )

        userID = response['UserId']

        response = connect_client.create_quick_connect(
            InstanceId=connect_instance_details['instanceID'],
            Name= name,
            Description='Created by Ignite',
            QuickConnectConfig={
                'QuickConnectType': 'USER',
                'UserConfig': {
                    'UserId': userID,
                    'ContactFlowId': connect_instance_details['agentTransferFlowID']
                }
            }
        )

        qc_id = response['QuickConnectId']
        
    except Exception as ex1:
        util.logger('create_user EXCEPTION: ' + str(ex1))

    #return(qc_id)
    return {
        'rpID': routing_profile_id,
        'qcID': qc_id
    }

def add_queue_to_rp(connect_client, connect_instance_details,rpID, queue_configs):
    util.logger("ADDING QUEUES TO ROUTING PROFILE")
    try:
        connect_client.associate_routing_profile_queues(
            InstanceId=connect_instance_details['instanceID'],
            RoutingProfileId=rpID,
            QueueConfigs=queue_configs
        )
    except Exception as ex1:
        util.logger('add_queue_to_rp EXCEPTION: ' + str(ex1))
        
def load_users_from_S3(s3FileName):

    user_records = util.read_csv(s3FileName, 'email', '')
    
    try:
        table = boto3.resource('dynamodb').Table('Users')
 
        for record in user_records:
            util.logger('INSERTING NEW AGENT RECORD: ' + user_records[record]['email'])
            table.put_item(Item= {'Email': user_records[record]['email'], 
                'Name': user_records[record]['name'], 
                'Role': json.loads(user_records[record]['role']), 
                'Priority': json.loads(user_records[record]['priority'])})

    except Exception as ex1:
        util.logger('load_users_from_S3 EXCEPTION: ' + str(ex1))

def get_users(ou, tenant_id):
    user_list = []
    util.logger("GETTING USER LIST")
    dynamodb_client = boto3.client('dynamodb')
    try:
        response = dynamodb_client.scan(
            TableName='Users-' + ou
        )
        util.logger("DB RESPONSE: " + str(response))

        for user in response['Items']:
            if user['Tenant']['S'] == tenant_id:
                user_list.append({
                    "FirstName" : user['Name']['S'][user['Name']['S'].find(',') + 1:],
                    "LastName" : user['Name']['S'][0:user['Name']['S'].find(',')],
                    "Languages": json.loads(user['Languages']['S']),
                    "Email" : user['Email']['S'],
                    "Role": json.loads(user['Role']['S']),
                    "Priority": json.loads(user['Priority']['S'])
                })
    
    except Exception as Ex1:
        util.logger("get_users EXCEPTION: " + str(Ex1))

    return(user_list)

def get_roles(connect_client, connect_id):
    security_profiles = {}
    permissions = []
    
    roles_list = []
    get_roles_response = connect_client.list_security_profiles(
        InstanceId=connect_id
    )

    permissions_record = {}
    for role in get_roles_response['SecurityProfileSummaryList']:
        roles_list.append(role['Name'])

        get_permissions_response = connect_client.list_security_profile_permissions(
            SecurityProfileId=role['Id'],
            InstanceId=connect_id
            #NextToken='string',
            #MaxResults=123
        )
        permissions_record[role['Name']] = []
        for permission in get_permissions_response['Permissions']:
            permissions_record[role['Name']].append(permission)

    security_profiles['roles'] = roles_list
    security_profiles['permissions'] = permissions_record

    return(security_profiles)

def create_user(ou, tenant_id, email, first_name, last_name, languages, role, priority, password):
    full_name = last_name + ", " + first_name
    try:
        if password:
            secret_client = boto3.client('secretsmanager')
            secret_client.create_secret(
                Name=email,
                SecretString=password
            )

        table = boto3.resource('dynamodb').Table('Users-' + ou)

        table.put_item(Item= {'Email': email, 
            'Languages': json.dumps(languages), 
            'Name':full_name, 
            'Priority': json.dumps(priority), 
            'Role': json.dumps(role),
            'Tenant': tenant_id
        })

    except Exception as ex1:
        util.logger('create_user EXCEPTION FOUND: ' + str(ex1))     
  


def update_user(ou, tenant_id, email, first_name, last_name, languages, role, priority, password):
    full_name = last_name.replace(" ", "") + "," + first_name.replace(" ", "")
    try:
        if password:
            secret_client = boto3.client('secretsmanager')

            list_secrets_response = secret_client.list_secrets(
                MaxResults=1,
                Filters=[
                    {
                        'Key': 'name',
                        'Values': [
                            email
                        ]
                    },
                ]
            )

            secret_client.update_secret(
                SecretId=list_secrets_response['SecretList'][0]['ARN'],
                SecretString=password
            )

        table = boto3.resource('dynamodb').Table('Users-' + ou)

        table.update_item(
                Key = {
                    'Email': email
                },
                UpdateExpression='SET #attr1 = :val1, #attr2 = :val2, #attr3 = :val3, #attr4 = :val4, #attr5 = :val5',
                ExpressionAttributeNames={'#attr1': 'Languages', '#attr2': 'Name', '#attr3': 'Priority', '#attr4': 'Role', '#attr5': 'Tenant'},
                ExpressionAttributeValues={':val1': json.dumps(languages), ':val2': full_name, ':val3': json.dumps(priority), ':val4': json.dumps(role), ':val5': tenant_id}
            )
    except Exception as ex1:
        util.logger('update_user EXCEPTION FOUND: ' + str(ex1))   

def delete_user(ou, email):
    try:
        table = boto3.resource('dynamodb').Table('Users-' + ou)
        table.delete_item(Key={"Email": email})
    except Exception as ex1:
        status = 'delete_user EXCEPTION FOUND: ' + str(ex1)
        util.logger(status)

def load_users(ou, tenant_id, contents):
    user_records = {}
    csv_reader = csv.DictReader(contents)

    for rows in csv_reader:
        record = rows['Email']
        user_records[record] = rows
    
    try:
        table = boto3.resource('dynamodb').Table('Users-' + ou)
 
        for record in user_records:
            util.logger('INSERTING NEW AGENT RECORD: ' + user_records[record]['Email'])
            table.put_item(Item= {'Email': user_records[record]['Email'], 
                'Name': user_records[record]['LastName'] + ',' + user_records[record]['FirstName'], 
                'Role': json.dumps(user_records[record]['Role']),
                'Languages': json.dumps(user_records[record]['Languages']),
                'Tenant': tenant_id,  
                'Priority': json.dumps(user_records[record]['Priority'])})

    except Exception as ex1:
        util.logger('load_users EXCEPTION: ' + str(ex1))

def deploy_users(source_ou, target_ou, tenant_id):
    dynamodb_client = boto3.client('dynamodb')
    source_response = dynamodb_client.scan(TableName='Users-' + source_ou)
    target_table = boto3.resource('dynamodb').Table('Users-' + target_ou)

    for item in source_response['Items']:
        if item.get('Tenant')['S'] == tenant_id:
            util.logger('DEPLOYING USER RECORD: ' + item.get('Email')['S'])
            target_table.put_item(Item= {'Email': item.get('Email')['S'], 
                'Name': item.get('Name')['S'], 
                'Role': item.get('Role')['S'],
                'Languages': item.get('Languages')['S'],
                'Tenant': tenant_id,  
                'Priority': item.get('Priority')['S']})
         