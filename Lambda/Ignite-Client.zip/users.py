import json
import boto3
import util

def remove_user_record(event, connect_client, connect_instance_details):
    old_image = event['Records'][0]['dynamodb']['OldImage']
    
    name = old_image['name']['S']
    email = old_image['email']['S']

    try:
        role = old_image['role']['L']
    except:
        role = []
    try:
        agent_skills = old_image['priority']['M']['levels']['M']
    except:
        agent_skills = {}
        
    user_id = util.get_user_id(connect_instance_details['userList'], email)
    util.logger('REMOVING AGENT: ' + name + ' EMAIL: ' + email + ' ROLE: ' + json.dumps(role) + ' QUEUE: ' + json.dumps(agent_skills))
    remove_connect_user_profile(connect_client, connect_instance_details, name, email, user_id)
    
def insert_user_record(event, connect_client, connect_instance_details):
    dynamodb_client = boto3.client('dynamodb')
    #Set Languages
    english = '_En'
    french = '_Fr'
    spanish = '_Es'
    portuguese = '_Pt'
    
    #Get all company abbreviations
    temp_list = []
    response = dynamodb_client.scan(TableName='Tenants')
    for item in response['Items']:
        temp_list.append(item.get('Tenant')['S'])
        quick_connects = json.loads(item.get('Queues')['S'])
        for quick_connect in quick_connects:
            if not quick_connect.replace("+","").isnumeric():
                temp_list.append(quick_connect)        
    tenants = []
    for i in temp_list:
        if i not in tenants:
            tenants.append(i)
    
    new_image = event['Records'][0]['dynamodb']['NewImage']
    name = new_image['Name']['S']
    email = new_image['Email']['S']
    try:
        role = new_image['Role']['L']
    except:
        role = []
    try:
        agent_skills = new_image['priority']['M']['levels']['M']
    except:
        agent_skills = {}
        
    util.logger('ADDING AGENT: ' + name + ' EMAIL: ' + email + ' ROLE: ' + json.dumps(role) + ' QUEUE: ' + json.dumps(agent_skills))

    security_profiles = util.get_security_profiles(connect_instance_details['securityProfileList'], role)

    queue_configs = {}
    queue_config_ctr = 0
    queue_configs[queue_config_ctr] = []
    assigned_queues = []

    
    for skill in agent_skills:
        found = False
        for queue_prefix in tenants:
            if skill.find(queue_prefix) != -1:
                found = True
        if not found:
            if skill != "wrapTimer":
                util.logger('User: ' + name + ' is assigned to a non-existent queue: ' + skill)
	
    for queue_prefix in tenants:
        for skill in agent_skills:
            if skill.find(queue_prefix) != -1 and skill.find(english) != -1:
                queue_id = util.get_queue_id(connect_instance_details['queueList'], queue_prefix + 'GEN' + english)
                if queue_id != 'NOT FOUND':
                    util.logger('Assigning to Queue: ' + queue_prefix + 'GEN' + english + ' QUEUEID: ' + queue_id)
                    queue_config = util.get_queue_config(queue_id,'VOICE')
                    queue_configs[queue_config_ctr].append(queue_config)
                    queue_config = util.get_queue_config(queue_id, 'TASK')
                    queue_configs[queue_config_ctr].append(queue_config)
                    if len(queue_configs[queue_config_ctr]) == 10:
                        queue_config_ctr += 1
                        queue_configs[queue_config_ctr] = []
                    assigned_queues.append(queue_id)
                else:
                    util.logger('User: ' + name + ' is assigned to a non-existent queue: ' + queue_prefix + 'GEN' + english)
                break
        for skill in agent_skills:
            if skill.find(queue_prefix) != -1 and skill.find(french) != -1:
                queue_id = util.get_queue_id(connect_instance_details['queueList'], queue_prefix + 'GEN' + french)
                if queue_id != 'NOT FOUND':
                    util.logger('Assigning to Queue: ' + queue_prefix + 'GEN' + french + ' QUEUEID: ' + queue_id)
                    queue_config = util.get_queue_config(queue_id, 'VOICE')
                    queue_configs[queue_config_ctr].append(queue_config)                     			
                    queue_config = util.get_queue_config(queue_id, 'TASK')
                    queue_configs[queue_config_ctr].append(queue_config)
                    if len(queue_configs[queue_config_ctr]) == 10:
                        queue_config_ctr += 1
                        queue_configs[queue_config_ctr] = []
                    assigned_queues.append(queue_id)
                else:
                    util.logger('User: ' + name + ' is assigned to a non-existent queue: ' + queue_prefix + 'GEN' + french)
                break
        for skill in agent_skills:
            if skill.find(queue_prefix) != -1 and skill.find(spanish) != -1:
                queue_id = util.get_queue_id(connect_instance_details['queueList'], queue_prefix + 'GEN' + spanish)
                if queue_id != 'NOT FOUND':
                    util.logger('Assigning to Queue: ' + queue_prefix + 'GEN' + spanish + ' QUEUEID: ' + queue_id)
                    queue_config = util.get_queue_config(queue_id, 'VOICE')
                    queue_configs[queue_config_ctr].append(queue_config)     
                    queue_config = util.get_queue_config(queue_id, 'TASK')
                    queue_configs[queue_config_ctr].append(queue_config)
                    if len(queue_configs[queue_config_ctr]) == 10:
                        queue_config_ctr += 1
                        queue_configs[queue_config_ctr] = []
                    assigned_queues.append(queue_id)
                else:
                    util.logger('User: ' + name + ' is assigned to a non-existent queue: ' + queue_prefix + 'GEN' + spanish)
                break
        for skill in agent_skills:
            if skill.find(queue_prefix) != -1 and skill.find(portuguese) != -1:
                queue_id = util.get_queue_id(connect_instance_details['queueList'], queue_prefix + 'GEN' + portuguese)
                if queue_id != 'NOT FOUND':
                    util.logger('Assigning to Queue: ' + queue_prefix + 'GEN' + portuguese + ' QUEUEID: ' + queue_id)
                    queue_config = util.get_queue_config(queue_id, 'VOICE')
                    queue_configs[queue_config_ctr].append(queue_config)     
                    queue_config = util.get_queue_config(queue_id, 'TASK')
                    queue_configs[queue_config_ctr].append(queue_config)
                    if len(queue_configs[queue_config_ctr]) == 10:
                        queue_config_ctr += 1
                        queue_configs[queue_config_ctr] = []
                    assigned_queues.append(queue_id)
                else:
                    util.logger('User: ' + name + ' is assigned to a non-existent queue: ' + queue_prefix + 'GEN' + portuguese)
                break

    if len(queue_configs) == 1 and queue_config_ctr == 0:
        queue_id = util.get_queue_id(connect_instance_details['queueList'], 'BasicQueue')
        queue_config = util.get_queue_config(queue_id, 'VOICE')
        queue_configs[0].append(queue_config)

    result = create_connect_user_profile(connect_client, connect_instance_details, name, email, security_profiles, queue_configs[0])

    #Can only add 10 queue_configs per request.
    if len(queue_configs) > 1:
        for queue_config in queue_configs:
            if queue_config != 0:
                if len(queue_configs[queue_config]) != 0:
                    add_queue_to_rp(connect_client, connect_instance_details, result['rpID'], queue_configs[queue_config])
                
    try:
        for queue in assigned_queues:
            response = connect_client.associate_queue_quick_connects(
                InstanceId=connect_instance_details['instanceID'],
                QueueId=queue,
                QuickConnectIds=[result['qcID']]
            )
    except Exception as ex1:
        util.logger('insert_user_record EXCEPTION: ' + str(ex1))
        
def remove_connect_user_profile(connect_client, connect_instance_details, name, email, userID):
    try:
        connect_client.delete_user(
            InstanceId=connect_instance_details['instanceID'],
            UserId=userID
        )
    
        routing_profile_name = email.split('@')[0] + '-RP'

        routing_profile_id = util.get_routing_profile_id(connect_instance_details['routingProfileList'], routing_profile_name)

        connect_client.delete_routing_profile(
            InstanceId=connect_instance_details['instanceID'],
            RoutingProfileId=routing_profile_id
        )    

        qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], name + '_QC')

        connect_client.delete_quick_connect(
            InstanceId=connect_instance_details['instanceID'],
            QuickConnectId=qc_id
        )
    except Exception as ex1:
        util.logger('remove_connect_user_profile EXCEPTION: ' + str(ex1))
    
def create_connect_user_profile(connect_client, connect_instance_details, name, email, security_profiles, queue_configs):
    qc_id = ''
    if name.find(',') != -1:
        full_name = name.split(',')
        first_name = full_name[1]
        last_name = full_name[0]
    else:
        full_name = name.split(' ')
        first_name = full_name[1]
        last_name = full_name[0]
    
    try:
        response = connect_client.create_routing_profile(
            InstanceId=connect_instance_details['instanceID'], 
            #Name=''.join(name.split()).replace(',','-') + '-RP',
            Name=email.split('@')[0] + '-RP',
            Description='Routing Profile for ' + name,
            DefaultOutboundQueueId=connect_instance_details['outboundQueueID'],
            QueueConfigs= queue_configs,
            MediaConcurrencies=[
                {
                    'Channel': 'VOICE',
                    'Concurrency': 1,
                    'CrossChannelBehavior': {
                        'BehaviorType': 'ROUTE_CURRENT_CHANNEL_ONLY'
                    }
                },
                {
                    'Channel': 'TASK',
                    'Concurrency': 1,
                    'CrossChannelBehavior': {
                        'BehaviorType': 'ROUTE_CURRENT_CHANNEL_ONLY'
                    }
                }                
            ],
        )
        routing_profile_id = response['RoutingProfileId']
        
    except Exception as ex1:
        util.logger('create_routing_profile EXCEPTION: ' + str(ex1))
        routing_profile_name = email.split('@')[0] + '-RP'
        routing_profile_id = util.get_routing_profile_id(connect_instance_details['routingProfileList'], routing_profile_name)

    try:
        response = connect_client.create_user(
            Username=email,
            IdentityInfo={
                'FirstName': first_name,
                'LastName': last_name,
            },
            PhoneConfig={
                'PhoneType': 'SOFT_PHONE',
                'AutoAccept': False,
                'AfterContactWorkTimeLimit': 10
            },
            SecurityProfileIds= security_profiles,
            RoutingProfileId=routing_profile_id,
            InstanceId=connect_instance_details['instanceID']
        )

        userID = response['UserId']

        response = connect_client.create_quick_connect(
            InstanceId=connect_instance_details['instanceID'],
            Name= name + '_QC',
            Description='Created by AgentSync',
            QuickConnectConfig={
                'QuickConnectType': 'USER',
                'UserConfig': {
                    'UserId': userID,
                    'ContactFlowId': connect_instance_details['agentTransferFlowID']
                }
            }
        )

        qc_id = response['QuickConnectId']
        
    except Exception as ex1:
        util.logger('create_user EXCEPTION: ' + str(ex1))

    #return(qc_id)
    return {
        'rpID': routing_profile_id,
        'qcID': qc_id
    }

def add_queue_to_rp(connect_client, connect_instance_details,rpID, queue_configs):
    util.logger("ADDING QUEUES TO ROUTING PROFILE")
    try:
        connect_client.associate_routing_profile_queues(
            InstanceId=connect_instance_details['instanceID'],
            RoutingProfileId=rpID,
            QueueConfigs=queue_configs
        )
    except Exception as ex1:
        util.logger('add_queue_to_rp EXCEPTION: ' + str(ex1))
        
def load_users_from_S3(s3FileName):

    user_records = util.read_csv(s3FileName, 'email', '')
    
    try:
        table = boto3.resource('dynamodb').Table('Users')
 
        for record in user_records:
            util.logger('INSERTING NEW AGENT RECORD: ' + user_records[record]['email'])
            table.put_item(Item= {'Email': user_records[record]['email'], 
                'Name': user_records[record]['name'], 
                'Role': json.loads(user_records[record]['role']), 
                'Priority': json.loads(user_records[record]['priority'])})

    except Exception as ex1:
        util.logger('load_users_from_S3 EXCEPTION: ' + str(ex1))