import boto3
from typing import Dict
import struct
from botocore.exceptions import ClientError

# ---- Config ----
SAMPLE_RATE = 8000   # Amazon Connect: 8 kHz
SILENCE_MS = 500     # Half-second pause between segments
# -----------------

polly = boto3.client("polly")
s3_client = boto3.client("s3")

# ---------- μ-law encoder (audioop replacement) ----------
# ITU-T G.711 μ-law, integer implementation (no 3rd-party deps)
def _linear_to_mulaw(sample: int) -> int:
    """
    Convert a single 16-bit PCM sample (signed) to 8-bit μ-law.
    """
    BIAS = 0x84      # 132
    CLIP = 32635

    sign = 0x00
    if sample < 0:
        sign = 0x80
        sample = -sample
    if sample > CLIP:
        sample = CLIP

    sample = sample + BIAS

    # Determine segment
    segment = 0
    t = sample >> 7
    while t:
        segment += 1
        t >>= 1

    # Mantissa: next 4 bits after segment
    mantissa = (sample >> (segment + 3)) & 0x0F

    # Assemble, then bitwise invert
    uval = ~(sign | (segment << 4) | mantissa) & 0xFF
    return uval

def pcm16le_to_mulaw(pcm_bytes: bytes) -> bytes:
    """
    Convert 16-bit little-endian PCM mono -> 8-bit μ-law bytes.
    """
    out = bytearray(len(pcm_bytes) // 2)
    w = 0
    for i in range(0, len(pcm_bytes), 2):
        s = int.from_bytes(pcm_bytes[i:i+2], "little", signed=True)
        out[w] = _linear_to_mulaw(s)
        w += 1
    return bytes(out)
# ---------------------------------------------------------

def get_voice_for_language(lang_code: str, config: Dict[str, Dict[str, str]]) -> str:
    for v in config.values():
        if v.get("Language") == lang_code:
            return v.get("Voice", "Joanna")
    return "Joanna"

def synthesize_pcm(text: str, lang_code: str, voice_id: str, sample_rate: int) -> bytes:
    """
    Returns raw μ-law (8-bit) mono bytes at sample_rate Hz (expected 8000).
    """
    if int(sample_rate) != 8000:
        raise ValueError("This function only supports 8000 Hz for μ-law output.")
    try:
        resp = polly.synthesize_speech(
            Text=text,
            VoiceId=voice_id,
            OutputFormat="pcm",     # Polly returns 16-bit PCM LE
            LanguageCode=lang_code,
            SampleRate=str(sample_rate),
            Engine="neural",
        )
    except ClientError as e:
        if e.response.get("Error", {}).get("Code") == "ValidationException":
            resp = polly.synthesize_speech(
                Text=text,
                VoiceId=voice_id,
                OutputFormat="pcm",
                LanguageCode=lang_code,
                SampleRate=str(sample_rate),
                Engine="standard",
            )
        else:
            raise

    pcm_le_16 = resp["AudioStream"].read()   # 16-bit, little-endian, mono @ 8 kHz
    ulaw_8 = pcm16le_to_mulaw(pcm_le_16)     # -> μ-law (8-bit), no audioop needed
    return ulaw_8

def silence_bytes(ms: int, sample_rate: int) -> bytes:
    # μ-law silence byte is 0xFF
    num_samples = int((ms / 1000.0) * sample_rate)
    return b"\xFF" * num_samples

def build_wav(audio_bytes: bytes, sample_rate: int) -> bytes:
    """
    Write a μ-law WAV header (WAVE_FORMAT_MULAW = 0x0007) around audio_bytes.
    """
    channels = 1
    bits_per_sample = 8
    audio_format = 0x0007  # μ-law
    block_align = channels * (bits_per_sample // 8)  # 1
    byte_rate = sample_rate * block_align            # 8000
    data_size = len(audio_bytes)

    header = struct.pack("<4sI4s", b"RIFF", 36 + data_size, b"WAVE")
    fmt_chunk = struct.pack(
        "<4sIHHIIHH",
        b"fmt ", 16, audio_format, channels, sample_rate,
        byte_rate, block_align, bits_per_sample
    )
    data_chunk = struct.pack("<4sI", b"data", data_size)
    return header + fmt_chunk + data_chunk + audio_bytes

def create_and_upload_combined_wav(
    ivr_dict: Dict[str, str],
    lang_config: Dict[str, Dict[str, str]],
    s3_client,
    s3_bucket: str,
    s3_key: str,
    sample_rate: int = SAMPLE_RATE,
) -> None:
    if "greeting" not in ivr_dict:
        raise ValueError("Missing 'greeting' key in input")

    combined_ulaw = bytearray()
    blocks = ivr_dict["greeting"].split("|")

    for block in blocks:
        if ":" not in block:
            continue
        lang_code, message = block.split(":", 1)
        lang_code, message = lang_code.strip(), message.strip()
        if not message:
            continue

        voice_id = get_voice_for_language(lang_code, lang_config)
        print(f"Synthesizing {lang_code} ({voice_id}) @ {sample_rate}Hz → \"{message}\"")
        seg_ulaw = synthesize_pcm(message, lang_code, voice_id, sample_rate)
        combined_ulaw += seg_ulaw
        combined_ulaw += silence_bytes(SILENCE_MS, sample_rate)

    # Build a μ-law WAV
    wav_bytes = build_wav(bytes(combined_ulaw), sample_rate)

    # Upload to S3
    s3_client.put_object(
        Bucket=s3_bucket,
        Key=s3_key,
        Body=wav_bytes,
        ContentType="audio/wav",
    )
    print(f"✅ Uploaded WAV to s3://{s3_bucket}/{s3_key}")
