import instances
import tenants
import logger
import config
import applications
from pathlib import Path
import csv
import io
import util
from io import StringIO

def list_office_hours(s3_client, connect_id):
    shared_files_list = applications.get_file_list(s3_client, f"amazon-connect-{connect_id}", 'shared')
    office_hours_list = []

    prefix = "shared/"
    suffix = "-bushours.csv"
   
    for shared_file in shared_files_list:
        if suffix in shared_file:
            office_hours_name = shared_file.removeprefix(prefix).removesuffix(suffix)
            office_hours_list.append(office_hours_name)

    return office_hours_list

def get_office_hours(ou, s3_client, tenant_id, office_hours, app_id):
    found = False
    hours_config = []
    hours_tz = ''
    prompts = {}

    #office_hours = util.get_flow_control_item(ou, tenant_id, app_id, 'OfficeHours')

    if not office_hours:
        office_hours = 'Tenant'

    s3_response = s3_client.get_object(Bucket=instances.get_tenant_bucket(s3_client), Key= f"shared/{office_hours}-bushours.csv")
    office_hours_content = s3_response['Body'].read().decode('utf-8-sig')
    logger.info(office_hours_content)

    csv_file = io.StringIO(office_hours_content)
    csv_reader = csv.reader(csv_file)

    for row in csv_reader:
        found = True
        if not row:
            continue
            
        if row[0] == 'TIMEZONE':
            if len(row) >= 2:
                hours_tz = row[1]
            continue

        #if row[1]=='0:00' and row[2]=='0:00':
        #    continue

        day_object = {}
        day_object["Day"] = row[0]

        start_time_parts = row[1].split(":")
        end_time_parts = row[2].split(":")

        if len(start_time_parts) != 2 or len(end_time_parts) != 2:
            continue

        day_object["StartTime"] = {
            "Hours": int(start_time_parts[0]),
            "Minutes": int(start_time_parts[1])
        }

        day_object["EndTime"] = {
            "Hours": int(end_time_parts[0]),
            "Minutes": int(end_time_parts[1])
        }

        hours_config.append(day_object)

    if not found:
            hours_config = config.hours_of_operations
            hours_tz = 'America/Toronto'

    if app_id:
        prompts = tenants.read_tts(s3_client, tenant_id, app_id, ['closed'])

    return({
            "TimeZone" :hours_tz,
            "Config" : hours_config,
            "Prompts" : prompts
        })

def get_holidays(ou, s3_client, tenant_id, holidays, app_id):
    return_object = {}
    return_object['Prompts'] = {}

    #holidays = util.get_flow_control_item(ou, tenant_id, app_id, 'OfficeHours')
    if not holidays:
        holidays = 'Tenant'

    s3_response = s3_client.get_object(Bucket=instances.get_tenant_bucket(s3_client), Key= f"shared/{holidays}-holidays.csv")
    return_object['FileContents'] = s3_response['Body'].read().decode('utf-8-sig')
    
    if app_id:
        return_object['Prompts'] = tenants.read_tts(s3_client, tenant_id, app_id, ['holiday'])    

    return(return_object) 

def put_office_hours(ou, s3_client, s3_resource, role_credentials, hours_config, tenant_id, office_hours, app_id, prompts):
    logger.info(f"UPDATING OFFICE HOURS: {app_id}")

    csv_buffer = StringIO()
    csv_writer = csv.writer(csv_buffer, quoting=csv.QUOTE_NONNUMERIC)

    new_contents = ['DAY','START','END']
    csv_writer.writerow(new_contents)
    new_contents = ['TIMEZONE']
    new_contents.append(hours_config['TimeZone'])
    csv_writer.writerow(new_contents)
    for item in hours_config['Config']:
        new_contents = []
        new_contents.append(item["Day"])
        new_contents.append(str(item['StartTime']['Hours']) + ":" + str(item['StartTime']['Minutes']))
        new_contents.append(str(item['EndTime']['Hours']) + ":" + str(item['EndTime']['Minutes']))
        csv_writer.writerow(new_contents)

    #office_hours = util.get_flow_control_item(ou, tenant_id, app_id, 'OfficeHours')
    if not office_hours:
        office_hours = 'Tenant'    

    s3_resource.Object(instances.get_tenant_bucket(s3_client), f"shared/{office_hours}-bushours.csv").put(Body=csv_buffer.getvalue())

    if app_id and prompts:
        tenants.update_tts(s3_client, s3_resource, tenant_id, app_id, prompts, role_credentials)

def put_holidays(s3_client, s3_resource, role_credentials, content, tenant_id, office_hours, app_id, prompts, ou):
    logger.info(f"UPDATING HOLIDAYS: {app_id}")

    #holidays = util.get_flow_control_item(ou, tenant_id, app_id, 'OfficeHours')
    if not office_hours:
        office_hours = 'Tenant'    

    body = content.replace(",undefined", "").encode("utf-8-sig")

    s3_resource.Object(instances.get_tenant_bucket(s3_client), f"shared/{office_hours}-holidays.csv").put(Body=body)

    if app_id and prompts:
        logger.info('UPDATING TTS: ' + str(prompts))
        tenants.update_tts(s3_client, s3_resource, tenant_id, app_id, prompts, role_credentials)

def delete_office_hours(s3_client, office_hours):
    """Delete both Office Hours and Holiday files from the tenant's S3 bucket."""

    bucket = instances.get_tenant_bucket(s3_client)
    keys = [
        f"shared/{office_hours}-bushours.csv",
        f"shared/{office_hours}-holidays.csv"
    ]

    for key in keys:
        try:
            s3_client.delete_object(Bucket=bucket, Key=key)
            logger.info(f"Deleted {key} from {bucket}")
        except Exception as Ex1:
            logger.error(f"Error deleting {key} from {bucket}: {Ex1}")

def get_connect_hours(s3_client, connect_client, connect_id, tenant_id, app_id):
    found = False
    if app_id == 'Default':
        business_hours_name = "Business Hours"
    else:
        business_hours_name = app_id

    list_hours_response = connect_client.list_hours_of_operations(InstanceId=connect_id)
    for hours_setting in list_hours_response['HoursOfOperationSummaryList']:
        if hours_setting['Name'] == business_hours_name:
            found = True
            hours_id =  hours_setting['Id']

            hours_response = connect_client.describe_hours_of_operation(
                InstanceId=connect_id,
                HoursOfOperationId=hours_id
            )
            hours_config = hours_response['HoursOfOperation']['Config']
            hours_tz = hours_response['HoursOfOperation']['TimeZone']

    if not found:
            hours_config = config.hours_of_operations
            hours_tz = 'America/Toronto'

    prompts = tenants.read_tts(s3_client, tenant_id, app_id, ['closed'])
    return({
            "TimeZone" :hours_tz,
            "Config" : hours_config,
            "Prompts" : prompts
        })

def put_connect_hours(s3_client, s3_resource, role_credentials, connect_client, connect_id, hours_config, tenant_id, app_id, prompts):
    if app_id == 'Default':
        business_hours_name = "Business Hours"
        app_id = 'default'
    else:
        business_hours_name = app_id

    hours_exists = False
    list_hours_response = connect_client.list_hours_of_operations(InstanceId=connect_id)
    for hours_setting in list_hours_response['HoursOfOperationSummaryList']:
        if hours_setting['Name'] == business_hours_name:
            hours_id =  hours_setting['Id']
            hours_exists = True
    
            describe_hours_response = connect_client.describe_hours_of_operation(
                InstanceId=connect_id,
                HoursOfOperationId=hours_id
            )
            hours_name = describe_hours_response['HoursOfOperation']['Name']
            try:
                hours_desc = describe_hours_response['HoursOfOperation']['Description']
            except:
                hours_desc = ""

            logger.info('UPDATING ' + app_id + ' BUSINESS HOURS')
            connect_client.update_hours_of_operation(
                InstanceId=connect_id,
                HoursOfOperationId=hours_id,
                Name=hours_name,
                Description=hours_desc,
                TimeZone=hours_config['TimeZone'],
                Config=hours_config['Config']
            )

    if not hours_exists:
        logger.info('CREATING ' + app_id + ' BUSINESS HOURS')
        connect_client.create_hours_of_operation(
            InstanceId=connect_id,
            Name=app_id,
            Description=app_id + ' Business Hours',
            TimeZone=hours_config['TimeZone'],
            Config=hours_config['Config']
        ) 

    if prompts:
        tenants.update_tts(s3_client, s3_resource, tenant_id, app_id, prompts, role_credentials)


