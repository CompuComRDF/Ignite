import json
import boto3
import time
import util
from time import sleep
import random
import config
import instances
import users

def delete_app_record(event, connect_client, role_credentials, connect_id, connect_instance_details):
    status = 'Success'
    dynamodb_client = boto3.client('dynamodb')
    ou = event['Env']
    tenant_id = event['TenantID']
    app_id=event['AppID']
    tenant = tenant_id + '-' + app_id
    language = event['Language'].replace(" ", "")

    try:
        business_hours = event['BusinessHours']
    except:
        business_hours = 'Default'
        
    release_dnis = event['ReleaseNumber']

    response = dynamodb_client.get_item(
        TableName='Tenants-' + ou,
        Key={
            'Tenant': {'S': tenant},
            'Language': {'S': language}
        }
    )

    related_queues = json.loads(response['Item']['Queues']['S'])
    dnis_id = response['Item']['ID']['S']

    queues_to_delete = []
    #queues_to_delete.append(app_id + '_') #Include the default queue that was created for the app
    for related_queue in related_queues:
        if '+' not in related_queue:
            if related_queue not in queues_to_delete: 
                queues_to_delete.append(related_queue) #Queues & Queue Quick Connects
        else:
            queues_to_delete.append(related_queue) #Phone Quick Connects

    #util.logger("QUEUES TO DELETE: " + str(queues_to_delete))
    delete_queues(event, connect_client, connect_instance_details, queues_to_delete, language, language)

    try:
        table = boto3.resource('dynamodb').Table('Tenants-' + ou)
        table.delete_item(Key={"Tenant": tenant, "Language": language})
    except Exception as ex1:
        status = 'delete_app_record EXCEPTION FOUND: ' + str(ex1)
        util.logger(status)

    delete_rdf_application_files(role_credentials, 'amazon-connect-' + connect_id, tenant_id, app_id)

    list_hours_response = connect_client.list_hours_of_operations(
        InstanceId=connect_id
    )

    for hours in list_hours_response['HoursOfOperationSummaryList']:
        if hours['Name'] == app_id:
            util.logger('DELETING ' + app_id + ' BUSINESS HOURS')
            connect_client.delete_hours_of_operation(
                InstanceId=connect_id,
                HoursOfOperationId=hours['Id']
            )     

    if release_dnis:                        
        release_phone_number(connect_client, dnis_id)

    return status

def insert_app_record(event, s3_client, s3_resource, connect_client, role_credentials, connect_id, connect_instance_details):
    ou = event['Env']
    tenant_id = event['TenantID']
    app_id = event['AppID']
    description = event['Description']
    dnis_array = []
    dnis_object = {}

    dnis_array = json.loads(event['DNIS'])
    for dnis_object in dnis_array:
        for dnis_entry in dnis_object:
            dnis_id = dnis_object[dnis_entry]

    queue_list = []
    util.logger('CREATING NEW APPLICATION: ' + tenant_id + '-' + app_id)

    default_greeting = "You've reached the " + app_id + " application."
    greeting = {}
    multi_languages = instances.get_languages(ou, tenant_id)
    for language in multi_languages:
        #lang_code = language[0].upper() + language[1].lower()
        greeting[language] = util.translate_text(default_greeting, 'en-US', language)
        create_queue(ou, connect_client, connect_instance_details, app_id, language, description, dnis_id, 'Default')
    
    queue_list.append(app_id)

    (greeting, language_menu) = create_language_menu(ou, greeting, multi_languages, role_credentials, ['en-US'])

    upload_rdf_application_files(role_credentials, 'amazon-connect-' + connect_id, tenant_id, app_id, [])

    try:
        table = boto3.resource('dynamodb').Table('Tenants-' + ou)
 
        table.put_item(Item= {'Tenant': tenant_id + '-' + app_id, 
            'Language': json.dumps(multi_languages, ensure_ascii=False).replace(" ", ""),
            'Description': description, 
            'DNIS': json.dumps(dnis_array), 
            'ID': dnis_id,
            'Greeting': json.dumps(greeting, ensure_ascii=False),
            'LanguageMenu': json.dumps(language_menu, ensure_ascii=False),
            'CallFlow': '',
            'Queues': json.dumps(queue_list),
            'FlowControl': '{"0":"Greeting", "1":"Queue"}',
            'BusinessHours': 'Default',
            'Holidays': 'Default'
        })

    except Exception as ex1:
        util.logger('insert_app_record EXCEPTION FOUND: ' + str(ex1))

    prompts = read_tts(s3_client, tenant_id, app_id, config.default_prompts)
    new_prompts = {}
    for prompt in prompts:
        new_prompts[prompt] = {}
        for language in multi_languages:
            if language == 'en-US':
                new_prompts[prompt][language] = prompts[prompt]['en-US']
            else:
                new_prompts[prompt][language] = util.translate_text(prompts[prompt]['en-US'], 'en-US', language)

    update_tts(s3_client, s3_resource, tenant_id, app_id, new_prompts, role_credentials)

    s3_response = s3_client.get_object(Bucket=instances.get_tenant_bucket(s3_client), Key= event['TenantID'] + "-" + event['AppID'] + "/config/ivr-menutree.csv")
    instances.put_tenant_object(s3_client, s3_resource, role_credentials, 'ivr-menutree.csv', s3_response['Body'], event['TenantID'], event['AppID'], {}, event['Env'])

    import datetime
    s3_client.put_object(Bucket=instances.get_tenant_bucket(s3_client), Key=tenant_id + '-' + app_id + '/Project Repository/ReadMe.txt', Body=app_id + " was created on " + str(datetime.datetime.now()))

    return {
        "Language": multi_languages,
        "Greeting": greeting,
        "flowControl": '{"0":"Greeting", "1":"Queue"}',
        "BusinessHours": "Default",
        'Holidays': 'Default',
        'Queues': queue_list,
        'Prompts': prompts
    }

def update_app_record(event, s3_client, s3_resource, connect_client, connect_instance_details, role_credentials):
    status = 'Success'
    ou = event['Env']
    tenant_id = event['TenantID']
    app_id = event['AppID']
    try:
        prompts = event['Prompts']
    except:
        prompts = []
    tenant = tenant_id + '-' + app_id
    dnis_array = []
    dnis_object = {}

    dnis_array = json.loads(event['DNIS'])
    dnis_object = dnis_array[0]
    dnis = next(iter(dnis_object))
    dnis_id = dnis_object[dnis]

    description = event['Description']
    old_language = event['PreviousLanguage'].replace(" ", "")
    new_language = event['Language'].replace(" ", "")
    greeting = json.loads(event['Greeting'])
    callFlow = event['CallFlow']
    related_queues = json.loads(event['Queues'])
    flow_control = json.loads(event['flowControl'])
    business_hours = event['BusinessHours'] if event['BusinessHours'] == 'Default' else app_id
    holidays = event['Holidays'] if event['Holidays'] == 'Default' else app_id
    util.logger('UPDATING APPLICATION: ' + tenant)

    queues_created = []
    quick_connect_ids=[]
   
    queues_to_delete = []
    languages = []
    for lang in json.loads(old_language):
        if lang not in json.loads(new_language):
            languages.append(lang)
            #lang_code = lang[0].upper() + lang[1].lower()
            #queues_to_delete.append(app_id + "_")
            for queue in related_queues:
                if queue not in queues_to_delete:
                    queues_to_delete.append(queue)

    #util.logger("QUEUES TO DELETE: " + str(queues_to_delete))
    #util.logger("LANGUAGES: " + str(languages))

    if queues_to_delete:
        delete_queues(event, connect_client, connect_instance_details, queues_to_delete, json.dumps(languages), old_language)

    #multi_languages = new_language.split('_')
    #while('' in multi_languages):
    #    multi_languages.remove('')
    # 
    multi_languages = json.loads(new_language)
    (greeting, language_menu) = create_language_menu(ou, greeting, multi_languages, role_credentials, json.loads(old_language))
    #language_menu['default'] = multi_languages[0][0].upper() + multi_languages[0][1].lower()

    # THIS CREATES A QUEUE FOR THE APP BUT MAY NO LONGER BE NEEDED
    #for lang in multi_languages:
    #    lang_code = lang[0].upper() + lang[1].lower()
    #    response = create_queue(ou, connect_client, connect_instance_details, app_id, lang, description, dnis_id, business_hours)
    #    queue_id = response['queueID']
    #    queues_created.append(queue_id)
    #    if related_queues:
    #        if response['result']: #If Queue was newly created, also create a QC
    #            response = create_quick_connect(connect_client, connect_instance_details, app_id, lang_code, queue_id)
    #            if response['result']: #Add to QC array
    #                quick_connect_ids.append(response['qcID'])
                    
    #        else: #If Queue already existed, attempt to create a QC in case it wasn't created
    #            response = create_quick_connect(connect_client, connect_instance_details, app_id, lang_code, queue_id)
    #            if response['result']: #Add to QC array
    #                quick_connect_ids.append(response['qcID'])  
    #            else: #if QC already existed, find QC ID and add to QC array
    #                qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], app_id+'_'+lang_code+'_QC')
    #                quick_connect_ids.append(qc_id)            
        
    try:
        table = boto3.resource('dynamodb').Table('Tenants-' + ou)

        #Since Language is a Sort Key and can not be updated, need to recreate record.
        table.delete_item(Key={"Tenant": tenant, "Language": old_language})
 
        table.put_item(Item= {'Tenant': tenant, 
            'Language': new_language, 
            'Description': description, 
            'DNIS': json.dumps(dnis_array), 
            'ID': dnis_id,
            'Greeting': json.dumps(greeting, ensure_ascii=False),
            'LanguageMenu': json.dumps(language_menu, ensure_ascii=False),
            'CallFlow': callFlow,
            'Queues': json.dumps(related_queues),
            'FlowControl': json.dumps(flow_control),
            'BusinessHours': business_hours,
            'Holidays': holidays
        })

    except Exception as ex1:
        status = "Failed to update app"
        util.logger('update_app_record EXCEPTION FOUND: ' + str(ex1))

    if related_queues:
        for related_queue in related_queues:
            if '+' not in related_queue: #Create Queues + Quick Connect
                #language_menu = {'en-US': False, 'fr-CA': False, 'es-MX': False, 'pt-BR': False}
                for lang in multi_languages:
                    if lang:
                        #lang_code = lang[0].upper() + lang[1].lower()
                        #language_menu[lang] = True
                        #response = create_queue(ou, connect_client, connect_instance_details, related_queue, lang, related_queue.replace('_',''), dnis_id, business_hours) #Create Queue in case it doesn't exist
                        response = create_queue(ou, connect_client, connect_instance_details, related_queue, lang, related_queue, dnis_id, business_hours) #Create Queue in case it doesn't exist
                        queues_created.append(response['queueID'])
                        if response['result']: #If Queue was newly created, also create a QC
                            response = create_quick_connect(ou, connect_client, connect_instance_details, related_queue, lang, response['queueID'])
                            if response['result']: #Add to QC array
                                quick_connect_ids.append(response['qcID'])
                                
                        else: #If Queue already existed, attempt to create a QC in case it wasn't created
                            response = create_quick_connect(ou, connect_client, connect_instance_details, related_queue, lang, util.get_queue_id(connect_instance_details['QueueSummaryList'], related_queue + ' ' + get_language_name(ou, lang)))
                            if response['result']: #Add to QC array
                                quick_connect_ids.append(response['qcID'])  
                            else: #if QC already existed, find QC ID and add to QC array
                                qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], related_queue + ' ' + get_language_name(ou, lang))
                                quick_connect_ids.append(qc_id)
            else: #Create Phone Quick Connect
                response = create_phone_quick_connect(connect_client, connect_instance_details, related_queue, description)
                if response['result']: #Add to QC array
                    quick_connect_ids.append(response['qcID'])
                else:
                    qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], related_queue)
                    quick_connect_ids.append(qc_id)                 
        try:
            util.logger("ASSIGNING QUICK CONNECTS TO QUEUES")
            for queue in queues_created:
                #util.logger("ASSIGNING QUICK CONNECTS: " + str(quick_connect_ids) + " TO QUEUE: " + queue)
                response = connect_client.associate_queue_quick_connects(
                    InstanceId=connect_instance_details['instanceID'],
                    QueueId=queue,
                    QuickConnectIds=quick_connect_ids
                )
        except Exception as ex1:
            util.logger('associate_queue_quick_connects EXCEPTION: ' + str(ex1))

    if prompts:
        update_tts(s3_client, s3_resource, tenant_id, app_id, prompts, role_credentials)

    ##This code was added to correct Tenant Records that needed to be re-created.  Since Agent table was already populated and assigned to queues, this code does the reverse
    ##and searches through Agent table to assign agents to the Tenant Record that was re-created.

    #languages = list(filter(None, language.split("_")))
    #agent_list = util.get_users()

    #for queue in queues_created:
    #    for agentEmail in agent_list:
    #        queueConfigs = []
    #        skills={}
    #        queueFound = False
    #        if 'levels' in agent_list[agentEmail]['priority']:
    #            skills = agent_list[agentEmail]['priority']['levels']['M']
    #        for skill in skills:
    #            for language in languages:
    #                if skill.find(tenant_id) != -1 and skill.find('_'+language) != -1:
    #                    routingProfileName = agentEmail.split('@')[0] + '-RP'
    #                    routingProfileID = util.get_routing_profile_id(connect_instance_details['routingProfileList'], routingProfileName)
    #                    routingProfileQueues = connect_client.list_routing_profile_queues(
    #                        InstanceId=connect_instance_details['instanceID'],
    #                        RoutingProfileId=routingProfileID,
    #                        MaxResults=100
    #                    )
    #                    for routingProfileQueue in routingProfileQueues['RoutingProfileQueueConfigSummaryList']:
    #                        if queue == routingProfileQueue['QueueId']:
    #                            queueFound = True
    #                    if not queueFound:        
    #                        util.logger('Assigning agent: ' + agentEmail + ' to Queue: ' + tenant_id + '_' + language + ' with QUEUEID: ' + queue)
    #                        queueConfig = util.get_queue_config(queue,'VOICE')
    #                        queueConfigs.append(queueConfig)
    #                        queueConfig = util.get_queue_config(queue, 'TASK')
    #                        queueConfigs.append(queueConfig)
    #                        users.addQueuetoRP(connect_client, connect_instance_details, routingProfileID, queueConfigs)
    #                        qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], agent_list[agentEmail]['name'] + '_QC')
    #                        try:
    #                            response = connect_client.associate_queue_quick_connects(
    #                                InstanceId=connect_instance_details['instanceID'],
    #                                QueueId=queue,
    #                                QuickConnectIds=[qc_id]
    #                            )
    #                        except Exception as ex1:
    #                            util.logger('associate_queue_quick_connects EXCEPTION: ' + str(ex1))                        

    return status

def create_language_menu(ou, greeting, multi_languages, role_credentials, old_language):
    new_greeting = {}
    language_menu = {}
    language_menu['greeting'] = ''
    language_menu['options'] = ''
    lang_menu_opt = 0
    translation_language = old_language[0]

    util.logger("OLD GREETING: " + str(greeting))
    util.logger("TRANSLATION LANGUAGE: " + str(translation_language))
    #language_menu['default'] = multi_languages[0][0].upper() + multi_languages[0][1].lower()
    language_menu['default'] = multi_languages[0]

    for lang in multi_languages:
        #lang_code = lang[0].upper() + lang[1].lower()
        lang_menu_opt += 1
        if lang_menu_opt > 1:
            language_menu['greeting'] += '|'
            language_menu['options'] += '|'
        try:
            new_greeting[lang] = greeting[lang]
            language_menu['greeting'] += lang + ':' + greeting[lang]
        except:
            #new_greeting[lang_code] = util.translate_text(greeting[language_menu['default']], multi_languages[0], lang)
            #new_greeting[lang_code] = util.translate_text(greeting[language_menu['default']], translation_language, lang)
            new_greeting[lang] = util.translate_text(greeting[translation_language], translation_language, lang)
            language_menu['greeting'] += lang + ':' + new_greeting[lang]
            
        if not new_greeting[lang].endswith(".") and not len(new_greeting[lang])==0:
            language_menu['greeting'] += '.'
        if len(multi_languages) > 1:
            language = get_voices(ou, "")['Available'][lang]['Name']
            language_parts = language.split(" ")
            language_name = language_parts[len(language_parts) - 1]            
            #language_menu['greeting'] += ' ' + util.translate_text("For service in " + config.language_names[lang] + ", press " + str(lang_menu_opt), "en-US", lang)
            language_menu['greeting'] += ' ' + util.translate_text("For service in " + language_name + ", press " + str(lang_menu_opt), "en-US", lang)
            #language_menu['options'] += str(lang_menu_opt) + ':' + lang[0:2].upper()
            if lang_menu_opt != 10:
                language_menu['options'] += str(lang_menu_opt) + ':' + "LANG" + str(lang_menu_opt)
            else:
                language_menu['options'] += "0:LANG10"

    util.logger("NEW GREETING: " + str(new_greeting))

    if language_menu['options']:
        if lang_menu_opt < 9:
            language_menu['options'] += '|9:LANG1|*:LANG1|invalid:LANG1|timeout:LANG1'
        else:
            language_menu['options'] += '|*:LANG1|invalid:LANG1|timeout:LANG1'        

    return (new_greeting, language_menu)

def delete_queues(event, connect_client, connect_instance_details, queues_to_delete, languages, language_key):
    status = 'Success'
    dynamodb_client = boto3.client('dynamodb')
    ou = event['Env']
    tenant_id = event['TenantID']
    app_id=event['AppID']
    tenant = tenant_id + '-' + app_id
    #language = event['Language'].replace(" ", "")
    #multi_languages = language.split('_')
    multi_languages = json.loads(languages)

    for queue in queues_to_delete:
        if app_id not in queue:
            response = dynamodb_client.get_item(
                TableName='Tenants-' + ou,
                Key={
                    'Tenant': {'S': tenant},
                    'Language': {'S': language_key}
                }
            )

            queues = json.loads(response['Item']['Queues']['S'])
            #queues.remove(queue.replace("_", ""))
            queues.remove(queue)

            boto3.resource('dynamodb').Table('Tenants-' + ou).update_item(
                Key={'Tenant': tenant, 'Language': language_key},
                UpdateExpression='SET #attr1 = :val1',
                ExpressionAttributeNames={'#attr1': 'Queues'},
                ExpressionAttributeValues={':val1': json.dumps(queues)}
            )

        if '+' not in queue: #Queues + Quick Connects
            for lang in multi_languages:
                if lang:
                    #lang_code = lang[0].upper() + lang[1].lower()
                    #queue_name = queue + lang_code
                    language_name = get_language_name(ou, lang)
                    queue_name = queue + ' ' + language_name
                    queue_id = util.get_queue_id(connect_instance_details['QueueSummaryList'], queue_name)
                    delete_queue = False
                    
                    if len(multi_languages) > 2:
                        #util.logger("MULTI-LANGUAGE DNIS.  CHECKING IF QUEUE: " + queue_name + " IS STILL REQUIRED")
                        response = dynamodb_client.get_item(
                            TableName='Tenants-' + ou,
                            Key={
                                'Tenant': {'S': tenant},
                                #'Language': {'S': '_' + lang}
                                'Language': {'S': '["' + lang +'"]'}
                            }
                        )
                        try:
                            #util.logger("DB RESPONSE: " + str(response['Item']))
                            if response['Item']['Tenant']['S'] != tenant:
                                delete_queue = True
                        except:
                            delete_queue = True
                    else:
                        #util.logger("SINGLE-LANGUAGE DNIS.  CHECKING IF QUEUE: " + queue_name + " IS STILL REQUIRED")
                        delete_queue = True
                        response = dynamodb_client.query(
                            TableName='Tenants-' + ou,
                            KeyConditionExpression='Tenant = :tenant',
                            ExpressionAttributeValues={
                                ':tenant': {'S': tenant}
                            }
                        )
                        try:
                            #util.logger("DB RESPONSE: " + str(response['Items']))
                            if len(response['Items']) > 1:
                                for i in response['Items']:
                                    if lang in i['language']['S']:
                                        delete_queue = False
                        except:
                            delete_queue = False
                            
                    if delete_queue:
                        util.logger("DELETING QUEUE: " + queue_name)
                        qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], queue + ' ' + language_name)
                        if qc_id != "NOT FOUND":
                            remove_quick_connect(connect_client, connect_instance_details, qc_id, queue + ' ' + language_name)
                            
                        status = remove_queue(event, connect_client, connect_instance_details, queue_id, queue)
                    else:
                        util.logger("KEEPING QUEUE: " + queue_name)
        
        else:
            qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], queue)
            if qc_id != "NOT FOUND":
                remove_quick_connect(connect_client, connect_instance_details, qc_id, queue)

    return status
    
def remove_queue(event, connect_client, connect_instance_details, queue_id, queue):
    status = "Success"
    dynamodb_client = boto3.client('dynamodb')
    ou = event['Env']
    tenant_id = event['TenantID']
    app_id=event['AppID']
    tenant = tenant_id + '-' + app_id
    language = event['Language']
    #queue = queue[0:queue.find('_')]

    #SEARCH ALL ROUTING PROFILES AND REMOVE QUEUE FROM PROFILES
    for routing_profile in connect_instance_details['routingProfileList']['RoutingProfileSummaryList']:

        try:
            routing_queues = connect_client.list_routing_profile_queues(
                InstanceId=connect_instance_details['instanceID'],
                RoutingProfileId=routing_profile['Id'],
                MaxResults=100
            )
    
            for routing_queue in routing_queues['RoutingProfileQueueConfigSummaryList']:
                if routing_queue['QueueId'] == queue_id:
                    connect_client.disassociate_routing_profile_queues(
                        InstanceId=connect_instance_details['instanceID'],
                        RoutingProfileId=routing_profile['Id'],
                        QueueReferences=[
                            {
                                'QueueId': queue_id,
                                'Channel': 'VOICE'
                            },
                        ]
                    )
                    connect_client.disassociate_routing_profile_queues(
                        InstanceId=connect_instance_details['instanceID'],
                        RoutingProfileId=routing_profile['Id'],
                        QueueReferences=[
                            {
                                'QueueId': queue_id,
                                'Channel': 'TASK'
                            },
                        ]
                    )
          
        except Exception as ex1:
            util.logger('disassociate_routing_profile_queues EXCEPTION: ' + str(ex1))

    #UPDATE USERS TABLE TO REMOVE QUEUE
    util.logger("UPDATING USERS TABLE")
    try:
        get_users_response = dynamodb_client.scan(
            TableName='Users-' + ou
        )
        #util.logger("DB RESPONSE: " + str(get_users_response))

        for user_record in get_users_response['Items']:
            update = False
            if tenant_id == user_record['Tenant']['S']:
                old_priority = json.loads(user_record['Priority']['S'])
                new_priority = {}
                for assigned_queue in old_priority:
                    if assigned_queue == queue:
                        update = True
                    else:
                        new_priority[assigned_queue] = old_priority[assigned_queue]
                
                if update:
                    full_name = user_record['Name']['S']
                    last_name = full_name[0:full_name.find(',')]
                    first_name = full_name[full_name.find(',')+1:]
                    users.update_user(ou, tenant_id, user_record['Email']['S'], first_name, last_name, json.loads(user_record['Languages']['S']), json.loads(user_record['Role']['S']), new_priority, "")

    except Exception as ex1:
        util.logger('delete queue from user table EXCEPTION: ' + str(ex1))

    #DELETE QUEUE
    #util.logger('REMOVING QUEUE: ' + queue)
    try:
        connect_client.delete_queue(
            InstanceId=connect_instance_details['instanceID'],
            QueueId=queue_id
        )
 
    except Exception as ex1:
        status = 'remove_queue EXCEPTION: ' + str(ex1)
        util.logger(status)
    
    return status

def create_queue(ou, connect_client, connect_instance_details, app_id, language, description, dnis_id, business_hours):
    result = False
    language_name = get_language_name(ou, language)

    #lang_code = language[0].upper() + language[1].lower()
    queue_id = ''
    #queue_name = app_id + '_' + lang_code
    queue_name = app_id + ' ' + language_name
    queue_exists = False

    #CHECK BUSINESS HOURS
    business_hours = 'Business Hours' if business_hours=='Default' else business_hours
    business_hours_id = connect_instance_details['hoursOfOperationsID']
    bus_hours_set = False
    list_hours_response = connect_client.list_hours_of_operations(
        InstanceId=connect_instance_details['instanceID']
    )

    for hours in list_hours_response['HoursOfOperationSummaryList']:
        if hours['Name'] == business_hours:
            #util.logger(business_hours + ' HOURS ALREADY EXISTS')
            bus_hours_set = True
            business_hours_id = hours['Id']

    if not bus_hours_set:
        util.logger('CREATING ' + app_id + ' BUSINESS HOURS')
        create_hours_response = connect_client.create_hours_of_operation(
            InstanceId=connect_instance_details['instanceID'],
            Name=app_id,
            Description=app_id + ' Business Hours',
            TimeZone='America/Toronto',
            Config=config.hours_of_operations,
        ) 
        business_hours_id = create_hours_response['HoursOfOperationId']    

    for queue in connect_instance_details['QueueSummaryList']:
        if queue['Name'] == queue_name:
            queue_exists = True
            queue_id = queue['Id']

    if not queue_exists:    
        util.logger('CREATING QUEUE: ' + queue_name)
        if not description:
            description = app_id 
        try:
            response = connect_client.create_queue(
                InstanceId=connect_instance_details['instanceID'],
                Name=queue_name,
                Description=description + ' ' + language_name,
                OutboundCallerConfig={
                    'OutboundCallerIdName': description,
                    'OutboundCallerIdNumberId': dnis_id,
                    'OutboundFlowId': connect_instance_details['outboundFlowID']
                },
                HoursOfOperationId=business_hours_id,
                MaxContacts=50,
            )
            result = True
            queue_id = response['QueueId']
        except Exception as ex1:
            util.logger('create_queue EXCEPTION: ' + str(ex1))

    else:
        #util.logger('QUEUE ALREADY EXISTS: ' + queue_name)
        connect_client.update_queue_hours_of_operation(
            InstanceId=connect_instance_details['instanceID'],
            QueueId=queue_id,
            HoursOfOperationId=business_hours_id
        )        

    return {
        'result': result,
        'queueID': queue_id
    }

def remove_quick_connect(connect_client, connect_instance_details, quickConnectID, qc_name):
    util.logger("REMOVING QUICK CONNECT: " + str(qc_name))
    try:
        connect_client.delete_quick_connect(
            InstanceId=connect_instance_details['instanceID'],
            QuickConnectId=quickConnectID
        )
    except Exception as ex1:
        util.logger('delete_quick_connect EXCEPTION: ' + str(ex1))
        
def create_quick_connect(ou, connect_client, connect_instance_details, app_id, language, queue_id):
    result = False
    qc_exists = False
    qc_id = ''
    #qcName = app_id + ' ' + language + '_QC'
    qcName = app_id + ' ' + get_language_name(ou, language)
    qc_list = []

    try:
        list_qc_response = connect_client.list_quick_connects(
            InstanceId=connect_instance_details['instanceID'],
            QuickConnectTypes=[
                'QUEUE'
            ]
        )
        qc_list = list_qc_response['QuickConnectSummaryList']

        while 'NextToken' in list_qc_response:
            list_qc_response = connect_client.list_quick_connects(
                InstanceId=connect_instance_details['instanceID'],
                NextToken=list_qc_response['NextToken'],
                QuickConnectTypes=[
                    'QUEUE'
                ]
            )
            qc_list.extends(list_qc_response['QuickConnectSummaryList'])

        for qc in qc_list:
            if qcName in qc['Name']:
                qc_exists = True

        if not qc_exists:
            util.logger("CREATING QUICK CONNECT: " + qcName)
            response = connect_client.create_quick_connect(
                InstanceId=connect_instance_details['instanceID'],
                Name=qcName,
                Description='Created by Ignite',
                QuickConnectConfig={
                    'QuickConnectType': 'QUEUE',
                    'QueueConfig': {
                        'QueueId': queue_id,
                        'ContactFlowId': connect_instance_details['agentQueueFlowID']
                    }
                }
            )
            qc_id = response['QuickConnectId']
            result = True
    except Exception as ex1:
        result = False
        util.logger('create_quick_connect EXCEPTION: ' + str(ex1))
            
    return {
        'result': result,
        'qcID': qc_id
    }

def create_phone_quick_connect(connect_client, connect_instance_details, phone_number, tenant_name):
    result = False
    qc_id = ''
    util.logger("CREATING PHONE QUICK CONNECT: " + phone_number)
    
    try:            
        response = connect_client.create_quick_connect(
            InstanceId=connect_instance_details['instanceID'],
            Name=phone_number,
            Description='Created for ' + tenant_name,
            QuickConnectConfig={
                'QuickConnectType': 'PHONE_NUMBER',
                'PhoneConfig': {
                    'PhoneNumber': phone_number
                }
            }
        )
        result = True
        qc_id = response['QuickConnectId']
    except Exception as ex1:
        util.logger('create_quick_connect EXCEPTION: ' + str(ex1))

    return {
        'result': result,
        'qcID': qc_id
    }
    
def release_phone_number(connect_client, phone_number_id):
    util.logger('RELEASING PHONE NUMBER ID: ' + phone_number_id)
    
    try:
        connect_client.release_phone_number(
            PhoneNumberId=phone_number_id
            #ClientToken='string'
        )  
    except Exception as ex1:
        util.logger('release_phone_number EXCEPTION: ' + str(ex1))
    
def load_tenants_from_S3(s3_filename):

    tenant_records = util.read_csv(s3_filename, 'Tenant', 'Language')
    
    try:
        table = boto3.resource('dynamodb').Table('Tenants-' + ou)
 
        for record in tenant_records:
            util.logger('INSERTING NEW TENANT RECORD: ' + tenant_records[record]['Tenant'] + ' WITH LANGUAGE: ' + tenant_records[record]['Language'])
            table.put_item(Item= {'Tenant': tenant_records[record]['Tenant'], 
                'Language': tenant_records[record]['Language'], 
                'Description': tenant_records[record]['Description'], 
                'Greeting': tenant_records[record]['Greeting'], 
                'CallFlow': tenant_records[record]['CallFlow'], 
                'Queues': tenant_records[record]['Queues']})

    except Exception as ex1:
        util.logger('load_tenants_from_S3 EXCEPTION: ' + str(ex1))

def get_tenant_apps(s3_client, ou, tenant_id):
    tenant_app_list = []
    util.logger("GETTING TENANT APP LIST")
    dynamodb_client = boto3.client('dynamodb')
    try:
        response = dynamodb_client.scan(
            TableName='Tenants-' + ou
        )
        #util.logger("DB RESPONSE: " + str(response))

        for tenant_app in response['Items']:
            if tenant_id == util.get_tenant_id(tenant_app['Tenant']['S']):
                #queues = json.loads(tenant_app['Queues']['S'])
                #queues.append(util.get_app_id(tenant_app['Tenant']['S']))
                #queue_list = '[\"' + util.get_app_id(tenant_app['Tenant']['S']) + '\"'
                #for queue in queues:
                #    queue_list = queue_list + ',\"'+ queue + '\"'
                #queue_list = queue_list + ']'
                tenant_app_list.append({
                    "AppID" : util.get_app_id(tenant_app['Tenant']['S']),
                    "Language" : tenant_app['Language']['S'],
                    "CallFlow" : tenant_app['CallFlow']['S'],
                    "DNIS": tenant_app['DNIS']['S'],
                    "Greeting": tenant_app['Greeting']['S'],
                    #"Queues": queue_list,
                    "Queues": tenant_app['Queues']['S'],
                    "Description": tenant_app['Description']['S'],
                    "ID":tenant_app['ID']['S'],
                    "flowControl":tenant_app['FlowControl']['S'],
                    "BusinessHours": tenant_app['BusinessHours']['S'],
                    "Holidays": tenant_app['Holidays']['S'],
                    "Prompts": read_tts(s3_client, tenant_id, util.get_app_id(tenant_app['Tenant']['S']), ['pleasehold', 'monitor', 'noagents', 'busy', 'highvolume', 'stillbusy', 'goodbye'])
                })
    
    except Exception as Ex1:
        util.logger("get_tenant_apps EXCEPTION: " + str(Ex1))

    return(tenant_app_list)

def list_phone_numbers(connect_client, connect_arn, connect_id, ou, tenant_id):
    assigned_phone_numbers = []
    available_phone_numbers = []

    list_phone_numbers_response = connect_client.list_phone_numbers(
        #TargetArn=connect_arn,
        InstanceId=connect_id
    )

    #util.logger("PHONE NUMBER LIST: " + str(list_phone_numbers_response))

    dynamodb_client = boto3.client('dynamodb')
    list_apps_response = dynamodb_client.scan(
        TableName='Tenants-' + ou
    )

    for tenant_app in list_apps_response['Items']:
        if tenant_id in tenant_app['Tenant']['S']:
            dnis_list = json.loads(tenant_app['DNIS']['S'])
            for dnis_obj in dnis_list:
                for dnis in dnis_obj:
                    assigned_phone_numbers.append(dnis) 

    #util.logger("ASSIGNED NUMBERS: " + str(assigned_phone_numbers))

    for phone_record in list_phone_numbers_response['PhoneNumberSummaryList']:
        if phone_record['PhoneNumber'] not in assigned_phone_numbers:
            phone_obj = {}
            phone_obj['PhoneNumber'] = phone_record['PhoneNumber']
            phone_obj['ID'] = phone_record['Id']
            phone_obj['Type'] = phone_record['PhoneNumberType']
            phone_obj['Country'] = phone_record['PhoneNumberCountryCode']
            
            available_phone_numbers.append(phone_obj)

    #util.logger("AVAILABLE NUMBERS: " + str(available_phone_numbers))

    return(available_phone_numbers)

def get_phone_number(connect_client, connect_id, tenant_id, country, dnis_type):
    #CLAIM PHONE NUMBER
    retry = True
    retries = 0
    phone_number = ""
    phone_number_id=""

    while retry and retries < 3:
        util.logger('SEARCH AND CLAIM PHONE NUMBER ATTEMPT: ' + str(retries))
        sleep(random.randint(0,5)**retries*100/1000)
        try:
            response = connect_client.search_available_phone_numbers(
                TargetArn=connect_id,
                PhoneNumberCountryCode=country,
                PhoneNumberType=dnis_type,
                MaxResults=1
            )
            phone_number = response['AvailableNumbersList'][0]['PhoneNumber']
            util.logger('CLAIMING NEW PHONE NUMBER: ' + phone_number)
        
            response = connect_client.claim_phone_number(
                TargetArn=connect_id,
                PhoneNumber=phone_number,
                PhoneNumberDescription= 'Tenant: ' + tenant_id,
            )
            phone_number_id = response['PhoneNumberId']
            retry = False
        except Exception as ex1:
            retries += 1
            util.logger('claim_phone_number EXCEPTION: ' + str(ex1))

    #connect_instance_details['PhoneNumberId'] = phone_number_id
    #connect_instance_details['PhoneNumber'] = phone_number
    retry = True
    retries = 0    

    while retry and retries < 3:
        util.logger('ASSOCIATE PHONE NUMBER ATTEMPT: ' + str(retries))

        try:
            contact_flow_list = connect_client.list_contact_flows(
                InstanceId=connect_id,
                ContactFlowTypes=['CONTACT_FLOW'],
                MaxResults=100
            )

            # GET Connect-RDF-Init FLOW ID
            for flow in contact_flow_list['ContactFlowSummaryList']:
                if flow['Name'] == 'Connect-RDF-Init':
                    response = connect_client.associate_phone_number_contact_flow(
                        PhoneNumberId=phone_number_id,
                        InstanceId=connect_id,
                        ContactFlowId=flow['Id']
                    )
            retry = False
        except Exception as ex1:
            sleep(3)
            retries += 1
            util.logger('get_phone_number EXCEPTION: ' + str(ex1))

    return{
        "PhoneNumber" : phone_number,
        "PhoneNumberID": phone_number_id
    }

def update_phone_number(connect_client, connect_id, tenant_id, country, dnis_type, previous_id):
    util.logger('UPDATING PHONE NUMBER')

    try:
        connect_client.release_phone_number(
            PhoneNumberId=previous_id
        )  
    except Exception as ex1:
        util.logger('release_phone_number EXCEPTION: ' + str(ex1))

    
    return get_phone_number(connect_client, connect_id, tenant_id, country, dnis_type)

def manual_delete_queue(connect_client, connect_id, queue_name):
    #multi_languages = language.split('_')

    queue_list = util.get_queue_summary_list(connect_client, connect_id)
    queue_id = util.get_queue_id(queue_list, queue_name)

    for queue in queue_list:
        if queue_name in queue['Name']:
            util.logger('DELETING QUEUE: ' + queue['Name'])
            queue_id = queue['Id']

            try:
                connect_client.delete_queue(
                    InstanceId=connect_id,
                    QueueId=queue_id
                )
            except Exception as ex1:
                util.logger('delete_queue EXCEPTION: ' + str(ex1))

def upload_rdf_application_files(role_credentials, tenant_bucket_name, tenant_id, app_id, files_to_update):
    util.logger("UPLOADING IGNITE-RDF APPLICATION FILES TO AMAZON CONNECT S3 BUCKET")
    s3_central_client = boto3.client('s3')
    s3_tenant_client = boto3.client('s3', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])    
    s3_tenant_resource = boto3.resource('s3', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])
            
    try:
        rdf_file_list = []
        if tenant_id:
            if files_to_update: #Specific RDF Files to update default app config files from Central Mgmt Acct
                list_s3_buckets_response = s3_central_client.list_objects(
                    Bucket=instances.get_central_bucket(s3_central_client),
                    Prefix='IVR/'
                )

                if "Contents" in list_s3_buckets_response:
                    rdf_file_list = list_s3_buckets_response['Contents']

                    while list_s3_buckets_response['IsTruncated']:
                        list_s3_buckets_response = s3_central_client.list_objects(
                            Marker=list_s3_buckets_response['NextMarker'],
                            MaxItems=100
                        )
                        
                        rdf_file_list.extend(list_s3_buckets_response['Contents'])

                app_folder = app_id
                for rdf_file in rdf_file_list:
                    for file_to_update in files_to_update:
                        if file_to_update in rdf_file['Key']:
                            s3_get_file_response = s3_central_client.get_object(Bucket=instances.get_central_bucket(s3_central_client), Key=rdf_file['Key'])
                            upload_file = s3_get_file_response['Body'].read()
                            util.logger("UPLOADING FILE: " + app_folder + '/' + rdf_file['Key'][rdf_file['Key'].find('/')+1:])
                            s3_tenant_resource.Object(tenant_bucket_name, app_folder + '/' + rdf_file['Key'][rdf_file['Key'].find('/')+1:]).put(Body=upload_file)

                #for rdf_file in rdf_file_list:
                #    for file_to_update in files_to_update:
                #        if file_to_update in rdf_file['Key']:
                #            s3_get_file_response = s3_tenant_client.get_object(Bucket=tenant_bucket_name, Key=rdf_file['Key'])
                #            upload_file = s3_get_file_response['Body'].read()
                #            util.logger("UPLOADING FILE: " + app_folder + '/' + rdf_file['Key'][rdf_file['Key'].find('/')+1:])
                #            s3_tenant_resource.Object(tenant_bucket_name, app_folder + '/' + rdf_file['Key'][rdf_file['Key'].find('/')+1:]).put(Body=upload_file)

            else:   #Creates a new Tenant application and uploads all required config files from default/         
                list_s3_buckets_response = s3_tenant_client.list_objects(
                    Bucket=tenant_bucket_name,
                    Prefix='default/'
                )

                if "Contents" in list_s3_buckets_response:
                    rdf_file_list = list_s3_buckets_response['Contents']

                    while list_s3_buckets_response['IsTruncated']:
                        list_s3_buckets_response = s3_tenant_client.list_objects(
                            Marker=list_s3_buckets_response['NextMarker'],
                            MaxItems=100
                        )
                        
                        rdf_file_list.extend(list_s3_buckets_response['Contents'])

                app_folder = tenant_id + '-' + app_id
                for rdf_file in rdf_file_list:
                    s3_get_file_response = s3_tenant_client.get_object(Bucket=tenant_bucket_name, Key=rdf_file['Key'])
                    upload_file = s3_get_file_response['Body'].read()
                    util.logger("UPLOADING FILE: " + app_folder + '/' + rdf_file['Key'][rdf_file['Key'].find('/')+1:])
                    s3_tenant_resource.Object(tenant_bucket_name, app_folder + '/' + rdf_file['Key'][rdf_file['Key'].find('/')+1:]).put(Body=upload_file)
                                
        else: #Used when creating a new tenant and uploading initial default config files
            list_s3_buckets_response = s3_central_client.list_objects(
                Bucket=instances.get_central_bucket(s3_central_client),
                Prefix='IVR/'
            )

            if "Contents" in list_s3_buckets_response:
                rdf_file_list = list_s3_buckets_response['Contents']

                while list_s3_buckets_response['IsTruncated']:
                    list_s3_buckets_response = s3_central_client.list_objects(
                        Marker=list_s3_buckets_response['NextMarker'],
                        MaxItems=100
                    )
                    
                    rdf_file_list.extend(list_s3_buckets_response['Contents'])

            app_folder = app_id
            for rdf_file in rdf_file_list:
                s3_get_file_response = s3_central_client.get_object(Bucket=instances.get_central_bucket(s3_central_client), Key=rdf_file['Key'])
                upload_file = s3_get_file_response['Body'].read()
                util.logger("UPLOADING FILE: " + app_folder + '/' + rdf_file['Key'][rdf_file['Key'].find('/')+1:])
                s3_tenant_resource.Object(tenant_bucket_name, app_folder + '/' + rdf_file['Key'][rdf_file['Key'].find('/')+1:]).put(Body=upload_file)            

    except Exception as Ex1:
        util.logger("upload_rdf_application_files EXCEPTION: " + str(Ex1))          

def delete_rdf_application_files(role_credentials, tenant_bucket_name, tenant_id, app_id):
    util.logger("DELETING IGNITE-RDF APPLICATION FILES FROM AMAZON CONNECT S3 BUCKET")

    s3_tenant_client = boto3.client('s3', region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])            
    try:
        rdf_file_list = []
        delete_objects = []
        list_s3_buckets_response = s3_tenant_client.list_objects(
            Bucket=tenant_bucket_name,
            Prefix=tenant_id + '-' + app_id + '/'
        )

        if "Contents" in list_s3_buckets_response:
            rdf_file_list = list_s3_buckets_response['Contents']

            while list_s3_buckets_response['IsTruncated']:
                list_s3_buckets_response = s3_tenant_client.list_objects(
                    Marker=list_s3_buckets_response['NextMarker'],
                    MaxItems=100
                )
                
                rdf_file_list.extend(list_s3_buckets_response['Contents'])

        for rdf_file in rdf_file_list:
            util.logger("DELETING FILE: " + rdf_file['Key'])
            delete_objects.append({
                'Key': rdf_file['Key'],
            })
          
        s3_tenant_client.delete_objects(
            Bucket=tenant_bucket_name,
            Delete={
                'Objects': delete_objects
            }
        )        
        
    except Exception as Ex1:
        util.logger("delete_rdf_application_files EXCEPTION: " + str(Ex1))

def get_business_hours(s3_client, connect_client, connect_id, tenant_id, app_id):
    found = False
    if app_id == 'Default':
        business_hours_name = "Business Hours"
    else:
        business_hours_name = app_id

    list_hours_response = connect_client.list_hours_of_operations(InstanceId=connect_id)
    for hours_setting in list_hours_response['HoursOfOperationSummaryList']:
        if hours_setting['Name'] == business_hours_name:
            found = True
            hours_id =  hours_setting['Id']

            hours_response = connect_client.describe_hours_of_operation(
                InstanceId=connect_id,
                HoursOfOperationId=hours_id
            )
            hours_config = hours_response['HoursOfOperation']['Config']
            hours_tz = hours_response['HoursOfOperation']['TimeZone']

    if not found:
            hours_config = config.hours_of_operations
            hours_tz = 'America/Toronto'

    prompts = read_tts(s3_client, tenant_id, app_id, ['closed'])
    return({
            "TimeZone" :hours_tz,
            "Config" : hours_config,
            "Prompts" : prompts
        })

def put_business_hours(s3_client, s3_resource, role_credentials, connect_client, connect_id, hours_config, tenant_id, app_id, prompts):
    if app_id == 'Default':
        business_hours_name = "Business Hours"
        app_id = 'default'
    else:
        business_hours_name = app_id

    hours_exists = False
    list_hours_response = connect_client.list_hours_of_operations(InstanceId=connect_id)
    for hours_setting in list_hours_response['HoursOfOperationSummaryList']:
        if hours_setting['Name'] == business_hours_name:
            hours_id =  hours_setting['Id']
            hours_exists = True
    
            describe_hours_response = connect_client.describe_hours_of_operation(
                InstanceId=connect_id,
                HoursOfOperationId=hours_id
            )
            hours_name = describe_hours_response['HoursOfOperation']['Name']
            try:
                hours_desc = describe_hours_response['HoursOfOperation']['Description']
            except:
                hours_desc = ""

            util.logger('UPDATING ' + app_id + ' BUSINESS HOURS')
            connect_client.update_hours_of_operation(
                InstanceId=connect_id,
                HoursOfOperationId=hours_id,
                Name=hours_name,
                Description=hours_desc,
                TimeZone=hours_config['TimeZone'],
                Config=hours_config['Config']
            )

    if not hours_exists:
        util.logger('CREATING ' + app_id + ' BUSINESS HOURS')
        connect_client.create_hours_of_operation(
            InstanceId=connect_id,
            Name=app_id,
            Description=app_id + ' Business Hours',
            TimeZone=hours_config['TimeZone'],
            Config=hours_config['Config']
        ) 

    if prompts:
        update_tts(s3_client, s3_resource, tenant_id, app_id, prompts, role_credentials)

def update_tts(s3_client, s3_resource, tenant_id, app_id, prompts, role_credentials):
    util.logger('UPDATING TTS: ' + str(prompts))
    import csv
    import codecs
    from io import StringIO

    data={}
    csv_buffer = StringIO()
    new_contents = []
    new_contents.append('LABEL')
    prompt_key = next(iter(prompts))
    for language in prompts[prompt_key]:
        new_contents.append(language)
    
    csv_writer = csv.writer(csv_buffer, quoting=csv.QUOTE_NONNUMERIC)
    csv_writer.writerow(new_contents)
    if app_id != 'Default':
        s3_response = s3_client.get_object(Bucket=instances.get_tenant_bucket(s3_client), Key= tenant_id + "-" + app_id + "/config/" + 'ivr-tts.csv')
    else:
        s3_response = s3_client.get_object(Bucket=instances.get_tenant_bucket(s3_client), Key= "default/config/" + 'ivr-tts.csv')

    for row in csv.DictReader(codecs.getreader("utf-8-sig")(s3_response['Body'])):
        record = row['LABEL']
        data[record] = row

    for tts_record in data:
        new_contents = []
        new_contents.append(tts_record)
        if tts_record in prompts:
            for language in prompts[tts_record]:
                new_contents.append(prompts[tts_record][language])
        else:
            for language in prompts[prompt_key]:
                if language in data[tts_record]:
                    new_contents.append(data[tts_record][language])
                else:
                    #new_contents.append(" ")
                    util.logger('TRANSLATING: ' + str(data[tts_record]['en-US']))
                    new_contents.append(util.translate_text(data[tts_record]['en-US'], 'en-US', language))
        csv_writer.writerow(new_contents)

    if app_id == 'Default':
        app_folder = 'default'
    else:
        app_folder = tenant_id + "-" + app_id

    s3_resource.Object(instances.get_tenant_bucket(s3_client), app_folder + "/config/" + 'ivr-tts.csv').put(Body=csv_buffer.getvalue())
    #instances.put_tenant_object(s3_client, s3_resource, 'ivr-tts.csv', csv_buffer.getvalue(), tenant_id, app_id, prompts)

def read_tts(s3_client, tenant_id, app_id, prompt_keys):
    import csv
    import codecs
    data = {}
    prompts={}

    try:
        for prompt_key in prompt_keys:
            prompts[prompt_key]={}

        if app_id != 'Default':
            s3_response = s3_client.get_object(Bucket=instances.get_tenant_bucket(s3_client), Key= tenant_id + "-" + app_id + "/config/ivr-tts.csv")
        else:
            s3_response = s3_client.get_object(Bucket=instances.get_tenant_bucket(s3_client), Key= "default/config/ivr-tts.csv")

        for row in csv.DictReader(codecs.getreader("utf-8-sig")(s3_response['Body'])):
            record = row['LABEL']
            data[record] = row

        for tts_record in data:
            for prompt_key in prompt_keys:
                if tts_record == prompt_key:
                    for language in data[tts_record]:
                        if 'LABEL' not in language:
                            prompts[prompt_key][language] = data[tts_record][language]

    except Exception as Ex1:
        util.logger("read_tts EXCEPTION: " + str(Ex1))
               
    return(prompts)

def get_language_name(ou, language):
    language_full_name = get_voices(ou, "")['Available'][language]['Name']
    language_parts = language_full_name.split(" ")
    language_name = language_parts[len(language_parts) - 1]

    return(language_name)

def get_voices(ou, tenant_id):
    list_voices = []
    polly_client = boto3.client('polly')
    describe_voices_response = polly_client.describe_voices(
        IncludeAdditionalLanguageCodes=False
    )

    list_voices = describe_voices_response['Voices']

    while 'NextToken' in describe_voices_response:
        describe_voices_response = polly_client.describe_voices(
            IncludeAdditionalLanguageCodes=False,
            NextToken=describe_voices_response['NextToken']
        )
        list_voices.extend(describe_voices_response['Voices'])        

    voices = {}
    voices['Available'] = {}
    #voices['Available'] = config.voices

    for voice in list_voices:
        if voice['LanguageCode'] not in voices['Available']:
            voices['Available'][voice['LanguageCode']] = {}
            voices['Available'][voice['LanguageCode']]['Name'] = voice['LanguageName']
            voices['Available'][voice['LanguageCode']]['Voices'] = []
            voices['Available'][voice['LanguageCode']]['Voices'].append(voice['Id'])
        else:
            voices['Available'][voice['LanguageCode']]['Voices'].append(voice['Id'])

    if tenant_id:
        dynamodb_client = boto3.client('dynamodb')
        try:
            response = dynamodb_client.scan(
                TableName='Instances-' + ou
            )
            #util.logger("DB RESPONSE: " + str(response))

            for tenant in response['Items']:
                if tenant_id in tenant['Tenant']['S']:
                    #default_voices = json.loads(tenant['DefaultVoices']['S'])
                    active_voices = json.loads(tenant['ActiveVoices']['S'])

            #voices['Default'] = default_voices
            voices['Active'] = active_voices
            
        except Exception as Ex1:
            util.logger("get_voices EXCEPTION: " + str(Ex1))
    else:
        voices['Active'] = config.default_voices

    return(voices)

#def get_voices(connect_client, connect_id):
#    voices = {}
#    language_identifiers={}
#    default_voices = {}
#
#    list_contact_flows_response = connect_client.list_contact_flows(
#        InstanceId=connect_id,
#        ContactFlowTypes=[
#            'CONTACT_FLOW'
#        ]
#    )
#
#    for voice_identifier in config.voice_identifiers:
#        default_voices[voice_identifier]={}
#        language_identifiers[voice_identifier]={}
#
#    for contact_flow in list_contact_flows_response['ContactFlowSummaryList']:
#        if contact_flow['Name'] == 'Connect-RDF-Main':
#            util.logger("GETTING LANGUAGES FOR APP: " + contact_flow['Name'])
#            
#            get_contact_flow_response = connect_client.describe_contact_flow(
#                InstanceId=connect_id,
#                ContactFlowId=contact_flow['Id']
#            )
#
#            flow = json.loads(get_contact_flow_response['ContactFlow']['Content'])

#            for action in flow['Actions']:
#                for voice_identifier in config.voice_identifiers:
#                    if action["Identifier"] == config.voice_identifiers[voice_identifier]:
#                        default_voices[voice_identifier]['Voice'] = action['Parameters']['TextToSpeechVoice']
#                        language_identifiers[voice_identifier] = action['Transitions']['NextAction']

#            for action in flow['Actions']:
#                for language_identifier in language_identifiers:
#                    if action["Identifier"] == language_identifiers[language_identifier]:
#                        default_voices[language_identifier]['Language'] = action['Parameters']['LanguageCode']

#    voices['Default'] = default_voices
#    voices['Available'] = config.voices

#    return(voices)

def set_voices(connect_client, connect_id, ou, tenant_id, active_voices):
    import os
    polly_client = boto3.client('polly')

    #default_voices = get_voices(connect_client, connect_id)['Active']
    if config.bcp_install and ou == 'PROD':
        ou = 'BCP'

    tenant_name = ou.lower() + os.environ['ORGANIZATION_NAME'] + '-' + tenant_id

    list_contact_modules_response = connect_client.list_contact_flow_modules(
        InstanceId=connect_id,
        ContactFlowModuleState='ACTIVE'
    )

    language_identifiers={}
    #current_voices = {}
    #for voice_identifier in config.voice_identifiers:
        #current_voices[voice_identifier]={}
        #language_identifiers[voice_identifier]={}
    #    language_identifiers = {}

    for contact_module in list_contact_modules_response['ContactFlowModulesSummaryList']:
        if contact_module['Name'] == 'Connect-RDF-Languages':
            util.logger("UPDATING LANGUAGES FOR: " + contact_module['Name'])
            
            get_contact_module_response = connect_client.describe_contact_flow_module(
                InstanceId=connect_id,
                ContactFlowModuleId=contact_module['Id']
            )
            
            flow = json.loads(get_contact_module_response['ContactFlowModule']['Content'])
            new_flow = {}
            new_flow['Version'] = flow['Version']
            new_flow['StartAction'] = flow['StartAction']
            new_flow['Metadata'] = flow['Metadata']
            new_flow['Settings'] = flow['Settings']
            new_flow['Actions'] = []
            temp_actions = []
            cond_counter = 0

            for action in flow['Actions']:
                for voice_index in config.case_actions:
                    if action['Identifier'] == config.case_actions[voice_index]:
                        try:
                            describe_voice_response = polly_client.describe_voices(
                                LanguageCode=active_voices[voice_index]["Language"],
                                IncludeAdditionalLanguageCodes=False
                            )
                            for voice in describe_voice_response['Voices']:
                                if active_voices[voice_index]['Voice'] == voice['Id']:
                                    supported_engines = voice['SupportedEngines']

                            action['Parameters']['TextToSpeechVoice'] = active_voices[voice_index]['Voice']
                            if 'neural' in supported_engines:                            
                                action['Parameters']['TextToSpeechEngine'] = 'Neural'
                                action['Parameters']['TextToSpeechStyle'] = 'None'
                            else:
                                try:
                                    del action['Parameters']['TextToSpeechEngine']
                                    del action['Parameters']['TextToSpeechStyle']
                                except:
                                    pass
                        except:
                            action['Parameters']['TextToSpeechVoice'] = 'Stephen'
                        language_identifiers[voice_index] = action['Transitions']['NextAction']
                    if action['Type'] == "Compare":
                        for condition in action['Transitions']['Conditions']:
                            if condition['NextAction'] == config.case_actions[voice_index]:
                                try:
                                    condition['Condition']['Operands'] = [active_voices[voice_index]["Language"]]
                                except:
                                    cond_counter += 1
                                    condition['Condition']['Operands'] = ['notused_' + str(cond_counter)] 

                temp_actions.append(action)

            for action in temp_actions:
                for voice_index in config.case_actions:
                    if action['Identifier'] == language_identifiers[voice_index]:
                        try:
                            action['Parameters']['LanguageCode'] = active_voices[voice_index]["Language"]
                        except:
                            action['Parameters']['LanguageCode'] = 'en-US'

                new_flow['Actions'].append(action)

            flow = json.dumps(new_flow)

            connect_client.update_contact_flow_module_content(
                InstanceId=connect_id,
                ContactFlowModuleId=contact_module['Id'],
                Content=flow
            )

    try:
        table = boto3.resource('dynamodb').Table('Instances-' + ou)

        table.update_item(
                Key = {
                    'Tenant': tenant_name
                },
                UpdateExpression='SET #attr1 = :val1',
                ExpressionAttributeNames={'#attr1': 'ActiveVoices'},
                ExpressionAttributeValues={':val1': json.dumps(active_voices)}
            )

    except Exception as Ex1:
        util.logger("update voices EXCEPTION: " + str(Ex1)) 

def list_objects(s3_client, connect_id, tenant_id, app_id, object_type, language):
    from datetime import datetime
    if language:
        prefix = tenant_id + '-' + app_id + '/' + object_type + '/ivr/' + language + '/'
    else:
        prefix = tenant_id + '-' + app_id + '/' + object_type + '/'

    list_objects = []
    list_objects_response = s3_client.list_objects_v2(
        Bucket='amazon-connect-' + connect_id,
        #Prefix= tenant_id + '-' + app_id + '/' + object_type + '/'
        Prefix= prefix
    )

    if list_objects_response['KeyCount'] > 0:
        for object in list_objects_response['Contents']:
            #list_objects.append(object['Key'][object['Key'].find('/')+1:])
            found_object = {}
            found_object['Name'] = object['Key'][object['Key'].find('/')+1:]
            date_object = str(object['LastModified'])
            found_object['Date'] = date_object[0:date_object.find('+')]
            found_object['Size'] = str(object['Size']) + ' bytes'
            list_objects.append(found_object)
    else:
        list_objects.append('Not Found')

    return(list_objects)

def get_binary_object(s3_resource, connect_id, tenant_id, app_id, object_type, filename, language):
    import io
    import base64
    #import sys
    if object_type == 'prompts':
        object_key = tenant_id + '-' + app_id + '/' + object_type + '/ivr/' + language + '/' + filename
    else:
        object_key = tenant_id + '-' + app_id + '/' + object_type + '/' + filename

    #meta_data = s3_client.head_object(Bucket='amazon-connect-' + connect_id, Key=object_key)
    #total_length = int(meta_data.get('ContentLength', 0))
    #downloaded = 0
    #def progress(chunk):
    #    nonlocal downloaded
    #    downloaded += chunk
    #    done = int(50 * downloaded / total_length)
    #    sys.stdout.write("\r[%s%s] %%%s " % ('=' * done, ' ' * (50 - done), round(downloaded / total_length * 100, 2)))
    #    sys.stdout.flush()
    
    obj = s3_resource.Object('amazon-connect-' + connect_id, object_key)
    data = io.BytesIO()
    obj.download_fileobj(data)

    #f = io.BytesIO()
    #s3_resource.download_fileobj('amazon-connect-' + connect_id, object_key, f, Callback=progress)
    #f.seek(0)    
    #s3_response = s3_client.get_object(Bucket='amazon-connect-' + connect_id, Key= object_key) 
    #util.logger("S3 RESPONSE: " + str(s3_response))  
    #return(s3_response['Body'].read().decode('utf-8'))   
    return(base64.b64encode(data.getvalue()).decode())

def put_binary_object(s3_resource, connect_id, tenant_id, app_id, object_type, filename, language, content):
    import io
    import base64
    #import sys
    if object_type == 'prompts':
        object_key = tenant_id + '-' + app_id + '/' + object_type + '/ivr/' + language + '/' + filename
    else:
        object_key = tenant_id + '-' + app_id + '/' + object_type + '/' + filename

    #obj = s3_resource.Object('amazon-connect-' + connect_id, object_key)
    #data = io.BytesIO()
    #obj.download_fileobj(data)
    s3_resource.Object('amazon-connect-' + connect_id, object_key).put(Body=base64.b64decode(content))

def delete_object(s3_client, connect_id, tenant_id, app_id, object_type, filename, language):
    if object_type == 'prompts':
        object_key = tenant_id + '-' + app_id + '/' + object_type + '/ivr/' + language + '/' + filename
    else:
        object_key = tenant_id + '-' + app_id + '/' + object_type + '/' + filename

    response = s3_client.delete_object(
        Bucket='amazon-connect-' + connect_id,
        Key=object_key
    )

def get_tenant_queues(ou, tenant_id):
    queues_list = []
    util.logger("GETTING QUEUE LIST FOR TENANT: " + tenant_id)
    dynamodb_client = boto3.client('dynamodb')
    try:
        response = dynamodb_client.scan(
            TableName='Tenants-' + ou
        )
        util.logger("DB RESPONSE: " + str(response))

        for tenant in response['Items']:
            if tenant_id + '-' in tenant['Tenant']['S']:
                app_queues = json.loads(tenant['Queues']['S'])
                for app_queue in app_queues:
                    if app_queue not in queues_list:
                        queues_list.append(app_queue)
    
    except Exception as Ex1:
        util.logger("get_tenant_queues EXCEPTION: " + str(Ex1))

    return(queues_list)   

def deploy_app(source_ou, target_ou, tenant_id, app_id, dnis, role_credentials, s3_source_client, s3_target_client, s3_target_resource, connect_source_client, connect_target_client, connect_instance_details, source_connect_id, target_connect_id, deploy_tenant, deploy_users):
    status = 'Success'

    tenant_name = tenant_id + '-' + app_id
    dnis_array = []
    dnis_object = {}

    dnis_array = json.loads(dnis)
    dnis_object = dnis_array[0]
    dnis = next(iter(dnis_object))
    dnis_id = dnis_object[dnis]

    util.logger("DEPLOYING APP: " + app_id + " FOR TENANT: " + tenant_id + " FROM: " + source_ou + " TO: " + target_ou)
    dynamodb_client = boto3.client('dynamodb')
    try:
        response = dynamodb_client.scan(
            TableName='Tenants-' + source_ou
        )
        util.logger("DB RESPONSE: " + str(response))

        for tenant in response['Items']:
            if tenant_name == tenant['Tenant']['S']:
                util.logger("Found Tenant: " + tenant['Tenant']['S'])
                description = tenant['Description']['S']
                language = tenant['Language']['S']
                greeting = tenant['Greeting']['S']
                callFlow = tenant['CallFlow']['S']
                related_queues = json.loads(tenant['Queues']['S'])
                flow_control = tenant['FlowControl']['S']
                business_hours = tenant['BusinessHours']['S']
                holidays = tenant['Holidays']['S']
                language_menu = tenant['LanguageMenu']['S']

    except Exception as Ex1:
        util.logger("deploy_app EXCEPTION: " + str(Ex1))

    queues_created = []
    quick_connect_ids=[]

    multi_languages = json.loads(language)
    #language_menu['default'] = multi_languages[0][0].upper() + multi_languages[0][1].lower()

    for lang in multi_languages:
        #lang_code = lang[0].upper() + lang[1].lower()
        response = create_queue(target_ou, connect_target_client, connect_instance_details, app_id, lang, description, dnis_id, business_hours)
        queue_id = response['queueID']
        queues_created.append(queue_id)
        if related_queues:
            if response['result']: #If Queue was newly created, also create a QC
                response = create_quick_connect(target_ou, connect_target_client, connect_instance_details, app_id, lang, queue_id)
                if response['result']: #Add to QC array
                    quick_connect_ids.append(response['qcID'])
                    
            else: #If Queue already existed, attempt to create a QC in case it wasn't created
                response = create_quick_connect(target_ou, connect_target_client, connect_instance_details, app_id, lang, queue_id)
                if response['result']: #Add to QC array
                    quick_connect_ids.append(response['qcID'])  
                else: #if QC already existed, find QC ID and add to QC array
                    qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], app_id + ' ' + get_language_name(target_ou, lang))
                    quick_connect_ids.append(qc_id)            

    try:
        table = boto3.resource('dynamodb').Table('Tenants-' + target_ou)

        #Since Language is a Sort Key and can not be updated, need to recreate record.
        try:
            table.delete_item(Key={"Tenant": tenant, "Language": language})
        except:
            pass
 
        table.put_item(Item= {'Tenant': tenant_name, 
            'Language': language, 
            'Description': description, 
            'DNIS': json.dumps(dnis_array),
            'Greeting': greeting,
            'LanguageMenu': language_menu,
            'CallFlow': callFlow,
            'Queues': json.dumps(related_queues),
            'FlowControl': flow_control,
            'BusinessHours': business_hours,
            'Holidays': holidays,
            'ID': dnis_id
        })

    except Exception as ex1:
        status = "Failed to deploy app"
        util.logger('deploy_app EXCEPTION FOUND: ' + str(ex1))

    if related_queues:
        for related_queue in related_queues:
            if '+' not in related_queue: #Create Queues + Quick Connect
                #language_menu = {'en-US': False, 'fr-CA': False, 'es-MX': False, 'pt-BR': False}
                for lang in multi_languages:
                    if lang:
                        #lang_code = lang[0].upper() + lang[1].lower()
                        #language_menu[lang] = True
                        response = create_queue(target_ou, connect_target_client, connect_instance_details, related_queue, lang, related_queue, dnis_id, business_hours) #Create Queue in case it doesn't exist
                        queues_created.append(response['queueID'])
                        if response['result']: #If Queue was newly created, also create a QC
                            response = create_quick_connect(target_ou, connect_target_client, connect_instance_details, related_queue, lang, response['queueID'])
                            if response['result']: #Add to QC array
                                quick_connect_ids.append(response['qcID'])
                                
                        else: #If Queue already existed, attempt to create a QC in case it wasn't created
                            response = create_quick_connect(target_ou, connect_target_client, connect_instance_details, related_queue, lang, util.get_queue_id(connect_instance_details['QueueSummaryList'], related_queue + ' ' + get_language_name(target_ou,lang)))
                            if response['result']: #Add to QC array
                                quick_connect_ids.append(response['qcID'])  
                            else: #if QC already existed, find QC ID and add to QC array
                                qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], related_queue + ' ' + get_language_name(target_ou, lang))
                                quick_connect_ids.append(qc_id)
            else: #Create Phone Quick Connect
                response = create_phone_quick_connect(connect_target_client, connect_instance_details, related_queue, description)
                if response['result']: #Add to QC array
                    quick_connect_ids.append(response['qcID'])
                else:
                    qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], related_queue)
                    quick_connect_ids.append(qc_id)                 
        try:
            for queue in queues_created:
                util.logger("ASSIGNING QUICK CONNECTS: " + str(quick_connect_ids) + " TO QUEUE: " + queue)
                response = connect_target_client.associate_queue_quick_connects(
                    InstanceId=connect_instance_details['instanceID'],
                    QueueId=queue,
                    QuickConnectIds=quick_connect_ids
                )
        except Exception as ex1:
            util.logger('associate_queue_quick_connects EXCEPTION: ' + str(ex1))


    deploy_rdf_application_files(s3_source_client, s3_target_client, source_connect_id, target_connect_id, tenant_id, app_id)

    if deploy_tenant:
        util.logger("DEPLOYING TENANT SETTINGS FOR: " + tenant_id + " FROM: " + source_ou + " TO: " + target_ou)
        voice_config_default = get_voices(target_ou, tenant_id)
        voice_config_active = get_voices(source_ou, tenant_id) 
        set_voices(connect_target_client, target_connect_id, target_ou, tenant_id, voice_config_active['Active'])  
        hours_config = get_business_hours(s3_source_client, connect_source_client, source_connect_id, tenant_id, app_id)
        put_business_hours(s3_target_client, s3_target_resource, role_credentials, connect_target_client, target_connect_id, hours_config, tenant_id, app_id, {})
    if deploy_users:
        util.logger("DEPLOYING USERS FOR: " + tenant_id + " FROM: " + source_ou + " TO: " + target_ou)
        users.deploy_users(source_ou, target_ou, tenant_id)

    return status

def deploy_rdf_application_files(s3_source_client, s3_target_client, source_connect_id, target_connect_id, tenant_id, app_id):
    util.logger("DEPLOYING IGNITE-RDF APPLICATION FILES TO AMAZON CONNECT S3 BUCKET")

    try:
        rdf_file_list = []
        list_s3_buckets_response = s3_source_client.list_objects(
            Bucket='amazon-connect-' + source_connect_id,
            Prefix=tenant_id + '-' + app_id + '/'
        )

        if "Contents" in list_s3_buckets_response:
            rdf_file_list = list_s3_buckets_response['Contents']

            while list_s3_buckets_response['IsTruncated']:
                list_s3_buckets_response = s3_source_client.list_objects(
                    Marker=list_s3_buckets_response['NextMarker'],
                    MaxItems=100
                )
                
                rdf_file_list.extend(list_s3_buckets_response['Contents'])

        list_s3_buckets_response = s3_source_client.list_objects(
            Bucket='amazon-connect-' + source_connect_id,
            Prefix='default/'
        )

        if "Contents" in list_s3_buckets_response:
            rdf_file_list.extend(list_s3_buckets_response['Contents'])

            while list_s3_buckets_response['IsTruncated']:
                list_s3_buckets_response = s3_source_client.list_objects(
                    Marker=list_s3_buckets_response['NextMarker'],
                    MaxItems=100
                )
                
                rdf_file_list.extend(list_s3_buckets_response['Contents'])

        for rdf_file in rdf_file_list:
            s3_get_file_response = s3_source_client.get_object(Bucket='amazon-connect-' + source_connect_id, Key=rdf_file['Key'])
            upload_file = s3_get_file_response['Body'].read()
            util.logger("UPLOADING FILE: " + rdf_file['Key'])
            s3_target_client.Object('amazon-connect-' + target_connect_id, rdf_file['Key']).put(Body=upload_file)            

    except Exception as Ex1:
        util.logger("deploy_rdf_application_files EXCEPTION: " + str(Ex1))      

def update_menu_tree(ou, role_credentials, s3_client, s3_resource, tenant_id, app_id, content):
    util.logger("UPDATING MENU TREE")
    import csv
    import codecs
    from io import StringIO

    data={}
    csv_buffer = StringIO()
    new_contents = []
    new_contents.append('LABEL')
    new_contents.append('QUEUE')
    languages = instances.get_languages(ou, tenant_id)

    for language in languages:
        new_contents.append(language)
    
    csv_writer = csv.writer(csv_buffer, quoting=csv.QUOTE_NONNUMERIC)
    csv_writer.writerow(new_contents)

    
    if type(content) is str:
        for row in csv.DictReader(content.splitlines()):
            record = row['LABEL']
            data[record] = row
    else:
        for row in csv.DictReader(codecs.getreader("utf-8-sig")(content)):
            record = row['LABEL']
            data[record] = row

    for menu_key in data:
        new_contents = []
        new_contents.append(menu_key)
        new_contents.append(data[menu_key]['QUEUE'])
        for language in languages:
            if language in data[menu_key]:
                new_contents.append(data[menu_key][language])
            else:
                try:
                #if data[menu_key]['en-US']:
                    new_contents.append(util.translate_text(data[menu_key]['en-US'], 'en-US', language))
                    util.logger('TRANSLATING: ' + str(data[menu_key]['en-US']))
                except:
                    new_contents.append("")   
                
        csv_writer.writerow(new_contents)

    return(csv_buffer.getvalue())
#    if app_id == 'Default':
#        app_folder = 'default'
#    else:
#        app_folder = tenant_id + "-" + app_id

#    s3_resource.Object(instances.get_tenant_bucket(s3_client), app_folder + "/config/" + 'ivr-tts.csv').put(Body=csv_buffer.getvalue())

def synthesize_speech(language, voice, text):
    import base64
    import io
    client = boto3.client('polly')
    s3_resource = boto3.resource('s3')

    if "Hello, my name is" in text:
        text = util.translate_text(text, 'en-US', language)

    describe_voice_response = client.describe_voices(
        LanguageCode=language,
        IncludeAdditionalLanguageCodes=False
    )
    for voice_id in describe_voice_response['Voices']:
        if voice == voice_id['Id']:
            supported_engines = voice_id['SupportedEngines']
            if 'neural' in supported_engines:
                engine_type = 'neural'
            else:
                engine_type = 'standard'

    util.logger(engine_type)
    response = client.synthesize_speech(
        Engine=engine_type,
        LanguageCode=language,
        OutputFormat='mp3',
        #SampleRate='24000',
        Text='<speak>' + text + '</speak>',
        TextType='ssml',
        VoiceId=voice
    )

    stream = response['AudioStream'].read()
    #audio = io.BytesIO(stream)
    #content = base64.b64encode(stream).decode()
    content = base64.b64encode(stream)
    
    #s3_resource.Object('central-jwsulvgjg54f', "test.wav").put(Body=audio) 
    return(content)