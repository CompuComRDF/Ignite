import json
import boto3
import time
import util

def remove_connect_tenant(ou, event, connect_client, connect_instance_details):
    dynamodb_client = boto3.client('dynamodb')
    old_image = event['Records'][0]['dynamodb']['OldImage']
    tenant_id = old_image['Tenant']['S']
    language = old_image['Language']['S']
    related_queues = json.loads(old_image['Queues']['S'])
    try:
        phone_number_id = old_image['ID']['S']
    except:
        phone_number_id = "NA"

    queues_to_delete = []
    queues_to_delete.append(tenant_id + 'GEN_')
    for related_queue in related_queues:
        if '+' not in related_queue: 
            queues_to_delete.append(related_queue + 'GEN_') #Queues & Queue Quick Connects
        else:
            queues_to_delete.append(related_queue) #Phone Quick Connects
    
    multi_languages = language.split('_')

    for queue in queues_to_delete:
        if '+' not in queue: #Queues + Quick Connects
            for lang in multi_languages:
                if lang:
                    queue_id = util.get_queue_id(connect_instance_details['queueList'], queue + lang)
                    delete_queue = False
                    
                    if len(multi_languages) > 2:
                        util.logger("MULTI-LANGUAGE DNIS.  CHECKING IF QUEUE: " + queue + lang + " IS STILL REQUIRED")
                        response = dynamodb_client.get_item(
                            TableName='Tenants-' + ou,
                            Key={
                                'Tenant': {'S': tenant_id},
                                'Language': {'S': '_' + lang}
                            }
                        )
                        try:
                            util.logger("DB RESPONSE: " + str(response['Item']))
                            if response['Item']['Tenant']['S'] != tenant_id:
                                delete_queue = True
                        except:
                            delete_queue = True
                    else:
                        util.logger("SINGLE-LANGUAGE DNIS.  CHECKING IF QUEUE: " + queue + lang + " IS STILL REQUIRED")
                        delete_queue = True
                        response = dynamodb_client.query(
                            TableName='Tenants-' + ou,
                            KeyConditionExpression='Tenant = :tenant_id',
                            ExpressionAttributeValues={
                                ':Tenant': {'S': tenant_id}
                            }
                        )
                        try:
                            util.logger("DB RESPONSE: " + str(response['Items']))
                            for i in response['Items']:
                                if lang in i['language']['S']:
                                    delete_queue = False
                        except:
                            delete_queue = False
                            
                    if delete_queue:
                        util.logger("DELETING QUEUE: " + queue + lang)
                        qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], queue +lang+'_QC')
                        if qc_id != "NOT FOUND":
                            remove_quick_connect(connect_client, connect_instance_details, qc_id)
                            
                        remove_queue(connect_client, connect_instance_details, queue_id)
                    else:
                        util.logger("KEEPING QUEUE: " + queue + lang)
        
        else:
            qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], queue)
            if qc_id != "NOT FOUND":
                remove_quick_connect(connect_client, connect_instance_details, qc_id)
                            
    release_phone_number(connect_client, phone_number_id)

def create_connect_tenant(ou, event, connect_client, connect_instance_details):
    new_image = event['Records'][0]['dynamodb']['NewImage']
    tenant_id = new_image['Tenant']['S']
    tenant_name = new_image['TenantName']['S']
    greeting = json.loads(new_image['Greeting']['S'])
    language = new_image['Language']['S']
    related_queues = json.loads(new_image['Queues']['S'])
    queues_created = []
    quick_connect_ids=[]
    language_regions = {'En': 'en-US', 'Fr':'fr-CA', 'Es':'es-MX', 'Pt':'pt-BR'}
    language_options = {'En': 'For service in English, press ', 'Fr': 'Pour le service en français, appuyez sur ', 'Es': 'Para servicio en español, presione ', 'Pt': 'Para atendimento em português, pressione '}
    language_menu = {}
    language_menu['greeting'] = ''
    language_menu['options'] = ''
    lang_menu_opt = 0

    multi_languages = language.split('_')
    while('' in multi_languages):
        multi_languages.remove('')
    
    language_menu['default'] = multi_languages[0]

    for lang in multi_languages:
        lang_menu_opt += 1
        if lang_menu_opt > 1:
            language_menu['greeting'] += '|'
            language_menu['options'] += '|'
        language_menu['greeting'] += language_regions[lang] + ':' + greeting[lang]
        if not greeting[lang].endswith(".") and not len(greeting[lang])==0:
            language_menu['greeting'] += '.'
        if len(multi_languages) > 1:
            language_menu['greeting'] += ' ' + language_options[lang] + str(lang_menu_opt)
            language_menu['options'] += str(lang_menu_opt) + ':' + lang.upper()
        response = create_queue(connect_client, connect_instance_details, tenant_id, '_' + lang, tenant_name)
        queue_id = response['queueID']
        queues_created.append(queue_id)
        if related_queues:
            response = create_quick_connect(connect_client, connect_instance_details, tenant_id, lang, queue_id)
            quick_connect_ids.append(response['qcID'])
        
    if language_menu['options']:
        language_menu['options'] += '|maxaction:' + language_menu['default'].upper()

    phone_number = claim_phone_number(connect_client, connect_instance_details, tenant_id, language, language_menu, tenant_name, ou)

    if related_queues:
        for related_queue in related_queues:
            if '+' not in related_queue: #Create Queues + Quick Connect
                language_menu = {'En': False, 'Fr': False, 'Es': False, 'Pt': False}
                for lang in multi_languages:
                    if lang:
                        language_menu[lang] = True
                        response = create_queue(connect_client, connect_instance_details, related_queue, '_' + lang, related_queue.replace('_','')) #Create Queue in case it doesn't exist
                        queues_created.append(response['queueID'])
                        
                        if response['result']: #If Queue was newly created, also create a QC
                            response = create_quick_connect(connect_client, connect_instance_details, related_queue, lang, response['queueID'])
                            if response['result']: #Add to QC array
                                quick_connect_ids.append(response['qcID'])
                                
                        else: #If Queue already existed, attempt to create a QC in case it wasn't created
                            response = create_quick_connect(connect_client, connect_instance_details, related_queue, lang, util.get_queue_id(connect_instance_details['queueList'], related_queue + 'GEN_' + lang))
                            if response['result']: #Add to QC array
                                quick_connect_ids.append(response['qcID'])                                
                            else: #if QC already existed, find QC ID and add to QC array
                                qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], related_queue+'GEN_'+lang+'_QC')
                                quick_connect_ids.append(qc_id)
            else: #Create Phone Quick Connect
                response = create_phone_quick_connect(connect_client, connect_instance_details, related_queue, tenant_name)
                if response['result']: #Add to QC array
                    quick_connect_ids.append(response['qcID'])
                else:
                    qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], related_queue)
                    quick_connect_ids.append(qc_id)                 
        try:
            for queue in queues_created:
                util.logger("ASSIGNING QUICK CONNECTS: " + str(quick_connect_ids) + " TO QUEUE: " + queue)
                response = connect_client.associate_queue_quick_connects(
                    InstanceId=connect_instance_details['instanceID'],
                    QueueId=queue,
                    QuickConnectIds=quick_connect_ids
                )
        except Exception as ex1:
            util.logger('associate_queue_quick_connects EXCEPTION: ' + str(ex1))

    #This code was added to correct Tenant Records that needed to be re-created.  Since Agent table was already populated and assigned to queues, this code does the reverse
    #and searches through Agent table to assign agents to the Tenant Record that was re-created.
    '''
    languages = list(filter(None, language.split("_")))
    agent_list = util.get_users()

    for queue in queues_created:
        for agentEmail in agent_list:
            queueConfigs = []
            skills={}
            queueFound = False
            if 'levels' in agent_list[agentEmail]['priority']:
                skills = agent_list[agentEmail]['priority']['levels']['M']
            for skill in skills:
                for language in languages:
                    if skill.find(tenant_id) != -1 and skill.find('_'+language) != -1:
                        routingProfileName = agentEmail.split('@')[0] + '-RP'
                        routingProfileID = util.get_routing_profile_id(connect_instance_details['routingProfileList'], routingProfileName)
                        routingProfileQueues = connect_client.list_routing_profile_queues(
                            InstanceId=connect_instance_details['instanceID'],
                            RoutingProfileId=routingProfileID,
                            MaxResults=100
                        )
                        for routingProfileQueue in routingProfileQueues['RoutingProfileQueueConfigSummaryList']:
                            if queue == routingProfileQueue['QueueId']:
                                queueFound = True
                        if not queueFound:        
                            util.logger('Assigning agent: ' + agentEmail + ' to Queue: ' + tenant_id + 'GEN_' + language + ' with QUEUEID: ' + queue)
                            queueConfig = util.get_queue_config(queue,'VOICE')
                            queueConfigs.append(queueConfig)
                            queueConfig = util.get_queue_config(queue, 'TASK')
                            queueConfigs.append(queueConfig)
                            users.addQueuetoRP(connect_client, connect_instance_details, routingProfileID, queueConfigs)
                            qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], agent_list[agentEmail]['name'] + '_QC')
                            try:
                                response = connect_client.associate_queue_quick_connects(
                                    InstanceId=connect_instance_details['instanceID'],
                                    QueueId=queue,
                                    QuickConnectIds=[qc_id]
                                )
                            except Exception as ex1:
                                util.logger('associate_queue_quick_connects EXCEPTION: ' + str(ex1))                        
    '''

def remove_queue(connect_client, connect_instance_details, queue_id):
    #SEARCH ALL ROUTING PROFILES AND REMOVE QUEUE FROM PROFILES
    for routing_profile in connect_instance_details['routingProfileList']['RoutingProfileSummaryList']:

        try:
            routing_queues = connect_client.list_routing_profile_queues(
                InstanceId=connect_instance_details['instanceID'],
                RoutingProfileId=routing_profile['Id'],
                MaxResults=100
            )
    
            for routing_queue in routing_queues['RoutingProfileQueueConfigSummaryList']:
                if routing_queue['QueueId'] == queue_id:
                    connect_client.disassociate_routing_profile_queues(
                        InstanceId=connect_instance_details['instanceID'],
                        RoutingProfileId=routing_profile['Id'],
                        QueueReferences=[
                            {
                                'QueueId': queue_id,
                                'Channel': 'VOICE'
                            },
                        ]
                    )
                    connect_client.disassociate_routing_profile_queues(
                        InstanceId=connect_instance_details['instanceID'],
                        RoutingProfileId=routing_profile['Id'],
                        QueueReferences=[
                            {
                                'QueueId': queue_id,
                                'Channel': 'TASK'
                            },
                        ]
                    )
          
        except Exception as ex1:
            util.logger('disassociate_routing_profile_queues EXCEPTION: ' + str(ex1))

    #DELETE QUEUE
    util.logger('REMOVING QUEUEID: ' + queue_id)
    try:
        connect_client.delete_queue(
            InstanceId=connect_instance_details['instanceID'],
            QueueId=queue_id
        )
    except Exception as ex1:
        util.logger('delete_queue EXCEPTION: ' + str(ex1))

def create_queue(connect_client, connect_instance_details, tenant_id, language, tenant_name):
    result = False
    language_dict = {"_En":"English", "_Fr":"French", "_Es":"Spanish", "_Pt":"Portuguese"}
    queue_id = ''
    queue_name = tenant_id + 'GEN' + language
    queue_exisits = False
    for queue in connect_instance_details['queueList']['QueueSummaryList']:
        if queue['Name'] == queue_name:
            queue_exisits = True
            queue_id = queue['Id']

    if not queue_exisits:    
        util.logger('CREATING QUEUE: ' + queue_name)
        try:
            response = connect_client.create_queue(
                InstanceId=connect_instance_details['instanceID'],
                Name=queue_name,
                Description=tenant_name + ' - ' + language_dict[language],
                OutboundCallerConfig={
                    'OutboundCallerIdName': tenant_name,
                    'OutboundCallerIdNumberId': connect_instance_details['outboundPhoneNumber'],
                    'OutboundFlowId': connect_instance_details['outboundFlowID']
                },
                HoursOfOperationId=connect_instance_details['hoursOfOperationsID'],
                MaxContacts=50,
            )
            result = True
            queue_id = response['QueueId']
        except Exception as ex1:
            util.logger('create_queue EXCEPTION: ' + str(ex1))

    else:
        util.logger('QUEUE ALREADY EXISTS: ' + queue_name)

    return {
        'result': result,
        'queueID': queue_id
    }

def remove_quick_connect(connect_client, connect_instance_details, quickConnectID):
    util.logger("REMOVING QUICK CONNECT: " + str(quickConnectID))
    try:
        connect_client.delete_quick_connect(
            InstanceId=connect_instance_details['instanceID'],
            QuickConnectId=quickConnectID
        )
    except Exception as ex1:
        util.logger('delete_quick_connect EXCEPTION: ' + str(ex1))
        
def create_quick_connect(connect_client, connect_instance_details, tenant_id, language, queue_id):
    result = False
    qc_id = ''
    qcName = tenant_id + 'GEN_' + language + '_QC'
    util.logger("CREATING QUICK CONNECT: " + qcName)
    
    try:            
        response = connect_client.create_quick_connect(
            InstanceId=connect_instance_details['instanceID'],
            Name=qcName,
            Description='Created by AgentSync',
            QuickConnectConfig={
                'QuickConnectType': 'QUEUE',
                'QueueConfig': {
                    'QueueId': queue_id,
                    'ContactFlowId': connect_instance_details['agentQueueFlowID']
                }
            }
        )
        result = True
        qc_id = response['QuickConnectId']
    except Exception as ex1:
        util.logger('create_quick_connect EXCEPTION: ' + str(ex1))
            
    return {
        'result': result,
        'qcID': qc_id
    }

def create_phone_quick_connect(connect_client, connect_instance_details, phone_number, tenant_name):
    result = False
    qc_id = ''
    util.logger("CREATING PHONE QUICK CONNECT: " + phone_number)
    
    try:            
        response = connect_client.create_quick_connect(
            InstanceId=connect_instance_details['instanceID'],
            Name=phone_number,
            Description='Created for ' + tenant_name,
            QuickConnectConfig={
                'QuickConnectType': 'PHONE_NUMBER',
                'PhoneConfig': {
                    'PhoneNumber': phone_number
                }
            }
        )
        result = True
        qc_id = response['QuickConnectId']
    except Exception as ex1:
        util.logger('create_quick_connect EXCEPTION: ' + str(ex1))

    return {
        'result': result,
        'qcID': qc_id
    }
    
def release_phone_number(connect_client, phone_number_id):
    util.logger('RELEASING PHONE NUMBER ID: ' + phone_number_id)
    
    try:
        connect_client.release_phone_number(
            PhoneNumberId=phone_number_id
            #ClientToken='string'
        )  
    except Exception as ex1:
        util.logger('release_phone_number EXCEPTION: ' + str(ex1))
    
def claim_phone_number(connect_client, connect_instance_details, tenant_id, language, language_menu, tenant_name, ou):
    import random
    retry = True
    retries = 0

    while retry and retries < 3:
        util.logger('SEARCH AND CLAIM PHONE NUMBER ATTEMPT: ' + str(retries))
        time.sleep(random.randint(0,5)**retries*100/1000)
        try:
            response = connect_client.search_available_phone_numbers(
                TargetArn=connect_instance_details['instanceARN'],
                PhoneNumberCountryCode='CA',
                PhoneNumberType='DID',
                MaxResults=1,
            )
            phone_number = response['AvailableNumbersList'][0]['PhoneNumber']
            util.logger('CLAIMING NEW PHONE NUMBER: ' + phone_number)
          
            response = connect_client.claim_phone_number(
                TargetArn=connect_instance_details['instanceARN'],
                PhoneNumber=phone_number,
                PhoneNumberDescription= 'Tenant: ' + tenant_name + ' | Language: ' + language,
            )
            phone_number_id = response['PhoneNumberId']
            retry = False
        except Exception as ex1:
            retries += 1
            util.logger('claim_phone_number EXCEPTION: ' + str(ex1))

    try:
        table = boto3.resource('dynamodb').Table('Tenants-' + ou)
        
        response = table.update_item(
            Key={'Tenant': tenant_id, 'Language': language},
            UpdateExpression='SET #attr1 = :val1, #attr2 = :val2, #attr3 = :val3',
            ExpressionAttributeNames={'#attr1': 'DNIS', '#attr2': 'ID', '#attr3': 'LanguageMenu'},
            ExpressionAttributeValues={':val1': phone_number, ':val2': phone_number_id, ':val3': json.dumps(language_menu, ensure_ascii=False)}
        )

    except Exception as ex1:
        util.logger('update_item EXCEPTION: ' + str(ex1))
    
    time.sleep(3)
    
    try:
        response = connect_client.associate_phone_number_contact_flow(
            PhoneNumberId=phone_number_id,
            InstanceId=connect_instance_details['instanceID'],
            ContactFlowId=connect_instance_details['mainFlowID']
        )
    except Exception as ex1:
        util.logger('associate_phone_number_contact_flow EXCEPTION: ' + str(ex1))

def load_tenants_from_S3(s3_filename):

    tenant_records = util.read_csv(s3_filename, 'Tenant', 'Language')
    
    try:
        table = boto3.resource('dynamodb').Table('Tenants-' + ou)
 
        for record in tenant_records:
            util.logger('INSERTING NEW TENANT RECORD: ' + tenant_records[record]['Tenant'] + ' WITH LANGUAGE: ' + tenant_records[record]['Language'])
            table.put_item(Item= {'Tenant': tenant_records[record]['Tenant'], 
                'Language': tenant_records[record]['Language'], 
                'TenantName': tenant_records[record]['TenantName'], 
                'Greeting': tenant_records[record]['Greeting'], 
                'CallFlow': tenant_records[record]['CallFlow'], 
                'Queues': tenant_records[record]['Queues']})

    except Exception as ex1:
        util.logger('load_tenants_from_S3 EXCEPTION: ' + str(ex1))

def insert_tenant_record(ou, language, tenant_id, tenant_name, greeting, call_flow, queues):
    util.logger('INSERTING NEW TENANT RECORD: ' + tenant_name + ' WITH LANGUAGE: ' + language)
    try:
        table = boto3.resource('dynamodb').Table('Tenants-' + ou)
 
        table.put_item(Item= {'Tenant': tenant_id, 
            'Language': language, 
            'TenantName': tenant_name, 
            'Greeting': greeting, 
            'CallFlow': call_flow, 
            'Queues': queues})

    except Exception as ex1:
        util.logger('insert_tenant_record EXCEPTION FOUND: ' + str(ex1))