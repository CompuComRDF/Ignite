import json
import boto3
import time
import util
from time import sleep
import random
import config

def delete_app_record(event, connect_client, connect_instance_details):
    status = 'Success'
    dynamodb_client = boto3.client('dynamodb')
    ou = event['Env']
    tenant_id = event['TenantID']
    app_id=event['AppID']
    tenant = tenant_id + '-' + app_id
    language = event['Language'].replace(" ", "")
    #related_queues = json.loads(event['Queues'])
    #dnis_id = event['ID']
    release_dnis = event['ReleaseNumber']

    response = dynamodb_client.get_item(
        TableName='Tenants-' + ou,
        Key={
            'Tenant': {'S': tenant},
            'Language': {'S': language}
        }
    )

    related_queues = json.loads(response['Item']['Queues']['S'])
    dnis_id = response['Item']['ID']['S']

    queues_to_delete = []
    queues_to_delete.append(app_id + '_') #Include the default queue that was created for the app
    for related_queue in related_queues:
        if '+' not in related_queue: 
            queues_to_delete.append(related_queue + '_') #Queues & Queue Quick Connects
        else:
            queues_to_delete.append(related_queue) #Phone Quick Connects

    util.logger("QUEUES TO DELETE: " + str(queues_to_delete))
    delete_queues(event, connect_client, connect_instance_details, queues_to_delete, language, language)

    try:
        table = boto3.resource('dynamodb').Table('Tenants-' + ou)
        table.delete_item(Key={"Tenant": tenant, "Language": language})
    except Exception as ex1:
        status = 'delete_app_record EXCEPTION FOUND: ' + str(ex1)
        util.logger(status)

    if release_dnis:                        
        release_phone_number(connect_client, dnis_id)

    return status

def insert_app_record(event, connect_client, connect_instance_details):
    ou = event['Env']
    tenant_id = event['TenantID']
    app_id = event['AppID']
    description = event['Description']
    dnis = event['DNIS']
    dnis_id = event['ID']
    util.logger('CREATING NEW APPLICATION: ' + tenant_id + '-' + app_id)

    #default_language = '["en-US"]'
    default_language = "en-US"
    lang_code = default_language[0].upper() + default_language[1].lower()

    greeting = {}
    greeting[default_language] = "You've reached the " + app_id + " application."

    language_menu = {}
    language_menu['greeting'] = default_language + ':' + greeting[default_language]
    language_menu['options'] = ''
    language_menu['default'] = "En"

    create_queue(connect_client, connect_instance_details, app_id, default_language, description, dnis_id)

    try:
        table = boto3.resource('dynamodb').Table('Tenants-' + ou)
 
        table.put_item(Item= {'Tenant': tenant_id + '-' + app_id, 
            'Language': '["' + default_language + '"]', 
            'Description': description, 
            'DNIS': dnis, 
            'ID': dnis_id,
            #'Greeting': greeting[default_language],
            'Greeting': json.dumps(greeting, ensure_ascii=False),
            'LanguageMenu': json.dumps(language_menu, ensure_ascii=False),
            'CallFlow': '',
            'Queues': '[]'})

    except Exception as ex1:
        util.logger('insert_app_record EXCEPTION FOUND: ' + str(ex1))

    return {
        "Language": json.loads('["' + default_language + '"]'),
        "Greeting": greeting
    }

def update_app_record(event, connect_client, connect_instance_details, role_credentials):
    status = 'Success'
    ou = event['Env']
    tenant_id = event['TenantID']
    app_id = event['AppID']
    tenant = tenant_id + '-' + app_id
    dnis = event['DNIS']
    dnis_id = event['ID']
    description = event['Description']
    old_language = event['PreviousLanguage'].replace(" ", "")
    new_language = event['Language'].replace(" ", "")
    greeting = json.loads(event['Greeting'])
    callFlow = event['CallFlow']
    related_queues = json.loads(event['Queues'])
    util.logger('UPDATING APPLICATION: ' + tenant)

    queues_created = []
    quick_connect_ids=[]
    #language_regions = {'En': 'en-US', 'Fr':'fr-CA', 'Es':'es-MX', 'Pt':'pt-BR'}
    #language_options = {'en-US': 'For service in English, press ', 'fr-CA': 'Pour le service en français, appuyez sur ', 'es-MX': 'Para servicio en español, presione ', 'pt-PT': 'Para atendimento em português, pressione '}

    language_options = {}
    language_menu = {}
    language_menu['greeting'] = ''
    language_menu['options'] = ''
    lang_menu_opt = 0

    
    if len(json.loads(old_language)) > len(json.loads(new_language)):
        queues_to_delete = []
        languages = []
        for lang in json.loads(old_language):
            if lang not in json.loads(new_language):
                languages.append(lang)
                lang_code = lang[0].upper() + lang[1].lower()
                queues_to_delete.append(app_id + "_")
                for queue in related_queues:
                    queues_to_delete.append(queue + "_")

        delete_queues(event, connect_client, connect_instance_details, queues_to_delete, json.dumps(languages), old_language)

    #multi_languages = new_language.split('_')
    #while('' in multi_languages):
    #    multi_languages.remove('')
    # 
    multi_languages = json.loads(new_language)
    language_menu['default'] = multi_languages[0][0].upper() + multi_languages[0][1].lower()

    for lang in multi_languages:
        lang_code = lang[0].upper() + lang[1].lower()
        lang_menu_opt += 1
        if lang_menu_opt > 1:
            language_menu['greeting'] += '|'
            language_menu['options'] += '|'
        try:
            language_menu['greeting'] += lang + ':' + greeting[lang_code]
        except:
            greeting[lang_code] = util.translate_text(role_credentials, greeting[language_menu['default']], multi_languages[0], lang)
            language_menu['greeting'] += lang + ':' + greeting[lang_code]
            
        if not greeting[lang_code].endswith(".") and not len(greeting[lang_code])==0:
            language_menu['greeting'] += '.'
        if len(multi_languages) > 1:
            #language_menu['greeting'] += ' ' + language_options[lang] + str(lang_menu_opt)
            language_menu['greeting'] += ' ' + util.translate_text(role_credentials, "For service in " + config.language_names[lang] + ", press " + str(lang_menu_opt), "en-US", lang)
            language_menu['options'] += str(lang_menu_opt) + ':' + lang[0:2].upper()
        response = create_queue(connect_client, connect_instance_details, app_id, lang, description, dnis_id)
        queue_id = response['queueID']
        queues_created.append(queue_id)
        if related_queues:
            #response = create_quick_connect(connect_client, connect_instance_details, app_id, lang, queue_id)
            #quick_connect_ids.append(response['qcID'])
            if response['result']: #If Queue was newly created, also create a QC
                response = create_quick_connect(connect_client, connect_instance_details, app_id, lang_code, queue_id)
                if response['result']: #Add to QC array
                    quick_connect_ids.append(response['qcID'])
                    
            else: #If Queue already existed, attempt to create a QC in case it wasn't created
                response = create_quick_connect(connect_client, connect_instance_details, app_id, lang_code, queue_id)
                if response['result']: #Add to QC array
                    quick_connect_ids.append(response['qcID'])  
                else: #if QC already existed, find QC ID and add to QC array
                    qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], app_id+'_'+lang_code+'_QC')
                    quick_connect_ids.append(qc_id)            
        
    if language_menu['options']:
        language_menu['options'] += '|9:' + language_menu['default'].upper() + '|*:' + language_menu['default'].upper() + '|invalid:' + language_menu['default'].upper() + '|timeout:' + language_menu['default'].upper()

    try:
        table = boto3.resource('dynamodb').Table('Tenants-' + ou)

        #Since Language is a Sort Key and can not be updated, need to recreate record.
        table.delete_item(Key={"Tenant": tenant, "Language": old_language})
 
        table.put_item(Item= {'Tenant': tenant, 
            'Language': new_language, 
            'Description': description, 
            'DNIS': dnis, 
            'ID': dnis_id,
            'Greeting': json.dumps(greeting, ensure_ascii=False),
            'LanguageMenu': json.dumps(language_menu, ensure_ascii=False),
            'CallFlow': callFlow,
            'Queues': json.dumps(related_queues)})

    except Exception as ex1:
        status = "Failed to create new app"
        util.logger('insert_app_record EXCEPTION FOUND: ' + str(ex1))

    if related_queues:
        for related_queue in related_queues:
            if '+' not in related_queue: #Create Queues + Quick Connect
                language_menu = {'en-US': False, 'fr-CA': False, 'es-MX': False, 'pt-BR': False}
                for lang in multi_languages:
                    if lang:
                        lang_code = lang[0].upper() + lang[1].lower()
                        language_menu[lang] = True
                        response = create_queue(connect_client, connect_instance_details, related_queue, lang, related_queue.replace('_',''), dnis_id) #Create Queue in case it doesn't exist
                        queues_created.append(response['queueID'])
                        if response['result']: #If Queue was newly created, also create a QC
                            response = create_quick_connect(connect_client, connect_instance_details, related_queue, lang_code, response['queueID'])
                            if response['result']: #Add to QC array
                                quick_connect_ids.append(response['qcID'])
                                
                        else: #If Queue already existed, attempt to create a QC in case it wasn't created
                            response = create_quick_connect(connect_client, connect_instance_details, related_queue, lang_code, util.get_queue_id(connect_instance_details['QueueSummaryList'], related_queue + '_' + lang_code))
                            if response['result']: #Add to QC array
                                quick_connect_ids.append(response['qcID'])  
                            else: #if QC already existed, find QC ID and add to QC array
                                qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], related_queue+'_'+lang_code+'_QC')
                                quick_connect_ids.append(qc_id)
            else: #Create Phone Quick Connect
                response = create_phone_quick_connect(connect_client, connect_instance_details, related_queue, description)
                if response['result']: #Add to QC array
                    quick_connect_ids.append(response['qcID'])
                else:
                    qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], related_queue)
                    quick_connect_ids.append(qc_id)                 
        try:
            for queue in queues_created:
                util.logger("ASSIGNING QUICK CONNECTS: " + str(quick_connect_ids) + " TO QUEUE: " + queue)
                response = connect_client.associate_queue_quick_connects(
                    InstanceId=connect_instance_details['instanceID'],
                    QueueId=queue,
                    QuickConnectIds=quick_connect_ids
                )
        except Exception as ex1:
            util.logger('associate_queue_quick_connects EXCEPTION: ' + str(ex1))

    ##This code was added to correct Tenant Records that needed to be re-created.  Since Agent table was already populated and assigned to queues, this code does the reverse
    ##and searches through Agent table to assign agents to the Tenant Record that was re-created.

    #languages = list(filter(None, language.split("_")))
    #agent_list = util.get_users()

    #for queue in queues_created:
    #    for agentEmail in agent_list:
    #        queueConfigs = []
    #        skills={}
    #        queueFound = False
    #        if 'levels' in agent_list[agentEmail]['priority']:
    #            skills = agent_list[agentEmail]['priority']['levels']['M']
    #        for skill in skills:
    #            for language in languages:
    #                if skill.find(tenant_id) != -1 and skill.find('_'+language) != -1:
    #                    routingProfileName = agentEmail.split('@')[0] + '-RP'
    #                    routingProfileID = util.get_routing_profile_id(connect_instance_details['routingProfileList'], routingProfileName)
    #                    routingProfileQueues = connect_client.list_routing_profile_queues(
    #                        InstanceId=connect_instance_details['instanceID'],
    #                        RoutingProfileId=routingProfileID,
    #                        MaxResults=100
    #                    )
    #                    for routingProfileQueue in routingProfileQueues['RoutingProfileQueueConfigSummaryList']:
    #                        if queue == routingProfileQueue['QueueId']:
    #                            queueFound = True
    #                    if not queueFound:        
    #                        util.logger('Assigning agent: ' + agentEmail + ' to Queue: ' + tenant_id + '_' + language + ' with QUEUEID: ' + queue)
    #                        queueConfig = util.get_queue_config(queue,'VOICE')
    #                        queueConfigs.append(queueConfig)
    #                        queueConfig = util.get_queue_config(queue, 'TASK')
    #                        queueConfigs.append(queueConfig)
    #                        users.addQueuetoRP(connect_client, connect_instance_details, routingProfileID, queueConfigs)
    #                        qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], agent_list[agentEmail]['name'] + '_QC')
    #                        try:
    #                            response = connect_client.associate_queue_quick_connects(
    #                                InstanceId=connect_instance_details['instanceID'],
    #                                QueueId=queue,
    #                                QuickConnectIds=[qc_id]
    #                            )
    #                        except Exception as ex1:
    #                            util.logger('associate_queue_quick_connects EXCEPTION: ' + str(ex1))                        

    return status

def delete_queues(event, connect_client, connect_instance_details, queues_to_delete, languages, language_key):
    status = 'Success'
    dynamodb_client = boto3.client('dynamodb')
    ou = event['Env']
    tenant_id = event['TenantID']
    app_id=event['AppID']
    tenant = tenant_id + '-' + app_id
    #language = event['Language'].replace(" ", "")
    #multi_languages = language.split('_')
    multi_languages = json.loads(languages)

    for queue in queues_to_delete:
        if app_id not in queue:
            response = dynamodb_client.get_item(
                TableName='Tenants-' + ou,
                Key={
                    'Tenant': {'S': tenant},
                    'Language': {'S': language_key}
                }
            )

            queues = json.loads(response['Item']['Queues']['S'])
            queues.remove(queue.replace("_", ""))

            boto3.resource('dynamodb').Table('Tenants-' + ou).update_item(
                Key={'Tenant': tenant, 'Language': language_key},
                UpdateExpression='SET #attr1 = :val1',
                ExpressionAttributeNames={'#attr1': 'Queues'},
                ExpressionAttributeValues={':val1': json.dumps(queues)}
            )

        if '+' not in queue: #Queues + Quick Connects
            for lang in multi_languages:
                if lang:
                    lang_code = lang[0].upper() + lang[1].lower()
                    queue_name = queue + lang_code
                    queue_id = util.get_queue_id(connect_instance_details['QueueSummaryList'], queue_name)
                    delete_queue = False
                    
                    if len(multi_languages) > 2:
                        util.logger("MULTI-LANGUAGE DNIS.  CHECKING IF QUEUE: " + queue_name + " IS STILL REQUIRED")
                        response = dynamodb_client.get_item(
                            TableName='Tenants-' + ou,
                            Key={
                                'Tenant': {'S': tenant},
                                #'Language': {'S': '_' + lang}
                                'Language': {'S': '["' + lang +'"]'}
                            }
                        )
                        try:
                            util.logger("DB RESPONSE: " + str(response['Item']))
                            if response['Item']['Tenant']['S'] != tenant:
                                delete_queue = True
                        except:
                            delete_queue = True
                    else:
                        util.logger("SINGLE-LANGUAGE DNIS.  CHECKING IF QUEUE: " + queue_name + " IS STILL REQUIRED")
                        delete_queue = True
                        response = dynamodb_client.query(
                            TableName='Tenants-' + ou,
                            KeyConditionExpression='Tenant = :tenant',
                            ExpressionAttributeValues={
                                ':tenant': {'S': tenant}
                            }
                        )
                        try:
                            util.logger("DB RESPONSE: " + str(response['Items']))
                            if len(response['Items']) > 1:
                                for i in response['Items']:
                                    if lang in i['language']['S']:
                                        delete_queue = False
                        except:
                            delete_queue = False
                            
                    if delete_queue:
                        util.logger("DELETING QUEUE: " + queue_name)
                        qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], queue +lang_code+'_QC')
                        if qc_id != "NOT FOUND":
                            remove_quick_connect(connect_client, connect_instance_details, qc_id)
                            
                        status = remove_queue(event, connect_client, connect_instance_details, queue_id, queue)
                    else:
                        util.logger("KEEPING QUEUE: " + queue_name)
        
        else:
            qc_id = util.get_quick_connect_id(connect_instance_details['quickConnectList'], queue)
            if qc_id != "NOT FOUND":
                remove_quick_connect(connect_client, connect_instance_details, qc_id)

    return status
    
def remove_queue(event, connect_client, connect_instance_details, queue_id, queue):
    status = "Success"
    dynamodb_client = boto3.client('dynamodb')
    ou = event['Env']
    tenant_id = event['TenantID']
    app_id=event['AppID']
    tenant = tenant_id + '-' + app_id
    language = event['Language']

    #SEARCH ALL ROUTING PROFILES AND REMOVE QUEUE FROM PROFILES
    for routing_profile in connect_instance_details['routingProfileList']['RoutingProfileSummaryList']:

        try:
            routing_queues = connect_client.list_routing_profile_queues(
                InstanceId=connect_instance_details['instanceID'],
                RoutingProfileId=routing_profile['Id'],
                MaxResults=100
            )
    
            for routing_queue in routing_queues['RoutingProfileQueueConfigSummaryList']:
                if routing_queue['QueueId'] == queue_id:
                    connect_client.disassociate_routing_profile_queues(
                        InstanceId=connect_instance_details['instanceID'],
                        RoutingProfileId=routing_profile['Id'],
                        QueueReferences=[
                            {
                                'QueueId': queue_id,
                                'Channel': 'VOICE'
                            },
                        ]
                    )
                    connect_client.disassociate_routing_profile_queues(
                        InstanceId=connect_instance_details['instanceID'],
                        RoutingProfileId=routing_profile['Id'],
                        QueueReferences=[
                            {
                                'QueueId': queue_id,
                                'Channel': 'TASK'
                            },
                        ]
                    )
          
        except Exception as ex1:
            util.logger('disassociate_routing_profile_queues EXCEPTION: ' + str(ex1))

    #DELETE QUEUE
    util.logger('REMOVING QUEUEID: ' + queue_id)
    try:
        connect_client.delete_queue(
            InstanceId=connect_instance_details['instanceID'],
            QueueId=queue_id
        )
 
    except Exception as ex1:
        status = 'remove_queue EXCEPTION: ' + str(ex1)
        util.logger(status)
    
    return status

def create_queue(connect_client, connect_instance_details, app_id, language, description, dnis_id):
    result = False
    #language_dict = {"En":"English", "Fr":"French", "Es":"Spanish", "Pt":"Portuguese"}
    lang_code = language[0].upper() + language[1].lower()
    queue_id = ''
    queue_name = app_id + '_' + lang_code
    queue_exists = False
    for queue in connect_instance_details['QueueSummaryList']:
        if queue['Name'] == queue_name:
            queue_exists = True
            queue_id = queue['Id']

    if not queue_exists:    
        util.logger('CREATING QUEUE: ' + queue_name)
        try:
            response = connect_client.create_queue(
                InstanceId=connect_instance_details['instanceID'],
                Name=queue_name,
                Description=description + ' - ' + config.language_names[language],
                OutboundCallerConfig={
                    'OutboundCallerIdName': description,
                    'OutboundCallerIdNumberId': dnis_id,
                    'OutboundFlowId': connect_instance_details['outboundFlowID']
                },
                HoursOfOperationId=connect_instance_details['hoursOfOperationsID'],
                MaxContacts=50,
            )
            result = True
            queue_id = response['QueueId']
        except Exception as ex1:
            util.logger('create_queue EXCEPTION: ' + str(ex1))

    else:
        util.logger('QUEUE ALREADY EXISTS: ' + queue_name)

    return {
        'result': result,
        'queueID': queue_id
    }

def remove_quick_connect(connect_client, connect_instance_details, quickConnectID):
    util.logger("REMOVING QUICK CONNECT: " + str(quickConnectID))
    try:
        connect_client.delete_quick_connect(
            InstanceId=connect_instance_details['instanceID'],
            QuickConnectId=quickConnectID
        )
    except Exception as ex1:
        util.logger('delete_quick_connect EXCEPTION: ' + str(ex1))
        
def create_quick_connect(connect_client, connect_instance_details, app_id, language, queue_id):
    result = False
    qc_id = ''
    qcName = app_id + '_' + language + '_QC'
    util.logger("CREATING QUICK CONNECT: " + qcName)

    try:            
        response = connect_client.create_quick_connect(
            InstanceId=connect_instance_details['instanceID'],
            Name=qcName,
            Description='Created by Ignite',
            QuickConnectConfig={
                'QuickConnectType': 'QUEUE',
                'QueueConfig': {
                    'QueueId': queue_id,
                    'ContactFlowId': connect_instance_details['agentQueueFlowID']
                }
            }
        )
        qc_id = response['QuickConnectId']
        result = True
    except Exception as ex1:
        result = False
        util.logger('create_quick_connect EXCEPTION: ' + str(ex1))
            
    return {
        'result': result,
        'qcID': qc_id
    }

def create_phone_quick_connect(connect_client, connect_instance_details, phone_number, tenant_name):
    result = False
    qc_id = ''
    util.logger("CREATING PHONE QUICK CONNECT: " + phone_number)
    
    try:            
        response = connect_client.create_quick_connect(
            InstanceId=connect_instance_details['instanceID'],
            Name=phone_number,
            Description='Created for ' + tenant_name,
            QuickConnectConfig={
                'QuickConnectType': 'PHONE_NUMBER',
                'PhoneConfig': {
                    'PhoneNumber': phone_number
                }
            }
        )
        result = True
        qc_id = response['QuickConnectId']
    except Exception as ex1:
        util.logger('create_quick_connect EXCEPTION: ' + str(ex1))

    return {
        'result': result,
        'qcID': qc_id
    }
    
def release_phone_number(connect_client, phone_number_id):
    util.logger('RELEASING PHONE NUMBER ID: ' + phone_number_id)
    
    try:
        connect_client.release_phone_number(
            PhoneNumberId=phone_number_id
            #ClientToken='string'
        )  
    except Exception as ex1:
        util.logger('release_phone_number EXCEPTION: ' + str(ex1))
    
def load_tenants_from_S3(s3_filename):

    tenant_records = util.read_csv(s3_filename, 'Tenant', 'Language')
    
    try:
        table = boto3.resource('dynamodb').Table('Tenants-' + ou)
 
        for record in tenant_records:
            util.logger('INSERTING NEW TENANT RECORD: ' + tenant_records[record]['Tenant'] + ' WITH LANGUAGE: ' + tenant_records[record]['Language'])
            table.put_item(Item= {'Tenant': tenant_records[record]['Tenant'], 
                'Language': tenant_records[record]['Language'], 
                'Description': tenant_records[record]['Description'], 
                'Greeting': tenant_records[record]['Greeting'], 
                'CallFlow': tenant_records[record]['CallFlow'], 
                'Queues': tenant_records[record]['Queues']})

    except Exception as ex1:
        util.logger('load_tenants_from_S3 EXCEPTION: ' + str(ex1))

def get_tenant_apps(ou):
    tenant_app_list = []
    util.logger("GETTING TENANT APP LIST")
    dynamodb_client = boto3.client('dynamodb')
    try:
        response = dynamodb_client.scan(
            TableName='Tenants-' + ou
        )
        util.logger("DB RESPONSE: " + str(response))

        for tenant_app in response['Items']:
            tenant_app_list.append({
                "AppID" : util.get_app_id(tenant_app['Tenant']['S']),
                "Language" : tenant_app['Language']['S'],
                "CallFlow" : tenant_app['CallFlow']['S'],
                "DNIS": tenant_app['DNIS']['S'],
                "Greeting": tenant_app['Greeting']['S'],
                "Queues": tenant_app['Queues']['S'],
                "Description": tenant_app['Description']['S'],
                "ID":tenant_app['ID']['S']
            })
    
    except Exception as Ex1:
        util.logger("get_tenant_apps EXCEPTION: " + str(Ex1))

    return(tenant_app_list)

def get_phone_number(connect_client, connect_id, tenant_id, country, dnis_type):
    #CLAIM PHONE NUMBER
    retry = True
    retries = 0
    phone_number = ""
    phone_number_id=""

    while retry and retries < 3:
        util.logger('SEARCH AND CLAIM PHONE NUMBER ATTEMPT: ' + str(retries))
        sleep(random.randint(0,5)**retries*100/1000)
        try:
            response = connect_client.search_available_phone_numbers(
                TargetArn=connect_id,
                PhoneNumberCountryCode=country,
                PhoneNumberType=dnis_type,
                MaxResults=1
            )
            phone_number = response['AvailableNumbersList'][0]['PhoneNumber']
            util.logger('CLAIMING NEW PHONE NUMBER: ' + phone_number)
        
            response = connect_client.claim_phone_number(
                TargetArn=connect_id,
                PhoneNumber=phone_number,
                PhoneNumberDescription= 'Tenant: ' + tenant_id,
            )
            phone_number_id = response['PhoneNumberId']
            retry = False
        except Exception as ex1:
            retries += 1
            util.logger('claim_phone_number EXCEPTION: ' + str(ex1))

    #connect_instance_details['PhoneNumberId'] = phone_number_id
    #connect_instance_details['PhoneNumber'] = phone_number
    retry = True
    retries = 0    

    while retry and retries < 3:
        util.logger('ASSOCIATE PHONE NUMBER ATTEMPT: ' + str(retries))
        try:
            contact_flow_list = connect_client.list_contact_flows(
                InstanceId=connect_id,
                ContactFlowTypes=['CONTACT_FLOW'],
                MaxResults=100
            )
            # GET Connect-RDF-Main FLOW ID
            for flow in contact_flow_list['ContactFlowSummaryList']:
                if flow['Name'] == 'Connect-RDF-Main':
                    response = connect_client.associate_phone_number_contact_flow(
                        PhoneNumberId=phone_number_id,
                        InstanceId=connect_id,
                        ContactFlowId=flow['Id']
                    )

        except Exception as ex1:
            sleep(3)
            retries += 1
            util.logger('get_phone_number EXCEPTION: ' + str(ex1))
    
    return{
        "PhoneNumber" : phone_number,
        "PhoneNumberID": phone_number_id
    }

def update_phone_number(connect_client, connect_id, tenant_id, country, dnis_type, previous_id):
    util.logger('UPDATING PHONE NUMBER')

    try:
        connect_client.release_phone_number(
            PhoneNumberId=previous_id
        )  
    except Exception as ex1:
        util.logger('release_phone_number EXCEPTION: ' + str(ex1))

    
    return get_phone_number(connect_client, connect_id, tenant_id, country, dnis_type)

def manual_delete_queue(connect_client, connect_id, queue_name):
    #multi_languages = language.split('_')

    queue_list = util.get_queue_summary_list(connect_client, connect_id)
    queue_id = util.get_queue_id(queue_list, queue_name)

    for queue in queue_list:
        if queue_name in queue['Name']:
            util.logger('DELETING QUEUE: ' + queue['Name'])
            queue_id = queue['Id']

            try:
                connect_client.delete_queue(
                    InstanceId=connect_id,
                    QueueId=queue_id
                )
            except Exception as ex1:
                util.logger('delete_queue EXCEPTION: ' + str(ex1))