import json
import boto3
import traceback
import time
import util
import config
import users

def removeTenantRecord(event, connectClient, connectInstanceDetails):
    dynamodb_client = boto3.client('dynamodb')
    oldImage = event['Records'][0]['dynamodb']['OldImage']
    tenantID = oldImage['tenantID']['S']
    language = oldImage['language']['S']
    relatedQueues = json.loads(oldImage['quickConnects']['S'])
    try:
        phoneNumberID = oldImage['ID']['S']
    except:
        phoneNumberID = "NA"

    queuesToDelete = []
    queuesToDelete.append(tenantID + 'GEN_')
    for relatedQueue in relatedQueues:
        if '+' not in relatedQueue: 
            queuesToDelete.append(relatedQueue + 'GEN_') #Queues & Queue Quick Connects
        else:
            queuesToDelete.append(relatedQueue) #Phone Quick Connects
    
    multiLanguages = language.split('_')

    for queue in queuesToDelete:
        if '+' not in queue: #Queues + Quick Connects
            for lang in multiLanguages:
                if lang:
                    queueID = util.getQueueID(connectInstanceDetails['queueList'], queue + lang)
                    #vmQueueID = util.getQueueID(connectInstanceDetails['queueList'], queue + lang + '_VM')
                    deleteQueue = False
                    
                    if len(multiLanguages) > 2:
                        print("MULTI-LANGUAGE DNIS.  CHECKING IF QUEUE: " + queue + lang + " IS STILL REQUIRED")
                        response = dynamodb_client.get_item(
                            TableName='Tenants',
                            Key={
                                'tenantID': {'S': tenantID},
                                'language': {'S': '_' + lang}
                            }
                        )
                        try:
                            print("DB RESPONSE: " + str(response['Item']))
                            if response['Item']['tenantID']['S'] != tenantID:
                                deleteQueue = True
                        except:
                            deleteQueue = True
                    else:
                        print("SINGLE-LANGUAGE DNIS.  CHECKING IF QUEUE: " + queue + lang + " IS STILL REQUIRED")
                        deleteQueue = True
                        response = dynamodb_client.query(
                            TableName='Tenants',
                            KeyConditionExpression='tenantID = :tenantID',
                            ExpressionAttributeValues={
                                ':tenantID': {'S': tenantID}
                            }
                        )
                        try:
                            print("DB RESPONSE: " + str(response['Items']))
                            for i in response['Items']:
                                if lang in i['language']['S']:
                                    deleteQueue = False
                        except:
                            deleteQueue = False
                            
                    if deleteQueue:
                        print("DELETING QUEUE: " + queue + lang)
                        qcID = util.getQuickConnectID(connectInstanceDetails['quickConnectList'], queue +lang+'_QC')
                        if qcID != "NOT FOUND":
                            removeQuickConnect(connectClient, connectInstanceDetails, qcID)
                            
                        #removeQueue(connectClient, connectInstanceDetails, queueID, vmQueueID)
                        removeQueue(connectClient, connectInstanceDetails, queueID)
                    else:
                        print("KEEPING QUEUE: " + queue + lang)
        
        else:
            qcID = util.getQuickConnectID(connectInstanceDetails['quickConnectList'], queue)
            if qcID != "NOT FOUND":
                removeQuickConnect(connectClient, connectInstanceDetails, qcID)
                            
    releasePhoneNumber(connectClient, phoneNumberID)
    

def insertTenantRecord(event, connectClient, connectInstanceDetails):
    newImage = event['Records'][0]['dynamodb']['NewImage']
    tenantID = newImage['tenantID']['S']
    tenantName = newImage['tenantName']['S']
    greeting = json.loads(newImage['greeting']['S'])
    language = newImage['language']['S']
    relatedQueues = json.loads(newImage['quickConnects']['S'])
    queuesCreated = []
    quickConnectIds=[]
    languageRegions = {'En': 'en-US', 'Fr':'fr-CA', 'Es':'es-MX', 'Pt':'pt-BR'}
    languageOptions = {'En': 'For service in English, press ', 'Fr': 'Pour le service en français, appuyez sur ', 'Es': 'Para servicio en español, presione ', 'Pt': 'Para atendimento em português, pressione '}
    languageMenu = {}
    languageMenu['greeting'] = ''
    languageMenu['options'] = ''
    langMenuOpt = 0

    multiLanguages = language.split('_')
    while('' in multiLanguages):
        multiLanguages.remove('')
    
    languageMenu['default'] = multiLanguages[0]

    for lang in multiLanguages:
        langMenuOpt += 1
        if langMenuOpt > 1:
            languageMenu['greeting'] += '|'
            languageMenu['options'] += '|'
        languageMenu['greeting'] += languageRegions[lang] + ':' + greeting[lang]
        if not greeting[lang].endswith(".") and not len(greeting[lang])==0:
            languageMenu['greeting'] += '.'
        if len(multiLanguages) > 1:
            languageMenu['greeting'] += ' ' + languageOptions[lang] + str(langMenuOpt)
            languageMenu['options'] += str(langMenuOpt) + ':' + lang.upper()
        response = createQueue(connectClient, connectInstanceDetails, tenantID, '_' + lang, tenantName)
        queueID = response['queueID']
        queuesCreated.append(queueID)
        if relatedQueues:
            response = createQuickConnect(connectClient, connectInstanceDetails, tenantID, lang, queueID)
            quickConnectIds.append(response['qcID'])
        
    if languageMenu['options']:
        languageMenu['options'] += '|maxaction:' + languageMenu['default'].upper()

    phoneNumber = claimPhoneNumber(connectClient, connectInstanceDetails, tenantID, language, languageMenu, tenantName, queueID)

    if relatedQueues:
        for relatedQueue in relatedQueues:
            if '+' not in relatedQueue: #Create Queues + Quick Connect
                queueCreated = False
                languageMenu = {'En': False, 'Fr': False, 'Es': False, 'Pt': False}
                for lang in multiLanguages:
                    if lang:
                        languageMenu[lang] = True
                        response = createQueue(connectClient, connectInstanceDetails, relatedQueue, '_' + lang, relatedQueue.replace('_','')) #Create Queue in case it doesn't exist
                        queuesCreated.append(response['queueID'])
                        #queueID = response['queueID']
                        
                        if response['result']: #If Queue was newly created, also create a QC
                            queueCreated=True
                            response = createQuickConnect(connectClient, connectInstanceDetails, relatedQueue, lang, response['queueID'])
                            if response['result']: #Add to QC array
                                quickConnectIds.append(response['qcID'])
                                
                        else: #If Queue already existed, attempt to create a QC in case it wasn't created
                            response = createQuickConnect(connectClient, connectInstanceDetails, relatedQueue, lang, util.getQueueID(connectInstanceDetails['queueList'], relatedQueue + 'GEN_' + lang))
                            if response['result']: #Add to QC array
                                quickConnectIds.append(response['qcID'])                                
                            else: #if QC already existed, find QC ID and add to QC array
                                qcID = util.getQuickConnectID(connectInstanceDetails['quickConnectList'], relatedQueue+'GEN_'+lang+'_QC')
                                quickConnectIds.append(qcID)
            else: #Create Phone Quick Connect
                response = createPhoneQuickConnect(connectClient, connectInstanceDetails, relatedQueue, tenantName)
                if response['result']: #Add to QC array
                    quickConnectIds.append(response['qcID'])
                else:
                    qcID = util.getQuickConnectID(connectInstanceDetails['quickConnectList'], relatedQueue)
                    quickConnectIds.append(qcID)                 
        try:
            for queue in queuesCreated:
                print("ASSIGNING QUICK CONNECTS: " + str(quickConnectIds) + " TO QUEUE: " + queue)
                response = connectClient.associate_queue_quick_connects(
                    InstanceId=connectInstanceDetails['instanceID'],
                    QueueId=queue,
                    QuickConnectIds=quickConnectIds
                )
        except Exception as ex1:
            print('#####   ASSOCIATE QUEUE QUICK CONNECTS EXCEPTION FOUND: ' + str(ex1) + '   #####')

    #This code was added to correct Tenant Records that needed to be re-created.  Since Agent table was already populated and assigned to queues, this code does the reverse
    #and searches through Agent table to assign agents to the Tenant Record that was re-created.
    languages = list(filter(None, language.split("_")))
    agentList = util.getAgents()

    for queue in queuesCreated:
        for agentEmail in agentList:
            queueConfigs = []
            skills={}
            queueFound = False
            if 'levels' in agentList[agentEmail]['priority']:
                skills = agentList[agentEmail]['priority']['levels']['M']
            for skill in skills:
                for language in languages:
                    if skill.find(tenantID) != -1 and skill.find('_'+language) != -1:
                        routingProfileName = agentEmail.split('@')[0] + '-RP'
                        routingProfileID = util.getRoutingProfileID(connectInstanceDetails['routingProfileList'], routingProfileName)
                        routingProfileQueues = connectClient.list_routing_profile_queues(
                            InstanceId=connectInstanceDetails['instanceID'],
                            RoutingProfileId=routingProfileID,
                            MaxResults=100
                        )
                        for routingProfileQueue in routingProfileQueues['RoutingProfileQueueConfigSummaryList']:
                            if queue == routingProfileQueue['QueueId']:
                                queueFound = True
                        if not queueFound:        
                            print('Assigning agent: ' + agentEmail + ' to Queue: ' + tenantID + 'GEN_' + language + ' with QUEUEID: ' + queue)
                            queueConfig = util.getQueueConfig(queue,'VOICE')
                            queueConfigs.append(queueConfig)
                            queueConfig = util.getQueueConfig(queue, 'TASK')
                            queueConfigs.append(queueConfig)
                            agent.addQueuetoRP(connectClient, connectInstanceDetails, routingProfileID, queueConfigs)
                            qcID = util.getQuickConnectID(connectInstanceDetails['quickConnectList'], agentList[agentEmail]['name'] + '_QC')
                            try:
                                response = connectClient.associate_queue_quick_connects(
                                    InstanceId=connectInstanceDetails['instanceID'],
                                    QueueId=queue,
                                    QuickConnectIds=[qcID]
                                )
                            except Exception as ex1:
                                print('#####   ASSOCIATE QUEUE QUICK CONNECTS EXCEPTION FOUND: ' + str(ex1) + '   #####')                        

def removeQueue(connectClient, connectInstanceDetails, queueID):
    #SEARCH ALL ROUTING PROFILES AND REMOVE QUEUE FROM PROFILES
    for routingProfile in connectInstanceDetails['routingProfileList']['RoutingProfileSummaryList']:

        try:
            routingQueues = connectClient.list_routing_profile_queues(
                InstanceId=connectInstanceDetails['instanceID'],
                RoutingProfileId=routingProfile['Id'],
                MaxResults=100
            )
    
            for routingQueue in routingQueues['RoutingProfileQueueConfigSummaryList']:
                if routingQueue['QueueId'] == queueID:
                    response = connectClient.disassociate_routing_profile_queues(
                        InstanceId=connectInstanceDetails['instanceID'],
                        RoutingProfileId=routingProfile['Id'],
                        QueueReferences=[
                            {
                                'QueueId': queueID,
                                'Channel': 'VOICE'
                            },
                        ]
                    )
                    response = connectClient.disassociate_routing_profile_queues(
                        InstanceId=connectInstanceDetails['instanceID'],
                        RoutingProfileId=routingProfile['Id'],
                        QueueReferences=[
                            {
                                'QueueId': queueID,
                                'Channel': 'TASK'
                            },
                        ]
                    )
                #if routingQueue['QueueId'] == vmQueueID:
                #    response = connectClient.disassociate_routing_profile_queues(
                #        InstanceId=connectInstanceDetails['instanceID'],
                #        RoutingProfileId=routingProfile['Id'],
                #        QueueReferences=[
                #            {
                #                'QueueId': vmQueueID,
                #                'Channel': 'TASK'
                #            },
                #        ]
                #    )            
        except Exception as ex1:
            print('#####   DISASSOCIATE ROUTING PROFILES EXCEPTION FOUND: ' + str(ex1) + '   #####')

    #DELETE QUEUE
    print('REMOVING QUEUEID: ' + queueID)
    try:
        response = connectClient.delete_queue(
            InstanceId=connectInstanceDetails['instanceID'],
            QueueId=queueID
        )
    except Exception as ex1:
        print('#####   DELETE QUEUE EXCEPTION FOUND: ' + str(ex1) + '   #####')

    #DELETE VM QUEUE
    #print('REMOVING VM QUEUEID: ' + vmQueueID)    
    #try:        
    #    response = connectClient.delete_queue(
    #        InstanceId=connectInstanceDetails['instanceID'],
    #        QueueId=vmQueueID
    #    )        
    #except Exception as ex1:
    #    print('#####   DELETE VM QUEUE EXCEPTION FOUND: ' + str(ex1) + '   #####')

def createQueue(connectClient, connectInstanceDetails, tenantID, language, tenantName):
    result = False
    languageDict = {"_En":"English", "_Fr":"French", "_Es":"Spanish", "_Pt":"Portuguese"}
    queueID = ''
    queueName = tenantID + 'GEN' + language
    queueExists = False
    for queue in connectInstanceDetails['queueList']['QueueSummaryList']:
        if queue['Name'] == queueName:
            queueExists = True
            queueID = queue['Id']

    if not queueExists:    
        print('CREATING QUEUE: ' + queueName)
        try:
            response = connectClient.create_queue(
                InstanceId=connectInstanceDetails['instanceID'],
                Name=queueName,
                Description=tenantName + ' - ' + languageDict[language],
                OutboundCallerConfig={
                    'OutboundCallerIdName': tenantName,
                    'OutboundCallerIdNumberId': connectInstanceDetails['outboundPhoneNumber'],
                    'OutboundFlowId': connectInstanceDetails['outboundFlowID']
                },
                HoursOfOperationId=connectInstanceDetails['hoursOfOperationsID'],
                MaxContacts=50,
            )
            result = True
            queueID = response['QueueId']
        except Exception as ex1:
            print('#####   CREATE QUEUE EXCEPTION FOUND: ' + str(ex1) + '   #####')

        #print('CREATING VM QUEUE: ' + queueName + '_VM')
        #try:
        #    response = connectClient.create_queue(
        #        InstanceId=connectInstanceDetails['instanceID'],
        #        Name=queueName + "_VM",
        #        Description=tenantName + ' - Voice Mail - ' + languageDict[language],
        #        OutboundCallerConfig={
        #            'OutboundCallerIdName': 'COMPUCOM',
        #            #'OutboundCallerIdNumberId': '+1 437-880-7439',
        #            'OutboundFlowId': connectInstanceDetails['outboundFlowID']
        #        },
        #        HoursOfOperationId=connectInstanceDetails['hoursOfOperationsID'],
        #        MaxContacts=50,
        #    )
        #    result = True
        #except Exception as ex1:
        #    print('#####   CREATE VM QUEUE EXCEPTION FOUND: ' + str(ex1) + '   #####')

    else:
        print('#####   QUEUE ALREADY EXISTS: ' + queueName + '   #####')

    return {
        'result': result,
        'queueID': queueID
    }

def removeQuickConnect(connectClient, connectInstanceDetails, quickConnectID):
    print("REMOVING QUICK CONNECT: " + str(quickConnectID))
    try:
        response = connectClient.delete_quick_connect(
            InstanceId=connectInstanceDetails['instanceID'],
            QuickConnectId=quickConnectID
        )
    except Exception as ex1:
        print('#####   REMOVE QUICK CONNECT EXCEPTION FOUND: ' + str(ex1) + '   #####')
        
def createQuickConnect(connectClient, connectInstanceDetails, tenantID, language, queueID):
    result = False
    qcID = ''
    qcName = tenantID + 'GEN_' + language + '_QC'
    print("CREATING QUICK CONNECT: " + qcName)
    
    try:            
        response = connectClient.create_quick_connect(
            InstanceId=connectInstanceDetails['instanceID'],
            Name=qcName,
            Description='Created by AgentSync',
            QuickConnectConfig={
                'QuickConnectType': 'QUEUE',
                'QueueConfig': {
                    'QueueId': queueID,
                    'ContactFlowId': connectInstanceDetails['agentQueueFlowID']
                }
            }
        )
        result = True
        qcID = response['QuickConnectId']
    except Exception as ex1:
        print('#####   CREATE QUICK CONNECT EXCEPTION FOUND: ' + str(ex1) + '   #####')
            
    return {
        'result': result,
        'qcID': qcID
    }

def createPhoneQuickConnect(connectClient, connectInstanceDetails, phoneNumber, tenantName):
    result = False
    qcID = ''
    print("CREATING PHONE QUICK CONNECT: " + phoneNumber)
    
    try:            
        response = connectClient.create_quick_connect(
            InstanceId=connectInstanceDetails['instanceID'],
            Name=phoneNumber,
            Description='Created for ' + tenantName,
            QuickConnectConfig={
                'QuickConnectType': 'PHONE_NUMBER',
                'PhoneConfig': {
                    'PhoneNumber': phoneNumber
                }
            }
        )
        result = True
        qcID = response['QuickConnectId']
    except Exception as ex1:
        print('#####   CREATE QUICK PHONE CONNECT EXCEPTION FOUND: ' + str(ex1) + '   #####')

    return {
        'result': result,
        'qcID': qcID
    }
    
def releasePhoneNumber(connectClient, phoneNumberID):
    print('#####   RELEASING PHONE NUMBER ID: ' + phoneNumberID + '   #####')
    
    try:
        response = connectClient.release_phone_number(
            PhoneNumberId=phoneNumberID
            #ClientToken='string'
        )  
    except Exception as ex1:
        print('#####   RELEASE PHONE NUMBER EXCEPTION FOUND: ' + str(ex1) + '   #####')
    
def claimPhoneNumber(connectClient, connectInstanceDetails, tenantID, language, languageMenu, tenantName, queueID):
    import random
    retry = True
    retries = 0

    while retry and retries < 3:
        print('#####   SEARCH AND CLAIM PHONE NUMBER ATTEMPT: ' + str(retries) + '    #####')
        time.sleep(random.randint(0,5)**retries*100/1000)
        try:
            response = connectClient.search_available_phone_numbers(
                TargetArn=connectInstanceDetails['instanceARN'],
                PhoneNumberCountryCode='US',
                PhoneNumberType='DID',
                MaxResults=1,
            )
            phoneNumber = response['AvailableNumbersList'][0]['PhoneNumber']
            print('#####   CLAIMING NEW PHONE NUMBER: ' + phoneNumber + '   #####')
          
            response = connectClient.claim_phone_number(
                TargetArn=connectInstanceDetails['instanceARN'],
                PhoneNumber=phoneNumber,
                PhoneNumberDescription= 'Tenant: ' + tenantName + ' | Language: ' + language,
                #Tags={
                #    'LanguageMenu': str(languageMenu)
                #},            
            )
            phoneNumberID = response['PhoneNumberId']
            retry = False
        except Exception as ex1:
            retries += 1
            print('#####   CLAIM PHONE NUMBER EXCEPTION FOUND: ' + str(ex1) + '   #####')

    try:
        table = boto3.resource('dynamodb').Table('Tenants')
        
        response = table.update_item(
            Key={'tenantID': tenantID, 'language': language},
            UpdateExpression='SET #attr1 = :val1, #attr2 = :val2, #attr3 = :val3',
            ExpressionAttributeNames={'#attr1': 'DNIS', '#attr2': 'ID', '#attr3': 'languageMenu'},
            ExpressionAttributeValues={':val1': phoneNumber, ':val2': phoneNumberID, ':val3': json.dumps(languageMenu, ensure_ascii=False)}
        )

    except Exception as ex1:
        print('#####   UPDATE TENANTS TABLE EXCEPTION FOUND: ' + str(ex1) + '   #####')
    
    time.sleep(3)
    
    try:
        response = connectClient.associate_phone_number_contact_flow(
            PhoneNumberId=phoneNumberID,
            InstanceId=connectInstanceDetails['instanceID'],
            ContactFlowId=connectInstanceDetails['mainFlowID']
        )
    except Exception as ex1:
        print('#####   ASSIGN CALL FLOW EXCEPTION FOUND: ' + str(ex1) + '   #####')

    #try:
    #    response = connectClient.update_queue_outbound_caller_config(
    #        InstanceId=connectInstanceDetails['instanceID'],
    #        QueueId=queueID,
    #        OutboundCallerConfig={
    #            'OutboundCallerIdName': tenantName,
    #            'OutboundCallerIdNumberId': phoneNumberID,
    #            'OutboundFlowId': connectInstanceDetails['outboundFlowID']
    #        }
    #    )
    #except Exception as ex1:
    #    print('#####   UPDATE QUEUE OUTBOUND PHONE NUMBER EXCEPTION FOUND: ' + str(ex1) + '   #####')    

def loadTenantsfromS3(s3FileName):

    tenantRecords = util.readCSV(s3FileName, 'tenantID', 'language')
    
    try:
        table = boto3.resource('dynamodb').Table('Tenants')
 
        for record in tenantRecords:
            print('INSERTING NEW TENANT RECORD: ' + tenantRecords[record]['tenantID'] + ' WITH LANGUAGE: ' + tenantRecords[record]['language'])
            table.put_item(Item= {'tenantID': tenantRecords[record]['tenantID'], 
                'language': tenantRecords[record]['language'], 
                'tenantName': tenantRecords[record]['tenantName'], 
                'greeting': tenantRecords[record]['greeting'], 
                'dynamoFlow': tenantRecords[record]['dynamoFlow'], 
                'quickConnects': tenantRecords[record]['quickConnects']})

    except Exception as ex1:
        print('#####   UPDATE TENANTS TABLE EXCEPTION FOUND: ' + str(ex1) + '   #####')

def insertTwilioDID(s3FileName):
    
    tenantRecords = util.readCSV(s3FileName, 'tenantID', 'language')
    
    try:
        table = boto3.resource('dynamodb').Table('Tenants')
        
        for record in tenantRecords:
            print('INSERTING TWILIO DID: ' + tenantRecords[record]['twilioDID'] + ' FOR: ' + tenantRecords[record]['tenantID'] + ' WITH LANGUAGE: ' + tenantRecords[record]['language'])

            response = table.update_item(
                Key={'tenantID': tenantRecords[record]['tenantID'], 'language': tenantRecords[record]['language']},
                UpdateExpression='SET #attr1 = :val1',
                ExpressionAttributeNames={'#attr1': 'twilioDID'},
                ExpressionAttributeValues={':val1': tenantRecords[record]['twilioDID']}
            )            

    except Exception as ex1:
        print('#####   UPDATE TWILIO DID EXCEPTION FOUND: ' + str(ex1) + '   #####')

def insertTwilioURL(s3FileName):
    
    twilioNumbers = util.readJSON(s3FileName)

    try:
        dynamodb_client = boto3.client('dynamodb')
        response = dynamodb_client.scan(TableName='Tenants')
        table = boto3.resource('dynamodb').Table('Tenants')

        for twilioRecord in twilioNumbers:
            for item in response['Items']:
                if twilioRecord['phoneNumber'].replace('+','') in json.loads(item['twilioDID']['S']):
                    print('INSERTING TWILIO URL: ' + twilioRecord['voiceUrl'] + ' FOR: ' + item['tenantID']['S'] + ' WITH LANGUAGE: ' + item['language']['S'])
                    table.update_item(
                        Key={'tenantID': item['tenantID']['S'], 'language': item['language']['S']},
                        UpdateExpression='SET #attr1 = :val1',
                        ExpressionAttributeNames={'#attr1': 'twilioURL'},
                        ExpressionAttributeValues={':val1': twilioRecord['voiceUrl']}
                    )

    except Exception as ex1:
        print('#####   UPDATE TWILIO URL EXCEPTION FOUND: ' + str(ex1) + '   #####')
