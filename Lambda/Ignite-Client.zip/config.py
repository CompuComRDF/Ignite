import boto3

AWS_ACCOUNT_ID = boto3.client('sts').get_caller_identity()["Account"]
region = ''
s3BucketName = ''

assume_role_policy_document = '{\
    "Version": "2012-10-17",\
    "Statement": [\
        {\
            "Effect": "Allow",\
            "Principal": {\
                "AWS": "arn:aws:iam::<ACCOUNT_ID>:root"\
            },\
            "Action": "sts:AssumeRole",\
            "Condition": {}\
        }\
    ]\
}'

kms_key_policy = '{\
    "Version": "2012-10-17",\
    "Id": "key-consolepolicy-3",\
    "Statement": [\
        {\
            "Sid": "Enable IAM User Permissions",\
            "Effect": "Allow",\
            "Principal": {\
                "AWS": "arn:aws:iam::<TENANT_ACCOUNT>:root"\
            },\
            "Action": "kms:*",\
            "Resource": "*"\
        },\
        {\
            "Sid": "Enable Amazon Connect",\
            "Effect": "Allow",\
            "Principal": {\
                "Service": "connect.amazonaws.com"\
            },\
            "Action": "kms:decrypt",\
            "Resource": "*"\
        },\
        {\
            "Sid": "Allow access for Key Administrators",\
            "Effect": "Allow",\
            "Principal": {\
                "AWS": "arn:aws:iam::<TENANT_ACCOUNT>:role/aws-controltower-AdministratorExecutionRole"\
            },\
            "Action": [\
                "kms:Create*",\
                "kms:Describe*",\
                "kms:Enable*",\
                "kms:List*",\
                "kms:Put*",\
                "kms:Update*",\
                "kms:Revoke*",\
                "kms:Disable*",\
                "kms:Get*",\
                "kms:Delete*",\
                "kms:TagResource",\
                "kms:UntagResource",\
                "kms:ScheduleKeyDeletion",\
                "kms:CancelKeyDeletion"\
            ],\
            "Resource": "*"\
        },\
        {\
            "Sid": "Allow use of the key",\
            "Effect": "Allow",\
            "Principal": {\
                "AWS": "arn:aws:iam::<CENTRAL_ACCOUNT>:root"\
            },\
            "Action": [\
                "kms:Encrypt",\
                "kms:Decrypt",\
                "kms:ReEncrypt*",\
                "kms:GenerateDataKey*",\
                "kms:DescribeKey"\
            ],\
            "Resource": "*"\
        }\
    ]\
}'

s3_main_bucket_policy = '{\
    "Version": "2012-10-17",\
    "Statement": [\
        {\
            "Effect": "Allow",\
            "Principal": {\
                "AWS": "<RDF_ROLE>"\
            },\
            "Action": "s3:*",\
            "Resource": [\
                "arn:aws:s3:::<S3BUCKETNAME>"\
                "arn:aws:s3:::<S3BUCKETNAME>/*"\
            ]\
        },\
        {\
            "Sid": "statement1",\
            "Effect": "Allow",\
            "Principal": {\
                "Service": "connect.amazonaws.com"\
            },\
            "Action": [\
                "s3:ListBucket",\
                "s3:GetObject"\
            ],\
            "Resource": [\
                "arn:aws:s3:::<S3BUCKETNAME>",\
                "arn:aws:s3:::<S3BUCKETNAME>/*"\
            ],\
            "Condition": {\
                "StringEquals": {\
                    "aws:SourceArn": "<INSTANCE_ARN>",\
                    "aws:SourceAccount": "<TENANT_ACCOUNT>"\
                }\
            }\
        }\
    ]\
}'

db_tables = {
    "Tenants":{
        "attribute_definitions":[
            {
                'AttributeName': 'TenantID',
                'AttributeType': 'S'                    
            },
            {
                'AttributeName': 'language',
                'AttributeType': 'S'                    
            }
        ],
        "key_schema":[
            {
                'AttributeName': 'TenantID',
                'KeyType': 'HASH'
            },
            {
                'AttributeName': 'language',
                'KeyType': 'RANGE'
            }   
        ]
    },
    "Users":{
        "attribute_definitions":[
            {
                'AttributeName': 'email',
                'AttributeType': 'S'                    
            }
        ],
        "key_schema":[
            {
                'AttributeName': 'email',
                'KeyType': 'HASH'
            }  
        ]
    },
    "ivr-recording-contactTranscriptSegments":{
        "attribute_definitions":[
            {
                'AttributeName': 'ContactId',
                'AttributeType': 'S'                    
            },
            {
                'AttributeName': 'StartTime',
                'AttributeType': 'N'                    
            }
        ],
        "key_schema":[
            {
                'AttributeName': 'ContactId',
                'KeyType': 'HASH'
            },
            {
                'AttributeName': 'StartTime',
                'KeyType': 'RANGE'
            }   
        ]
    },
    "ivr-recording-contactDetails":{
        "attribute_definitions":[
            {
                'AttributeName': 'contactId',
                'AttributeType': 'S'                    
            }
        ],
        "key_schema":[
            {
                'AttributeName': 'contactId',
                'KeyType': 'HASH'
            }
        ]
    }
}

lambda_functions = {
    "kvs_Converter":{
        "permissions_to_attach":[
            "AmazonDynamoDBFullAccess",
            "AmazonKinesisVideoStreamsFullAccess",
            "AmazonS3FullAccess",
            "AmazonTranscribeFullAccess",
            "AWSLambdaBasicExecutionRole-kvs_Converter"
        ],
        "environment":{
            "Variables": {
                "APP_REGION":"",
                "RECORDINGS_BUCKET_NAME":"",
                "RECORDINGS_KEY_PREFIX":"audio/",
                "SAVE_PARTIAL_TRANSCRIPTS":"FALSE",
                "START_SELECTOR_TYPE":"FRAGMENT_NUMBER",
                "TABLE_CALLER_TRANSCRIPT":"ivr-recording-contactTranscriptSegments",
                "TABLE_CALLER_TRANSCRIPT_TO_CUSTOMER":"ivr-recording-contactTranscriptSegmentsToCustomer",
                "TRANSCRIBE_REGION":""
            }
        }, 
        "handler":"com.amazonaws.kvstranscribestreaming.KVSTranscribeStreamingLambda::handleRequest",           
        "runtime":"java8.al2",
        "timeout":120,
        "memory": 256,
        "ephemeral":1024
    },
    "ConnectKVS2Audio":{
        "permissions_to_attach":[
            "AmazonConnect_FullAccess",
            "AmazonDynamoDBFullAccess",
            "AmazonKinesisVideoStreamsFullAccess",
            "AmazonS3FullAccess",
            "AWSLambda_FullAccess",
            "AWSLambdaBasicExecutionRole-ConnectKVS2Audio"
        ],
        "environment":{
            "Variables": {}
        },
        "handler":"lambda_function.lambda_handler",            
        "runtime":"python3.9",
        "timeout":120,
        "memory": 128,
        "ephemeral":512    }
}

contact_flows={            
    'ContactFlows/Default customer whisper':"CUSTOMER_WHISPER",
    'ContactFlows/Connect-RDF-Outbound':"OUTBOUND_WHISPER",
    'ContactFlows/Connect-RDF-Queue':"CUSTOMER_QUEUE",
    'ContactFlows/Connect-RDF-Whisper':"AGENT_WHISPER",
    'ContactFlows/Connect-RDF-Agent':"QUEUE_TRANSFER",
    'ContactFlows/Connect-RDF-Main':"CONTACT_FLOW"
}

lambda_exec_policy = '{\
    "Version": "2012-10-17",\
    "Statement": [\
        {\
            "Effect": "Allow",\
            "Action": "logs:CreateLogGroup",\
            "Resource": "arn:aws:logs:<AWS_REGION>:<AWS_ACCOUNT_ID>:*"\
        },\
        {\
            "Effect": "Allow",\
            "Action": [\
                "logs:CreateLogStream",\
                "logs:PutLogEvents"\
            ],\
            "Resource": [\
                "arn:aws:logs:<AWS_REGION>:<AWS_ACCOUNT_ID>:log-group:/aws/lambda/<FUNCTION_NAME>:*"\
            ]\
        }\
    ]\
}'

assume_role_policy = '{\
    "Version": "2012-10-17",\
    "Statement": [\
        {\
            "Effect": "Allow",\
            "Principal": {\
                "Service": "lambda.amazonaws.com"\
            },\
            "Action": "sts:AssumeRole"\
        }\
    ]\
}'

connect_event_rule = '{\
    "source": [\
        "aws.connect"\
    ],\
    "detail-type": [\
        "Amazon Connect Contact Event"\
    ]\
}'
