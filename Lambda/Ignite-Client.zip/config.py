import boto3

AWS_ACCOUNT_ID = boto3.client('sts').get_caller_identity()["Account"]
region = ''
s3_bucket_name = ''

hours_of_operations = [
    {
        "Day": "MONDAY",
        "StartTime": {
            "Hours": 8,
            "Minutes": 30
        },
        "EndTime": {
            "Hours": 17,
            "Minutes": 0
        }
    },
    {
        "Day": "TUESDAY",
        "StartTime": {
            "Hours": 8,
            "Minutes": 30
        },
        "EndTime": {
            "Hours": 17,
            "Minutes": 0
        }
    },
    {
        "Day": "WEDNESDAY",
        "StartTime": {
            "Hours": 8,
            "Minutes": 30
        },
        "EndTime": {
            "Hours": 17,
            "Minutes": 0
        }
    },
    {
        "Day": "THURSDAY",
        "StartTime": {
            "Hours": 8,
            "Minutes": 30
        },
        "EndTime": {
            "Hours": 17,
            "Minutes": 0
        }
    },
    {
        "Day": "FRIDAY",
        "StartTime": {
            "Hours": 8,
            "Minutes": 30
        },
        "EndTime": {
            "Hours": 17,
            "Minutes": 0
        }
    }
]

assume_role_policy_document = '{\
    "Version": "2012-10-17",\
    "Statement": [\
        {\
            "Effect": "Allow",\
            "Principal": {\
                "AWS": "arn:aws:iam::<ACCOUNT_ID>:root"\
            },\
            "Action": "sts:AssumeRole",\
            "Condition": {}\
        }\
    ]\
}'

kms_key_policy = '{\
    "Version": "2012-10-17",\
    "Id": "key-consolepolicy-3",\
    "Statement": [\
        {\
            "Sid": "Enable IAM User Permissions",\
            "Effect": "Allow",\
            "Principal": {\
                "AWS": "arn:aws:iam::<TENANT_ACCOUNT>:root"\
            },\
            "Action": "kms:*",\
            "Resource": "*"\
        },\
        {\
            "Sid": "Enable Amazon Connect",\
            "Effect": "Allow",\
            "Principal": {\
                "Service": "connect.amazonaws.com"\
            },\
            "Action": "kms:decrypt",\
            "Resource": "*"\
        },\
        {\
            "Sid": "Allow access for Key Administrators",\
            "Effect": "Allow",\
            "Principal": {\
                "AWS": "arn:aws:iam::<TENANT_ACCOUNT>:role/AWSControlTowerExecution"\
            },\
            "Action": [\
                "kms:Create*",\
                "kms:Describe*",\
                "kms:Enable*",\
                "kms:List*",\
                "kms:Put*",\
                "kms:Update*",\
                "kms:Revoke*",\
                "kms:Disable*",\
                "kms:Get*",\
                "kms:Delete*",\
                "kms:TagResource",\
                "kms:UntagResource",\
                "kms:ScheduleKeyDeletion",\
                "kms:CancelKeyDeletion"\
            ],\
            "Resource": "*"\
        },\
        {\
            "Sid": "Allow use of the key",\
            "Effect": "Allow",\
            "Principal": {\
                "AWS": [\
                    "arn:aws:iam::<CENTRAL_ACCOUNT>:root",\
                    "<CONNECT_KVS_ROLE_ARN>",\
                    "<KVS_CONV_ROLE_ARN>"\
                ]\
            },\
            "Action": [\
                "kms:Encrypt",\
                "kms:Decrypt",\
                "kms:ReEncrypt*",\
                "kms:GenerateDataKey*",\
                "kms:DescribeKey"\
            ],\
            "Resource": "*"\
        },\
        {\
            "Sid": "Allow attachment of persistent resources",\
            "Effect": "Allow",\
            "Principal": {\
                "AWS": [\
                    "<CONNECT_KVS_ROLE_ARN>",\
                    "arn:aws:iam::<CENTRAL_ACCOUNT>:root",\
                    "<KVS_CONV_ROLE_ARN>"\
                ]\
            },\
            "Action": [\
                "kms:CreateGrant",\
                "kms:ListGrants",\
                "kms:RevokeGrant"\
            ],\
            "Resource": "*",\
            "Condition": {\
                "Bool": {\
                    "kms:GrantIsForAWSResource": "true"\
                }\
            }\
        }\
    ]\
}'

s3_main_bucket_policy = '{\
    "Version": "2012-10-17",\
    "Statement": [\
        {\
            "Effect": "Allow",\
            "Principal": {\
                "AWS": "<RDF_ROLE>"\
            },\
            "Action": "s3:*",\
            "Resource": [\
                "arn:aws:s3:::<S3BUCKETNAME>",\
                "arn:aws:s3:::<S3BUCKETNAME>/*"\
            ]\
        },\
        {\
            "Sid": "statement1",\
            "Effect": "Allow",\
            "Principal": {\
                "Service": "connect.amazonaws.com"\
            },\
            "Action": [\
                "s3:ListBucket",\
                "s3:GetObject"\
            ],\
            "Resource": [\
                "arn:aws:s3:::<S3BUCKETNAME>",\
                "arn:aws:s3:::<S3BUCKETNAME>/*"\
            ],\
            "Condition": {\
                "StringEquals": {\
                    "aws:SourceArn": "<INSTANCE_ARN>",\
                    "aws:SourceAccount": "<TENANT_ACCOUNT>"\
                }\
            }\
        }\
    ]\
}'

db_tables = {
    "Tenants":{
        "attribute_definitions":[
            {
                'AttributeName': 'TenantID',
                'AttributeType': 'S'                    
            },
            {
                'AttributeName': 'language',
                'AttributeType': 'S'                    
            }
        ],
        "key_schema":[
            {
                'AttributeName': 'TenantID',
                'KeyType': 'HASH'
            },
            {
                'AttributeName': 'language',
                'KeyType': 'RANGE'
            }   
        ]
    },
    "Users":{
        "attribute_definitions":[
            {
                'AttributeName': 'email',
                'AttributeType': 'S'                    
            }
        ],
        "key_schema":[
            {
                'AttributeName': 'email',
                'KeyType': 'HASH'
            }  
        ]
    },
    "ivr-recording-contactTranscriptSegments":{
        "attribute_definitions":[
            {
                'AttributeName': 'ContactId',
                'AttributeType': 'S'                    
            },
            {
                'AttributeName': 'StartTime',
                'AttributeType': 'N'                    
            }
        ],
        "key_schema":[
            {
                'AttributeName': 'ContactId',
                'KeyType': 'HASH'
            },
            {
                'AttributeName': 'StartTime',
                'KeyType': 'RANGE'
            }   
        ]
    },
    "ivr-recording-contactDetails":{
        "attribute_definitions":[
            {
                'AttributeName': 'contactId',
                'AttributeType': 'S'                    
            }
        ],
        "key_schema":[
            {
                'AttributeName': 'contactId',
                'KeyType': 'HASH'
            }
        ]
    }
}

lambda_functions = {
    "kvs_Converter":{
        "permissions_to_attach":[
            "AmazonDynamoDBFullAccess",
            "AmazonKinesisVideoStreamsFullAccess",
            "AmazonS3FullAccess",
            "AmazonTranscribeFullAccess",
            "AWSLambdaBasicExecutionRole-kvs_Converter"
        ],
        "environment":{
            "Variables": {
                "APP_REGION":"",
                "RECORDINGS_BUCKET_NAME":"",
                "RECORDINGS_KEY_PREFIX":"audio/",
                "SAVE_PARTIAL_TRANSCRIPTS":"FALSE",
                "START_SELECTOR_TYPE":"FRAGMENT_NUMBER",
                "TABLE_CALLER_TRANSCRIPT":"ivr-recording-contactTranscriptSegments",
                "TABLE_CALLER_TRANSCRIPT_TO_CUSTOMER":"ivr-recording-contactTranscriptSegmentsToCustomer",
                "TRANSCRIBE_REGION":""
            }
        }, 
        "handler":"com.amazonaws.kvstranscribestreaming.KVSTranscribeStreamingLambda::handleRequest",           
        "runtime":"java8.al2",
        "timeout":120,
        "memory": 512,
        "ephemeral":512
    },
    "ConnectKVS2Audio":{
        "permissions_to_attach":[
            "AmazonConnect_FullAccess",
            "AmazonDynamoDBFullAccess",
            "AmazonKinesisVideoStreamsFullAccess",
            "AmazonS3FullAccess",
            "AWSLambda_FullAccess",
            "AWSLambdaBasicExecutionRole-ConnectKVS2Audio"
        ],
        "environment":{
            "Variables": {}
        },
        "handler":"lambda_function.lambda_handler",            
        "runtime":"python3.9",
        "timeout":120,
        "memory": 128,
        "ephemeral":512    }
}

contact_flows={            
    'ContactFlows/Default customer whisper':"CUSTOMER_WHISPER",
    'ContactFlows/Connect-RDF-Outbound':"OUTBOUND_WHISPER",
    'ContactFlows/Connect-RDF-Queue':"CUSTOMER_QUEUE",
    'ContactFlows/Connect-RDF-Whisper':"AGENT_WHISPER",
    'ContactFlows/Connect-RDF-Agent':"QUEUE_TRANSFER",
    'ContactFlows/Connect-RDF-Languages':"MODULE",
    'ContactFlows/Connect-RDF-Init':"CONTACT_FLOW",
    'ContactFlows/Connect-RDF-Play':"CONTACT_FLOW",
    'ContactFlows/Connect-RDF-Record':"CONTACT_FLOW",
    'ContactFlows/Connect-RDF-Main':"CONTACT_FLOW"
}

config_files=[
    'config.csv',
    'ivr-callflow.csv',
    'ivr-holidays.csv',
    'ivr-menutree.csv',
    'ivr-sysadmin.csv',
    'ivr-tts.csv'
]

lambda_exec_policy = '{\
    "Version": "2012-10-17",\
    "Statement": [\
        {\
            "Effect": "Allow",\
            "Action": "logs:CreateLogGroup",\
            "Resource": "arn:aws:logs:<AWS_REGION>:<AWS_ACCOUNT_ID>:*"\
        },\
        {\
            "Effect": "Allow",\
            "Action": [\
                "logs:CreateLogStream",\
                "logs:PutLogEvents"\
            ],\
            "Resource": [\
                "arn:aws:logs:<AWS_REGION>:<AWS_ACCOUNT_ID>:log-group:/aws/lambda/<FUNCTION_NAME>:*"\
            ]\
        }\
    ]\
}'

assume_role_policy = '{\
    "Version": "2012-10-17",\
    "Statement": [\
        {\
            "Effect": "Allow",\
            "Principal": {\
                "Service": "lambda.amazonaws.com"\
            },\
            "Action": "sts:AssumeRole"\
        }\
    ]\
}'

connect_event_rule = '{\
    "source": [\
        "aws.connect"\
    ],\
    "detail-type": [\
        "Amazon Connect Contact Event"\
    ]\
}'

language_names = {
    "ar-AE": "Arabic",
    "ca-ES": "Catalan",
    "de-AT": "German",
    "de-DE": "German",
    "en-AU": "English",
    "en-GB": "English",
    "en-IN": "English",
    "en-US": "English",
    "en-ZA": "English",
    "es-419": "Spanish",
    "es-ES": "Spanish",
    "es-US": "Spanish",
    "fi-FI": "Finnish",
    "fr-CA": "French",
    "fr-FR": "French",
    "hi-IN": "Hindi",
    "it-IT": "Italian",
    "ja-JP": "Japanese",
    "ko-KR": "Korean",
    "nl-NL": "Dutch",
    "no-NO": "Norwegian",
    "pl-PL": "Polish",
    "pt-BR": "Portuguese",
    "pt-PT": "Portuguese",
    "sv-SE": "Swedish",
    "zh-CN": "Mandarin",
    "zh-HK": "Cantonese"
}

voices = {
   "ar-AE":{
      "Name":"Arabic (Gulf)",
      "Voices":[
         "Hala",
         "Zayd"
      ]
   },
   "nl-BE":{
      "Name":"Belgian Dutch (Flemish)",
      "Voices":[
         "Lisa"
      ]
   },
   "ca-ES":{
      "Name":"Catalan",
      "Voices":[
         "Arlet"
      ]
   },
   "yue-CN":{
      "Name":"Chinese (Cantonese)",
      "Voices":[
         "Hiujin"
      ]
   },
   "cmn-CN":{
      "Name":"Chinese (Mandarin)",
      "Voices":[
         "Zhiyu"
      ]
   },
   "da-DK":{
      "Name":"Danish",
      "Voices":[
         "Sofie",
         "Naja",
         "Mads"
      ]
   },
   "nl-NL":{
      "Name":"Dutch",
      "Voices":[
         "Laura",
         "Ruben",
         "Lotte"
      ]
   },
   "en-AU":{
      "Name":"English (Australian)",
      "Voices":[
         "Olivia",
         "Russell",
         "Nicole"
      ]
   },
   "en-GB":{
      "Name":"English (British)",
      "Voices":[
         "Amy",
         "Emma",
         "Brian",
         "Arthur"
      ]
   },
   "en-IN":{
      "Name":"English (Indian)",
      "Voices":[
         "Kajal",
         "Raveena",
         "Aditi"
      ]
   },
   "en-IE":{
      "Name":"English (Irish)",
      "Voices":[
         "Niamh"
      ]
   },
   "en-NZ":{
      "Name":"English (New Zealand)",
      "Voices":[
         "Aria"
      ]
   },
   "en-ZA":{
      "Name":"English (South African)",
      "Voices":[
         "Ayanda"
      ]
   },
   "en-US":{
      "Name":"English (US)",
      "Voices":[
         "Danielle",
         "Gregory",
         "Ivy",
         "Joanna",
         "Kendra",
         "Kimberly",
         "Salli",
         "Joey",
         "Justin",
         "Kevin",
         "Matthew",
         "Ruth",
         "Stephen"
      ]
   },
   "fi-FI":{
      "Name":"Finnish",
      "Voices":[
         "Suvi"
      ]
   },
   "fr-BE":{
      "Name":"French (Belgian)",
      "Voices":[
         "Isabelle"
      ]
   },
   "fr-CA":{
      "Name":"French (Canadian)",
      "Voices":[
         "Gabrielle",
         "Liam",
         "Chantal"
      ]
   },
   "fr-FR":{
      "Name":"French",
      "Voices":[
         "Léa",
         "Rémi",
         "Mathieu",
         "Céline"
      ]
   },
   "de-DE":{
      "Name":"German",
      "Voices":[
         "Vicki",
         "Daniel",
         "Marlene",
         "Hans"
      ]
   },
   "de-AT":{
      "Name":"German (Austrian)",
      "Voices":[
         "Hannah"
      ]
   },
   "hi-IN":{
      "Name":"Hindi",
      "Voices":[
         "Kajal"
      ]
   },
   "it-IT":{
      "Name":"Italian",
      "Voices":[
         "Bianca",
         "Adriano",
         "Giorgio",
         "Carla"
      ]
   },
   "ja-JP":{
      "Name":"Japanese",
      "Voices":[
         "Takumi",
         "Kazuha",
         "Tomoko",
         "Mizuki"
      ]
   },
   "ko-KR":{
      "Name":"Korean",
      "Voices":[
         "Seoyeon"
      ]
   },
   "nb-NO":{
      "Name":"Norwegian",
      "Voices":[
         "Ida",
         "Liv"
      ]
   },
   "pl-PL":{
      "Name":"Polish",
      "Voices":[
         "Ola",
         "Maja",
         "Jan",
         "Jacek",
         "Ewa"
      ]
   },
   "pt-BR":{
      "Name":"Portuguese (Brazilian)",
      "Voices":[
         "Camila",
         "Vitória",
         "Thiago",
         "Ricardo"
      ]
   },
   "pt-PT":{
      "Name":"Portuguese (European)",
      "Voices":[
         "Inês",
         "Cristiano"
      ]
   },
   "es-ES":{
      "Name":"Spanish (European)",
      "Voices":[
         "Lucia",
         "Sergio",
         "Enrique",
         "Conchita"
      ]
   },
   "es-MX":{
      "Name":"Spanish (Mexican)",
      "Voices":[
         "Mia",
         "Andrés"
      ]
   },
   "es-US":{
      "Name":"Spanish (US)",
      "Voices":[
         "Lupe",
         "Pedro",
         "Penélope",
         "Miguel"
      ]
   },
   "sv-SE":{
      "Name":"Swedish",
      "Voices":[
         "Elin",
         "Astrid"
      ]
   },
   "tr-TR":{
      "Name":"Turkish",
      "Voices":[
         "Burcu",
         "Filiz"
      ]
   }
}

default_voices = {
    "1": {
        "Language": "en-US",
        "Name": "US English",
        "Voice": "Stephen"
    }
}

active_voices = {
   "1":{
      "Language":"en-US",
      "Name":"English (US)",
      "Voice":"Stephen"
   }    
}

default_prompts = [
   "EM01",
   "BM01",
   "BM02",
   "BM03",
   "closed",
   "holiday",
   "monitor",
   "noagents",
   "pleasehold",
   "busy",
   "highvolume",
   "stillbusy",
   "voicemail",
   "saved",
   "goodbye",
   "difficulties",
   "InvalidInput1",
   "InvalidInput2",
   "NoInput1",
   "NoInput2",
   "MaxInputXfer"
]

voice_identifiers_main={
   "1":"a0c6336f-cb00-4564-a02f-f292ef69ff4f",
   "2":"c2834a53-9e3b-4157-84c1-7e0e3c67676a",
   "3":"ff0f33d6-cd1a-49ff-9be7-b61afaa57c4b",
   "4":"5e61c7e0-0e9c-49c7-ad53-5e4d6716b56b"
}

voice_identifiers={
   "1":"bd71ebfd-cf07-41b5-af23-5a5a4321350f",
   "2":"5cd822a9-0445-49e3-82fa-9ccc4ec62ae2",
   "3":"fad308d0-6708-439a-86dc-5a4760047e6b",
   "4":"ad9d35d9-2124-48e7-b3da-582df4b57ef5",
   "5":"9ce94d97-5e91-45d3-a14d-83878039bdbe",
   "6":"16dcf4d9-c9d9-43e2-b627-abc38332e9a2",
   "7":"faf56914-28cc-4576-8afd-e1f3e07a692d",
   "8":"3acf68de-28f6-4e65-a086-b99d5d676d21",
   "9":"61baf4bf-916a-43b3-8fb9-8d91a79592cc",
   "10":"56edff0f-8a1c-439a-a1db-75c1ad1858ea"
}


case_identifier = "ca58a56e-7f3f-478a-a91b-2b1fa4764799"

case_actions = {
    "1": "bd71ebfd-cf07-41b5-af23-5a5a4321350f",
    "2": "5cd822a9-0445-49e3-82fa-9ccc4ec62ae2",
    "3": "fad308d0-6708-439a-86dc-5a4760047e6b",
    "4": "ad9d35d9-2124-48e7-b3da-582df4b57ef5",
    "5": "9ce94d97-5e91-45d3-a14d-83878039bdbe",
    "6": "16dcf4d9-c9d9-43e2-b627-abc38332e9a2",
    "7": "faf56914-28cc-4576-8afd-e1f3e07a692d",
    "8": "3acf68de-28f6-4e65-a086-b99d5d676d21",
    "9": "61baf4bf-916a-43b3-8fb9-8d91a79592cc",
    "10": "56edff0f-8a1c-439a-a1db-75c1ad1858ea"
}
