import json
import boto3
import traceback
import users
import tenants
import util
import config
import instances

def lambda_handler(event, context):
    util.logger(event)
    status_code = 200
    response = {}
    #print("boto3 version:" + boto3.__version__)
    try:
        event_source = event['Records'][0]['eventSource'] #S3 Event = aws:s3 | DynamoDB Event = aws:dynamodb
        config.region = event['Records'][0]['awsRegion'] 
    except:
        event_source = 'aws:lambda'
        config.region = event['Region']
        pass

    try:
        if event_source == 'aws:lambda':
            #FOR TESTING PURPOSES, USE THE FOLLOWING TO TEST FROM AWS CLI:
            #aws lambda invoke --function-name Ignite-Client --profile demo --invocation-type Event --cli-binary-format raw-in-base64-out --payload '{"request":"create-tenant","TenantID":"abc","InstanceType":"SAML","EmailDomain":"ps.compucom.com","Region":"ca-central-1"}' response.json
            organizational_units = ['DEV', 'UAT', 'PROD']

            if event['request'] == 'create-tenant':
                for ou in organizational_units:
                    instances.insert_instance_record(ou, event['TenantID'], event['InstanceType'], event['EmailDomain'])

            #aws lambda invoke --function-name Ignite-Client --profile demo --invocation-type Event --cli-binary-format raw-in-base64-out --payload '{"request":"create-app","TenantID":"abc", "AppID":"Main","Language":"_En_Fr","TenantName":"ABC","Greeting":"Thanks for calling ABC company.","CallFlow":"","Queues":"", "Region":"ca-central-1"}' response.json
            elif event['request'] == 'create-app':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)

                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                connect_instance_details = util.get_connect_instance_details(connect_client)                    
                response = tenants.insert_app_record(event, connect_client, connect_instance_details)

            elif event['request'] == 'update-app':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)

                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                connect_instance_details = util.get_connect_instance_details(connect_client)
                response = tenants.update_app_record(event, connect_client, connect_instance_details, role_credentials)                    

            elif event['request'] == 'delete-app':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)

                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                connect_instance_details = util.get_connect_instance_details(connect_client)
                response = tenants.delete_app_record(event, connect_client, connect_instance_details) 

            elif event['request'] == 'get-tenant-status':
                ou_instances_status = {}
                for ou in organizational_units:
                    ou_instance_status = instances.get_tenant_status(ou, ou.lower() + event['TenantID'])
                    print(ou + " " + str(ou_instance_status))
                    ou_instances_status[ou] = ou_instance_status
                response = ou_instances_status

            elif event['request'] == 'get-tenants':
                tenant_list = instances.get_tenants()
                response = tenant_list

            elif event['request'] == 'get-tenant-object':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = boto3.client('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                response = instances.get_tenant_object(s3_client, event['FileName'])                

            elif event['request'] == 'put-tenant-object':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = boto3.client('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])  
                s3_resource = boto3.resource('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                
                response = instances.put_tenant_object(s3_client, s3_resource, event['FileName'], event['Content'])   

            elif event['request'] == 'get-business-hours':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                  
                response = instances.get_business_hours(connect_client, connect_id)   

            elif event['request'] == 'put-business-hours':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                  
                response = instances.put_business_hours(connect_client, connect_id, event['HoursConfig'])
                
            elif event['request'] == 'get-tenant-apps':
                response = tenants.get_tenant_apps(event['Env'])
                
            elif event['request'] == 'get-translation':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                response = util.translate_text(role_credentials, event['Message'], event['SourceLanguage'], event['TargetLanguage'])
            
            elif event['request'] == 'get-callflows':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = boto3.client('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN']) 
                response = util.get_callflows(s3_client)

            elif event['request'] == 'get-queues':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                  
                response = util.get_queues(connect_client, connect_id) 

            elif event['request'] == 'get-phone-number':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                  
                response = tenants.get_phone_number(connect_client, connect_arn, event['TenantID'], event['Country'], event['Type']) 

            elif event['request'] == 'update-phone-number':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                  
                response = tenants.update_phone_number(connect_client, connect_arn, event['TenantID'], event['Country'], event['Type'], event['PreviousID']) 

            elif event['request'] == 'delete-queue':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                  
                connect_instance_details = util.get_connect_instance_details(connect_client)
                queues_to_delete = json.loads('["' + event['QueueName'] + '_"]')
                #response = tenants.manual_delete_queue(connect_client, connect_id, event['QueueName']) 
                response = tenants.delete_queues(event, connect_client, connect_instance_details, queues_to_delete, event['Language'].replace(" ", ""), event['Language'].replace(" ", ""))

            elif event['request' == 'clear-queue']:
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                  
                connect_instance_details = util.get_connect_instance_details(connect_client)
                response = tenants.delete_queue

            else:
                util.logger("INVALID REQUEST")

        elif event_source == 'aws:dynamodb':
            table = event['Records'][0]['eventSourceARN'].split(':')[5].split('/')[1]
            ou = table[table.find('-')+1:]
            app_id = event['Records'][0]['dynamodb']['Keys']['Tenant']['S']
            tenant_id = app_id[0:app_id.find('-')]
            event_type =  event['Records'][0]['eventName']

            if 'Instances' in table:
                if event_type == 'INSERT':
                    instances.create_tenant_instance(event, ou)

            elif 'Users' in table:
                (account_id, connect_id, connect_arn) = util.get_instance_config(ou, tenant_id)
                role_credentials = util.assume_role(account_id)

                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                
                connect_instance_details = util.get_connect_instance_details(event, connect_client)
                #config.s3_bucket_name = 'amazon-connect-' + connect_instance_details['instanceID']
                #Check Event Operation Type
                if event_type == 'REMOVE':
                    users.remove_user_record(event, connect_client, connect_instance_details)
                
                if event_type == 'MODIFY':
                    oldImage = event['Records'][0]['dynamodb']['OldImage']
                    newImage = event['Records'][0]['dynamodb']['NewImage']
                    if newImage != oldImage:
                        users.remove_user_record(event, connect_client, connect_instance_details)
                        users.insert_user_record(event, connect_client, connect_instance_details)
                    
                if event_type == 'INSERT':
                    users.insert_user_record(event, connect_client, connect_instance_details)
    
            else: #'Tenants'
                (account_id, connect_id, connect_arn) = util.get_instance_config(ou, tenant_id)
                role_credentials = util.assume_role(account_id)

                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])

                #config.s3_bucket_name = 'amazon-connect-' + connect_instance_details['instanceID']
                if event_type == 'REMOVE':
                    connect_instance_details = util.get_connect_instance_details(connect_client)
                    tenants.remove_connect_tenant(ou, event, connect_client, connect_instance_details)
    
                if event_type == 'INSERT':
                    connect_instance_details = util.get_connect_instance_details(connect_client)
                    tenants.create_connect_tenant(ou, event, connect_client, connect_instance_details)

        else: #'aws:s3'
            config.s3_bucket_name = event['Records'][0]['s3']['bucket']['name']
            s3_filename = event['Records'][0]['s3']['object']['key']

            #This was used for the initial load only
            if s3_filename == 'init/tenants.csv':
                tenants.load_tenants_from_S3(s3_filename)
            if s3_filename == 'init/users.csv':
                users.load_users_from_S3(s3_filename)

    except Exception as ex1:
        status_code = 500
        response = str(ex1)
        print('#####   EXCEPTION FOUND: ' + str(ex1) + '   #####')
        print('#####   TRACEBACK MESSAGE: ' + traceback.format_exc() + '   #####')
    
    return {
        'statusCode': status_code,
        'body': response
    }
