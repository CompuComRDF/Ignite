import json
import boto3
import traceback
import users
import util
import config
import time
import datetime
import applications
import instances
import tenants
import queues
import officehours
import phonenumbers
import logger
import logging
import cloudwatch

logging.getLogger('boto3').setLevel(logging.WARNING)
logging.getLogger('botocore').setLevel(logging.WARNING)
logging.getLogger('botocore.credentials').setLevel(logging.WARNING)

def lambda_handler(event, context):
    logger.info(event)
    status_code = 200
    response = {}

    try:
        event_source = event['Records'][0]['eventSource'] #S3 Event = aws:s3 | DynamoDB Event = aws:dynamodb
        config.region = event['Records'][0]['awsRegion'] 
    except:
        try: 
            event_source = event['source']
            config.region = event['detail']['awsRegion']
        except:
            event_source = 'aws:lambda'
            try:
                config.region = event['Region']
            except:
                config.region = ''

    try:
        if event_source == 'aws:lambda':
            #FOR TESTING PURPOSES, USE THE FOLLOWING TO TEST FROM AWS CLI:
            #aws lambda invoke --function-name Ignite-Client --profile demo --invocation-type Event --cli-binary-format raw-in-base64-out --payload '{"request":"create-tenant","TenantID":"abc","InstanceType":"SAML","EmailDomain":"ps.compucom.com","Region":"ca-central-1"}' response.json
            organizational_units = ['DEV', 'UAT', 'PROD']

            if event['request'] == 'create-tenant':
                for ou in organizational_units:
                    try:
                        active_voices = event['ActiveVoices']
                    except:
                        active_voices = config.active_voices
                    instances.insert_instance_record(ou, event['TenantID'], event['InstanceType'], event['EmailDomain'], active_voices)

            elif event['request'] == 'update-tenant':
                if event.get("Env"):
                    organizational_units = [event['Env']]

                for ou in organizational_units:
                    (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(ou, event['TenantID'])
                    role_credentials = util.assume_role(account_id)
                    connect_client = util.get_client('connect', role_credentials)
                    s3_target_resource = util.get_resource('s3', role_credentials)
                    #lex_client = util.get_client('lexv2-models', role_credentials)
                    instances.update_instance_record(role_credentials, account_id, connect_id, connect_arn, ou, s3_target_resource, tenant_name, event['TenantID'], event['ContactFlows'], event['ConfigFiles'])

            #aws lambda invoke --function-name Ignite-Client --profile demo --invocation-type Event --cli-binary-format raw-in-base64-out --payload '{"request":"create-app","TenantID":"abc", "AppID":"Main","Language":"_En_Fr","TenantName":"ABC","Greeting":"Thanks for calling ABC company.","CallFlow":"","Queues":"", "Region":"ca-central-1"}' response.json
            elif event['request'] == 'create-app':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                s3_resource = util.get_resource('s3', role_credentials)
                response = applications.insert_app_record(event, s3_client, s3_resource, role_credentials, connect_id)

            elif event['request'] == 'update-app':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                s3_resource = util.get_resource('s3', role_credentials)
                connect_client = util.get_client('connect', role_credentials)
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)
                response = applications.update_app_record(event, s3_client, s3_resource, role_credentials, connect_id)                    

            elif event['request'] == 'update-app-v2':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                s3_resource = util.get_resource('s3', role_credentials)
                connect_client = util.get_client('connect', role_credentials)
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)
                response = applications.update_app_record_v2(event, s3_client, s3_resource, role_credentials, connect_id)                    

            elif event['request'] == 'delete-app':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                response = applications.delete_app_record(event, s3_client, connect_id) 

            elif event['request'] == 'deploy-app':
                #Check if PROD/BCP
                if event['TargetEnv'] == 'PROD':
                    bcp_region = event.get('BCPRegion','')
                    if bcp_region:
                        config.region = bcp_region
                #Get Source Instance
                (account_id, source_connect_id, connect_arn, tenant_name) = util.get_instance_config(event['SourceEnv'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_source_client = util.get_client('s3', role_credentials)
                connect_source_client = util.get_client('connect', role_credentials)
                source_instance_details = util.get_connect_instance_details(connect_source_client, source_connect_id)
                #Get Target Instance
                (account_id, target_connect_id, connect_arn, tenant_name) = util.get_instance_config(event['TargetEnv'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_target_resource = util.get_resource('s3', role_credentials)
                connect_target_client = util.get_client('connect', role_credentials)
                target_instance_details = util.get_connect_instance_details(connect_target_client, target_connect_id)

                response = applications.deploy_app(event, s3_source_client, s3_target_resource, connect_target_client, source_instance_details, target_instance_details, source_connect_id, target_connect_id)

            elif event['request'] == 'get-tenant-status':
                ou_instances_status = {}
                for ou in organizational_units:
                    ou_instance_status = instances.get_tenant_status(ou, ou.lower() + event['TenantID'])
                    print(ou + " " + str(ou_instance_status))
                    ou_instances_status[ou] = ou_instance_status
                response = ou_instances_status

            elif event['request'] == 'get-tenants':
                tenant_list = instances.get_tenants(event['Env'])
                response = tenant_list

            elif event['request'] == 'get-holidays':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                response = officehours.get_holidays(event['Env'], s3_client, event['TenantID'], event['OfficeHours'], event.get('AppID',''))

            elif event['request'] == 'get-tenant-object':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                if '-holidays.csv' in event['FileName']:
                    response = officehours.get_holidays(event['Env'], s3_client, event['TenantID'], event['AppID'])
                else:
                    response = instances.get_tenant_object(s3_client, event['FileName'], event['TenantID'], event['AppID'])                

            elif event['request'] == 'put-tenant-object':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                s3_resource = util.get_resource('s3', role_credentials)
                if '-holidays.csv' in event['FileName']:
                    response = officehours.put_holidays(s3_client, s3_resource, role_credentials, event['Content'], event['TenantID'], event['AppID'], event['Prompts'], event['Env'])
                else:
                    response = instances.put_tenant_object(s3_client, s3_resource, role_credentials, event['FileName'], event['Content'], event['TenantID'], event['AppID'], event['Prompts'], event['Env'])   

            elif event['request'] == 'get-callflow':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                response = tenants.get_callflow(s3_client, event['TenantID'], event['CallFlow'], event.get('AppID',''))                

            elif event['request'] == 'put-callflow':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                s3_resource = util.get_resource('s3', role_credentials)
                response = tenants.put_callflow(s3_client, s3_resource, role_credentials,  event['Content'], event['JsonContent'], event['TenantID'], event['CallFlow'], event.get('AppID',''), event['Prompts'])   

            elif event['request'] == 'get-office-hours':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                connect_client = util.get_client('connect', role_credentials)
                response = officehours.get_office_hours(event['Env'], s3_client, event['TenantID'], event['OfficeHours'], event.get('AppID',''))   

            elif event['request'] == 'get-business-hours':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                connect_client = util.get_client('connect', role_credentials)
                response = officehours.get_app_business_hours(s3_client, event['TenantID'], event['OfficeHours'])
                #response = officehours.get_office_hours(event['Env'], s3_client, event['TenantID'], event['AppID'])   

            elif event['request'] == 'put-business-hours':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                s3_resource = util.get_resource('s3', role_credentials)
                connect_client = util.get_client('connect', role_credentials)
                officehours.put_office_hours(event['Env'], s3_client, s3_resource, role_credentials, event['HoursConfig'], event['TenantID'], event['AppID'], event['Prompts'])

            elif event['request'] == 'put-office-hours':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                s3_resource = util.get_resource('s3', role_credentials)
                connect_client = util.get_client('connect', role_credentials)
                officehours.put_office_hours(event['Env'], s3_client, s3_resource, role_credentials, event['HoursConfig'], event['TenantID'], event['OfficeHours'], event.get('AppID', ''), event['Prompts'])

            elif event['request'] == 'put-holidays':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                s3_resource = util.get_resource('s3', role_credentials)
                response = officehours.put_holidays(s3_client, s3_resource, role_credentials, event['Content'], event['TenantID'], event['OfficeHours'], event.get('AppID', ''), event['Prompts'], event['Env'])

            elif event['request'] == 'list-office-hours':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                response = officehours.list_office_hours(s3_client, connect_id)   

            elif event['request'] == 'delete-office-hours':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                response = officehours.delete_office_hours(s3_client, event['OfficeHours']) 

            elif event['request'] == 'delete-callflow':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                response = tenants.delete_office_hours(s3_client, event['CallFlow']) 

            #elif event['request'] == 'put-office-hours':
            #    (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
            #    role_credentials = util.assume_role(account_id)
            #    s3_client = util.get_client('s3', role_credentials)
            #    s3_resource = util.get_resource('s3', role_credentials)
            #    connect_client = util.get_client('connect', role_credentials)
            #    officehours.put_office_hours(event['Env'], s3_client, s3_resource, role_credentials, event['HoursConfig'], event['TenantID'], event['AppID'], event['Prompts'])

            elif event['request'] == 'list-contact-flows':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = util.get_client('connect', role_credentials)
                response = tenants.list_contact_flows(connect_client, connect_id)

            elif event['request'] == 'list-contact-flow-modules':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = util.get_client('connect', role_credentials)
                response = tenants.list_contact_flow_modules(connect_client, connect_id)

            elif event['request'] == 'get-tenant-apps':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                connect_client = util.get_client('connect', role_credentials)
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)                                    
                response = applications.get_tenant_apps(s3_client, event['Env'], event['TenantID'], connect_id)
                
            elif event['request'] == 'get-tenant-apps-v2':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                connect_client = util.get_client('connect', role_credentials)
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)                                    
                response = applications.get_tenant_apps_v2(s3_client, event['Env'], event['TenantID'], connect_id)
                
            elif event['request'] == 'list-menu-actions':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                connect_client = util.get_client('connect', role_credentials)
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)
                response = applications.list_menu_actions(s3_client, connect_client, connect_id, connect_instance_details, event['Env'], event['TenantID'], event['AppID'])

            elif event['request'] == 'get-translation':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                response = util.translate_text(event.get('Message'), event.get('SourceLanguage','en-US'), event.get('TargetLanguage','en-US'))
            
            elif event['request'] == 'list-callflows':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                response = util.get_callflows(s3_client, connect_id)

            elif event['request'] == 'get-contactflows':
                contact_flow_list = []
                for contact_flow in config.contact_flows:
                    contact_flow_list.append(contact_flow.replace('ContactFlows/',''))                
                response = contact_flow_list

            elif event['request'] == 'get-config-files':
                response = config.config_files

            elif event['request'] == 'get-queues':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = util.get_client('connect', role_credentials)
                response = util.get_queues(connect_client, connect_id) 

            elif event['request'] == 'list-available-phone-numbers':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = util.get_client('connect', role_credentials)
                response = phonenumbers.list_available_phone_numbers(connect_client, connect_id, event['Env'], event['TenantID']) 

            elif event['request'] == 'list-phone-numbers':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = util.get_client('connect', role_credentials)
                response = phonenumbers.list_phone_numbers(connect_client, connect_id) 

            elif event['request'] == 'get-phone-number':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = util.get_client('connect', role_credentials)
                response = phonenumbers.get_phone_number(connect_client, connect_arn, event['TenantID'], event['Country'], event['Type']) 

            elif event['request'] == 'release-phone-number':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = util.get_client('connect', role_credentials)
                response = phonenumbers.release_phone_number(connect_client, event['PhoneId'])

            elif event['request'] == 'release-phone-number':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = util.get_client('connect', role_credentials)
                response = phonenumbers.update_phone_number(connect_client, connect_arn, event['TenantID'], event['Country'], event['Type'], event['PreviousID']) 

            elif event['request'] == 'delete-queue':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = util.get_client('connect', role_credentials)
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)
                queues_to_delete = [event['QueueName']]
                response = queues.delete_queues(event, connect_client, connect_instance_details, queues_to_delete)
                queue_data = util.get_queue_data(event['Env'], event['TenantID'])

                del queue_data[event['QueueName']]

                queues.write_queue_data(event['TenantID'], event['Env'], queue_data)

            elif event['request'] == 'create-queues':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                connect_client = util.get_client('connect', role_credentials)
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)

                queues.create_queues(event['Env'], event['TenantID'], s3_client, connect_instance_details, connect_client, connect_id, event['Queues'])

            elif event['request'] == 'manual-delete-queue':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = util.get_client('connect', role_credentials)
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)
                #queues_to_delete = json.loads('["' + event['QueueName'] + '_"]')
                response = queues.manual_delete_queue(connect_client, connect_id, event['QueueName']) 

            elif event['request'] == 'list-queue-configs':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                connect_client = util.get_client('connect', role_credentials)
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)
                response = queues.list_queue_configs(connect_client, connect_id, s3_client, connect_instance_details, event['Env'], event['TenantID'])

            elif event['request'] == 'list-queue-configs-v2':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                connect_client = util.get_client('connect', role_credentials)
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)
                response = queues.list_queue_configs_v2(connect_client, connect_id, s3_client, connect_instance_details, event['Env'], event['TenantID'])

            elif event['request'] == 'update-tts':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                s3_resource = util.get_resource('s3', role_credentials)
                response = tenants.update_tts(s3_client, s3_resource, event['TenantID'], event['AppID'], event['PromptKey'], event['Prompts'])

            elif event['request'] == 'read-tts':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                response = tenants.read_tts(s3_client, event['TenantID'], event['AppID'], event['PromptKeys'])

            elif event['request'] == 'get-voices':
                try:
                    tenant_id = event['TenantID']
                except:
                    tenant_id = ""
                response = tenants.get_voices(event['Env'], tenant_id)

            elif event['request'] == 'set-voices':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = util.get_client('connect', role_credentials)
                response = tenants.set_voices(connect_client, connect_id, event['Env'], event['TenantID'], event['ActiveVoices'])

            elif event['request'] == 'list-objects':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)

                if "Language" in event:                
                    response = tenants.list_objects(s3_client, connect_id, event['TenantID'], event['AppID'], event['ObjectType'], event['Language'])
                else:
                    response = tenants.list_objects(s3_client, connect_id, event['TenantID'], event['AppID'], event['ObjectType'], "")

            elif event['request'] == 'get-binary-object':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_resource = util.get_resource('s3', role_credentials)
                response = tenants.get_binary_object(s3_resource, connect_id, event['TenantID'], event['AppID'], event['ObjectType'], event['Filename'], event['Language'])

            elif event['request'] == 'put-binary-object':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_resource = util.get_resource('s3', role_credentials)
                response = tenants.put_binary_object(s3_resource, connect_id, event['TenantID'], event['AppID'], event['ObjectType'], event['Filename'], event['Language'], event['Content'])

            elif event['request'] == 'delete-object':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = util.get_client('s3', role_credentials)
                if "Language" in event:
                    response = tenants.delete_object(s3_client, connect_id, event['TenantID'], event['AppID'], event['ObjectType'], event['Filename'], event['Language'])
                else:
                    response = tenants.delete_object(s3_client, connect_id, event['TenantID'], event['AppID'], event['ObjectType'], event['Filename'], "")

            elif event['request'] == 'get-users':
                response = users.get_users(event['Env'], event['TenantID'])

            elif event['request'] == 'get-languages':
                response, _ = instances.get_languages(event['Env'], event['TenantID'])

            elif event['request'] == 'get-tenant-queues':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = util.get_client('connect', role_credentials)
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)                
                response = queues.get_tenant_queues(event['TenantID'], connect_instance_details['QueueSummaryList'])

            elif event['request'] == 'get-roles':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = util.get_client('connect', role_credentials)
                response = users.get_roles(connect_client, connect_id)

            elif event['request'] == 'get-group-hierarchy':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = util.get_client('connect', role_credentials)
                response = users.get_group_hierarchy(connect_client, connect_id)

            elif event['request'] == 'create-user':
                password = event.get('Password','')
                response = users.create_user(event['Env'], event['TenantID'], event['Email'], event['FirstName'], event['LastName'], event['Languages'], event['Role'], event['Priority'], password)

            elif event['request'] == 'update-user':
                password = event.get('Password','')
                response = users.update_user(event['Env'], event['TenantID'], event['Email'], event['FirstName'], event['LastName'], event['Languages'], event['Role'], event['Priority'], password)

            elif event['request'] == 'delete-user':
                response = users.delete_user(event['Env'], event['Email'])
            
            elif event['request'] == 'load-users':
                response = users.load_users(event['Env'], event['tenantID'], event['Contents'])

            elif event['request'] == 'synthesize-speech':
                response = tenants.synthesize_speech(event['Language'], event['Voice'], event['Text'])

            elif event['request'] =='get-connect-users':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = util.get_client('connect', role_credentials)
                response = users.get_connect_users(connect_client, connect_id)

            elif event['request'] =='get-quick-connects':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = util.get_client('connect', role_credentials)
                response = users.get_quick_connects(connect_client, connect_id)

            elif event['request'] =='create-user-quick-connects':
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = util.get_client('connect', role_credentials)
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)
                response = users.create_user_quick_connects(connect_client, connect_id, connect_instance_details)

            elif event['request'] == 'tail-logs':
                log_client = boto3.client('logs')
                log_group_name = '/aws/lambda/Ignite-RDF'
                log_stream_prefix = None
                response = cloudwatch.tail_logs(log_client, log_group_name, log_stream_prefix)

            elif event['request'] == 'tail-log':
                log_client = boto3.client('logs')
                log_group_name = '/aws/lambda/Ignite-RDF'
                response = cloudwatch.tail_log(log_client, log_group_name, event['TimeStamp'], event['DNIS'])

            else:
                logger.info("INVALID REQUEST")

        elif event_source == 'aws:dynamodb':
            table = event['Records'][0]['eventSourceARN'].split(':')[5].split('/')[1]
            ou = table[table.find('-')+1:]
            event_type =  event['Records'][0]['eventName']

            if 'Instances' in table:
                update_required = False
                app_id = event['Records'][0]['dynamodb']['Keys']['Tenant']['S']
                tenant_id = app_id[0:app_id.find('-')]                
                if event_type == 'INSERT':
                    instances.create_tenant_instance(event, ou)
                if event_type == 'MODIFY':
                    old_image_voices = json.loads(event['Records'][0]['dynamodb']['OldImage']['ActiveVoices']['S'])
                    new_image_voices = json.loads(event['Records'][0]['dynamodb']['NewImage']['ActiveVoices']['S'])
                    old_languages = []
                    new_languages = []
                    for voice_index in old_image_voices:
                        old_languages.append(old_image_voices[voice_index]['Language'])
                    for voice_index in new_image_voices:
                        new_languages.append(new_image_voices[voice_index]['Language'])

                    if len(old_image_voices) == len(new_image_voices):
                        for old_lang in old_languages:
                            if old_lang not in new_languages:
                                update_required = True
                        for new_lang in new_languages:
                            if new_lang not in old_languages:
                                update_required = True
                    else:
                        update_required = True

                    if update_required:

                        dynamodb_client = boto3.client('dynamodb')
                           
                        arn = event['Records'][0]['eventSourceARN']
                        event['Env'] = arn[arn.find("Instances-")+10:arn.find("/stream")]
                        tenant_name = event['Records'][0]['dynamodb']['OldImage']['Tenant']['S']
                        event['TenantID'] = tenant_name[tenant_name.find("-")+1:]
                        
                        (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(event['Env'] , event['TenantID'])
                        role_credentials = util.assume_role(account_id)
                        s3_client = util.get_client('s3', role_credentials)
                        s3_resource = util.get_resource('s3', role_credentials)
                        connect_client = util.get_client('connect', role_credentials)
                        connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)
                        
                        try:
                            get_apps_response = dynamodb_client.scan(
                                TableName='Tenants-' + event['Env']
                            )

                            for app_record in get_apps_response['Items']:
                                if event['TenantID'] in app_record['Tenant']['S']:
                                    event['AppID'] = app_record['Tenant']['S'][app_record['Tenant']['S'].find('-')+1:]
                                    event['DNIS'] = app_record['DNIS']['S']
                                    event['Description'] = app_record['Description']['S']
                                    event['PreviousLanguage'] = app_record['Language']['S']
                                    #event['Greeting'] = app_record['Greeting']['S']
                                    #event['CallFlow'] = app_record['CallFlow']['S']
                                    #event['Queues'] = app_record['Queues']['S']
                                    event['flowControl'] = app_record['FlowControl']['S']
                                    #event['BusinessHours'] = app_record['BusinessHours']['S']
                                    #event['Holidays'] = app_record['Holidays']['S']
                                    prompts = tenants.read_tts(s3_client, event['TenantID'], event['AppID'], config.default_prompts)
                                    active_voices = json.loads(event['Records'][0]['dynamodb']['NewImage']['ActiveVoices']['S'])
                                    new_prompts = {}

                                    translate_language = json.loads(event['PreviousLanguage'])[0]                                        
                                    for prompt in prompts:
                                        new_prompts[prompt] = {}
                                        for language_index in active_voices:
                                            if active_voices[language_index]['Language'] == translate_language:
                                                new_prompts[prompt][active_voices[language_index]['Language']] = prompts[prompt][translate_language]
                                            else:
                                                new_prompts[prompt][active_voices[language_index]['Language']] = util.translate_text(prompts[prompt][translate_language], translate_language, active_voices[language_index]['Language'])
    
                                    event['Prompts'] = new_prompts
                                    new_language = []
                                    active_voices = json.loads(event['Records'][0]['dynamodb']['NewImage']['ActiveVoices']['S'])
                                    for active_lang in active_voices:
                                        new_language.append(active_voices[active_lang]['Language'])
                                    event['Language'] = json.dumps(new_language)

                                    applications.update_app_record(event, s3_client, s3_resource, role_credentials, connect_id)

                                    s3_response = s3_client.get_object(Bucket=instances.get_tenant_bucket(s3_client), Key= f"{event['TenantID']}-{event['AppID']}/config/{event['AppID']}-menutree.csv")
                                    instances.put_tenant_object(s3_client, s3_resource, role_credentials, f"{event['AppID']}-menutree.csv", s3_response['Body'], event['TenantID'], event['AppID'], {}, event['Env'])

                        except Exception as ex1:
                            logger.info('get apps EXCEPTION: ' + str(ex1))
                            logger.info('TRACEBACK MESSAGE: ' + traceback.format_exc())

            else: #'Users'
                if event_type == 'REMOVE':
                    old_image = event['Records'][0]['dynamodb']['OldImage']
                    tenant_id = old_image['Tenant']['S']
                else:
                    new_image = event['Records'][0]['dynamodb']['NewImage']
                    tenant_id = new_image['Tenant']['S']                    
                (account_id, connect_id, connect_arn, tenant_name) = util.get_instance_config(ou, tenant_id)
                role_credentials = util.assume_role(account_id)
                connect_client = util.get_client('connect', role_credentials)
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)

                if event_type == 'REMOVE':
                    users.remove_user_record(event, connect_client, connect_instance_details, ou, event_type)

                if event_type == 'MODIFY':
                    #oldImage = event['Records'][0]['dynamodb']['OldImage']
                    #newImage = event['Records'][0]['dynamodb']['NewImage']
                    #if newImage != oldImage:
                    #    (routing_profile_id, hierarchy_group_id) = users.remove_user_record(event, connect_client, connect_instance_details, ou, event_type)
                    #    users.insert_user_record(event, connect_client, connect_instance_details, ou, routing_profile_id, hierarchy_group_id, event_type)
                    users.update_user_record(event, connect_client, connect_id, connect_instance_details, ou)
                    
                if event_type == 'INSERT':
                    users.insert_user_record(event, connect_client, connect_id, connect_instance_details, ou, '', '', event_type)

        else: #'aws:s3'
            config.s3_bucket_name = event['Records'][0]['s3']['bucket']['name']
            s3_filename = event['Records'][0]['s3']['object']['key']

            #This was used for the initial load only
            if s3_filename == 'init/tenants.csv':
                tenants.load_tenants_from_S3(s3_filename)
            if s3_filename == 'init/users.csv':
                users.load_users_from_S3(s3_filename)

    except Exception as ex1:
        status_code = 500
        response = str(ex1)
        print('#####   EXCEPTION FOUND: ' + str(ex1) + '   #####')
        print('#####   TRACEBACK MESSAGE: ' + traceback.format_exc() + '   #####')
    
    return {
        'statusCode': status_code,
        'body': response
    }
