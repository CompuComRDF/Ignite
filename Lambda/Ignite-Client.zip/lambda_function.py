import json
import boto3
import traceback
import users
import tenants
import util
import config
import instances

def lambda_handler(event, context):
    util.logger(event)
    status_code = 200
    response = {}
    #print("boto3 version:" + boto3.__version__)
    try:
        event_source = event['Records'][0]['eventSource'] #S3 Event = aws:s3 | DynamoDB Event = aws:dynamodb
        config.region = event['Records'][0]['awsRegion'] 
    except:
        event_source = 'aws:lambda'
        try:
            config.region = event['Region']
        except:
            config.region = ''

    try:
        if event_source == 'aws:lambda':
            #FOR TESTING PURPOSES, USE THE FOLLOWING TO TEST FROM AWS CLI:
            #aws lambda invoke --function-name Ignite-Client --profile demo --invocation-type Event --cli-binary-format raw-in-base64-out --payload '{"request":"create-tenant","TenantID":"abc","InstanceType":"SAML","EmailDomain":"ps.compucom.com","Region":"ca-central-1"}' response.json
            organizational_units = ['DEV', 'UAT', 'PROD']

            if event['request'] == 'create-tenant':
                for ou in organizational_units:
                    try:
                        active_voices = event['ActiveVoices']
                    except:
                        active_voices = config.active_voices
                    instances.insert_instance_record(ou, event['TenantID'], event['InstanceType'], event['EmailDomain'], active_voices)

            elif event['request'] == 'update-tenant':
                for ou in organizational_units:
                    (account_id, connect_id, connect_arn) = util.get_instance_config(ou, event['TenantID'])
                    role_credentials = util.assume_role(account_id)
                    connect_client = boto3.client('connect', region_name=config.region,
                        aws_access_key_id=role_credentials['KEY_ID'],
                        aws_secret_access_key=role_credentials['ACCESS_KEY'],
                        aws_session_token=role_credentials['TOKEN'])
                    #connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)                                          
                    instances.update_instance_record(role_credentials, connect_arn, account_id, connect_id, ou, event['TenantID'], event['ContactFlows'], event['ConfigFiles'])

            #aws lambda invoke --function-name Ignite-Client --profile demo --invocation-type Event --cli-binary-format raw-in-base64-out --payload '{"request":"create-app","TenantID":"abc", "AppID":"Main","Language":"_En_Fr","TenantName":"ABC","Greeting":"Thanks for calling ABC company.","CallFlow":"","Queues":"", "Region":"ca-central-1"}' response.json
            elif event['request'] == 'create-app':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = boto3.client('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                s3_resource = boto3.resource('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)                    
                response = tenants.insert_app_record(event, s3_client, s3_resource, connect_client, role_credentials, connect_id, connect_instance_details)

            elif event['request'] == 'update-app':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = boto3.client('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                s3_resource = boto3.resource('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)
                response = tenants.update_app_record(event, s3_client, s3_resource, connect_client, connect_instance_details, role_credentials)                    

            elif event['request'] == 'delete-app':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)

                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)
                response = tenants.delete_app_record(event, connect_client, role_credentials, connect_id, connect_instance_details) 

            elif event['request'] == 'deploy-app':
                (account_id, source_connect_id, connect_arn) = util.get_instance_config(event['SourceEnv'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_source_client = boto3.client('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                connect_source_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])

                if event['TargetEnv'] == 'PROD':
                    bcp_region = ''
                    try:
                        bcp_region = event['BCPRegion']
                        if bcp_region:
                            config.region = bcp_region
                    except:
                        pass

                (account_id, target_connect_id, connect_arn) = util.get_instance_config(event['TargetEnv'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_target_client = boto3.resource('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                s3_target_resource= boto3.resource('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                connect_target_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                                
                connect_instance_details = util.get_connect_instance_details(connect_target_client, target_connect_id)
                response = tenants.deploy_app(event['SourceEnv'], event['TargetEnv'], event['TenantID'], event['AppID'], event['DNIS'], role_credentials, s3_source_client, s3_target_client, s3_target_resource, connect_source_client, connect_target_client, connect_instance_details, source_connect_id, target_connect_id, event['DeployTenant'], event['DeployUsers'])

            elif event['request'] == 'get-tenant-status':
                ou_instances_status = {}
                for ou in organizational_units:
                    ou_instance_status = instances.get_tenant_status(ou, ou.lower() + event['TenantID'])
                    print(ou + " " + str(ou_instance_status))
                    ou_instances_status[ou] = ou_instance_status
                response = ou_instances_status

            elif event['request'] == 'get-tenants':
                tenant_list = instances.get_tenants(event['Env'])
                response = tenant_list

            elif event['request'] == 'get-tenant-object':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = boto3.client('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                response = instances.get_tenant_object(s3_client, event['FileName'], event['TenantID'], event['AppID'])                

            elif event['request'] == 'put-tenant-object':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = boto3.client('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])  
                s3_resource = boto3.resource('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                
                response = instances.put_tenant_object(s3_client, s3_resource, role_credentials, event['FileName'], event['Content'], event['TenantID'], event['AppID'], event['Prompts'], event['Env'])   

            elif event['request'] == 'get-business-hours':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                s3_client = boto3.client('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                                   
                response = tenants.get_business_hours(s3_client, connect_client, connect_id, event['TenantID'], event['AppID'])   

            elif event['request'] == 'put-business-hours':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])

                role_credentials = util.assume_role(account_id)
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                  
                s3_client = boto3.client('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                s3_resource = boto3.resource('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                          
                response = tenants.put_business_hours(s3_client, s3_resource, role_credentials, connect_client, connect_id, event['HoursConfig'], event['TenantID'], event['AppID'], event['Prompts'])
                
            elif event['request'] == 'get-tenant-apps':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = boto3.client('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                
                response = tenants.get_tenant_apps(s3_client, event['Env'], event['TenantID'])
                
            elif event['request'] == 'get-translation':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                response = util.translate_text(event['Message'], event['SourceLanguage'], event['TargetLanguage'])
            
            elif event['request'] == 'get-callflows':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = boto3.client('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN']) 
                response = util.get_callflows(s3_client, event['TenantID'], event['AppID'])

            elif event['request'] == 'get-queues':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                  
                response = util.get_queues(connect_client, connect_id) 

            elif event['request'] == 'list-phone-numbers':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                  
                response = tenants.list_phone_numbers(connect_client, connect_arn, connect_id, event['Env'], event['TenantID']) 

            elif event['request'] == 'get-phone-number':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                  
                response = tenants.get_phone_number(connect_client, connect_arn, event['TenantID'], event['Country'], event['Type']) 

            elif event['request'] == 'update-phone-number':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                  
                response = tenants.update_phone_number(connect_client, connect_arn, event['TenantID'], event['Country'], event['Type'], event['PreviousID']) 

            elif event['request'] == 'delete-queue':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                  
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)
                queues_to_delete = json.loads('["' + event['QueueName'] + '"]')
                response = tenants.delete_queues(event, connect_client, connect_instance_details, queues_to_delete, event['Language'].replace(" ", ""), event['Language'].replace(" ", ""))

            elif event['request'] == 'manual-delete-queue':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                  
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)
                #queues_to_delete = json.loads('["' + event['QueueName'] + '_"]')
                response = tenants.manual_delete_queue(connect_client, connect_id, event['QueueName']) 

            elif event['request'] == 'update-tts':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = boto3.client('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                s3_resource = boto3.resource('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                     
                response = tenants.update_tts(s3_client, s3_resource, event['TenantID'], event['AppID'], event['PromptKey'], event['Prompts'])

            elif event['request'] == 'read-tts':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = boto3.client('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                response = tenants.read_tts(s3_client, event['TenantID'], event['AppID'], event['PromptKeys'])

            elif event['request'] == 'get-voices':
                try:
                    tenant_id = event['TenantID']
                except:
                    tenant_id = ""
                response = tenants.get_voices(event['Env'], tenant_id)

            elif event['request'] == 'set-voices':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                #try:
                #    default_voices = event['DefaultVoices']
                #except:
                #    default_voices = config.default_voices
                response = tenants.set_voices(connect_client, connect_id, event['Env'], event['TenantID'], event['ActiveVoices'])

            elif event['request'] == 'list-objects':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = boto3.client('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])

                if "Language" in event:                
                    response = tenants.list_objects(s3_client, connect_id, event['TenantID'], event['AppID'], event['ObjectType'], event['Language'])
                else:
                    response = tenants.list_objects(s3_client, connect_id, event['TenantID'], event['AppID'], event['ObjectType'], "")

            elif event['request'] == 'get-binary-object':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_resource = boto3.resource('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])   
                response = tenants.get_binary_object(s3_resource, connect_id, event['TenantID'], event['AppID'], event['ObjectType'], event['Filename'], event['Language'])

            elif event['request'] == 'put-binary-object':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_resource = boto3.resource('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])   
                response = tenants.put_binary_object(s3_resource, connect_id, event['TenantID'], event['AppID'], event['ObjectType'], event['Filename'], event['Language'], event['Content'])

            elif event['request'] == 'delete-object':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                s3_client = boto3.client('s3', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])   
                if "Language" in event:
                    response = tenants.delete_object(s3_client, connect_id, event['TenantID'], event['AppID'], event['ObjectType'], event['Filename'], event['Language'])
                else:
                    response = tenants.delete_object(s3_client, connect_id, event['TenantID'], event['AppID'], event['ObjectType'], event['Filename'], "")

            elif event['request'] == 'get-users':
                response = users.get_users(event['Env'], event['TenantID'])

            elif event['request'] == 'get-languages':
                response = instances.get_languages(event['Env'], event['TenantID'])

            elif event['request'] == 'get-tenant-queues':
                response = tenants.get_tenant_queues(event['Env'], event['TenantID'])

            elif event['request'] == 'get-roles':
                (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'], event['TenantID'])
                role_credentials = util.assume_role(account_id)
                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])                   
                response = users.get_roles(connect_client, connect_id)

            elif event['request'] == 'create-user':
                try:
                    password = event['Password']
                except:
                    password = ""
                response = users.create_user(event['Env'], event['TenantID'], event['Email'], event['FirstName'], event['LastName'], event['Languages'], event['Role'], event['Priority'], password)

            elif event['request'] == 'update-user':
                try:
                    password = event['Password']
                except:
                    password = ""
                response = users.update_user(event['Env'], event['TenantID'], event['Email'], event['FirstName'], event['LastName'], event['Languages'], event['Role'], event['Priority'], password)

            elif event['request'] == 'delete-user':
                response = users.delete_user(event['Env'], event['Email'])
            
            elif event['request'] == 'load-users':
                response = users.load_users(event['Env'], event['tenantID'], event['Contents'])

            elif event['request'] == 'synthesize-speech':
                response = tenants.synthesize_speech(event['Language'], event['Voice'], event['Text'])

            else:
                util.logger("INVALID REQUEST")

        elif event_source == 'aws:dynamodb':
            table = event['Records'][0]['eventSourceARN'].split(':')[5].split('/')[1]
            ou = table[table.find('-')+1:]
            #app_id = event['Records'][0]['dynamodb']['Keys']['Tenant']['S']
            #tenant_id = app_id[0:app_id.find('-')]
            event_type =  event['Records'][0]['eventName']

            if 'Instances' in table:
                update_required = False
                app_id = event['Records'][0]['dynamodb']['Keys']['Tenant']['S']
                tenant_id = app_id[0:app_id.find('-')]                
                if event_type == 'INSERT':
                    instances.create_tenant_instance(event, ou)
                if event_type == 'MODIFY':
                    old_image_voices = json.loads(event['Records'][0]['dynamodb']['OldImage']['ActiveVoices']['S'])
                    new_image_voices = json.loads(event['Records'][0]['dynamodb']['NewImage']['ActiveVoices']['S'])
                    old_languages = []
                    new_languages = []
                    for voice_index in old_image_voices:
                        old_languages.append(old_image_voices[voice_index]['Language'])
                    for voice_index in new_image_voices:
                        new_languages.append(new_image_voices[voice_index]['Language'])

                    if len(old_image_voices) == len(new_image_voices):
                        for old_lang in old_languages:
                            if old_lang not in new_languages:
                                update_required = True
                        for new_lang in new_languages:
                            if new_lang not in old_languages:
                                update_required = True
                    else:
                        update_required = True

                    if update_required:

                        dynamodb_client = boto3.client('dynamodb')
                           
                        arn = event['Records'][0]['eventSourceARN']
                        event['Env'] = arn[arn.find("Instances-")+10:arn.find("/stream")]
                        tenant_name = event['Records'][0]['dynamodb']['OldImage']['Tenant']['S']
                        event['TenantID'] = tenant_name[tenant_name.find("-")+1:]
                        
                        (account_id, connect_id, connect_arn) = util.get_instance_config(event['Env'] , event['TenantID'])
                        role_credentials = util.assume_role(account_id)

                        connect_client = boto3.client('connect', region_name=config.region,
                            aws_access_key_id=role_credentials['KEY_ID'],
                            aws_secret_access_key=role_credentials['ACCESS_KEY'],
                            aws_session_token=role_credentials['TOKEN'])
                        connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)
                        s3_client = boto3.client('s3', region_name=config.region,
                            aws_access_key_id=role_credentials['KEY_ID'],
                            aws_secret_access_key=role_credentials['ACCESS_KEY'],
                            aws_session_token=role_credentials['TOKEN'])
                        s3_resource = boto3.resource('s3', region_name=config.region,
                            aws_access_key_id=role_credentials['KEY_ID'],
                            aws_secret_access_key=role_credentials['ACCESS_KEY'],
                            aws_session_token=role_credentials['TOKEN'])    
                        
                        try:
                            get_apps_response = dynamodb_client.scan(
                                TableName='Tenants-' + event['Env']
                            )
                            #util.logger("DB RESPONSE: " + str(get_apps_response))

                            for app_record in get_apps_response['Items']:
                                if event['TenantID'] in app_record['Tenant']['S']:
                                    event['AppID'] = app_record['Tenant']['S'][app_record['Tenant']['S'].find('-')+1:]
                                    event['DNIS'] = app_record['DNIS']['S']
                                    event['Description'] = app_record['Description']['S']
                                    event['PreviousLanguage'] = app_record['Language']['S']
                                    event['Greeting'] = app_record['Greeting']['S']
                                    event['CallFlow'] = app_record['CallFlow']['S']
                                    event['Queues'] = app_record['Queues']['S']
                                    event['flowControl'] = app_record['FlowControl']['S']
                                    event['BusinessHours'] = app_record['BusinessHours']['S']
                                    event['Holidays'] = app_record['Holidays']['S']
                                    #util.logger("TenantID = " + event['TenantID'] + " AppID = " + event['AppID'])
                                    prompts = tenants.read_tts(s3_client, event['TenantID'], event['AppID'], config.default_prompts)
                                    active_voices = json.loads(event['Records'][0]['dynamodb']['NewImage']['ActiveVoices']['S'])
                                    new_prompts = {}
                                    #default_language = active_voices["1"]['Language']

                                    translate_language = json.loads(event['PreviousLanguage'])[0]                                        
                                    for prompt in prompts:
                                        new_prompts[prompt] = {}
                                        for language_index in active_voices:
                                            if active_voices[language_index]['Language'] == translate_language:
                                                new_prompts[prompt][active_voices[language_index]['Language']] = prompts[prompt][translate_language]
                                            else:
                                                new_prompts[prompt][active_voices[language_index]['Language']] = util.translate_text(prompts[prompt][translate_language], translate_language, active_voices[language_index]['Language'])
    
                                    event['Prompts'] = new_prompts
                                    new_language = []
                                    active_voices = json.loads(event['Records'][0]['dynamodb']['NewImage']['ActiveVoices']['S'])
                                    for active_lang in active_voices:
                                        new_language.append(active_voices[active_lang]['Language'])
                                    event['Language'] = json.dumps(new_language)

                                    tenants.update_app_record(event, s3_client, s3_resource, connect_client, connect_instance_details, role_credentials)

                                    #menu_tree_found = False
                                    #flow_control = json.loads(event['flowControl'])
                                    #for item in flow_control:
                                    #    if flow_control[item] == 'MenuTree':
                                    #        menu_tree_found = True
                                    
                                    #if menu_tree_found:
                                    s3_response = s3_client.get_object(Bucket=instances.get_tenant_bucket(s3_client), Key= event['TenantID'] + "-" + event['AppID'] + "/config/ivr-menutree.csv")
                                    instances.put_tenant_object(s3_client, s3_resource, role_credentials, 'ivr-menutree.csv', s3_response['Body'], event['TenantID'], event['AppID'], {}, event['Env'])

                        except Exception as ex1:
                            util.logger('get apps EXCEPTION: ' + str(ex1))
                            util.logger('TRACEBACK MESSAGE: ' + traceback.format_exc())

            elif 'Users' in table:
                if event_type == 'REMOVE':
                    old_image = event['Records'][0]['dynamodb']['OldImage']
                    tenant_id = old_image['Tenant']['S']
                else:
                    new_image = event['Records'][0]['dynamodb']['NewImage']
                    tenant_id = new_image['Tenant']['S']                    
                (account_id, connect_id, connect_arn) = util.get_instance_config(ou, tenant_id)
                role_credentials = util.assume_role(account_id)

                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                
                connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)
                #config.s3_bucket_name = 'amazon-connect-' + connect_instance_details['instanceID']
                #Check Event Operation Type
                if event_type == 'REMOVE':
                    users.remove_user_record(event, connect_client, connect_instance_details, ou, event_type)
                
                if event_type == 'MODIFY':
                    oldImage = event['Records'][0]['dynamodb']['OldImage']
                    newImage = event['Records'][0]['dynamodb']['NewImage']
                    if newImage != oldImage:
                        users.remove_user_record(event, connect_client, connect_instance_details, ou, event_type)
                        users.insert_user_record(event, connect_client, connect_instance_details, ou)
                    
                if event_type == 'INSERT':
                    users.insert_user_record(event, connect_client, connect_instance_details, ou)
    
            else: #'Tenants'
                (account_id, connect_id, connect_arn) = util.get_instance_config(ou, tenant_id)
                role_credentials = util.assume_role(account_id)

                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])

                #config.s3_bucket_name = 'amazon-connect-' + connect_instance_details['instanceID']
                if event_type == 'REMOVE':
                    connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)
                    tenants.remove_connect_tenant(ou, event, connect_client, connect_instance_details)
    
                if event_type == 'INSERT':
                    connect_instance_details = util.get_connect_instance_details(connect_client, connect_id)
                    tenants.create_connect_tenant(ou, event, connect_client, connect_instance_details)

        else: #'aws:s3'
            config.s3_bucket_name = event['Records'][0]['s3']['bucket']['name']
            s3_filename = event['Records'][0]['s3']['object']['key']

            #This was used for the initial load only
            if s3_filename == 'init/tenants.csv':
                tenants.load_tenants_from_S3(s3_filename)
            if s3_filename == 'init/users.csv':
                users.load_users_from_S3(s3_filename)

    except Exception as ex1:
        status_code = 500
        response = str(ex1)
        print('#####   EXCEPTION FOUND: ' + str(ex1) + '   #####')
        print('#####   TRACEBACK MESSAGE: ' + traceback.format_exc() + '   #####')
    
    return {
        'statusCode': status_code,
        'body': response
    }
