import json
import boto3
import traceback
import users
import tenants
import util
import config
import instances

def lambda_handler(event, context):
    print(event)
    statusCode = 200
    #print("boto3 version:" + boto3.__version__)
    try:
        eventSource = event['Records'][0]['eventSource'] #S3 Event = aws:s3 | DynamoDB Event = aws:dynamodb
        config.region = event['Records'][0]['awsRegion'] 
    except:
        eventSource = 'aws:lambda'
        config.region = event['Region']
        pass

    try:
        if eventSource == 'aws:lambda':
            #FOR TESTING PURPOSES, USE THE FOLLOWING TO TEST FROM AWS CLI:
            #aws lambda invoke --function-name Ignite-Client --profile demo --invocation-type Event --cli-binary-format raw-in-base64-out --payload {\"request\":\"create-tenant\",\"TenantID\":\"test1\",\"InstanceType\":\"SAML\",\"EmailDomain\":\"ps.compucom.com\"} response.json

            if event['request'] == 'create-tenant':
                organizational_units = ['DEV', 'UAT', 'PROD']

                for ou in organizational_units:
                    instances.insert_instance_record(ou, event['TenantID'], event['InstanceType'], event['EmailDomain'])
                    #instances.createTenantInstance(event)
            else:
                util.logger("INVALID REQUEST")

        elif eventSource == 'aws:dynamodb':
            account = event['Records'][0]['eventSourceARN'].split(':')[4]
            table = event['Records'][0]['eventSourceARN'].split(':')[5].split('/')[1]
            eventType =  event['Records'][0]['eventName']

            if 'Instances' in table:
                if eventType == 'INSERT':
                    ou = table[table.find('-')+1:]
                    instances.createTenantInstance(event, ou)

            elif 'Users' in table:
                connectClient = boto3.client('connect', region_name=config.region)
                connectInstanceDetails = util.getConnectInstanceDetails(connectClient)
                config.s3BucketName = 'amazon-connect-' + connectInstanceDetails['instanceID']
                #Check Event Operation Type
                if eventType == 'REMOVE':
                    users.removeUserRecord(event, connectClient, connectInstanceDetails)
                
                if eventType == 'MODIFY':
                    oldImage = event['Records'][0]['dynamodb']['OldImage']
                    newImage = event['Records'][0]['dynamodb']['NewImage']
                    if newImage != oldImage:
                        users.removeuserRecord(event, connectClient, connectInstanceDetails)
                        users.insertUserRecord(event, connectClient, connectInstanceDetails)
                    
                if eventType == 'INSERT':
                    users.insertAgentRecord(event, connectClient, connectInstanceDetails)
    
            else: #'Tenants'
                if eventType == 'REMOVE':
                    tenants.removeTenantRecord(event, connectClient, connectInstanceDetails)
    
                if eventType == 'INSERT':
                    tenants.insertTenantRecord(event, connectClient, connectInstanceDetails)

        else: #'aws:s3'
            config.s3BucketName = event['Records'][0]['s3']['bucket']['name']
            s3FileName = event['Records'][0]['s3']['object']['key']

            #This was used for the initial load only
            if s3FileName == 'init/tenants.csv':
                tenants.loadTenantsfromS3(s3FileName)
            #if s3FileName == 'init/companies-twilio.csv':
            #    companies.insertTwilioDID(s3FileName)
            #if s3FileName == 'init/twilionumbers.json':
            #    companies.insertTwilioURL(s3FileName)
            if s3FileName == 'init/users.csv':
                users.loadUsersfromS3(s3FileName)

    except Exception as ex1:
        statusCode = 500
        print('#####   EXCEPTION FOUND: ' + str(ex1) + '   #####')
        print('#####   TRACEBACK MESSAGE: ' + traceback.format_exc() + '   #####')
    
    return {
        'statusCode': statusCode,
        'body': json.dumps('Success!')
    }
