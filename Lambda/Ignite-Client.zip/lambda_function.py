import json
import boto3
import traceback
import agent
import companies
import util
import config

def lambda_handler(event, context):
    print(event)
    statusCode = 200
    eventSource = event['Records'][0]['eventSource'] #S3 Event = aws:s3 | DynamoDB Event = aws:dynamodb
    region = event['Records'][0]['awsRegion'] 
    #print("boto3 version:" + boto3.__version__)

    try:    
        if eventSource == 'aws:dynamodb':
            account = event['Records'][0]['eventSourceARN'].split(':')[4]
            table = event['Records'][0]['eventSourceARN'].split(':')[5].split('/')[1]
            eventType =  event['Records'][0]['eventName']
    
            connectClient = boto3.client('connect', region_name=region)
            connectInstanceDetails = util.getConnectInstanceDetails(connectClient)
            config.s3BucketName = 'amazon-connect-' + connectInstanceDetails['instanceID']

            if table == 'Agents':
                #Check Event Operation Type
                if eventType == 'REMOVE':
                    agent.removeAgentRecord(event, connectClient, connectInstanceDetails)
                
                if eventType == 'MODIFY':
                    oldImage = event['Records'][0]['dynamodb']['OldImage']
                    newImage = event['Records'][0]['dynamodb']['NewImage']
                    if newImage != oldImage:
                        agent.removeAgentRecord(event, connectClient, connectInstanceDetails)
                        agent.insertAgentRecord(event, connectClient, connectInstanceDetails)
                    
                if eventType == 'INSERT':
                    agent.insertAgentRecord(event, connectClient, connectInstanceDetails)
    
            else: #'Companies'
                if eventType == 'REMOVE':
                    companies.removeCompanyRecord(event, connectClient, connectInstanceDetails)
    
                if eventType == 'INSERT':
                    companies.insertCompanyRecord(event, connectClient, connectInstanceDetails)

        else: #'aws:s3'
            config.s3BucketName = event['Records'][0]['s3']['bucket']['name']
            s3FileName = event['Records'][0]['s3']['object']['key']

            #This was used for the initial load only
            if s3FileName == 'init/companies.csv':
                companies.loadCompaniesfromS3(s3FileName)
            #if s3FileName == 'init/companies-twilio.csv':
            #    companies.insertTwilioDID(s3FileName)
            #if s3FileName == 'init/twilionumbers.json':
            #    companies.insertTwilioURL(s3FileName)
            if s3FileName == 'init/worker_info.csv':
                agent.loadAgentsfromS3(s3FileName)

    except Exception as ex1:
        statusCode = 500
        print('#####   EXCEPTION FOUND: ' + str(ex1) + '   #####')
        print('#####   TRACEBACK MESSAGE: ' + traceback.format_exc() + '   #####')
    
    return {
        'statusCode': statusCode,
        'body': json.dumps('Success!')
    }
