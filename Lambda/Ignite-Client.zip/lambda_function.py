import json
import boto3
import traceback
import users
import tenants
import util
import config
import instances

def lambda_handler(event, context):
    util.logger(event)
    status_code = 200
    #print("boto3 version:" + boto3.__version__)
    try:
        event_source = event['Records'][0]['eventSource'] #S3 Event = aws:s3 | DynamoDB Event = aws:dynamodb
        config.region = event['Records'][0]['awsRegion'] 
    except:
        event_source = 'aws:lambda'
        config.region = event['Region']
        pass

    try:
        if event_source == 'aws:lambda':
            #FOR TESTING PURPOSES, USE THE FOLLOWING TO TEST FROM AWS CLI:
            #aws lambda invoke --function-name Ignite-Client --profile demo --invocation-type Event --cli-binary-format raw-in-base64-out --payload {\"request\":\"create-tenant\",\"TenantID\":\"test1\",\"InstanceType\":\"SAML\",\"EmailDomain\":\"ps.compucom.com\"} response.json
            organizational_units = ['DEV']

            if event['request'] == 'create-tenant':
                for ou in organizational_units:
                    instances.insert_instance_record(ou, event['TenantID'], event['InstanceType'], event['EmailDomain'])

            elif event['request'] == 'create-app':
                for ou in organizational_units:
                    tenants.insert_app_record(ou, event['TenantID'], event['AppID'], event['Language'], event['TenantName'], event['Greeting'], event['CallFlow'], event['Queues'])
            else:
                util.logger("INVALID REQUEST")

        elif event_source == 'aws:dynamodb':
            table = event['Records'][0]['eventSourceARN'].split(':')[5].split('/')[1]
            ou = table[table.find('-')+1:]
            app_id = event['Records'][0]['dynamodb']['Keys']['Tenant']['S']
            tenant_id = app_id[0:app_id.find('-')]
            event_type =  event['Records'][0]['eventName']

            if 'Instances' in table:
                if event_type == 'INSERT':
                    instances.create_tenant_instance(event, ou)

            elif 'Users' in table:
                account_id = util.get_instance_config(ou, tenant_id)
                role_credentials = util.assume_role(account_id)

                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])
                
                connect_instance_details = util.get_connect_instance_details(event, connect_client)
                #config.s3_bucket_name = 'amazon-connect-' + connect_instance_details['instanceID']
                #Check Event Operation Type
                if event_type == 'REMOVE':
                    users.remove_user_record(event, connect_client, connect_instance_details)
                
                if event_type == 'MODIFY':
                    oldImage = event['Records'][0]['dynamodb']['OldImage']
                    newImage = event['Records'][0]['dynamodb']['NewImage']
                    if newImage != oldImage:
                        users.remove_user_record(event, connect_client, connect_instance_details)
                        users.insert_user_record(event, connect_client, connect_instance_details)
                    
                if event_type == 'INSERT':
                    users.insert_user_record(event, connect_client, connect_instance_details)
    
            else: #'Tenants'
                account_id = util.get_instance_config(ou, tenant_id)
                role_credentials = util.assume_role(account_id)

                connect_client = boto3.client('connect', region_name=config.region,
                    aws_access_key_id=role_credentials['KEY_ID'],
                    aws_secret_access_key=role_credentials['ACCESS_KEY'],
                    aws_session_token=role_credentials['TOKEN'])

                #config.s3_bucket_name = 'amazon-connect-' + connect_instance_details['instanceID']
                if event_type == 'REMOVE':
                    connect_instance_details = util.get_connect_instance_details(connect_client)
                    tenants.remove_connect_tenant(ou, event, connect_client, connect_instance_details)
    
                if event_type == 'INSERT':
                    connect_instance_details = util.get_connect_instance_details(connect_client)
                    util.init_connect_instance(event, connect_client, connect_instance_details)
                    tenants.create_connect_tenant(ou, event, connect_client, connect_instance_details, role_credentials)

        else: #'aws:s3'
            config.s3_bucket_name = event['Records'][0]['s3']['bucket']['name']
            s3_filename = event['Records'][0]['s3']['object']['key']

            #This was used for the initial load only
            if s3_filename == 'init/tenants.csv':
                tenants.load_tenants_from_S3(s3_filename)
            if s3_filename == 'init/users.csv':
                users.load_users_from_S3(s3_filename)

    except Exception as ex1:
        status_code = 500
        print('#####   EXCEPTION FOUND: ' + str(ex1) + '   #####')
        print('#####   TRACEBACK MESSAGE: ' + traceback.format_exc() + '   #####')
    
    return {
        'statusCode': status_code,
        'body': json.dumps('Success!')
    }
