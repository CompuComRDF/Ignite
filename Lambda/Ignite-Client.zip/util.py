import json
import boto3
import traceback
import csv
import config
from time import sleep

def logger(message):
    print("#####   " + message + "    #####")
    
def getConnectInstanceDetails(connectClient):
    connectInstanceDetails = {}
    
    try:
        response = connectClient.list_instances(
            MaxResults=1
        )
        connectInstanceDetails['instanceID'] = response['InstanceSummaryList'][0]['Id']
        connectInstanceDetails['instanceARN'] = response['InstanceSummaryList'][0]['Arn']
    
        connectInstanceDetails['queueList'] = connectClient.list_queues(
            InstanceId = connectInstanceDetails['instanceID'],
            QueueTypes=[
                'STANDARD'
            ],
            MaxResults=100
        )
        
        queueSummaryList = connectInstanceDetails['queueList']['QueueSummaryList']
        
        while "NextToken" in connectInstanceDetails['queueList']:
            connectInstanceDetails['queueList'] = connectClient.list_queues(
                InstanceId = connectInstanceDetails['instanceID'],
                QueueTypes=[
                    'STANDARD'
                ],
                MaxResults=100,
                NextToken=connectInstanceDetails['queueList']['NextToken']
            )            
            
            queueSummaryList.extend(connectInstanceDetails['queueList']['QueueSummaryList'])
        
        connectInstanceDetails['queueList']['QueueSummaryList'] = queueSummaryList
            
        for queue in connectInstanceDetails['queueList']['QueueSummaryList']:
            if queue['Name'] == 'OutboundQueue':
                connectInstanceDetails['outboundQueueID'] = queue['Id']
    
        #GET OUTBOUND PHONE NUMBER FROM OUTBOUND QUEUE
        response = connectClient.describe_queue(
            InstanceId=connectInstanceDetails['instanceID'],
            QueueId=connectInstanceDetails['outboundQueueID']
        )
        connectInstanceDetails['outboundPhoneNumber'] = response['Queue']['OutboundCallerConfig']['OutboundCallerIdNumberId']
        
        contactFlowList = connectClient.list_contact_flows(
            InstanceId=connectInstanceDetails['instanceID'],
            ContactFlowTypes=['CONTACT_FLOW','OUTBOUND_WHISPER','QUEUE_TRANSFER', 'AGENT_TRANSFER'],
            MaxResults=100
        )
        
        for flow in contactFlowList['ContactFlowSummaryList']:
            if flow['Name'] == 'Connect-RDF-Main':
                connectInstanceDetails['mainFlowID'] = flow['Id']
            if flow['Name'] == 'Connect-RDF-Outbound':
                connectInstanceDetails['outboundFlowID'] = flow['Id']
            if flow['Name'] == 'Connect-RDF-Agent':
                connectInstanceDetails['agentQueueFlowID'] = flow['Id']
            if flow['Name'] == 'Default agent transfer':
                connectInstanceDetails['agentTransferFlowID'] = flow['Id']
                
        hoursList = connectClient.list_hours_of_operations(
            InstanceId=connectInstanceDetails['instanceID'],
            MaxResults=1
        )
        
        connectInstanceDetails['hoursOfOperationsID'] = hoursList['HoursOfOperationSummaryList'][0]['Id']
    
        #response = client.list_accounts()
        #results = response["Accounts"]
        #while "NextToken" in response:
        #    response = client.list_accounts(NextToken=response["NextToken"])
        #    results.extend(response["Accounts"])
    
        #GET AGENTS - NEED TO USE TOKEN SINCE RESULTS CAN BE > 1000
        connectInstanceDetails['agentList'] = connectClient.list_users(
            InstanceId=connectInstanceDetails['instanceID'],
            #NextToken='string',
            MaxResults=100
        )
    
        UserSummaryList = connectInstanceDetails['agentList']['UserSummaryList']
    
        while "NextToken" in connectInstanceDetails['agentList']:
            connectInstanceDetails['agentList'] = connectClient.list_users(
                InstanceId=connectInstanceDetails['instanceID'],
                NextToken=connectInstanceDetails['agentList']["NextToken"],
                MaxResults=100
            ) 
            UserSummaryList.extend(connectInstanceDetails['agentList']['UserSummaryList'])
    
        connectInstanceDetails['agentList']['UserSummaryList'] = UserSummaryList
        
        #Get Security Profiles
        connectInstanceDetails['securityProfileList'] = connectClient.list_security_profiles(
            InstanceId=connectInstanceDetails['instanceID'],
            MaxResults=10
        ) 
    
        #Get Routing Profiles
        connectInstanceDetails['routingProfileList'] = connectClient.list_routing_profiles(
            InstanceId=connectInstanceDetails['instanceID'],
            #NextToken='string',
            MaxResults=1000
        )    
    
        RoutingProfileSummaryList = connectInstanceDetails['routingProfileList']['RoutingProfileSummaryList']
        
        while "NextToken" in connectInstanceDetails['routingProfileList']:
            connectInstanceDetails['routingProfileList'] = connectClient.list_routing_profiles(
                InstanceId=connectInstanceDetails['instanceID'],
                NextToken=connectInstanceDetails['routingProfileList']['NextToken'],
                MaxResults=1000
            ) 
            RoutingProfileSummaryList.extend(connectInstanceDetails['routingProfileList']['RoutingProfileSummaryList'])
        
        connectInstanceDetails['routingProfileList']['RoutingProfileSummaryList'] = RoutingProfileSummaryList
        
        #Get Quick Connects
    
        connectInstanceDetails['quickConnectList']  = connectClient.list_quick_connects(
            InstanceId=connectInstanceDetails['instanceID'],
            #NextToken='string',
            MaxResults=1000,
            QuickConnectTypes=['QUEUE', 'USER', 'PHONE_NUMBER']
        )
        
        QuickConnectSummaryList = connectInstanceDetails['quickConnectList']['QuickConnectSummaryList']
        
        while "NextToken" in connectInstanceDetails['quickConnectList']:
            connectInstanceDetails['quickConnectList'] = connectClient.list_quick_connects(
                InstanceId=connectInstanceDetails['instanceID'],
                NextToken=connectInstanceDetails['quickConnectList']["NextToken"],
                MaxResults=1000,
                QuickConnectTypes=['QUEUE', 'USER', 'PHONE_NUMBER']
            ) 
            QuickConnectSummaryList.extend(connectInstanceDetails['quickConnectList']['QuickConnectSummaryList'])
        
        connectInstanceDetails['quickConnectList']['QuickConnectSummaryList'] = QuickConnectSummaryList
    except Exception as ex1:
        print('#####   getConnectInstanceDetails EXCEPTION FOUND: ' + str(ex1) + '   #####')
    
    return(connectInstanceDetails)

def getQueueID(queueList, queueName):
    queueID = 'NOT FOUND'
    for queue in queueList['QueueSummaryList']:
        if queue['Name'] == queueName:
            queueID = queue['Id']
    
    return(queueID)
    
def getUserID(userList, userName):
    userID = 'NOT FOUND'
    for user in userList['UserSummaryList']:
        if user['Username'] == userName:
            userID = user['Id']
    
    return(userID)

def getRoutingProfileID(routingProfileList, routingProfileName):
    for routingProfile in routingProfileList['RoutingProfileSummaryList']:
        if routingProfile['Name'] == routingProfileName:
            routingProfileID = routingProfile['Id']

    return(routingProfileID)

def getQuickConnectID(quickConnectList, qcName):
    qcID = 'NOT FOUND'
    for quickConnect in quickConnectList['QuickConnectSummaryList']:
        if quickConnect['Name'] == qcName:
            qcID = quickConnect['Id']
            
    return(qcID)
                                
def getSecurityProfiles(securityProfileList, role):
    #activeProfiles = {'Admin':'admin','CallCenterManager': 'Supervisor', 'Agent':'Agent', 'QualityAnalyst':'NotApplicable'}
    activeProfiles = {'Admin':['admin'],'CallCenterManager': ['Supervisor', 'supervisor', 'wfo.full_access', 'wfo.access'], 'Agent':['Agent'], 'QualityAnalyst':['NotApplicable']}
    securityProfiles = []
    for profile in securityProfileList['SecurityProfileSummaryList']: #profile = [{'Name':'CallCenterManager', 'Id':'XXX'}, {'Name':'Admin', 'Id':'XXX'}, {'Name':'Agent', 'Id':'XXX'}]
        for i in role: # i = ['Agent', 'Supervisor']
            #if i == activeProfiles[profile['Name']]:
            if i['S'] in activeProfiles[profile['Name']] and profile['Id'] not in securityProfiles:
                securityProfiles.append(profile['Id'])
    
    return(securityProfiles)

def getQueueConfig(queueID, channel):
    queueReference = {}
    queueReference['QueueId'] = queueID
    queueReference['Channel'] = channel
    queueConfig={}
    queueConfig['QueueReference'] = queueReference
    queueConfig['Priority'] = 1
    queueConfig['Delay'] = 0

    return(queueConfig)

def readCSV(fileName, key, key2):
    data = {}
    s3Resource = boto3.resource('s3')
    contentObject = s3Resource.Object(config.s3BucketName, fileName)
    fileContent = contentObject.get()['Body'].read().decode('utf-8-sig').splitlines()
    csvReader = csv.DictReader(fileContent)

    for rows in csvReader:
        if key2:
            record = rows[key] + 'GEN' + rows[key2]
        else:
            record = rows[key]
            
        if rows['UPDATE'] == 'Y':
            data[record] = rows

    return(data)

def readJSON(fileName):
    #data = []
    s3Resource = boto3.resource('s3')
    contentObject = s3Resource.Object(config.s3BucketName, fileName)
    data = json.loads(contentObject.get()['Body'].read())
    
    return(data)

def logError(error):
    print(error)
    s3Resource = boto3.resource('s3')
    s3Resource.Object(config.s3BucketName, 'log/AgentSync.log').put(Body=error)

def getAgents():
    agentList = {}
    
    try:
        dynamodb_client = boto3.client('dynamodb')
        response = dynamodb_client.scan(TableName='Agents')

        for item in response['Items']:
            agentList[item['email']['S']] = {}
            agentList[item['email']['S']]['name'] = item['name']['S']
            agentList[item['email']['S']]['priority'] = item['priority']['M']
            agentList[item['email']['S']]['role'] = item['role']['L']

    except Exception as ex1:
        print('#####   READ AGENT LIST EXCEPTION FOUND: ' + str(ex1) + '   #####')
    
    return(agentList)

def create_random_suffix(length):
    random_suffix = ''
    char_list = ''
    char_list += string.ascii_lowercase
    char_list += string.digits

    for i in range(length):
        random_suffix += random.choice(char_list)

    return random_suffix  