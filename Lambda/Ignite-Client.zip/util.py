import json
import boto3
import csv
import config
from time import sleep
import string
import random
import os
import sys
import logger
import instances

def get_client(client_type, role_credentials):
    boto3_client = boto3.client(client_type, region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])   

    return boto3_client

def get_resource(resource_type, role_credentials):
    boto3_resource = boto3.resource(resource_type, region_name=config.region,
        aws_access_key_id=role_credentials['KEY_ID'],
        aws_secret_access_key=role_credentials['ACCESS_KEY'],
        aws_session_token=role_credentials['TOKEN'])   

    return boto3_resource

def assume_role(account_id):
    role_credentials = {}

    wait_counter = 0
    sts_client = boto3.client('sts')
    while(wait_counter <= 3):
        try:
            sts_session = sts_client.assume_role(RoleArn='arn:aws:iam::' + account_id + ':role/Ignite-Client',
                                            RoleSessionName='initialization-session')
            
            role_credentials['KEY_ID'] = sts_session['Credentials']['AccessKeyId']
            role_credentials['ACCESS_KEY'] = sts_session['Credentials']['SecretAccessKey']
            role_credentials['TOKEN'] = sts_session['Credentials']['SessionToken']
            break
        except Exception as Ex1:
            logger.info('WAITING FOR ACCOUNT SERVICES TO BE READY')
            wait_counter += 1
            sleep(30)
            pass
    else:
        logger.info("UNABLE TO ASSUME Ignite-Client ROLE.  PLEASE TRY AGAIN.")
        sys.exit(1)
    
    return(role_credentials)

def get_instance_config(ou, tenant_id):
    if config.region == os.environ['BCP_REGION']:
        tenant_name = 'bcp' + os.environ['ORGANIZATION_NAME'] + '-' + tenant_id
    else:
        tenant_name = ou.lower() + os.environ['ORGANIZATION_NAME'] + '-' + tenant_id

    dynamodb_client = boto3.client('dynamodb', region_name=config.region)
    account_id = ''

    try:
        get_instance_config_response = dynamodb_client.get_item(
            TableName='Instances-' + ou,
            Key={
                'Tenant': {'S': tenant_name}
            }
        )
        
        account_id = get_instance_config_response['Item']['AccountID']['S']
        connect_arn = get_instance_config_response['Item']['InstanceARN']['S']
        connect_id = connect_arn.split(":")[5][connect_arn.split(":")[5].find('/')+1:]

    except Exception as Ex1:
        logger.info("get_instance_config EXCEPTION: " + str(Ex1))

    return (account_id, connect_id, connect_arn, tenant_name)

def get_connect_instance_details(connect_client, connect_id):
    connect_instance_details = {}
    
    try:
        response = connect_client.list_instances(
            MaxResults=6
        )
        for instance in response['InstanceSummaryList']:
            if instance['Id'] == connect_id:
                connect_instance_details['instanceID'] = instance['Id']
                connect_instance_details['instanceARN'] = instance['Arn']

        contact_flow_list = connect_client.list_contact_flows(
            InstanceId=connect_instance_details['instanceID'],
            ContactFlowTypes=['CONTACT_FLOW','OUTBOUND_WHISPER','QUEUE_TRANSFER', 'AGENT_TRANSFER'],
            MaxResults=100
        )
        # GET CONTACT FLOW ID's
        for flow in contact_flow_list['ContactFlowSummaryList']:
            if flow['Name'] == 'Connect-RDF-Main':
                connect_instance_details['mainFlowID'] = flow['Id']
            if flow['Name'] == 'Connect-RDF-Outbound':
                connect_instance_details['outboundFlowID'] = flow['Id']
            if flow['Name'] == 'Connect-RDF-Agent':
                connect_instance_details['agentQueueFlowID'] = flow['Id']
            if flow['Name'] == 'Default agent transfer':
                connect_instance_details['agentTransferFlowID'] = flow['Id']
            if flow['Name'] == 'Default queue transfer':
                connect_instance_details['queueTransferFlowID'] = flow['Id']                

        # GET QUEUES
        connect_instance_details['QueueSummaryList'] = get_queue_summary_list(connect_client, connect_instance_details['instanceID'])
        for queue in connect_instance_details['QueueSummaryList']:
            if queue['Name'] == 'BasicQueue':
                connect_instance_details['DefaultOutboundQueueId'] = queue['QueueId']

        #GET AGENTS - NEED TO USE TOKEN SINCE RESULTS CAN BE > 1000
        connect_instance_details['userList'] = connect_client.list_users(
            InstanceId=connect_instance_details['instanceID'],
            MaxResults=100
        )
    
        user_summary_list = connect_instance_details['userList']['UserSummaryList']
    
        while "NextToken" in connect_instance_details['userList']:
            connect_instance_details['userList'] = connect_client.list_users(
                InstanceId=connect_instance_details['instanceID'],
                NextToken=connect_instance_details['userList']["NextToken"],
                MaxResults=100
            ) 
            user_summary_list.extend(connect_instance_details['userList']['UserSummaryList'])
    
        connect_instance_details['userList']['UserSummaryList'] = user_summary_list
        
        #Get Security Profiles
        connect_instance_details['securityProfileList'] = connect_client.list_security_profiles(
            InstanceId=connect_instance_details['instanceID'],
            MaxResults=10
        ) 
    
        #Get Routing Profiles
        connect_instance_details['routingProfileList'] = connect_client.list_routing_profiles(
            InstanceId=connect_instance_details['instanceID'],
            MaxResults=1000
        )    
    
        routing_summary_list = connect_instance_details['routingProfileList']['RoutingProfileSummaryList']
        
        while "NextToken" in connect_instance_details['routingProfileList']:
            connect_instance_details['routingProfileList'] = connect_client.list_routing_profiles(
                InstanceId=connect_instance_details['instanceID'],
                NextToken=connect_instance_details['routingProfileList']['NextToken'],
                MaxResults=1000
            ) 
            routing_summary_list.extend(connect_instance_details['routingProfileList']['RoutingProfileSummaryList'])
        
        connect_instance_details['routingProfileList']['RoutingProfileSummaryList'] = routing_summary_list
        
        #Get Quick Connects
    
        connect_instance_details['quickConnectList']  = connect_client.list_quick_connects(
            InstanceId=connect_instance_details['instanceID'],
            MaxResults=1000,
            QuickConnectTypes=['QUEUE', 'USER', 'PHONE_NUMBER']
        )
        
        quick_connect_summary_list = connect_instance_details['quickConnectList']['QuickConnectSummaryList']
        
        while "NextToken" in connect_instance_details['quickConnectList']:
            connect_instance_details['quickConnectList'] = connect_client.list_quick_connects(
                InstanceId=connect_instance_details['instanceID'],
                NextToken=connect_instance_details['quickConnectList']["NextToken"],
                MaxResults=1000,
                QuickConnectTypes=['QUEUE', 'USER', 'PHONE_NUMBER']
            ) 
            quick_connect_summary_list.extend(connect_instance_details['quickConnectList']['QuickConnectSummaryList'])
        
        connect_instance_details['quickConnectList']['QuickConnectSummaryList'] = quick_connect_summary_list

        connect_instance_details['business_hours_id'] = get_business_hours_id(connect_client, connect_instance_details['instanceID'])

    except Exception as ex1:
        logger.info('get_connect_instance_details EXCEPTION FOUND: ' + str(ex1))

    return(connect_instance_details)

def get_business_hours_id(connect_client, instance_id):
    list_hours_response = connect_client.list_hours_of_operations(
        InstanceId=instance_id
    )

    for hours in list_hours_response['HoursOfOperationSummaryList']:
        if hours['Name'] == 'Basic Hours':
            business_hours_id = hours['Id']
    
    return business_hours_id

def get_queue_summary_list(connect_client, instance_id):
    queue_list = connect_client.search_queues(
        InstanceId = instance_id,
        MaxResults=100
    )

    queue_summary_list = queue_list['Queues']
    
    while "NextToken" in queue_list:
        queue_list = connect_client.search_queues(
            InstanceId = instance_id,
            MaxResults=100,
            NextToken=queue_list['NextToken']
        )            
        
        queue_summary_list.extend(queue_list['Queues'])

    return queue_summary_list

def get_queue_id(queue_list, queueName):
    queue_id = 'NOT FOUND'
    for queue in queue_list:
        if queue['Name'] == queueName:
            queue_id = queue['QueueId']
    
    return(queue_id)

def get_queue_tags(queue_list, queueName):
    callBack = 'off'
    voiceMail = 'off'
    for queue in queue_list:
        if queue['Name'] == queueName:
            callBack = queue['Tags'].get('CallBack', 'off')
            voiceMail = queue['Tags'].get('VoiceMail', 'off')
    
    return(callBack, voiceMail)
        
def get_user_id(user_list, user_name):
    user_id = 'NOT FOUND'
    for user in user_list['UserSummaryList']:
        if user['Username'] == user_name:
            user_id = user['Id']
    
    return(user_id)

def get_routing_profile_id(routing_profile_list, routing_profile_name):
    for routing_profile in routing_profile_list['RoutingProfileSummaryList']:
        if routing_profile['Name'] == routing_profile_name:
            routing_profile_id = routing_profile['Id']

    return(routing_profile_id)

def get_quick_connect_id(quick_connect_list, qc_name):
    qc_id = 'NOT FOUND'
    for quick_connect in quick_connect_list['QuickConnectSummaryList']:
        if quick_connect['Name'] == qc_name:
            qc_id = quick_connect['Id']
            
    return(qc_id)

def get_quick_connect_name(connect_client, connect_id, quick_connect_list, qc_id):
    qc_name = 'NOT FOUND'
    get_qc_list_response = connect_client.list_quick_connects(
        InstanceId=connect_id,
        QuickConnectTypes=['QUEUE']
    )

    for qc in get_qc_list_response['QuickConnectSummaryList']:
        if qc_id == qc['Id']:
            qc_name = qc['Name']
            
    return(qc_name)

def get_security_profiles(security_profile_list, role):
    security_profiles = []
    for profile in security_profile_list['SecurityProfileSummaryList']: #profile = [{'Name':'CallCenterManager', 'Id':'XXX'}, {'Name':'Admin', 'Id':'XXX'}, {'Name':'Agent', 'Id':'XXX'}]
        for i in role: # i = ['Agent', 'Supervisor']
            if i == profile['Name']:
                security_profiles.append(profile['Id'])
    
    return(security_profiles)

def get_queue_config(queue_id, channel, priority):
    queue_reference = {}
    queue_reference['QueueId'] = queue_id
    queue_reference['Channel'] = channel
    queue_config={}
    queue_config['QueueReference'] = queue_reference
    queue_config['Priority'] = priority
    queue_config['Delay'] = 0

    return(queue_config)

def read_csv(fileName, key, key2):
    data = {}
    s3_resource = boto3.resource('s3')
    content_object = s3_resource.Object(config.s3BucketName, fileName)
    file_content = content_object.get()['Body'].read().decode('utf-8-sig').splitlines()
    csv_reader = csv.DictReader(file_content)

    for rows in csv_reader:
        if key2:
            record = rows[key] + rows[key2]
        else:
            record = rows[key]
            
        if rows['UPDATE'] == 'Y':
            data[record] = rows

    return(data)

def read_json(fileName):
    #data = []
    s3_resource = boto3.resource('s3')
    content_object = s3_resource.Object(config.s3BucketName, fileName)
    data = json.loads(content_object.get()['Body'].read())
    
    return(data)

def log_error(error):
    print(error)
    s3_resource = boto3.resource('s3')
    s3_resource.Object(config.s3BucketName, 'log/AgentSync.log').put(Body=error)

def get_users():
    user_list = {}
    
    try:
        dynamodb_client = boto3.client('dynamodb')
        response = dynamodb_client.scan(TableName='Agents')

        for item in response['Items']:
            user_list[item['Email']['S']] = {}
            user_list[item['Email']['S']]['Name'] = item['Name']['S']
            user_list[item['Email']['S']]['Skill'] = item['Skill']['M']
            user_list[item['Email']['S']]['Role'] = item['Role']['L']

    except Exception as ex1:
        logger.info('get_users EXCEPTION: ' + str(ex1))
    
    return(user_list)

def create_random_suffix(length):
    random_suffix = ''
    char_list = ''
    char_list += string.ascii_lowercase
    char_list += string.digits

    for i in range(length):
        random_suffix += random.choice(char_list)

    return random_suffix  

def translate_text(text_string, source_language, target_language):
    translate_client = boto3.client('translate', region_name=config.region)    
    translated_text = ''

    try:
        if text_string:
            translation_response = translate_client.translate_text(
                Text=text_string,
                SourceLanguageCode=source_language,
                TargetLanguageCode=target_language

            )
            translated_text = translation_response['TranslatedText']

    except Exception as ex1:
        logger.info('translate_text EXCEPTION: ' + str(ex1))
    
    return translated_text

def get_callflows(s3_client, connect_id):
    list_of_s3_objects_response=''
    callflow_list = []

    try:
        list_of_s3_buckets_response = s3_client.list_buckets()

        for bucket in list_of_s3_buckets_response['Buckets']:
            if "amazon-connect-" + connect_id in bucket['Name']:
                
                list_of_s3_objects_response = s3_client.list_objects(
                    Bucket=bucket['Name'],
                    Prefix="shared/"
                )
                
                for callflow in list_of_s3_objects_response['Contents']:
                    if '-callflow' in callflow['Key']:
                        callflow['Key'] = callflow['Key'][callflow['Key'].find('/')+1:callflow['Key'].find('-callflow.csv')]
                        callflow_list.append(callflow['Key'][callflow['Key'].find('/')+1:])

    except Exception as Ex1:
        logger.info("get_callflows EXCEPTION: " + str(Ex1))

    return callflow_list

def get_queues(connect_client, connect_id):
    queues_list = []
    list_queues_response = get_queue_summary_list(connect_client, connect_id)

    for queue in list_queues_response:
        queues_list.append(queue['Name'])
        
    return queues_list

def get_app_id(tenant_app):
    return tenant_app[tenant_app.find('-')+1:]

def get_tenant_id(tenant_app):
    return tenant_app[0:tenant_app.find('-')]

def get_tenant_from_account(account_id):
    organizational_units = ['DEV', 'UAT', 'PROD']
    user_list = {}
    
    try:
        for ou in organizational_units:
            dynamodb_client = boto3.client('dynamodb', region_name=config.region)
            response = dynamodb_client.scan(TableName='Instances-' + ou)

            for item in response['Items']:
                if item['AccountID']['S'] == account_id:
                    tenant_key = item['Tenant']['S'][item['Tenant']['S'].find('-')+1:]
                    env = item['Tenant']['S'][0:3].upper()

    except Exception as ex1:
        logger.info('get_tenant_from_account EXCEPTION: ' + str(ex1))
    
    return(env, tenant_key)

def chunk_list(data, chunk_size):
    """Yield successive chunks from the list."""
    for i in range(0, len(data), chunk_size):
        yield data[i:i + chunk_size]

def convert(raw_data):
    converted_data = {}
    for item in raw_data.split("|"):
        key, _, value = item.partition(":")
        converted_data[key] = value
    return converted_data

def get_flow_control_item(ou, tenant_id, app_id, flow_item):
    dynamodb_client = boto3.client('dynamodb', region_name=config.region)
    flow_value = ''
    tenant_key = f"{tenant_id}-{app_id}"
    languages, _ = instances.get_languages(ou, tenant_id)

    try:
        get_item_response = dynamodb_client.get_item(TableName=f"Tenants-{ou}", Key={"Tenant": {'S': tenant_key}, "Language": {'S': json.dumps(languages)}})

        flow_control = json.loads(get_item_response['Item']['FlowControl']['S'])
        for flow_index in flow_control:
            if next(iter(flow_control[flow_index])) == flow_item:
                flow_value = flow_control[flow_index][flow_item]
    except Exception as ex1:
        logger.info('get_flow_control_item EXCEPTION: ' + str(ex1))
        pass

    return flow_value

def get_queue_data(ou, tenant_id):
    queue_data = {}
    table = boto3.resource('dynamodb').Table(f"Instances-{ou}")

    tenant_key = f"{ou.lower()}{os.environ['ORGANIZATION_NAME']}-{tenant_id}"
    get_item_response = table.get_item(Key={'Tenant': tenant_key})
    if 'Item' in get_item_response:
        queue_data = json.loads(get_item_response['Item'].get('QueueData', '{}'))

    return queue_data    

def get_queues_to_update(connect_instance_details):
    queues_to_update = {"VoiceQueues":[], "EmailQueues": [], "ToDoQueues": [], "External":[]}

    for queue_found in connect_instance_details['QueueSummaryList']:
        queue_name = queue_found['Name']
        queue_id = queue_found['QueueId']
        if '- Email' not in queue_name and '- ToDo' not in queue_name:
            queues_to_update['VoiceQueues'].append(queue_id)
        if '- ToDo' in queue_name:
            queues_to_update['ToDoQueues'].append(queue_id)
        if '- Email' in queue_name:
            queues_to_update['EmailQueues'].append(queue_id)
    
    return queues_to_update

def get_quick_connects_to_update(connect_instance_details):
    quick_connects_to_update = {"VoiceQueues":[], "EmailQueues": [], "ToDoQueues": [], "External": []}

    for qc_found in connect_instance_details['quickConnectList']['QuickConnectSummaryList']:
        qc_name = qc_found['Name']
        qc_id = qc_found['Id']
        if '- Email' not in qc_name and '- ToDo' not in qc_name:
            quick_connects_to_update['VoiceQueues'].append(qc_id)
        if '- ToDo' in qc_name:
            quick_connects_to_update['ToDoQueues'].append(qc_id)
        if '- Email' in qc_name:
            quick_connects_to_update['EmailQueues'].append(qc_id)
    
    return quick_connects_to_update


